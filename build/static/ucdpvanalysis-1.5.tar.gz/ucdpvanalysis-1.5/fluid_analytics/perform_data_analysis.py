"""
perform_data_analysis
~~~~~~~~~~~~~~~~~~~~~

A helper script for analytics.py. Runs functions from there in a comprehensible way
so that we can understand at a high level what is happening.
"""
import argparse
from StringIO import StringIO

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from analytics import BloodPressureAnalysis, BolusAnalytics, VentAnalytics
from algorithms.breath_meta import get_production_breath_meta
from algorithms.raw_utils import pos_neg_flow_bs_be_denoting_extractor


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('data_file')
    parser.add_argument('-l', '--load-vent-data', help="load vent data and don't attempt to reprocess it", action='store_true')
    args = parser.parse_args()

    if not args.data_file.endswith(".csv"):
        raise Exception('Input a CSV file')
    df = pd.read_csv(args.data_file)
    bp = BloodPressureAnalysis(df, 2)
    bp.mark_pulses_with_wabp()
    bp_features = bp.derive_all_features()
    vent = VentAnalytics()
    vent.process_vent_data_from_cif(df)
    vent_features = vent.analyze_all_breath_meta()
    bolus = BolusAnalytics(df)
    bp_features = bolus.align_frame_with_microboluses(bp_features, 'beat_start_time')
    bp_features = bolus.align_frame_with_macroboluses(bp_features, 'beat_start_time')
    vent_features = bolus.align_frame_with_microboluses(vent_features, 'bs_time')
    vent_features = bolus.align_frame_with_macroboluses(vent_features, 'bs_time')
    microbol_analytics = bolus.perform_microbolus_analytics()
    macrobol_analytics = bolus.perform_macrobolus_analytics()
    microbol_analytics = bolus.add_heart_rate_to_bolus_analytics(microbol_analytics, bp_features, 'microbolus_num')
    macrobol_analytics = bolus.add_heart_rate_to_bolus_analytics(macrobol_analytics, bp_features, 'macrobolus_num')

    ax1 = plt.subplot(4, 1, 1)
    plt.plot(macrobol_analytics.bolus_num, macrobol_analytics.mean_co, '.-')
    plt.ylabel('Cardiac Output')
    plt.subplot(4, 1, 2, sharex=ax1)
    plt.plot(macrobol_analytics.bolus_num, macrobol_analytics.mean_heart_rate, '.-')
    plt.ylabel('Heart Rate')
    plt.subplot(4, 1, 3, sharex=ax1)
    plt.plot(macrobol_analytics.bolus_num, macrobol_analytics.mean_stroke_vol, '.-')
    plt.ylabel('Stroke Volume')
    plt.subplot(4, 1, 4, sharex=ax1)
    plt.plot(macrobol_analytics.bolus_num, macrobol_analytics.mean_abp, '.-')
    plt.ylabel('ABP')
    plt.suptitle('Macrobolus Metrics By Bolus')
    plt.show()

    sns.lmplot(data=macrobol_analytics, x='mean_abp', y='mean_co')
    plt.ylim(0, max(macrobol_analytics.mean_co)+1000)
    plt.title('Blood Pressure v. Cardiac Output')
    plt.show()

    sns.jointplot(x='mean_stroke_vol', y='mean_heart_rate', data=macrobol_analytics)
    plt.suptitle('Stroke Volume v. Heart Rate')
    plt.show()

    ax1 = plt.subplot(4, 1, 1)
    plt.plot(microbol_analytics.bolus_num, microbol_analytics.mean_co, '.-')
    plt.ylabel('Cardiac Output')
    plt.subplot(4, 1, 2, sharex=ax1)
    plt.plot(microbol_analytics.bolus_num, microbol_analytics.mean_heart_rate, '.-')
    plt.ylabel('Heart Rate')
    plt.subplot(4, 1, 3, sharex=ax1)
    plt.plot(microbol_analytics.bolus_num, microbol_analytics.mean_stroke_vol, '.-')
    plt.ylabel('Stroke Volume')
    plt.subplot(4, 1, 4, sharex=ax1)
    plt.plot(microbol_analytics.bolus_num, microbol_analytics.mean_abp, '.-')
    plt.ylabel('ABP')
    plt.suptitle('Microbolus Metrics By Bolus')
    plt.show()

    sns.lmplot(data=microbol_analytics, x='mean_abp', y='mean_co')
    plt.ylim(0, max(microbol_analytics.mean_co)+1000)
    plt.title('Blood Pressure v. Cardiac Output')
    plt.show()

    sns.jointplot(x='mean_stroke_vol', y='mean_heart_rate', data=microbol_analytics)
    plt.suptitle('Stroke Volume v. Heart Rate')
    plt.show()

    # Lower level feature visualization
    f, ax = plt.subplots(3, 1, sharex=True)
    sns.relplot(x='beat_num', y='cvp_mean', data=bp_features, ax=ax[0], kind='line', hue='macrobolus_num')
    sns.relplot(x='beat_num', y='abp_mean', data=bp_features, hue='macrobolus_num', kind='line', ax=ax[1])
    sns.relplot(x='beat_num', y='heart_rate', data=bp_features, hue='macrobolus_num', kind='line', ax=ax[2])
    plt.suptitle('BP features over time.')
    plt.show()

    sns.pairplot(bp_features[['abp_mean', 'cvp_mean', 'heart_rate']].dropna())
    plt.suptitle('Cardio Features and Relation To Each Other')
    plt.show()

    f, ax = plt.subplots(4, 1, sharex=True)
    sns.relplot(x='rel_bn', y='tvi', data=vent_features, ax=ax[0], kind='line', hue='macrobolus_num')
    sns.relplot(x='rel_bn', y='tve', data=vent_features, hue='macrobolus_num', kind='line', ax=ax[1])
    sns.relplot(x='rel_bn', y='tv_ratio', data=vent_features, hue='macrobolus_num', kind='line', ax=ax[2])
    sns.relplot(x='rel_bn', y='i_time', data=vent_features, hue='macrobolus_num', kind='line', ax=ax[3])
    plt.suptitle('Vent features over time')
    plt.show()

    sns.pairplot(vent_features.iloc[:, 2:-2].dropna())
    plt.show()


if __name__ == "__main__":
    main()
