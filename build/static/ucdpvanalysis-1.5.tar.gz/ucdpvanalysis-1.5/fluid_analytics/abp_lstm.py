"""
abp_lstm
~~~~~~~~

LSTM for detecting ABP beats
"""
from __future__ import print_function
import argparse

import numpy as np
from sklearn.metrics import classification_report
import torch
from torch import nn
from torch.autograd import Variable
from torch.optim import Adam, SGD
from torch.utils.data import DataLoader

from dataset import PhysioNetABPData


class LSTMClassifier(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers):
        super(LSTMClassifier, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers=num_layers, batch_first=True)
        self.classifier = nn.Linear(hidden_size, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, input, hidden=None):
        out, (hn, cn) = self.lstm(input, hidden)
        out = self.classifier(out)
        return self.sigmoid(out), hidden


def build_parser():
    parser = argparse.ArgumentParser()
    # dataset options
    parser.add_argument('-d', '--dir', default='data/physionet2014/training1/')
    parser.add_argument('-tr', '--train-file', default='physionet_train_initial.txt')
    parser.add_argument('-te', '--test-file', default='physionet_test_initial.txt')
    parser.add_argument('-c', '--chunksize', type=int, default=300)

    # training options
    parser.add_argument('--batch-size', default=32, type=int)
    parser.add_argument('--epochs', default=20, type=int)
    parser.add_argument('--cuda', action='store_true', help='run on gpu')
    parser.add_argument('--no-shuffle', action='store_false')
    parser.add_argument('-lr', '--learning-rate', type=float, default=.01)

    # model options
    parser.add_argument('-l', '--load-saved-model')
    parser.add_argument('--hidden-size', type=int, default=32)
    parser.add_argument('-n', '--num-layers', type=int, default=1)
    return parser


def main():
    args = build_parser().parse_args()

    cuda_wrapper = lambda x: x.cuda() if args.cuda else x
    to_cpu_wrapper = lambda x: x.cpu() if args.cuda else x

    input_size = 1

    criterion = nn.BCELoss()
    if args.load_saved_model:
        model = cuda_wrapper(torch.load(args.load_saved_model))
    else:
        model = cuda_wrapper(LSTMClassifier(input_size, args.hidden_size, args.num_layers))
    optimizer = Adam(model.parameters(), lr=args.learning_rate)
    model.train()
    train_loss = []

    train_dataset = PhysioNetABPData(args.dir, args.train_file, args.chunksize)
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=args.no_shuffle)

    with torch.enable_grad():
        for ep in range(args.epochs):
            hidden = None
            for idx, (seq, labels) in enumerate(train_loader):
                model.zero_grad()
                optimizer.zero_grad()
                labels = cuda_wrapper(Variable(labels))
                seq = cuda_wrapper(Variable(seq))
                if args.no_shuffle:
                    pred, hidden = model(seq)
                else:
                    pred, hidden = model(seq, hidden)
                loss = criterion(pred, labels)
                loss.backward()
                optimizer.step()
                train_loss.append(float(to_cpu_wrapper(loss).detach().numpy()))
                print("epoch {}/{} batch {}/{}, av loss: {}\r".format(ep+1, args.epochs, idx, len(train_loader), round(np.mean(train_loss), 4)), end="")

    test_dataset = PhysioNetABPData(args.dir, args.test_file, args.chunksize)
    test_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)

    model.eval()
    preds = None
    gt = None
    hidden = None

    with torch.no_grad():
        for idx, (seq, labels) in enumerate(test_loader):
            labels = cuda_wrapper(Variable(labels.long()))
            seq = cuda_wrapper(Variable(seq))
            if args.no_shuffle:
                pred, hidden = model(seq)
            else:
                pred, hidden = model(seq, hidden)

            if preds is None:
                preds = pred
                gt = labels
            else:
                preds = torch.cat((preds, pred))
                gt = torch.cat((gt, labels))

    preds = preds.view(-1).round().cpu().numpy()
    gt = gt.view(-1).cpu().numpy()
    print(classification_report(gt, preds, digits=4))
    save_me = raw_input('Should we save this model? [y/n]')
    if save_me == 'y':
        torch.save(model, 'lstm-shuffle{}.pth'.format(args.no_shuffle))


if __name__ == "__main__":
    main()
