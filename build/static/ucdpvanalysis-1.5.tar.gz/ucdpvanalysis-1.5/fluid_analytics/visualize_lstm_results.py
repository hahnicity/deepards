import argparse
from copy import copy
import os

import numpy as np
from prettytable import PrettyTable
from sklearn.metrics import classification_report
import torch
from torch.autograd import Variable
from torch.utils.data import DataLoader
from wfdb.io import rdsamp

from abp_lstm import LSTMClassifier
from analytics import ProximalPressureAnalysis
from dataset import ABPTestData, PhysioNetABPData


def perform_prediction_post_processing(preds, cluster_dist, cluster_min_size):
    """
    Each beat basically comes in a cluster of observations, so perform post
    processing to cluster predictions, while dropping clusters that are too
    small
    """
    idxs = [i for i, val in enumerate(preds) if val == 1]
    tmp_clusters = []
    final_clusters = []
    current_clust = set([idxs[0]])
    for pos_i, i in enumerate(idxs[1:]):
        if i - idxs[pos_i] <= cluster_dist:
            current_clust.add(i)
        else:
            if len(current_clust) >= cluster_min_size:
                tmp_clusters.append(current_clust)
            current_clust = set([i])

    for clust_idx, clust in enumerate(tmp_clusters):
        final_clust = list(clust)
        vals_to_add = []
        for idx, val in enumerate(final_clust[1:]):
            # fill in intermediate vals
            if val - final_clust[idx] > 1:
                for i in range(1, val - final_clust[idx]):
                    vals_to_add.append(final_clust[idx] + i)

        if len(vals_to_add) > 0:
            final_clust.extend(vals_to_add)
            final_clust = sorted(final_clust)
        final_clusters.append(final_clust)

    flattened = np.array([elem for clust in final_clusters for elem in clust])
    preds[flattened] = 1
    preds[list(set(range(len(preds))).difference(set(flattened)))] = 0
    return preds, final_clusters


def perform_raw_predictions(args, preds, gt):
    preds = (preds.view(-1) > args.confidence).cpu().numpy()
    preds, clusters = perform_prediction_post_processing(preds, args.cluster_dist, args.cluster_min_size)
    if gt is not None:
        gt = gt.view(-1).cpu().numpy()
        print(classification_report(gt, preds, digits=4))
    return preds, gt


def perform_diastolic_predictions(args, preds, gt):
    preds = (preds.view(-1) > args.confidence).cpu().numpy()
    preds, pred_clusters = perform_prediction_post_processing(preds, args.cluster_dist, args.cluster_min_size)
    pred_idx = [sorted(clust)[0] for clust in pred_clusters]
    preds = np.zeros(len(preds))
    preds[pred_idx] = 1
    if gt is not None:
        gt, gt_clusters = perform_prediction_post_processing(gt.view(-1).cpu().numpy(), 1, 5)
        gt_idx = [sorted(clust)[0] for clust in gt_clusters]
        gt = np.zeros(len(gt))
        gt[gt_idx] = 1
        time_series_iou(pred_idx, gt_idx)
    return preds, gt


def time_series_iou(pred_idxs, gt_idxs):
    diffs = [0, 1, 5, 10]
    gt_idxs = set(gt_idxs)
    table = PrettyTable()
    table.field_names = ['diff_thresh', 'prec', 'recall']
    for diff in diffs:
        fps = 0
        tps = 0
        fns = 0
        iter_gt = copy(gt_idxs)
        for pred in pred_idxs:
            for gt in iter_gt:
                if abs(pred - gt) <= diff:
                    iter_gt.remove(gt)
                    tps += 1
                    break
            else:
                fps += 1
        fns = len(iter_gt)
        precision = round((float(tps) / (tps + fps)), 4)
        recall = round((float(tps) / (tps + fns)), 4)
        table.add_row([diff, precision, recall])
    print(table)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('file')
    parser.add_argument('model')
    parser.add_argument('-t', '--viz-type', choices=['raw', 'diastolic-idx'], default='raw')
    parser.add_argument('--use-hidden', action='store_true')
    parser.add_argument('-c', '--chunksize', type=int, default=200)
    parser.add_argument('-b', '--batch-size', type=int, default=32)
    parser.add_argument('-cf', '--confidence', type=float, default=.6)
    parser.add_argument('-cd', '--cluster-dist', type=int, default=5)
    parser.add_argument('-cm', '--cluster-min-size', type=int, default=10)
    parser.add_argument('--cuda', action='store_true')
    parser.add_argument('--no-viz', action='store_true', help='dont output visualizations, just numeric results')
    parser.add_argument('--no-physionet', action='store_true')
    args = parser.parse_args()

    cuda_wrapper = lambda x: x.cuda() if args.cuda else x
    model = cuda_wrapper(torch.load(args.model))
    #is_cuda = model.lstm.all_weights[0][0].device.type == 'cuda'
    dir = os.path.dirname(args.file)
    if args.no_physionet:
        dataset = ABPTestData(dir, [os.path.basename(args.file)], args.chunksize)
    else:
        dataset = PhysioNetABPData(dir, [os.path.basename(args.file)], args.chunksize)
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False)
    model.eval()

    preds = None
    gt = None
    hidden = None

    with torch.no_grad():
        if args.no_physionet:
            for seq in loader:
                seq = cuda_wrapper(Variable(seq))
                if args.use_hidden:
                    pred, hidden = model(seq, hidden)
                else:
                    pred, hidden = model(seq)

                if preds is None:
                    preds = pred
                else:
                    preds = torch.cat((preds, pred))
        else:
            for idx, (seq, labels) in enumerate(loader):
                labels = cuda_wrapper(Variable(labels.long()))
                seq = cuda_wrapper(Variable(seq))
                if args.use_hidden:
                    pred, hidden = model(seq, hidden)
                else:
                    pred, hidden = model(seq)

                if preds is None:
                    preds = pred
                    gt = labels
                else:
                    preds = torch.cat((preds, pred))
                    gt = torch.cat((gt, labels))

    if args.viz_type == 'raw':
        preds, gt = perform_raw_predictions(args, preds, gt)
        dot_size = 2
    elif args.viz_type == 'diastolic-idx':
        preds, gt = perform_diastolic_predictions(args, preds, gt)
        dot_size = 5

    if not args.no_viz:
        signal, info = rdsamp(args.file)
        colnames = info['sig_name']
        if 'BP' in colnames:
            idx = colnames.index('BP')
        elif 'ABP' in colnames:
            idx = colnames.index('ABP')
        pressure = signal[:, idx]
        analysis = ProximalPressureAnalysis(pressure, 3)
        analysis.diastolic_idx = np.array([idx for idx, val in enumerate(preds.astype(int)) if val == 1])
        for i in range(0, len(analysis.pp), 3000):
            analysis.validate(i, i+3000, dot_size=dot_size)


if __name__ == "__main__":
    main()
