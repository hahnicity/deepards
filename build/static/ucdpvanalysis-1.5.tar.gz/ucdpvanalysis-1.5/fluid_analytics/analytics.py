from copy import copy
import os
from StringIO import StringIO
import subprocess
import sys

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.ndimage.filters import gaussian_filter1d
from wfdb.io import rdann, wrsamp

from algorithms.breath_meta import get_production_breath_meta
from algorithms.raw_utils import pos_neg_flow_bs_be_denoting_extractor


def filter_outliers(df, n, ignore_cols):
    if filter_outliers is not None:
        cols = set(df.columns).difference(set(ignore_cols))
        for col in cols:
            df.loc[(df[col] > df[col].mean() + n*df[col].std()) | (df[col] < df[col].mean() - n*df[col].std()), col] = np.nan
    return df


class BloodPressureAnalysis(object):
    def __init__(self, df, smoothing_factor, freq=100):
        self.pp = gaussian_filter1d(df.BP, smoothing_factor)
        self.cvp = df.CVP
        self.diastolic_idx = None
        self.freq = freq

    def _find_min_maxes(self):
        # This can be parameterized in the future
        width = 4
        min_maxes = []
        cur_pair = []
        for idx, val in enumerate(self.pp):
            if idx + width > len(self.pp) - 1:
                if len(cur_pair) == 1:
                    cur_pair.append(idx)
                    min_maxes.append(copy(cur_pair))
                break
            if self.pp[idx-width] > val < self.pp[idx+width] and len(cur_pair) == 0:
                cur_pair.append(idx)
            elif self.pp[idx-width] < val > self.pp[idx+width] and len(cur_pair) == 1:
                cur_pair.append(idx)
                min_maxes.append(copy(cur_pair))
                cur_pair = []
        return min_maxes

    def _find_diastolic_idx(self, start_idx, min_window_len, diastolic_cuttoff_thresh):
        """
        :param start_idx: Index near where we think the diastolic pressure is located
        :param min_window_len: Number of points to search forward for the diastolic pressure
        :param diastolic_cuttoff_thresh: If pressure goes above the minimum recorded, then cutoff search and revert to minimum
        """
        # XXX I kinda wanna do this so it searches out a min in ddx or a 0
        # crossing in dx
        idx_since_min = 0
        prev = self.pp[start_idx]
        min_idx = start_idx
        min_ = sys.maxint
        dx = [val - self.pp[start_idx+offset-1] for offset, val in enumerate(self.pp[start_idx+1:start_idx+300])]
        for idx_offset, press in enumerate(self.pp[start_idx+1:]):
            diff = press - prev
            if idx_offset + 2 > len(dx)-1:
                return None

            if diff >= 0:
                idx_since_min += 1
            #elif idx_offset > 2 and press < min_ and (dx[idx_offset-3] <= 0 and dx[idx_offset+3] >= 0):
            elif idx_offset > 1  and (dx[idx_offset-2] <= 0 and dx[idx_offset+2] >= 0) and press < min_:
                min_ = press
                idx_since_min = 0
                min_idx = start_idx + 1 + idx_offset

            if idx_since_min >= min_window_len:
                break

            if press - min_ > diastolic_cuttoff_thresh:
                break
            prev = press
        else:
            return None

        return min_idx

    def mark_pulses(self, diastolic_press_thresh, min_window_len):
        min_maxes = self._find_min_maxes()
        diastolic_idx = []
        for min_max in min_maxes:
            time_diff = min_max[1] - min_max[0]
            pressure_diff = self.pp[min_max[1]] - self.pp[min_max[0]]
            if pressure_diff < diastolic_press_thresh:
                # the diastolic peak is also due to peripheral vascular resistance
                # so as fluid in body increases, vascular resistance decreases,
                # and thus the notches get washed away.
                start_idx = min_max[1]
                diastolic_idx.append(self._find_diastolic_idx(start_idx, min_window_len))
        self.diastolic_idx = np.array(diastolic_idx)

    def mark_pulses_with_wabp(self):
        tmp_file = 'tmp_prox_pressure'
        wrsamp(tmp_file, sig_name=['BP'], p_signal=self.pp.reshape(len(self.pp), 1), fs=self.freq, units=['mm/Hg'], fmt=['16'])
        proc = subprocess.Popen(['wabp', '-r', tmp_file], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = proc.communicate()
        self.diastolic_idx = rdann(tmp_file, 'wabp').sample
        for fe in ['.wabp', '.dat', '.hea']:
            os.remove(tmp_file + fe)

    def validate(self, min_idx, max_idx, dot_size=10):
        if self.diastolic_idx is None:
            raise Exception('You need to find pulse diastolic indices first.')
        slice = self.pp[min_idx:max_idx]
        mask = np.logical_and(self.diastolic_idx >= min_idx, self.diastolic_idx < max_idx)
        idxs = self.diastolic_idx[mask]
        press_vals = self.pp[idxs]
        plt.plot(self.pp[min_idx:max_idx])
        plt.plot(idxs - min_idx, press_vals, ls="", marker='o', label='points', markersize=dot_size)
        plt.show()

    def _derive_bp_features(self, arr, desc):
        if self.diastolic_idx is None:
            raise Exception('You need to find pulse diastolic indices first.')
        colnames = ['beat_num', 'beat_start_time', '{}_max'.format(desc), '{}_min'.format(desc), '{}_mean'.format(desc)]
        features = []
        time_step = 1.0 / self.freq
        for idx, beat_start in enumerate(self.diastolic_idx):
            if idx+1 == len(self.diastolic_idx):
                beat_vals = arr[beat_start:]
            else:
                beat_vals = arr[beat_start:self.diastolic_idx[idx+1]]

            beat_start_time = beat_start * time_step
            beat_min = min(beat_vals)
            beat_max = max(beat_vals)
            beat_mean = np.mean(beat_vals)
            features.append([idx+1, beat_start_time, beat_max, beat_min, beat_mean])

        df = pd.DataFrame(features, columns=colnames)
        # only derive heart rate for abp
        if desc == 'abp':
            beats_in_last_min = []
            heart_rate = []
            for idx, row in df.iterrows():
                beats_in_last_min.append(row.beat_start_time)
                minute_ago = row.beat_start_time - 60
                if minute_ago <= 0:
                    heart_rate.append(len(beats_in_last_min))
                    continue
                items_to_drop = 0
                for beat in beats_in_last_min:
                    if beat < minute_ago:
                        items_to_drop += 1
                    else:
                        break
                for _ in range(items_to_drop):
                    beats_in_last_min.pop(0)
                heart_rate.append(len(beats_in_last_min))
            df['heart_rate'] = heart_rate
        return df

    def derive_abp_features(self):
        return self._derive_bp_features(self.pp, 'abp')

    def derive_cvp_features(self):
        return self._derive_bp_features(self.cvp, 'cvp')

    def derive_all_features(self, filter_n=3):
        """
        Derive all BP related features for individual beats.

        :param filter_outliers: Filter outliers within x std deviations of mean. If
                                set to None then no filtering occurs
        """
        abp = self.derive_abp_features()
        cvp = self.derive_cvp_features()
        df = abp.merge(cvp, on=['beat_num', 'beat_start_time'])
        if filter_n is not None:
            df = filter_outliers(df, filter_n, ['beat_num', 'beat_start_time', 'heart_rate'])
        return df


class CardiacOutputAnalytics(object):
    def __init__(self, df):
        self.df = df

    def find_pulses(self):
        pulse_idxs = []
        last_co = None
        for idx, val in self.df.Cardiac_Output.items():
            if np.isnan(val):
                continue
            if val != last_co:
                pulse_idxs.append(idx)
            last_co = val
        return pulse_idxs


class VentAnalytics(object):
    def __init__(self, intermediate_file=''):
        # A list of variables in name: position ordering
        #
        # The position in question is the position the vars are in breath_meta output
        self.vent_vars = [('rel_bn', 0), ('bs_time', 2), ('tvi', 9), ('tve', 10), ('tv_ratio', 11), ("i_time", 6), ("e_time", 7)]
        self.intermediate_file = intermediate_file
        self.breath_gen = None

    def load_vent_data(self, filename):
        # XXX this method doesn't work for some reason
        vent_data = open(filename, 'r')
        self.breath_gen = pos_neg_flow_bs_be_denoting_extractor(vent_data, store_intermediate=self.intermediate_file, t_delta=.01)

    def process_vent_data_from_cif(self, df):
        vent_data = StringIO(df[['Spirometer', 'Resp_Pr']].to_csv(index=False))
        self.breath_gen = pos_neg_flow_bs_be_denoting_extractor(vent_data, store_intermediate=self.intermediate_file, t_delta=.01)

    def analyze_all_breath_meta(self, filter_n=3):
        if not self.breath_gen:
            raise Exception('You must analyze a file first. Choose from either load_vent_data or process_vent_data_from_cif functions')
        metadata = []
        for b in self.breath_gen:
            meta = get_production_breath_meta(b)
            metadata.append([meta[i] for _, i in self.vent_vars])
        colnames = [name for name, _ in self.vent_vars]
        df = pd.DataFrame(metadata, columns=colnames)
        if filter_n is not None:
            df = filter_outliers(df, filter_n, ['rel_bn', 'bs_time'])
        return df


class BolusAnalytics(object):
    """
    Analyze variables during pre, inter, and post bolus phases. If boluses are staged
    sequence then post bolus calculations for one bolus will match pre bolus calculations
    for the subsequent bolus.
    """
    transition_thresh = .5

    def __init__(self, df, freq=100):
        self.df = df
        self.freq = freq
        self.microbolus_idx = None
        self.macrobolus_idx = None

    def perform_macrobolus_analytics(self):
        if self.macrobolus_idx is None:
            self.find_macroboluses()
        colnames = [
            'bolus_num',
            'bolus_start_time',
            'bolus_end_time',
            'bolus_duration',
            'mean_abp',
            'mean_cvp',
            'mean_co',
            'mean_pv_press',
            'mean_pv_vol',
            'mean_abp_pre',
            'mean_cvp_pre',
            'mean_co_pre',
            'mean_pv_press_pre',
            'mean_pv_vol_pre',
            'mean_abp_post',
            'mean_cvp_post',
            'mean_co_post',
            'mean_pv_press_post',
            'mean_pv_vol_post',
        ]
        bolus_stats = []
        time_step = 1.0 / self.freq
        for idx, bolus in enumerate(self.macrobolus_idx):
            start = bolus[0]
            end = bolus[1]
            tmp = []

            # inter-bolus stats
            slice = self.df.loc[start:end]
            tmp.extend([
                idx+1,
                start*time_step,
                end*time_step,
                (end-start)*time_step,
                slice.BP.mean(),
                slice.CVP.mean(),
                slice.Cardiac_Output.mean(),
                slice.PV_Pressure.mean(),
                slice.PV_Volume.mean(),
            ])

            # pre-bolus stats
            slice = self.df.loc[start - (self.freq * 60):start]
            tmp.extend([
                slice.BP.mean(),
                slice.CVP.mean(),
                slice.Cardiac_Output.mean(),
                slice.PV_Pressure.mean(),
                slice.PV_Volume.mean(),
            ])

            # post-bolus stats
            slice = self.df.loc[end:end + (self.freq * 60)]
            tmp.extend([
                slice.BP.mean(),
                slice.CVP.mean(),
                slice.Cardiac_Output.mean(),
                slice.PV_Pressure.mean(),
                slice.PV_Volume.mean(),
            ])
            bolus_stats.append(tmp)

        return pd.DataFrame(bolus_stats, columns=colnames)

    def perform_microbolus_analytics(self):
        if self.microbolus_idx is None:
            self.find_microboluses()
        colnames = [
            'bolus_num',
            'bolus_start_time',
            'bolus_end_time',
            'bolus_duration',
            'mean_abp',
            'mean_cvp',
            'mean_co',
            'mean_pv_press',
            'mean_pv_vol'
        ]
        bolus_stats = []
        time_step = 1.0 / self.freq
        for idx, bolus in enumerate(self.microbolus_idx):
            start = bolus[0]
            end = bolus[1]
            slice = self.df.loc[start:end]

            # inter-bolus stats
            bolus_stats.append([
                idx+1,
                start*time_step,
                end*time_step,
                (end-start)*time_step,
                slice.BP.mean(),
                slice.CVP.mean(),
                slice.Cardiac_Output.mean(),
                slice.PV_Pressure.mean(),
                slice.PV_Volume.mean(),
            ])
        return pd.DataFrame(bolus_stats, columns=colnames)

    def align_frame_with_microboluses(self, frame, on):
        """
        Will take existing DataFrame and then add a microbolus index column to
        the DataFrame based on which microbolus an event happened in

        :param frame: DataFrame to add microbolus column to
        :param on: on which column should we find the time
        """
        if self.microbolus_idx is None:
            self.find_microboluses()
        return self._align_frame_with_boluses(frame, on, self.microbolus_idx, 'microbolus')

    def align_frame_with_macroboluses(self, frame, on):
        if self.macrobolus_idx is None:
            self.find_macroboluses()
        return self._align_frame_with_boluses(frame, on, self.macrobolus_idx, 'macrobolus')

    def _align_frame_with_boluses(self, frame, on, bolus_idx, bolus_name):
        time_step = 1.0 / self.freq
        for idx, bolus in enumerate(bolus_idx):
            start = bolus[0] * time_step
            end = bolus[1] * time_step
            frame.loc[(frame[on] >= start) & (frame[on] < end), '{}_num'.format(bolus_name)] = idx + 1
        return frame

    def add_heart_rate_to_bolus_analytics(self, frame, compr, on):
        """
        :param frame: DataFrame to add heart rate cols to
        :param compr: DataFrame that holds heart rate information
        :param on: column to use as a comparator; should be either microbolus_num or macrobolus_num
        """
        for n in frame.bolus_num:
            bolus_rows = compr[compr[on] == n]
            mask = frame.bolus_num == n
            frame.loc[mask, 'mean_heart_rate'] = bolus_rows.heart_rate.mean()
        frame['mean_stroke_vol'] = frame.mean_co / frame.mean_heart_rate
        return frame

    def find_macroboluses(self):
        if self.microbolus_idx is None:
            self.find_microboluses()
        self.macrobolus_idx = []
        cur_macrobolus = []
        # If the time the bolus occurred isn't within 55-65 minutes it's not
        # a minute long micro-bolus
        microbolus_num = 0
        for idx, bolus in enumerate(self.microbolus_idx):
            microbolus_start_idx = bolus[0]
            microbolus_end_idx = bolus[1]
            time_step = 1.0 / self.freq
            duration = (microbolus_end_idx - microbolus_start_idx) * time_step
            if 55 <= duration <= 65:
                if microbolus_num % 5 == 0:
                    cur_macrobolus.append(microbolus_start_idx)
                elif microbolus_num % 5 == 4:
                    cur_macrobolus.append(microbolus_end_idx)
                    self.macrobolus_idx.append(tuple(cur_macrobolus))
                    cur_macrobolus = []
                microbolus_num += 1

    def find_microboluses(self):
        """
        Find start/end of individual boluses. Returns a list of indexes

        [
            (idx bolus1 start, idx bolus1 end),
            (idx bolus2 start, idx bolus2 end),
            ...
        ]
        """
        # So this bolus mechanism worked for my initial demo, but on second look before
        # fatemeh arrived to the lab it seems broken. I don't know what happened. My data
        # never changed and my code didn't change either.

        bolus = self.df.BOLUS
        # Find where there are voltage jumps. downside of this approach is the
        # situation in which voltage goes down sharply for reason other than bolus
        # flipping. This has actually happened in practice and caused us to find an
        # off bolus that wasn't actually off, it was just a voltage flip.
        initial_transitions = bolus[(bolus.shift(1) - bolus).abs() > self.transition_thresh]
        # Filter out points that are adjcent to each other and just take the first point
        # This will give us the first probable inflection point for the start and the
        # first possible inflection point for the end
        first_idx = pd.Series(initial_transitions.index.values)
        first_idx = first_idx[(first_idx.shift(1) - first_idx) != -1]

        # find gradient of transitions so we can figure out if bolus is going on or off
        #
        # Voltage is 3 if flow is OFF. Voltage is 0 if flow is ON.
        on_idx = []
        off_idx = []
        for idx in first_idx.values:
            if bolus.loc[idx] - bolus.loc[idx-1] > 0:
                off_idx.append(idx)
            else:
                on_idx.append(idx)

        # find points closest to 0 so we can get as accurate a time length that
        # the bolus was occuring for.
        for k, idx in enumerate(on_idx):
            low_idx = idx + 1 if idx + 1 >= 0 else 0
            high_idx = idx + 5 if idx + 5 >= 0 else 0
            frame = [(i, j) for i, j in bolus.loc[low_idx:high_idx].abs().iteritems()]
            on_idx[k] = sorted(frame, key=lambda x: (x[1], -x[0]))[0]

        for k, idx in enumerate(off_idx):
            low_idx = idx - 5
            high_idx = idx - 1
            frame = [(i, j) for i, j in bolus.loc[low_idx:high_idx].abs().iteritems()]
            off_idx[k] = sorted(frame, key=lambda x: (x[1], x[0]))[0]

        # filter out anything that is transient abnormality.
        tmp = []
        for idx, val in on_idx:
            if not (val > .25 and idx > 0):
                tmp.append((idx, val))
        on_idx = tmp

        tmp = []
        for idx, val in off_idx:
            if not (val > .25 and idx > 0):
                tmp.append((idx, val))
        off_idx = tmp

        # structure our outputs. find off idx to match with on idx
        offset = 0
        full_line = []
        for on in on_idx:
            full_line.append((on[0], True))
        for off in off_idx:
            full_line.append((off[0], False))
        matches = []
        full_line = sorted(full_line, key=lambda x: x[0])
        for i, val in enumerate(full_line[:-1]):
            if full_line[i][1] and not full_line[i+1][1]:
                matches.append((full_line[i][0], full_line[i+1][0]))
            elif full_line[i][1] and full_line[i+1][1]:
                raise Exception('Have two ons after each other! pos1: {} pos2: {}'.format(full_line[i][0], full_line[i+1][0]))

        self.microbolus_idx = matches
