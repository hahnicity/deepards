"""
breath_meta
~~~~~~~~~~~

Create breath meta data.

WARNING: THIS FILE IS DEPRECATED AND ALL WORK SHOULD BE DONE IN ventMAP FROM NOW ON!!!
"""
from argparse import ArgumentParser
import csv
from datetime import datetime, timedelta
from dateutil import parser

import numpy as np
import pandas as pd
from scipy import var
from scipy.integrate import simps
from ventmap.breath_meta import *
from ventmap.detection import detect_version_v2
from ventmap.raw_utils import extract_raw

from algorithms import SAM
from algorithms.constants import EXPERIMENTAL_META_HEADER, IN_DATETIME_FORMAT, META_HEADER, OUT_DATETIME_FORMAT, SBT_META_HEADER


def get_file_experimental_breath_meta(file, tve_pos=True, ignore_missing_bes=True, rel_bn_interval=[], vent_bn_interval=[]):
    return _get_file_breath_meta(
        get_experimental_breath_meta, file, tve_pos, ignore_missing_bes,
        rel_bn_interval, vent_bn_interval
    )


def _get_file_breath_meta(func, file, tve_pos, ignore_missing_bes,
    rel_bn_interval, vent_bn_interval):
    if isinstance(file, str):
        file = open(file)
    if "experimental" in func.__name__:
        array = [EXPERIMENTAL_META_HEADER]
    else:
        array = [META_HEADER]
    missing_be_count_threshold = 1000
    missing_be_ratio_threshold = 0.8
    for breath in extract_raw(file, ignore_missing_bes,
        rel_bn_interval=rel_bn_interval, vent_bn_interval=vent_bn_interval):
        bs_count = breath['bs_count']
        be_count = breath['be_count']
        missing_be = bs_count - be_count
        if (missing_be > missing_be_count_threshold) and (missing_be / float(bs_count) > missing_be_ratio_threshold):
            return array

        array.append(func(breath))
    return array


def get_experimental_breath_meta(breath, tve_pos=True):
    """
    Add experimental breath meta information to the original breath meta info
    """
    flow = breath["flow"]
    pressure = breath["pressure"]
    dt = breath["dt"]
    if 't' not in breath:
        rel_time_array = [i * dt for i in range(len(flow))]
    else:
        rel_time_array = breath["t"]
    # set last data point as last value of breath

    non_experimental = get_production_breath_meta(breath, tve_pos)
    x0_index = non_experimental[28]
    tvi = non_experimental[9]
    minF = non_experimental[13]
    PIP = non_experimental[15]
    peep = non_experimental[17]
    eFlow = flow[x0_index:]  # technically this might need to be +1

    # convert tvi to liters. Units are L / cm H20
    dyn_compliance = (tvi / 1000) / (PIP - peep)
    pef_to_zero = SAM.find_slope_from_minf_to_zero(rel_time_array, flow, minF)
    # XXX must add additional time params here so we can see what works best
    pef_plus_16_to_zero = SAM.find_slope_from_minf_to_zero(
        rel_time_array, flow, minF, t_offset=0.16)
    mean_flow_from_pef = SAM.find_mean_flow_from_pef(flow, minF, 0.16)
    if eFlow:
        vol_at_05 = simps(eFlow[:int(.5 / dt)], dx=dt) * 1000 / 60
        vol_at_076 = simps(eFlow[:int(.76 / dt)], dx=dt) * 1000 / 60
        vol_at_1 = simps(eFlow[:int(1 / dt)], dx=dt) * 1000 / 60
    else:
        vol_at_05 = 0
        vol_at_076 = 0
        vol_at_1 = 0
    pressure_itime4 = SAM.calc_pressure_itime(rel_time_array, pressure, peep, 4)
    pressure_itime5 = SAM.calc_pressure_itime(rel_time_array, pressure, peep, 5)
    pressure_itime6 = SAM.calc_pressure_itime(rel_time_array, pressure, peep, 6)
    pressure_itime_pip5 = SAM.calc_pressure_itime_by_pip(rel_time_array, pressure, PIP, 5)
    pressure_itime_pip6 = SAM.calc_pressure_itime_by_pip(rel_time_array, pressure, PIP, 6)
    pressure_itime_from_front = SAM.calc_pressure_itime_from_front(rel_time_array, pressure, PIP, peep, .4)

    # The array indices go like this
    #
    # 0: rel_bn, 1: vent_bn, 2: rel_time_at_BS, 3: rel_time_at_x0,
    # 4: rel_time_at_BE, 5: IEratio, 6: iTime, 7: eTime, 8: RR, 9: tvi, 10: tve,
    # 11: TVratio, 12: maxF, 13: minF, 14: maxP, 15: PIP, 16: Maw, 17: peep,
    # 18: ipAUC, 19: epAUC, 20: '', 21: bs_time, 22: x01time, 23: tvi1, 24: tve1,
    # 25: x02index, 26: tvi2, 27: tve2, 28: x0_index, 29: abs_time_at_BS,
    # 30: abs_time_at_x0, 31: abs_time_at_BE, 32: rel_time_at_BS,
    # 33: rel_time_at_x0, 34: rel_time_at_BE, 35: min_pressure
    # 36: pef_to_zero, 37: pef_plus_16_to_zero, 38: mean_flow_from_pef,
    # 39: dyn_compliance, 40: vol_at_05, 41: vol_at_076, 42: vol_at_1,
    # 43: pressure_itime4, 44: pressure_itime5, 45: pressure_itime6,
    # 46: pressure_itime_pip5, 47: pressure_itime_by_pip6, 48: pressure_itime_from_front
    return non_experimental + [
        pef_to_zero, pef_plus_16_to_zero,
        mean_flow_from_pef, dyn_compliance, vol_at_05,
        vol_at_076, vol_at_1, pressure_itime4, pressure_itime5, pressure_itime6,
        pressure_itime_pip5, pressure_itime_pip6, pressure_itime_from_front,
    ]


def main():
    parser = ArgumentParser()
    parser.add_argument("input_file")
    parser.add_argument("output_file")
    parser.add_argument("--experimental", action="store_true")
    args = parser.parse_args()
    with open(args.input_file) as f:
        if args.experimental:
            array = get_file_experimental_breath_meta(f)
        else:
            array = get_file_breath_meta(f)
        write_breath_meta(array, args.output_file)


if __name__ == "__main__":
    main()
