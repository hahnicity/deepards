"""
tvv.py
~~~~~~~~~~
This script calculates tidal volume violations based on the ARDSnet protocol

    TVcut3 = 11.5 * pbw
    TVcut2 = 8.5 * pbw
    TVcut1 = 6.5 * pbw

Note this script can be for
- line-by-line detection: detectTVV
- on a data frame: add_tvv_to_df
- on a csv file: add_tvv_to_csv

Default values for pbw are female/67 inches

Optional args:
-------------
output directory--default is the same as input files
suffix--adds custom suffix to outputfiles, make sure it ends with .csv

---------------------------------------------------------
Ex.
python tvv.py /Users/monica/Box\ Sync/UCD/sandbox2016/3_summer/20160816_TVV_fusion/0174_2016-03-04-12-29-04_datetime_removed_1388to1688_v3_5_8__breath_meta__FUSED9_after_upgrades.csv /Users/monica/Box\ Sync/UCD/sandbox2016/3_summer/20160816_TVV_fusion/0174_2016-03-04-12-29-04_datetime_removed_1388to1688_v3_5_8__solo3__FUSED9_after_upgrades.csv -o /Users/monica/Box\ Sync/UCD/sandbox2016/3_summer/20160816_TVV_fusion/tvv_dev -s "_tvv.csv"

"""

from argparse import ArgumentParser, RawTextHelpFormatter
import pandas as pd
from utilikilt.oz import create_output_path
from utilikilt.custom_compare import assert_df_items_equal
from algorithms.constants import (GENDER, PT_HEIGHT)


def calcPBW(gender, height):
    """
    calculates predicted body weight for target tidal volumes
    ARGS:
    gender: accepts "male, female, m, f, M, F, Male, Female"
    height: in inches

    Ref: ARDSnet protocol

    Written: 2015/07/29
    """
    genderDict = {
        'm': 'male',
        'M': 'male',
        'Male': 'male',
        'f': 'female',
        'F': 'female',
        'Female': 'female'}
    if gender in genderDict:
        gender = genderDict[gender]  # replaces gender abbreviation
    if gender == "male":
        PBW = 50 + 2.3 * (float(height) - 60)
    if gender == "female":
        PBW = 45.5 + 2.3 * (float(height) - 60)
    return PBW


def detectTVV(tvi, pbw):
    """
    Versions
    --------
    Written 20160527 V1.0 Make into a function
    """
    TVcut3 = 11.5 * pbw
    TVcut2 = 8.5 * pbw
    TVcut1 = 6.5 * pbw  # may change, is due to wiggle room for target values

    if TVcut1 < tvi <= TVcut2:
        return 1
    elif TVcut2 < tvi <= TVcut3:
        return 2
    elif tvi > TVcut3:
        return 3
    else:
        return 0


def add_tvvs_to_df(meta_df, det_df, pbw):
    """
    wrapper for detectTVV, runs on a dataframe

    20160909 1.0- Written
    """
    assert isinstance(meta_df, pd.DataFrame)
    assert isinstance(det_df, pd.DataFrame)
    assert_df_items_equal('indices', meta_df.index, det_df.index, verbose=1)

    # ADD calls for any supporting functions
    det_df['tvv'] = meta_df['tvi'].apply(lambda x: detectTVV(x, pbw))
    return det_df


def add_tvvs_to_csv(breath_meta_file, det_file, pbw, output_subdir="",
                    suffix=""):
    """
    wrapper for add_tvvs_to_df

    20160909 1.0- Written
    """
    breath_meta_df = pd.read_csv(breath_meta_file)
    det_df = pd.read_csv(det_file)

    if suffix == "":
        suffix = "_tvv.csv"

    # add call for add_tvvs_to_df
    tvv_det = add_tvvs_to_df(breath_meta_df, det_df, pbw)
    tvv_det_path = create_output_path(
        breath_meta_file,
        output_suffix=suffix, output_subdir=output_subdir)

    tvv_det.to_csv(tvv_det_path, index=False)


def main_command_line():
    parser = ArgumentParser(description=__doc__,
                            formatter_class=RawTextHelpFormatter)
    parser.add_argument("breath_meta_file", help="breath meta file")
    parser.add_argument("det_file", help="last detection file, e.g.solo3")
    parser.add_argument(
        "-o", "--output_subdir", default="",
        help="output directory, default is same as input file directory")
    parser.add_argument(
        "-s", "--suffix", default="",
        help="suffix to add to output file name, must end with .csv")
    parser.add_argument('-g', '--gender', default=GENDER,
                        help="gender, necessary for pbw calculation")
    parser.add_argument('-a', '--height', default=PT_HEIGHT, help="height in inches")
    args = parser.parse_args()

    if args.suffix != "":
        assert args.suffix.endswith(".csv")

    pbw = calcPBW(args.gender, args.height)
    add_tvvs_to_csv(args.breath_meta_file, args.det_file, pbw, args.output_subdir,
                    args.suffix)

if __name__ == "__main__":
    main_command_line()
