"""
algorithms.raw_utils
~~~~~~~~~~~~~~~~~~~~

Extract raw data from a file and return it in some kind of presentable format
"""
import csv
from datetime import datetime, timedelta
from dateutil.parser import parse
import io
import re
from operator import xor
try:
    from StringIO import StringIO
except:  # python3
    from io import StringIO
import sys

import numpy as np
import pandas as pd
from ventmap.raw_utils import *

from algorithms.constants import IN_DATETIME_FORMAT, OUT_DATETIME_FORMAT
from algorithms.detection import detect_version_v2
from preprocessing.clear_null_bytes import clear_descriptor_null_bytes

csv.field_size_limit(sys.maxsize)


def pb840_bs_be_denoting_extractor(descriptor, rel_bn_interval=[], store_intermediate=""):
    """
    Takes a file descriptor without BS/BE markers and then adds
    BS and BE markers to it, and then returns the breath data generator
    from extract_raw. Is tuned to the PB-840, and this algorithm may not
    perform well with other ventilators.

    :param descriptor: A file descriptor for a ventilator data file without
    BS or BE markers.
    :param rel_bn_interval: A relative BN interval to use
    :param store_intermediate: Store the intermediate BS/BE denoted data into a file
    """
    last_bs_loc = None
    cur_bs_loc = None
    first_line = descriptor.readline()
    bs_col, ncol, ts_1st_col, ts_1st_row = detect_version_v2(first_line)
    if ts_1st_row:
        data = first_line
    else:
        descriptor.seek(0)
        data = ""

    # XXX need to add error checks for more than 2 cols of data.
    breath_idx = 1

    flow_min_threshold = 10
    flow_diff_threshold = 5
    n_last_flow_obs = 4
    n_last_pressure_obs = 5
    n_lookback = 4
    n_lookback_fallback = 2
    median_peep = 0
    median_pip = 100
    observations = np.genfromtxt(descriptor, delimiter=',')
    thresh_not_met = True
    peep_buffer = []
    pip_buffer = []
    pressure_buffer_len = 25
    pressure_diff_frac = 0.7

    # The current index we are at in observations variable will always be
    # i+n_last_flow_obs
    for i, obs in enumerate(observations[n_last_flow_obs:]):
        true_idx = i + n_last_flow_obs

        # We are always <n_last_flow_obs> ahead of i in the observations array
        flow_diff = obs[0] - observations[i,0]
        pressure_diff_thresh = (median_pip - median_peep) * pressure_diff_frac

        if obs[1] >= (median_peep + pressure_diff_thresh):
            thresh_not_met = False

        if thresh_not_met and obs[0] >= flow_min_threshold and flow_diff >= flow_diff_threshold:
            thresh_not_met = False
            for offset in range(n_lookback):
                if (
                    true_idx - (offset + 1) < 0
                    or observations[true_idx - (offset + 1), 0] < 0
                ):
                    last_bs_loc = cur_bs_loc
                    # Would including the first negative point be best? Let's try
                    #
                    # Results indicate it's more of a problem than anything, but it
                    # might be worth reinvestigation
                    cur_bs_loc = true_idx - offset
                    break
            else:
                last_bs_loc = cur_bs_loc
                cur_bs_loc = true_idx - n_lookback_fallback

            # XXX Current methodology just constructs a basic file descriptor
            # to pass to extract_raw. This is not very efficient, but was
            # easiest to code for evaluation of algorithms. Future engineering
            # can just modify this function to return our canonical data dict
            if last_bs_loc:
                data += (
                    "BS, S:{}\n".format(breath_idx) +
                    fmt_as_csv(observations[last_bs_loc:cur_bs_loc]) +
                    "\nBE\n"
                )
                breath_idx += 1

            if breath_idx != 1:
                peep_idx = cur_bs_loc - n_last_pressure_obs if cur_bs_loc - n_last_pressure_obs > 0 else 0
                peep = np.mean(observations[peep_idx:true_idx,1])
                pip = np.max(observations[last_bs_loc:cur_bs_loc,1])
                if len(peep_buffer) < pressure_buffer_len:
                    peep_buffer.append(peep)
                    pip_buffer.append(pip)
                else:
                    peep_buffer.pop(0)
                    peep_buffer.append(peep)
                    pip_buffer.pop(0)
                    pip_buffer.append(pip)
                median_peep = np.median(peep_buffer)
                median_pip = np.median(pip_buffer)

            # when debugging the i index cannot be trusted as a gauge of time
            # in relation to the file with BS and BE.
            if breath_idx:
                #import IPython; IPython.embed()
                pass

        elif not thresh_not_met and obs[0] < flow_min_threshold and obs[1] < (median_peep + pressure_diff_thresh):
            thresh_not_met = True
    else:
        data += (
            "BS, S:{}\n".format(breath_idx) +
            fmt_as_csv(observations[cur_bs_loc:]) +
            "\nBE\n"
        )

    data = StringIO(data)
    if store_intermediate:
        open(store_intermediate, 'w').write(data.read())
        data.seek(0)
    return extract_raw(data, False, rel_bn_interval=rel_bn_interval)


def pos_neg_flow_bs_be_denoting_extractor(descriptor, t_delta=.02, rel_bn_interval=[], store_intermediate=""):
    """
    Extracts BS/BE markers based on a basic positive flow starts the breath and
    negative flow ends it scheme.
    """
    last_bs_loc = 0
    cur_bs_loc = None
    first_line = descriptor.readline()
    bs_col, ncol, ts_1st_col, ts_1st_row = detect_version_v2(first_line)
    if ts_1st_col:
        raise Exception("There shouldn't be a timestamp in the first column!")
    if ts_1st_row:
        data = first_line
    else:
        descriptor.seek(0)
        data = ""

    # XXX need to add error checks for more than 2 cols of data.
    breath_idx = 1
    observations = np.genfromtxt(descriptor, delimiter=',')

    # There should at least be .2 seconds per breath
    min_points_per_breath = int(.2 / t_delta)

    for i, obs in enumerate(observations[1:]):
        true_idx = i + 1
        if obs[0] > 0 and observations[i-1,0] < 0 and true_idx - last_bs_loc >= min_points_per_breath:
            cur_bs_loc = true_idx
            data += (
                "BS, S:{}\n".format(breath_idx) +
                fmt_as_csv(observations[last_bs_loc:cur_bs_loc]) +
                "\nBE\n"
            )
            breath_idx += 1
            last_bs_loc = cur_bs_loc
    else:
        data += (
            "BS, S:{}\n".format(breath_idx) +
            fmt_as_csv(observations[cur_bs_loc:]) +
            "\nBE\n"
        )

    data = StringIO(data)
    if store_intermediate:
        open(store_intermediate, 'w').write(data.read())
        data.seek(0)
    return extract_raw(data, False, rel_bn_interval=rel_bn_interval, t_delta=t_delta)
