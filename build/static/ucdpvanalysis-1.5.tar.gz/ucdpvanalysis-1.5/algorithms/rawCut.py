# -*- coding: utf-8 -*-
"""
Created on Tue Aug 25 20:47:33 2015

@author: Keiko
versions
1.1 Initial version
1.2 Update for p65/auto timestamp
"""
import csv
from detection import detect_version_v3
from datetime import datetime

FINAL_TS_FORMAT = "%Y-%m-%d %H:%M:%S.%f"
TIME_ONLY_FORMAT = "%H:%M:%S.%f"

def rawTrunc(rawFile, outFile, interval=[], 
             printout=False, keepBS=True, addRelTime=False, replBN=False):
    """
    Truncates PB840 raw file by complete vent breaths
    
    This function can take both old files (2 columns) and new files(3 columns).
    When interval is left empty, the function only removes the incomplete 
    breaths at the beginning and the end of the file.
    To remove BS and BEs: set keepBS to false
    
    ARGs:
    rawFile: .csv file to be processed, can be a path
    outFile: .csv file to be written, can be a path
    interval: two value list with start and end BN to keep
        If start and stop are unknown, leave blank or use [0,1000000]
        The goal is to choose BNs lower/higher than the bounds of BNs 
        in the file
    timestamp: boolean, assumes file has a timestamp column by default
    printout: boolean, print out statements regarding progress
    keepBS: boolean, keeps BS and BE rows in output
    addRelTime: adds third column with relative time, 
        to use, input float number for sampling rate (dt)
    replBN: boolean, replaces native vent BN with relative BN
    
    EXAMPLES:
    
    rawTrunc(inputPath,outputPath, interval=[0,2],printout=True)
    
    For an old file with a sampling rate of 50hz (dt=0.02sec):
    rawTrunc(inputPath,outputPath, timestamp=False, printout=True, addRelTime=0.02)
    
    
    Updated 2015/09/15 for p65_truncate
    Written: 2015/08/27 for TVvalid
    Version 1.2 Added auto detect type (can put in an opened CSV to pipe from 
        remove null values)


    TODO: change name option based on interval
    TODO: copy raw row
    TODO: move pasting into BS section
    """
    
    if printout==True:
        print "Input: %s"%(rawFile)
        print "Output: %s"%(outFile)
        print "------------"
        print "Keep BS/BE Rows?: %s"%(keepBS)
    
    if addRelTime!=False:
        dt = addRelTime #sampling rate of the ventilator
    # counters
    i = 0 #relative time counter
    row_n = 0 #raw data row number (starting at 0)
    BN = 0 #breath number
    # frame variables
    copy = 0 # ensures data before first BS is not copied
    BSrow = []
    clipboard = []
    

    if not isinstance(outFile,str):
         raise TypeError, "output file must be a string"

    if isinstance(rawFile,str):
        raw=open(rawFile, 'rU')
    else:
        raw=rawFile

    with open (outFile, 'wb') as rt:
        rawCSV = csv.reader(raw, delimiter=',')
        truncCSV = csv.writer(rt, delimiter=',')

        # detect timestamp/determine BS column location
        first = raw.readline()
        # does first row start with '20' (the beginning of a year in a timestamp)?
        # eg. 2015-09-08

        version_info = detect_version_v3(first)
        print ("\n File version #: {} \n".format(str(version_info['version'])))
        print ("Rows Exported:")

        BScol = version_info['BScol']
        ncol = version_info['ncol']
        version = version_info['version']

        # if first.split(' ')[0].split('-')[0][0:2]=='20':  
        #     timestamp = True
        #     if printout:
        #         print 'Timestamp = True'
        #         print "Rows Exported:"
        #     BScol = 1
        #     ncol = 3
        # else:
        #     timestamp = False
        #     if printout:
        #         print 'Timestamp = False'
        #         print "Rows Exported:"
        #     BScol = 0
        #     ncol = 2 
        
        for row in rawCSV:
            row_n += 1
            if version == 2:
                if len(row) == 1:
                    continue
            if version == 3:
                continue

            # if timestamp:
            #     if len(row) == 1:
            #         continue
            #     elif version_info["version"] == 3:
            #         continue
            
            # detect breath start
            # -------------------
            if row[BScol] in [' BS', 'BS'] and row[0]!=[]:
                BN += 1 # breath number counter
                # BS row output will be the same as the raw row except
                # when outputting a new relative time column
                ventBN=row[BScol+1]
                if addRelTime!=False and version != 2:
                    BSrow = ['-',row[0],row[1]]
                else:
                    BSrow = row
                if replBN:
                    BSrow[BScol+1]="S:%s"%(str(BN))
                # by default, copy rows after first BS
                if interval ==[]:
                    copy = 1
                # if an interval is specified, copy following rows only if 
                # the BN is within the specified interval
                else:
                    if BN >= interval[0] and BN <= interval[1]:
                        copy = 1 
            
            # detect breath end
            # -----------------
            # after each BE, flush the clipboard and write to CSV
            # putting the csv writing in this section ensures the last 
            # incomplete breath is not copied
            elif row[BScol] in [' BE', 'BE'] and copy== 1 and row[0]!=[]:
                if printout:
                    print BN,ventBN,row_n #to see what BNs are being exported
                if keepBS: #outputs rows with BS
                    truncCSV.writerow(BSrow)
                for fpRow in clipboard: #outputs +/-time, flow, pressure 
                    truncCSV.writerow(fpRow)
                if keepBS:
                    if addRelTime!=False and timestamp==False:
                        BErow = ['-',row[0]]
                    else:
                        BErow=row
                    truncCSV.writerow(BErow)
                clipboard = []
                copy = 0
                
            # non BS/BE rows are appended to the clipboard
            elif copy: #see specifications under BS
                i +=1 #relative time counter
                fullrow=len(row)==ncol
                if  version == 2: #if there is a timestamp, copy all three columns
                    if fullrow:
                        t_structured = datetime.strptime(row[0], FINAL_TS_FORMAT)
                        t = t_structured.strftime(TIME_ONLY_FORMAT)
                        t_chopped = t[:-3]
                        clipboard.append([t_chopped,float(row[1]),float(row[2])])
                else:
                    if fullrow:
                        if addRelTime!=False: #old file + add relative time col
                            t = float(i*dt)
                            clipboard.append([t,float(row[0]),float(row[1])])
                        else: #old file + don't add relative time col
                            clipboard.append([float(row[0]),float(row[1])])


        raw.close()

                        
               
                