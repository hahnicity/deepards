"""
solo_fused
~~~~~~~~~~
This script can fuse double trigger breaths.

Requires a breath meta file and det file of same breaths.

Optional args:
-------------
output directory--default is the same as input files
suffix--adds custom suffix to outputfiles, make sure it ends with .csv

New breath
----------
Aspects taken from first breath-BN, ventBN, BS
Aspects taken from second breath-IEnd, eTime, tve, PEEP, x01, x02, tve1, tve2
New calculations-
 - new iTime = itime(1) - etime(1) + itime(2)
 - new tvi = tvi(1) - tve(1) + tvi(2)
 - new tvi1 = tvi1(1) - tve1(1) + tvi1(2)
 - new tvi2 = tvi2(1) - tve2(1) + tvi2(2)
 - new mins/maxes - min/max flow, max pressure, max insp pressure
 - redo IE ratio/instRR and tve:tvi ratio based on new values

Ex:
---

----------------------------------------------------------
"""

from argparse import ArgumentParser, RawTextHelpFormatter

import numpy as np
import pandas as pd

from utilikilt.oz import create_output_path


def create_solo_fused(breath_meta_file, det_file, output_subdir="", suffix=""):
    """
    runs fusion from csv files

    see overall documentation
    """
    breath_meta_df = pd.read_csv(breath_meta_file)
    det_df = pd.read_csv(det_file)

    if suffix == "":
        suffix = "_FUSED.csv"
    fused_bm, fused_det = fuse_dta(breath_meta_df, det_df)
    fused_bm_path = create_output_path(
        breath_meta_file,
        output_suffix=suffix, output_subdir=output_subdir)
    fused_det_path = create_output_path(
        det_file,
        output_suffix=suffix, output_subdir=output_subdir)

    fused_bm.to_csv(fused_bm_path, index=False)
    fused_det.to_csv(fused_det_path, index=False)


def fuse_dta(meta_df, det_df):
    """
    fuses double trigger asynchrony (dta) breaths in dataframes

    :param meta_df: data frame for all breath metadata
    :param det_df: data frame for all breath classifications
    """
    if len(meta_df) == 0:
        return meta_df, det_df

    if not (meta_df.BN == det_df.BN).all():
        raise Exception('Metadata and Classification indices do not match!')
    dbl_alg = 'dbl.4'
    breath_meta_row_prefix = ["BN", "ventBN", "BS"]
    fused_bm = meta_df
    fused_det = det_df

    # initialize variables
    second_frames_of_dbl = []
    original_length = len(det_df)
    try:
        dbl_1st_count = det_df[dbl_alg].value_counts()[1]
    except KeyError:  # no first frames found
        dbl_1st_count = 0
    try:
        dbl_2nd_count = det_df[dbl_alg].value_counts()[2]
    except KeyError:  # no second frames found
        dbl_2nd_count = 0

    assert dbl_1st_count == dbl_2nd_count, """ Difference in double trigger counts: \n
        breath 1: {}, breath 2: {}""".format(dbl_1st_count, dbl_2nd_count)

    # exit out of function if there are no double triggers
    if dbl_1st_count == 0:
        return fused_bm, fused_det

    second_frames = det_df[det_df[dbl_alg] == 2]
    first_frames = det_df[det_df[dbl_alg] == 1]
    # If you want an assertion you can do it here by subtracting BNs from each other
    meta_df.loc[first_frames.index, 'iTime'] = (
            meta_df.loc[first_frames.index, 'iTime'] + \
            meta_df.loc[first_frames.index, 'eTime'] + \
            meta_df.loc[second_frames.index, 'iTime'].values)
    meta_df.loc[first_frames.index, 'tvi'] = \
            meta_df.loc[first_frames.index, 'tvi'] - \
            meta_df.loc[first_frames.index, 'tve'] + \
            meta_df.loc[second_frames.index, 'tvi'].values
    meta_df.loc[first_frames.index, 'tvi1'] = \
            meta_df.loc[first_frames.index, 'tvi1'] - \
            meta_df.loc[first_frames.index, 'tve1'] + \
            meta_df.loc[second_frames.index, 'tvi1'].values
    meta_df.loc[first_frames.index, 'tvi2'] = \
            meta_df.loc[first_frames.index, 'tvi2'] - \
            meta_df.loc[first_frames.index, 'tve2'] + \
            meta_df.loc[second_frames.index, 'tvi2'].values
    from_2nd_list = ['IEnd', 'eTime', 'tve', 'PEEP', 'x01', 'x02', 'tve1', 'tve2']
    null_cols = ['Maw', 'ipAUC', 'epAUC', " "]
    meta_df.loc[first_frames.index, null_cols] = "-"
    # must account for indexing as a result we use .values
    meta_df.loc[first_frames.index, from_2nd_list] = meta_df.loc[second_frames.index, from_2nd_list].values
    meta_df.loc[first_frames.index, 'tve:tvi ratio'] = \
            meta_df.loc[first_frames.index, 'tve'] / meta_df.loc[first_frames.index, 'tvi']
    meta_df.loc[first_frames.index, 'I:E ratio'] = \
            meta_df.loc[first_frames.index, 'iTime'] / meta_df.loc[first_frames.index, 'eTime']
    meta_df.loc[first_frames.index, 'inst_RR'] = (
            60 / (meta_df.loc[first_frames.index, 'iTime'] + meta_df.loc[first_frames.index, 'eTime'])
    ).values
    meta_df.loc[first_frames.index, 'maxF'] = pd.concat([meta_df.loc[first_frames.index, 'maxF'], pd.Series(meta_df.loc[second_frames.index, 'maxF'].values, index=first_frames.index)], axis=1).max(axis=1)
    meta_df.loc[first_frames.index, 'minF'] = pd.concat([meta_df.loc[first_frames.index, 'minF'], pd.Series(meta_df.loc[second_frames.index, 'minF'].values, index=first_frames.index)], axis=1).min(axis=1)
    meta_df.loc[first_frames.index, 'maxP'] = pd.concat([meta_df.loc[first_frames.index, 'maxP'], pd.Series(meta_df.loc[second_frames.index, 'maxP'].values, index=first_frames.index)], axis=1).max(axis=1)
    meta_df.loc[first_frames.index, 'PIP'] = pd.concat([meta_df.loc[first_frames.index, 'PIP'], pd.Series(meta_df.loc[second_frames.index, 'PIP'].values, index=first_frames.index)], axis=1).max(axis=1)
    meta_df = meta_df.drop(second_frames.index, axis=0)
    det_df = det_df.drop(second_frames.index, axis=0)
    return meta_df, det_df


def fuse_bsa(meta_df, det_df):
    """
    fuses breath stacking asynchrony breaths in dataframes

    :param meta_df: data frame for all breath metadata
    :param det_df: data frame for all breath classifications
    """
    # Find clusters of moderate-severe BSA, calculate metadata, then fuse.

    # Fnd clusters of BSA
    if not (meta_df.BN == det_df.BN).all():
        raise Exception('Metadata and Classification indices do not match!')
    bs_mod_sev = det_df[(det_df['bs.1or2'] > 0) & ((det_df['bs.1'] > 1) | (det_df['bs.2'] > 1))]
    fuse_set = set(bs_mod_sev[(bs_mod_sev.shift(-1).BN - bs_mod_sev.BN).abs() == 1].index)
    fuse_set2 = set(bs_mod_sev[(bs_mod_sev.shift(1).BN - bs_mod_sev.BN).abs() == 1].index)
    fuse_set.update(fuse_set2)
    fuse_set = sorted(list(fuse_set))
    if len(fuse_set) == 0:
        return meta_df, det_df

    last_num = fuse_set[0]
    clust = [last_num]
    clusters = []
    for num in fuse_set[1:]:
        if abs(num - last_num) == 1:
            clust.append(num)
        else:
            clusters.append(clust)
            clust = [num]
        last_num = num

    tvis = ['tvi', 'tvi1', 'tvi2']
    tves = ['tve', 'tve1', 'tve2']
    min_vars = ['BN', 'ventBN', 'BS', 'minF', 'min_pressure', 'abs_time_at_BS', 'rel_time_at_BS', 'BS.1']
    max_vars = ['PIP', 'maxF', 'maxP']
    null_cols = ['Maw', 'ipAUC', 'epAUC', " ", 'iTime', 'eTime', 'I:E ratio']
    from_final_list = ['IEnd', 'PEEP', 'x01', 'x02', 'BE', 'abs_time_at_BE', 'rel_time_at_BE']

    for clust in clusters:
        meta_df.loc[clust[0], tves] = meta_df.loc[clust[-1], tves]
        meta_df.loc[clust[0], tvis] = (meta_df.loc[clust[:-1], tvis].sum(axis=0).values - meta_df.loc[clust[:-1], tves].sum(axis=0).values) + meta_df.loc[clust[-1], tvis].values
        meta_df.loc[clust[0], max_vars] = meta_df.loc[clust, max_vars].max()
        meta_df.loc[clust[0], min_vars] = meta_df.loc[clust, min_vars].min()
        meta_df.loc[clust[0], null_cols] = np.nan
        meta_df.loc[clust[0], from_final_list] = meta_df.loc[clust[-1], from_final_list]
        tve_tvi = meta_df.loc[clust[0], 'tve'] / meta_df.loc[clust[0], 'tvi']
        meta_df.loc[clust[0], 'tve:tvi ratio'] = tve_tvi
        stack_time = meta_df.loc[clust[-1], 'IEnd'] - meta_df.loc[clust[0], 'BS']
        meta_df.loc[clust[0], 'inst_RR'] = 60 / stack_time
        meta_df = meta_df.drop(clust[1:])

        is_bs1 = det_df.loc[clust[0], 'bs.1'] > 0
        col = 'bs.1' if is_bs1 else 'bs.2'

        if .66 <= tve_tvi < .9:
            det_df.loc[clust[0], col] = 1
        elif .33 <= tve_tvi < .66:
            det_df.loc[clust[0], col] = 2
        elif tve_tvi < .33:
            det_df.loc[clust[0], col] = 3
        else:
            det_df.loc[clust[0], col] = 0
        det_df = det_df.drop(clust[1:])

    return meta_df, det_df


def main_command_line():
    parser = ArgumentParser(description=__doc__,
                            formatter_class=RawTextHelpFormatter)
    parser.add_argument("breath_meta_file", help="breath meta file")
    parser.add_argument("det_file", help="last detection file, e.g.solo3")
    parser.add_argument(
        "-o", "--output_subdir", default="",
        help="output directory, default is same as input file directory")
    parser.add_argument(
        "-s", "--suffix", default="",
        help="suffix to add to output file name, must end with .csv")
    args = parser.parse_args()

    if args.suffix != "":
        assert args.suffix.endswith(".csv")
    create_solo_fused(args.breath_meta_file, args.det_file, args.output_subdir,
                      args.suffix)

if __name__ == "__main__":
    main_command_line()
