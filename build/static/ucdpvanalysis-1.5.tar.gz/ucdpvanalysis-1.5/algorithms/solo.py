"""
Created on Wed Feb 24 8:47 PM
@author: Keiko
"""
from pandas import DataFrame, read_csv


def remove_artifacts_from_BS_DBL(df):
    """
    Clears pvas if COSUMTVD has been detected

    :param df: input data frame
    """
    which_cosumtvd = ['co.noTVi', 'sumt', 'vd.2']

    first_pva_col = df.columns.get_loc("pvis")+1
    last_pva_col = df.columns.get_loc("cosumtvd")-1

    first_pva_name = df.columns[first_pva_col]
    last_pva_name = df.columns[last_pva_col]

    has_artifact_idx = df[df[which_cosumtvd].sum(axis=1) > 0].index
    df.loc[has_artifact_idx, first_pva_name:last_pva_name] = 0
    df.loc[has_artifact_idx, 'cosumtvd'] = 1
    df.loc[df.index.difference(has_artifact_idx), 'cosumtvd'] = 0

    return df


def remove_residual_dbl_single_frames(df, pva):
    """
    Remove single frames of residual dbl annotations
    """
    if len(df) == 0:
        return df
    shifted = df[pva].shift(-1)
    # Get the last index of a multi event and add the last row too.
    finals = df[df[pva] > shifted].append(df.iloc[-1])

    # Satisfies condition if reg and last pva is one but next isn't 2, remove
    hanging_idx = finals[finals[pva] == 1].index
    df.loc[hanging_idx, pva] = 0

    # Satisfies weird condition if pva is 1 and last pva is 1 then remove
    weirdos = df.loc[(hanging_idx - 1).difference([-1])]
    idx = weirdos[weirdos[pva] == 1].index
    df.loc[idx, pva] = 0

    # Satisfies condition if reg and last pva is 2 but prior isn't 1, remove
    is_2_idx = finals[finals[pva] == 2].index
    zero_to_2_idx = df.loc[is_2_idx - 1][df.loc[is_2_idx - 1, pva] == 0].index
    df.loc[zero_to_2_idx + 1, pva] = 0

    return df


def remove_small_multi_events(df, artifact):
    """
    Removes multi-events that are less than/equal to a threshold-frames long
    For removal of false positive suctions and multiple triggers

    This function assumes that multi-events are not missing any numbers
    So it might not work as expected with "1,2,3,0,5"

    :param df: DataFrame to be processed
    :param artifact: PVA that will be processed
    """
    if len(df) == 0:
        return df
    min_frame_threshold = 3
    shifted = df[artifact].shift(-1)
    shifted.iloc[-1] = 0
    # Get the last of a multi event
    finals = df[df[artifact] > shifted]
    less_than_min = finals[finals[artifact] < min_frame_threshold]
    df.loc[less_than_min.index, artifact] = 0
    one_less_idx = (less_than_min.index - 1).difference([-1])
    df.loc[one_less_idx, artifact] = 0
    return df


def remove_multi_from_BScoughANOS(input_df,cough_column, mt_column):
    """
    For removing the designation of a multi from a BS-cough-ANOS

    For example in pt 7 --BN 4389-4390-439

    Written
    2016-04-18


    ### not validated
    """
    output_df = DataFrame(0,index=input_df.index,columns=input_df.columns)

    # print "----in------",str(artifact)
    # input_df.head()

    for BN in input_df.index:

        #is current breath the 2nd frame in a 3 frame double trigger?
        is_MT_3 = input_df.loc[BN,mt_column]==2 and input_df.loc[BN+2,mt_column]!=4

        if is_MT_3 and input_df.loc[BN,cough_column]:
            input_df[BN-1,cough_column]=0
            input_df[BN,cough_column]=0
            input_df[BN+1,cough_column]=0

        #save current frame annotation
        PVA_event_counter = input_df.loc[BN,artifact]

    return input_df


def remove_cough_during_mt_or_su(df):
    """
    Remove the cough
    """
    idx = df[(df['sumt'] != 0) | (df['mt.su'] != 0) | (df['su.2'] != 0)].index
    df.loc[idx, 'co.noTVi'] = 0
    return df
