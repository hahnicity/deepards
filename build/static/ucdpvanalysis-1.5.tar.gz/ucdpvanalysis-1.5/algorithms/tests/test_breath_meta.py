import csv
from datetime import datetime
from io import open
from os.path import dirname, join

from nose.tools import assert_list_equal, eq_
import pandas as pd
from ventmap.rounding_rules import force_round_df, IE_recalc_with_rounding, force_round_df2

from algorithms.breath_meta import get_file_breath_meta, get_file_experimental_breath_meta, get_production_breath_meta
from algorithms.constants import META_HEADER, META_HEADER_TOR_3, IN_DATETIME_FORMAT, OUT_DATETIME_FORMAT
from algorithms.raw_utils import extract_raw
from algorithms.tests.constants import (
    BREATH_META1,
    BREATH_META1_CONTROL,
    DATETIME_FAILURE_CASE,
    JIMMY_TEST,
    PT0149_BREATH_META,
    PT0149_CSV,
    PT0149_BREATH_META_200TO300,
    SPEEDUP_PARSER_ERROR_CASE,
    SPEEDUP_NULL_BYTES_ERROR_CASE,
    WITH_TIMESTAMP,
    WITH_TIMESTAMP_CONTROL
)
from utilikilt.custom_compare import assert_dfs_equal


def perform_rounding(df):
    df = df.round({"tvi": 1, "tve": 1})
    df = df.round(2)
    return df


class TestBreathMeta(object):
    def breath_meta_helper(self, to_test, control, experimental):
        control_breath_array = pd.read_csv(control)
        control_breath_array = control_breath_array.rename(columns={"BS.1": "BS"})
        control_breath_array = perform_rounding(control_breath_array)

        with open(to_test) as f:
            if experimental:
                array = get_file_experimental_breath_meta(f)
            else:
                array = get_file_breath_meta(f)
            array = pd.DataFrame(array[1:], columns=array[0])
            array = perform_rounding(array)

        # subsetting allows breath meta to add new columns
        array = array[control_breath_array.columns]
        assert_dfs_equal(control_breath_array, array)

    def test_breath_meta_experimental(self):
        self.breath_meta_helper(BREATH_META1, BREATH_META1_CONTROL, True)
