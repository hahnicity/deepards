from io import open

from nose.tools import assert_list_equal, assert_raises, eq_

from algorithms.raw_utils import extract_raw, real_time_extractor
from algorithms.tests.constants import (
    ARDS_AND_COPD,
    JIMMY_TEST,
    MALFORMED_BREATH,
    RAW_UTILS_TEST,
    RAW_UTILS_3_COLUMNS_TEST,
    REAL_TIME_TEST,
    SPEEDUP_BAD_ROW_ERROR_CASE,
    SPEEDUP_BE_ERROR_CASE,
    SPEEDUP_EMPTY_FILE_ERROR_CASE,
    SPEEDUP_EXTRA_COLS_ERROR_CASE,
    SPEEDUP_MULTI_BAD_FIRST_LINES_ERROR_CASE,
    SPEEDUP_NULL_COLS_ERROR_CASE,
    SPEEDUP_PARSER_ERROR_CASE,
    THREE_COL_TEST,
)


def test_extract_raw_sunny_day():
    # To ensure everything is ok
    f = open(ARDS_AND_COPD)
    breaths = list(extract_raw(f, False))
    assert breaths


def test_extract_raw_ensure_no_empty_rows():
    f = open(RAW_UTILS_TEST)
    generator = extract_raw(f, False)
    has_data = False
    for sec in generator:
        has_data = True
        assert sec['flow']
    assert has_data


def test_extract_raw_with_spec_rel_bns():
    f = open(RAW_UTILS_TEST)
    generator = extract_raw(f, False, spec_rel_bns=[2, 3, 5, 7, 9])
    has_data = False
    for breath in generator:
        has_data = True
        if breath['rel_bn'] not in [2, 3, 5, 7, 9]:
            assert False, breath['rel_bn']
    assert has_data


def test_3_col():
    f = open(THREE_COL_TEST)
    generator = extract_raw(f, False)
    has_data = False
    for breath in generator:
        has_data = True
    assert has_data


def test_extract_raw_with_interval():
    f = open(RAW_UTILS_TEST)
    generator = extract_raw(f, False, vent_bn_interval=[65427, 65428])
    has_data = False
    for sec in generator:
        has_data = True
        if sec['vent_bn'] not in [65427, 65428]:
            assert False, data['vent_bn']
        # Ensure that bs_time doesn't start at 0.02
        assert sec['bs_time'] != 0.02
    assert has_data


def test_raw_utils_3_columns():
    f = open(RAW_UTILS_3_COLUMNS_TEST)
    generator = extract_raw(f, False)
    has_data = False
    for breath in generator:
        has_data = True
    assert has_data


def test_ensure_things_not_double_counter():
    f = open(RAW_UTILS_TEST)
    previous_vent_bn = None
    generator = extract_raw(f, False, vent_bn_interval=[65427, 65428])
    has_data = False
    for sec in generator:
        assert sec['vent_bn'] != previous_vent_bn
        has_data = True
        previous_vent_bn = sec['vent_bn']
    assert has_data


def test_malformed_breath_non_captured():
    """
    Ostensibly this would be because there is no BE
    """
    f = open(MALFORMED_BREATH)
    generator = extract_raw(f, True)
    breaths = list(generator)
    assert not breaths


def test_malformed_breath_is_captured():
    f = open(MALFORMED_BREATH)
    generator = extract_raw(f, False)
    breaths = list(generator)
    assert breaths


def test_extract_raw_list():
    f = open(REAL_TIME_TEST)
    list_ = real_time_extractor(f, False, vent_bn_interval=[65427, 65428])
    assert len(list_) == 2
    assert list_[0]['vent_bn'] == 65427
    assert list_[1]['vent_bn'] == 65428
    assert '2017-01-01 01-02-01' in list_[0]['ts'][0]
    assert '2017-01-01 01-03-01' in list_[1]['ts'][0]
    for var in ['flow', 'pressure']:
        for breath in list_:
            assert breath[var]
