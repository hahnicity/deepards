from io import open

from algorithms.tests.constants import NO_BOILERPLATE, TOR_REAL_TIME1, TOR_REAL_TIME2, TOR_REAL_TIME3, TOR_REAL_TIME4, TOR_REAL_TIME5, TOR_REAL_TIME6
from algorithms.tor_real_time import RealTimeTor


def test_tor_real_time_basic():
    data1 = open(TOR_REAL_TIME1).read()
    data2 = open(TOR_REAL_TIME2).read()
    real_time = RealTimeTor(10, 68, "m", '/tmp')
    real_time.add_new_data(data1)
    output1, _ = real_time.analyze_raw()
    assert len(output1) == 1
    assert list(output1.ventBN) == [65426]
    real_time.add_new_data(data2)
    output2, _ = real_time.analyze_raw()
    assert len(output2) == 2
    assert list(output2.ventBN) == [65426, 65427]


def test_tor_real_time_with_discontinuity():
    data1 = open(TOR_REAL_TIME1).read()
    data2 = open(TOR_REAL_TIME2).read()
    data4 = open(TOR_REAL_TIME4).read()
    real_time = RealTimeTor(10, 68, "m", '/tmp')
    real_time.add_new_data(data1)
    output1, _ = real_time.analyze_raw()
    assert len(output1) == 1
    assert list(output1.ventBN) == [65426]
    real_time.add_new_data(data2)
    output2, _ = real_time.analyze_raw()
    assert len(output2) == 2
    assert list(output2.ventBN) == [65426, 65427]
    real_time.add_new_data(data4)
    output3, _ = real_time.analyze_raw()
    assert len(output3) == 3
    assert list(output3.ventBN) == [65426, 65427, 65429]


def test_tor_real_time_with_prev_discontinuity():
    data1 = open(TOR_REAL_TIME1).read()
    data2 = open(TOR_REAL_TIME2).read()
    data4 = open(TOR_REAL_TIME4).read()
    real_time = RealTimeTor(10, 68, "m", '/tmp')
    real_time.add_new_data(data1)
    output1, _ = real_time.analyze_raw()
    assert len(output1) == 1
    assert list(output1.ventBN) == [65426]
    real_time.add_new_data(data2)
    output2, _ = real_time.analyze_raw()
    assert len(output2) == 2
    assert list(output2.ventBN) == [65426, 65427]
    real_time.add_new_data(data4)
    output3, _ = real_time.analyze_raw()
    assert len(output3) == 3
    assert list(output3.ventBN) == [65426, 65427, 65429]
    real_time.add_new_data(data1)
    output4, _ = real_time.analyze_raw()
    assert len(output4) == 4
    assert list(output4.ventBN) == [65426, 65427, 65429, 65426]

def test_tor_real_time_scrolling_window():
    window_size = 3
    real_time = RealTimeTor(window_size, 68, "m", '/tmp')
    expected_bns = [65426]
    for i in range(1, 10):
        file_ = NO_BOILERPLATE("real_time_tor{}.csv.test".format(i))
        data = open(file_).read()
        real_time.add_new_data(data)
        output, _ = real_time.analyze_raw()
        if i >= window_size:
            assert len(output) == window_size
        else:
            assert len(output) == i
        if i > 1:
            expected_bns.append(expected_bns[-1] + 1)
            expected_bns = expected_bns[-window_size:]
        assert list(output.ventBN) == expected_bns


def test_tor_real_time_with_dta():
    window_size = 3
    real_time = RealTimeTor(window_size, 68, "m", '/tmp')
    for i in range(1, 10):
        if i < 3:
            file_ = NO_BOILERPLATE("real_time_tor_dta{}.csv.test".format(i))
        else:
            file_ = NO_BOILERPLATE("real_time_tor{}.csv.test".format(i))

        data = open(file_).read()
        real_time.add_new_data(data)
        output, _ = real_time.analyze_raw()
        if len(output) == 1:
            assert output.iloc[0]['dbl.4'] == 0
        if len(output) == 2:
            assert output.iloc[0]['dbl.4'] == 1
            assert output.iloc[1]['dbl.4'] == 2
        if output.iloc[0].ventBN == 65427:
            assert output.iloc[0]['dbl.4'] == 2
            assert output.iloc[1]['dbl.4'] == 0


def test_tor_real_time_with_sumt():
    window_size = 4
    real_time = RealTimeTor(window_size, 68, "m", '/tmp')
    for i in range(1, 10):
        if i < 4:
            file_ = NO_BOILERPLATE("real_time_tor_sumt{}.csv.test".format(i))
        else:
            file_ = NO_BOILERPLATE("real_time_tor{}.csv.test".format(i))

        data = open(file_).read()
        output, vwd = real_time.analyze_new_breath(data)
        if output.iloc[0].ventBN == 65426 and len(output) == 4:
            output.iloc[0].sumt == 1
            output.iloc[1].sumt == 2
            output.iloc[2].sumt == 3
        if output.iloc[0].ventBN == 65427:
            output.iloc[0].sumt == 2
            output.iloc[1].sumt == 3
