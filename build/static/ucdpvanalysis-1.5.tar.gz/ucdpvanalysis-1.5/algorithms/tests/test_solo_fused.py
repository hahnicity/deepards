import os
import pandas as pd
from glob import glob

from ventmap.rounding_rules import force_round_df

from algorithms.solo_fused import fuse_dta
from algorithms.tests.constants import (
    PT0174_SOLO3,
    PT0174_SOLO3_FUSED,
    PT0174_BREATH_META,
    PT0174_BREATH_META_FUSED)
from utilikilt.custom_compare import assert_dfs_equal
from utilikilt.oz import create_output_path

class TestFusion(object):
    def setup(self):
        self.temp_output_dir = os.path.join(os.path.dirname(__file__),
            r"samples/temp_output_dir")
        try:
            os.mkdir(self.temp_output_dir)
        except OSError:
            pass
    def test_fusion(self):
        breath_meta_df = pd.read_csv(PT0174_BREATH_META)
        det_df = pd.read_csv(PT0174_SOLO3)
        fused_bm, fused_det = fuse_dta(breath_meta_df, det_df)
        # dropping these columns because they dont matter and theyre causing test to
        # fail
        fused_bm = fused_bm.drop(['tve1', 'tve2'], axis=1)

        fused_bm_control = pd.read_csv(PT0174_BREATH_META_FUSED)
        fused_bm_control = fused_bm_control.drop(['tve1', 'tve2'], axis=1)
        fused_det_control = pd.read_csv(PT0174_SOLO3_FUSED)

        # exporting and the re-importing, so that float values are handled
        # in a similar way to importing the controls
        fused_bm_path = create_output_path(PT0174_BREATH_META,
            output_subdir=self.temp_output_dir, output_suffix="_FUSED.csv_test")
        fused_det_path = create_output_path(PT0174_SOLO3,
            output_subdir=self.temp_output_dir, output_suffix="_FUSED.csv_test")
        fused_bm.to_csv(fused_bm_path, index=False)
        fused_det.to_csv(fused_det_path, index=False)
        fused_bm = pd.read_csv(fused_bm_path)
        fused_det = pd.read_csv(fused_det_path)

        # comparison
        assert_dfs_equal(force_round_df(fused_bm_control), force_round_df(fused_bm))
        assert_dfs_equal(force_round_df(fused_det_control), force_round_df(fused_det))

    def teardown(self):
        # remove output files that are in a temp dir
        files_in_temp_dir = glob(os.path.join(self.temp_output_dir,"*"))

        if files_in_temp_dir !=[]: # check if there are files
            for file_ in files_in_temp_dir:
                os.remove(file_)

        os.removedirs(self.temp_output_dir)
