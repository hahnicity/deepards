# -*- coding: utf-8 -*-
"""
Created on Thu Jun 11 17:49:20 2015
@author: Keiko
supportive functions for algorithms in TOR

versions
1.1.3: TOR 2.2.4 Additional OR clause
1.1.4: TOR 2.2.6 Improve x0 function sensitivity with 3rd OR clause
        and smaller neg threshold
1.1.5: TOR 2.2.8 Add 4th elif clause for dribbling x0
1.1.6: TOR 2.3.0 Change x0 4th clause for trailing zeros
1.1.7: TOR 2.3.1 Make x0 threshold less stringent for incr sensitivity
1.1.8: TOR 2.3.4 Add x02/tv2 and corrected missing BE-reported BN
1.1.9: TOR 2.3.5 Ignore NaN
1.2.0: TOR 2.3.8 Edit x02.1, Add TV3calc fctn
1.2.1: Add min flow to zero flow slope measurement
1.2.2  Move x0 scripts
20160515  1.2.3 Add x02 and findx0 edits for end of breath

"""
from __future__ import division
from copy import copy
import csv
import math
import sys

import numpy as np
from scipy.integrate import simps
from pandas import DataFrame

__version__="1.2.3"


def calc_plateau_from_vent(t, pressure, flow, dt, x0):
    """
    Calculate the plateau pressure for a breath
    """
    p_tolerance_band = 0.02
    flow_tolerance_band = 0.5
    p_last = 0
    plat = []
    for idx, p in enumerate(pressure):
        if p == 0:
            continue
        if (abs(p_last - p) / p < p_tolerance_band) and (abs(flow[idx]) < flow_tolerance_band) and t[idx] <= x0:
            plat.append(p)
        if len(plat) * dt >= 0.4:
            return sum(plat) / len(plat)
        p_last = p
    else:
        return np.nan


def find_x0_if_plat_in_vent(t, pressure, flow, dt, x0):
    zeros = []
    p_last = 0
    p_tolerance_band = 0.02
    flow_tolerance_band = 0.5
    for idx, p in enumerate(pressure):
        if p == 0:
            continue
        if (abs(p_last - p) / p < p_tolerance_band) and (abs(flow[idx]) < flow_tolerance_band) and t[idx] <= x0:
            zeros.append(t[idx])
        if len(zeros) * dt >= 0.4:
            last_t = t[int(zeros[0] / 0.02) - 1]
            return last_t
        p_last = p
    else:
        raise Exception("something something fix your method")


def calc_plat_from_time_constant(peep, pip, tvi, tau, pif):
    """
    PEEP + ((tvi * (pip - peep)) / (tvi + (TC * PIF)))
    """
    return peep + ((tvi * (pip - peep)) / (tvi + (tau * pif)))


def calc_pif(flow, x0):
    """
    Calculate the peak inspiratory flow. This calculation is pretty unvalidated.
    It works mainly from the perspective of time constants. On square ventilator
    waveforms then this works just fine. On pressure control we fallback on the
    magic constant where we take the last 15 points and take an average of them.
    """
    x0_start_idx = int((round(x0, 2) / .02)) - 1
    # 15 is just a magic constant. Lets see how it works
    #
    # All flows are in L/min so we convert to L/sec
    res_flows = map(lambda x: round(x / 60, 2), flow[x0_start_idx - 15:x0_start_idx + 1])
    return sum(res_flows) / len(res_flows) if res_flows else np.nan


def calc_resistance(pif, pip, plat):
    """
    The resistance is calculated as (pip - plat) / pif
    """
    if pif == 0:
        return np.nan
    return (pip - plat) / pif


def brunner(tve, e_time, f_min):
    """
    Perform the recursive brunner function
    """
    if f_min == 0:
        return np.nan

    if tve == 0:
        return np.nan

    def _brunner():
        return (tve / 1000) / abs(f_min / 60)

    bru = _brunner() * (1 / (1 - math.exp(-1 * e_time / _brunner())))
    for i in range(4):
        denominator = (1 - math.exp(-1 * e_time / bru))
        # XXX Do we want to return a nan?
        if denominator == 0:
            return 0
        bru = bru * (1 / denominator)
    return bru


def al_rawas(flow, x0, dt, tvi):
    """
    Calculate the Al Rawas time constant

    XXX All the indexing here is complex. We need to de-screw it.


    396 Control: x
    [1.335, 1.244, 1.139, 1.096, 1.063, 1.009, 0.962, 0.928, 0.886, 0.852, 0.793, 0.737, 0.702, 0.63, 0.587, 0.549, 0.522, 0.486, 0.43, 0.396, 0.349]

    396 Control y:
    [0.39192733333333335, 0.36613933333333337, 0.34231133333333336, 0.31996433333333335, 0.29837733333333333, 0.27766533333333332, 0.25795633333333334, 0.23905733333333334, 0.22092333333333333, 0.20354833333333333, 0.18710033333333334, 0.17180033333333333, 0.15740733333333334, 0.14408433333333334, 0.13191433333333336, 0.12054933333333336, 0.10983233333333335, 0.099745333333333352, 0.090580333333333346, 0.082325333333333348, 0.074875333333333349]
    """
    # Flow is in L/m must be L/s
    flow_l_s = [round(f / 60, 4) for f in flow]
    # TVi is in ml/s Units have to be in L/s
    tvi_l_s = round(tvi / 1000.0, 4)
    x0_start_idx = int(round(x0 / dt, 2))
    t_start_idx = x0_start_idx + 5 - 1  # 5 for .1 / .02
    t_end_idx = t_start_idx + int(.4 / 0.02)
    y = []
    x = flow_l_s[t_start_idx:t_end_idx + 1]
    x = [round(abs(i), 3) for i in x]
    y.append(tvi_l_s + simps(flow_l_s[x0_start_idx:t_start_idx + 1], dx=dt))
    i = 0
    for idx, f in enumerate(flow_l_s[t_start_idx + 1:t_end_idx + 1]):
        pts = [flow_l_s[t_start_idx + idx], f]
        y.append(y[i] + simps(pts, dx=dt))
        i += 1
    # XXX TODO add least squares
    return (y[-1] - y[0])  / (x[-1] - x[0])


def find_mean_flow_from_pef(flow, pef, t_offset):
    """
    Find the mean flow from our pef to end of expiration
    """
    for idx, vol in enumerate(flow):
        if vol == pef:
            # Advance the index to account for the time offset
            idx = idx + int(t_offset / .02)
            break

    # filter out anything over -3
    # Wait should we do this? This has potential to catch copd.
    #remaining_flow = filter(lambda x: x <= -3, flow[idx:])
    remaining_flow = flow[idx:]
    if len(remaining_flow) == 0:
        return np.nan
    return sum(remaining_flow) / len(remaining_flow)


def find_slope_from_minf_to_zero(t, flow, pef, t_offset=0):
    """
    In lieu of a compliance measurement now we will calculate the slope from min
    flow to 0.
    """
    min_idx = flow.index(pef)
    flow_min = (t[min_idx], min_idx, pef)
    flow_zero = (0, 0, sys.maxsize)  # (time, idx, flow)

    flow_threshold = 2
    for offset_idx, time in enumerate(t[flow_min[1]:]):
        idx = offset_idx + flow_min[1]
        if abs(flow[idx]) < flow_threshold and abs(flow[idx]) < flow_zero[2]:
            flow_zero = (time, idx, flow[idx])

    if flow_zero == (0, 0, sys.maxsize):
        return np.nan

    if (float(flow_zero[0]) - flow_min[0]) == 0:
        return np.nan

    slope = (float(flow_zero[2]) - flow_min[2]) / (float(flow_zero[0]) - flow_min[0])
    if slope < 0:
        return np.nan
    else:
        return slope


# 2015_06_22
def findx0(t, waveform, time_threshold):
    """
    Finds where waveform crosses 0 (changes from + to -)

    Args:
    t: time
    waveform: line to be analyzed
    time-threshold: upper limit (max value) for absolute value of time
    forward_dt: future point in waveform that must be negative

    Updated 2015/09/24 (SAM1.1.9) Stop evaluating if next value is nan
        (as in, non-data rows filled with 'nan' stop being considered as
         waveform[i+1])

    Updated 2015/09/11 and renamed SAM1_1_7; neg flow thresholds changed from
    <= -8 to <= -5 (note that 1st elif clause was found to be < -8 and was
    changed to be <= -5)

    Updated 2015/09/11 and renamed SAM1_1_6; included change in all clauses to
    replace <= to < signs. This dealt with run failures presumably due to
    trailing zeros at the end of the array. Also updated to include 0 in the
    definition of i to account for failures where the value just before the 1st
    neg value was 0 instead of positive.

    Updated 2015/09/09 and renamed SAM1_1_5 to signify SAM v1.1.5; included
    fourth elif clause to x0 logic to allow for cases in which flow 'dribbles'
    along at low values (e.g. -3) for a sustained period, never reaching -8
    threshold, but representing true exhalation event

    Updated 2015/09/04 2.2.6 Improve x0 function sensitivity with 3rd OR clause
        and smaller neg threshold
    Updated: 2015/09/03 2.2.4 Additional OR clause
    Updated: 2015/06/11
    Written: ?
    """
    t = copy(t)
    waveform = copy(waveform)
    t.extend([np.nan] * 6)
    waveform.extend([np.nan] * 6)
    cross0_time = []
    for i in range(len(waveform)-2): #if change to append scheme, will have to worry about -1 error
        nextNan=math.isnan(waveform[i+1])
        if waveform[i]>=0 and not(nextNan):
            if waveform[i + 1] <= -5 and waveform[i + 2] < 0:
                    cross0_time.append(t[i + 1])
            elif waveform[i + 1]<0 and waveform[i + 4] <= -5:
                    cross0_time.append(t[i + 1])
            elif waveform[i+1]<0 and waveform[i+2]<=-5:
                    cross0_time.append(t[i + 1])
            elif waveform[i+1]<0 and waveform[i+2]<0 and waveform[i+3]<0 and \
                waveform[i+4]<0 and waveform[i+5]<0:
                    cross0_time.append(t[i + 1])

    i = 0
    while i <= len(cross0_time) - 2:
        if abs(cross0_time[i] - cross0_time[i + 1]) < time_threshold:
            del cross0_time[i + 1]
        else:
            i += 1


    return cross0_time


def findx02(wave,dt):
    """
    Finds where waveform crosses 0 after largest portion contiguous positive AUC

    Args:
    wave: line to be analyzed (ex. flow)

    V1.0 2015-09-23 (2.0) SAM 1.1.8
    Find x02 separates the the wave into positive portions and negative portions.
    The largest positive portion will be considered the inspiratory portion.

    V1.1 2015-10-27 (2.1) SAM 1.2.0
    Utilizes AUC instead of just duration/length of portion

    20150615-V1.1 SAM 1.2.3 default for x0index is []
    """
    posPortions=[] #holds all positive portion arrays
    negPortions=[] #holds all negative portion arrays
    hold=[] #holding array that is being built
    largestPos=0 #eventually becomes the largest pos AUC (TVi)
    largestNeg=0 #eventually becomes the largest neg AUC (TVe)
#    longestPos=[] #eventually becomes the array with the largest pos values
#    longestNeg=[] #eventually becomes the array with the largest neg values
    x0index=[] #index where x0 occurs

    for i in range(len(wave)-1): #for each value in the wave
        if wave[i]>0: # if the value is greater than 0, it is considered positive
            hold.append(wave[i]) # and will be added to the holding array
            sign = 'pos'
        else: # if the value isn't greater than 0, it is considered negative
            hold.append(wave[i]) # and will be added to the holding array
            sign = 'neg'

        if wave[i+1]>0: #determine the sign of the next value in the wave
            nextSign = 'pos'
        else:
            nextSign = 'neg'

        if sign != nextSign: #if the sign is different than the sign of next value
            # save the holding array
            if sign=='pos':
                posPortions.append(hold)
                #calculate areas under the curve (TVi)
                holdAUC = simps(hold, dx=dt)*1000/60 #1000ml/L, 60 sec/min
                if holdAUC>largestPos: #if holding array has largest AUC
                    largestPos=holdAUC #it is now considered the largest AUC array
                    x0index=i+1 #x0 will be considered time + 1
#                if len(hold)>len(longestPos): # if the holding array is the largest
#                    longestPos=hold # it will become the longest pos array
#                    x0index=i+1 # x0 will be considered time + 1
            if sign =='neg': # similar to positive
                negPortions.append(hold)
                holdAUC = simps(hold, dx=dt)*1000/60 #1000ml/L, 60 sec/min
                if holdAUC<largestNeg:
                    largestNeg=holdAUC
#                if len(hold)>len(longestNeg):
#                    longestNeg=hold
            hold=[]
            #possibly add some additional thing here?
#        if i == len(wave)-1: #if function is at the second to last value
#            pass
    return posPortions, negPortions, largestPos, largestNeg, x0index
#    return posPortions, negPortions, longestPos,longestNeg, x0index

def calcTV3(wave,dt,x02index):
    """
    Written 2015/10/27
    """
    TVi=0
    TVe=0
    hold=[] #holding array
    for i in range(len(wave)-1):#for each value in the wave
        if wave[i]>0: # if the value is greater than 0, it is considered positive
            hold.append(wave[i]) # and will be added to the holding array
            sign = 'pos'
        else: # if the value isn't greater than 0, it is considered negative
            hold.append(wave[i]) # and will be added to the holding array
            sign = 'neg'

        if wave[i+1]>0: #determine the sign of the next value in the wave
            nextSign = 'pos'
        else:
            nextSign = 'neg'

        if sign != nextSign: #if the sign is different than the sign of next value
            if i<x02index and sign=='pos':
                holdAUC = simps(hold, dx=dt)*1000/60 #1000ml/L, 60 sec/min
                TVi+=holdAUC
            elif i>=x02index and sign =='neg':
                holdAUC = simps(hold, dx=dt)*1000/60 #1000ml/L, 60 sec/min
                TVe+=holdAUC
            else:
                pass

    return TVi, TVe
def writecsv(outputM, OUTPUT_FILE):
    """writes csv using CSV reader, requires python 2.7"""
    with open(OUTPUT_FILE, 'wb') as outputopen:
        outputwriter = csv.writer(outputopen, delimiter=',', quoting=csv.QUOTE_NONNUMERIC)
        for row in outputM:
            outputwriter.writerow(row)

    #print "'" + OUTPUT_FILE + "' written in" + '\n\t' + os.getcwd()

def isFlat(data, epsilon = 1, y=0):
    """
    Determines if a region is flat around the horizontal line y.

    This function is used in the delayed trigger algorithms

    ARGS:
    data: 1D list or array (ex. e_pressure)
    epsilon: upper/lower bound
    y: value that the data approaches

    RETURNS:
    flatLengths: list containing lengths of regions that meet criteria
    maxFlat: longest length (units: index numbers, NOT time)
    sumFlat: sum of flatLenghts, another way of measuring time spent near y

    written: 2015/05/23
    """
    flatLengths = []
    k = 0
    for row in data:
        if abs(row-y)<epsilon:
            k+=1
        else:
            if k>0:
                flatLengths.append(k)
                k = 0
    if flatLengths !=[]:
        maxFlat = max(flatLengths)
        sumFlat = sum(flatLengths)
    else:
        maxFlat = 0
        sumFlat = 0

    return flatLengths, maxFlat, sumFlat

def calcPBW (gender, height):
    """
    calculates predicted body weight for target tidal volumes
    ARGS:
    gender: accepts "male, female, m, f, M, F, Male, Female"
    height: in inches

    Ref: ARDSnet protocol

    Written: 2015/07/29
    """
    genderDict = {
        'm': 'male',
        'M': 'male',
        'Male': 'male',
        'f': 'female',
        'F': 'female',
        'Female': 'female'}
    if gender in genderDict:
        gender = genderDict[gender] #replaces gender abbreviation
    if gender =="male":
        PBW = 50 + 2.3*(float(height)-60)
    if gender =="female":
        PBW = 45.5 + 2.3*(float(height)-60)
    return PBW
#


def find_x0s_multi_algorithms(flow, t, last_t, BN, full_xO_tv_list,
                              timestamp_1st_col, BStime, dt, tvePos, ts):
    """
    Calculate x0s based on multiple algorithms

    versions
    20160503 V1 Original, from TOR 3.5.1
    """

    df = DataFrame(np.nan,index={BN},columns=full_xO_tv_list)

    x01s = findx0(t, flow, 0.5)

    BEindex = t.index(last_t)
    if x01s!=[]: #if x01 has multiple values, use the first value to mark end of breath
        x01index=t.index(x01s[0])
    else:# if breath doesn't cross 0 (eg. double trigger, nubbin)
        x01index = t.index(last_t) #???perhaps we should set to beginning of breath?

    #tvi/tve v1
    if timestamp_1st_col:
        # x01time=xoTimestamp
        x01time=ts[x01index]
    else:
        x01time=BStime +t[x01index]
    # tvi1=TVi
    # tve1=TVe

    #NOTE---this should be BEindex+1
    iFlow1=flow[0:x01index]
    eFlow1=flow[x01index:BEindex]
    tvi1 = simps(iFlow1, dx=dt)*1000/60 #1000ml/L, 60 sec/min
     #if expiratory flow DNE, don't calculate expiratory TV (e.g. )
    try:
        tve1 = simps(eFlow1, dx=dt)*1000/60
    except:
        tve1=0

    #tvi/tve v2
    truncated_flow=flow[0:(BEindex+1)] #because python indexes [a,b)
    pos,neg,FlowLargePos,FlowLargeNeg,x02index =findx02(truncated_flow,dt)
    if x02index==[]:
        x02index=t.index(last_t)

    if timestamp_1st_col:
        x02time= ts[x02index]
    else:
        x02time=BStime+t[x02index]
    iFlow2=flow[0:x02index]
    eFlow2=flow[x02index:BEindex]
    try:
        tvi2 = simps(iFlow2, dx=dt)*1000/60 #1000ml/L, 60 sec/min
    except:
        tvi2 = 0
    try:
       tve2 = simps(eFlow2, dx=dt)*1000/60 #1000ml/L, 60 sec/min
    except:
        tve2=0

    #tvi/tve3
    tvi3,tve3=calcTV3(flow,dt,x02index)


    # if BN ==4108:
    #     import pdb
    #     pdb.set_trace()

    #TV output
    if tvePos==True:
        tve1=abs(tve1)
        tve2=abs(tve2)
        # tve3=abs(tve3)
    if x01time==x02time:
        diffx0='-'
    else:
        diffx0='DIFF'
    if tvi1==tvi2 and tvi2==tvi3:
        diffTVi='-'
    else:
        diffTVi='DIFF'
    if tve1==tve2 and tve2==tve3:
        diffTVe='-'
    else:
        diffTVe='DIFF'

    TVoutput=[' ',x01time,tvi1,tve1,x02time,tvi2,tve2,tvi3,tve3,
                     ' ', diffx0, diffTVi, diffTVe]

    df.x01index=x01index; df.x02index=x02index
    df.x01time=x01time; df.x02time=x02time;
    df.tvi1=tvi1; df.tve1=tve1
    df.tvi2=tvi2; df.tve2=tve2
    df.tvi3=tvi3; df.tve3=tve3

    return df,TVoutput


def x0_heuristic(df_x0_row,BN,t):
    """
    Determine which x0 to use
    20160503 V1 Original, from TOR 3.5.1
    """
    x02index=int(df_x0_row.loc[BN,'x02index'])
    x01index=int(df_x0_row.loc[BN,'x01index'])

    # THIS IS ESPECIALLY IMPORTANT IN NUBBIN BREATHS
    if x02index>x01index:
        x0index=x02index
        iTime=t[x02index]
        IEindex=x02index
    else:
        iTime=t[x01index]
        IEindex=x01index
        x0index=x01index

    return iTime,IEindex,x0index

def is_cosumtvd(input_df, whichCosumtvd):
    """
    Adds 1 if COSUMTVD has been detected
    """
    #create empty data frame
    out_df = DataFrame(0,index=input_df.index,columns=input_df.columns)
    for BN in input_df.index:
        if whichCosumtvd=='any':
            if artifacts.any()>0:
                out_df.loc[BN,"cosumtvd"]=1

            else:
                out_df.loc[BN,"cosumtvd"]=0
        else:
            artifact_counter=0
            for artifact in whichCosumtvd:
                if input_df.loc[BN,artifact]!=0:
                    artifact_counter+=1

            if artifact_counter>0:
                out_df.loc[BN,"cosumtvd"]=1

            else:
                out_df.loc[BN,"cosumtvd"]=0
            artifact_counter=0

    return out_df



#-----
# DEPRECATED STUFF?
#-------
def find_plateau_length(data,maxHeight,percentThreshold=0,absThreshold=0):
    if percentThreshold!=0 and absThreshold!=0:
        pass
    elif percentThreshold!=0:
        threshold=percentThreshold*maxHeight
    elif absThreshold!=0:
        threshold=maxHeight-absThreshold
    else: #no threshold given
        pass


def calc_slopes(wave,dt=0.02):
    slopes=[]
    for i in range(len(wave)-1):
        slope=(wave[i+1]-wave[i])/dt

        slopes.append(slope)

    return slopes

def simple_rolling_average(wave, width):
    filtered_wave=[]

    for i in range(len(wave)-(width-1)):
        subset=wave[i:i+width]
        new_datapoint=np.mean(subset)
        filtered_wave.append(new_datapoint)

    return filtered_wave


def detect_pos_spike(wave):#,time_threshold,sd_threshold):
    mean=np.mean(wave)
    sd=np.std(wave)

    pos_spike=0
    longest_outlier_region=0
    outlier_counter=0
    regions=[]
    for i in range(len(wave)-1):
        if wave[i]>1*sd:
            outlier_counter+=1
        else:
            if outlier_counter>0:
                regions.append(outlier_counter)
                if outlier_counter>longest_outlier_region:
                    longest_outlier_region=outlier_counter

            outlier_counter=0

    if longest_outlier_region>2:
        pos_spike=1

    return pos_spike, regions



def detect_pos_spike_by_slope(slopes, delta_threshold):
    big_changes=[]
    isSpike=0
    for i in range(len(slopes)-1):
        if slopes[i]>0 and slopes[i+1]<0:
            big_changes.append(slopes[i]-slopes[i+1])
            delta=slopes[i]-slopes[i+1]
            if delta>delta_threshold:
                isSpike=1
    return isSpike


def where_spike(slopes, look_pos_spike=True, time_threshold=0.2,dt=0.02):
    """
    2016-06-06
    """
    i_threshold=time_threshold/0.02

    largest_pos_slope=max(slopes)
    largest_neg_slope=min(slopes)

    pos_index = slopes.index(largest_pos_slope)
    neg_index = slopes.index(largest_neg_slope)

    distance = neg_index-pos_index
    if look_pos_spike:
        if pos_index < neg_index and distance<=i_threshold:
            return pos_index
        else:
            return []
    else:
        if pos_index > neg_index and distance>= -i_threshold:
            return pos_index
        else:
            return []
