# functions that detect various patient-ventilator asynchronies

# function that detects flow asynchronies (FA) during volume control
# FA occurs when ventilator flow output does not coincide with patient demand

def flow_asynch(patient_file):

    # Get breath meta info per breath as provided by breath_meta.py which
    # uses a breath parameter provided by raw_utils.py

    global c_peep
    from algorithms.raw_utils import extract_raw
    from algorithms.breath_meta import get_production_breath_meta
    from collections import OrderedDict

    all_meta_data = []  # list with meta data (list) for each breath. all_meta_data[n-1] gives meta data for 'rel_bn' n
    fa_info_list = [] # list with all fa_info_dict

    generator = extract_raw(open(patient_file), False) # getting breath parameter
    # Ready to evaluate each breath of the patient file
    for breath in generator:

        # fa_info_dict: dictionary per breath containing the following keys:
        # 'rel_bn': relative breath number
        # 'vent_bn': absolute breath number
        # 'peep': positive end expiratory pressure
        # 'c_peep': calculated peep
        # 'min_p': minimun pressure during inspiration
        # 'severity': severity (Mild = 1, Moderate = 2, Severe = 3, Else = 0)
        # 'ipAUC': TODO
        fa_info_dict = OrderedDict() # key/value pairs will be in same order as added

        # Get meta data of the breath and append to all_meta_data list
        meta_data = get_production_breath_meta(breath)
        all_meta_data.append(meta_data)

        # We have the meta data for the breath. Now need the minimum pressure and calculated peep
        # Minimum pressure during inspiration
        min_p = meta_data[35]

        # Note: We are using a calculated PEEP (c_peep) not a breath's absolute PEEP
        # PEEP Calculation: Look at previous PEEPs or previous 20 PEEPS if we are
        # passed the 20th breath, order them, take 5 highest and then:
        # if all 5 peeps are >= 5cmH2O, find the average and assign to c_peep
        # if only some of 5 highest >= 5cmH2O, find the average of those and assign to c_peep
        # if none are >= 5cmH2O, then let c_peep = 5
        # This leads to three cases: 'rel_bn' <= 5, 5 < 'rel_bn' <= 20, 'rel_bn' > 20s
        if meta_data[0] <= 5: # c_peep calculation for breaths 1-5
            obs_peeps = []
            if meta_data[0] == 1: # c_peep calc. for breath 1
                if meta_data[17] >= 5:
                    c_peep = meta_data[17]
                else:
                    c_peep = 5
            else: # c_peep calculation for breaths 2-5
                for x in all_meta_data: # get previous PEEPs
                        obs_peeps.append(x[17])
                if all(x >= 5 for x in obs_peeps): # if all >= 5
                    c_peep = round(sum(obs_peeps)/len(obs_peeps),3)
                else: # some or none >= 5
                    above_5 = [x for x in obs_peeps if x >= 5]
                    if above_5: # if some >= 5
                        c_peep = round(sum(above_5)/len(above_5),3)
                    else: # if none >= 5
                        c_peep = 5
        elif 6 <= meta_data[0] <= 20: # c_peep calculation for breaths 6-20
            obs_peeps = []
            for x in all_meta_data:
                obs_peeps.append(x[17])
            obs_peeps.sort() # sort in ascending order
            if all(x >= 5 for x in obs_peeps[-5:]): # if all 5 highest >= 5
                c_peep = round(sum(obs_peeps[-5:])/5,3)
            else: # if some or none >= 5
                above_5 = [x for x in obs_peeps[-5:] if x >= 5]
                if above_5: # if some >= 5
                    c_peep = round(sum(above_5)/len(above_5), 3)
                else: # if none >= 5
                    c_peep = 5
        elif meta_data[0] > 20: #c_peep calculation for breaths after 20
            obs_peeps = []
            for x in all_meta_data[-20:]: # get previous 20 PEEPs (includes PEEP of current working breath)
                obs_peeps.append(x[17])
            obs_peeps.sort() # sort in ascending order
            if all(x >=5 for x in obs_peeps[-5:]): # if all 5 highest >= 5
                c_peep = round(sum(obs_peeps[-5:])/5,3)
            else: # if some or none >= 5
                above_5 = [x for x in obs_peeps[-5:] if x >= 5]
                if above_5: # if some >= 5
                    c_peep = round(sum(above_5)/len(above_5), 3)
                else:  # if none >= 5
                    c_peep = 5

        # We now have the min. pressure and the calculated PEEP for the breath
        # FA Criteria Part 1 begins:
        severity = '0'  # breath is pre-assigned to not being an FA (Else = 0)
        x = min_p - c_peep # testing parameter
        if x <= 8: # it's an FA, now find how severe (Mild = 1, Moderate = 2, Severe = 3)
            if c_peep < min_p: # mild FA
                severity = '1'
            elif 0 < min_p <= c_peep: # moderate FA
                severity = '2'
            elif min_p <= 0: # severe FA
                severity = '3'

        # Search for location of FA begins:
        if severity == '0': # case when breath is not an FA
            loc = 'NA'
        else: # case when breath is an FA, find its location: holo, early or late
            x0_index = meta_data[28]
            pressure = breath['pressure']
            len_press_insp = len(pressure[:x0_index]) # number of pressure data points during inhalation (denominator)
            # iterate over all pressure data points during inhalation to see how many are <= 8cmH2O over/below c_peep
            total = 0
            for y in pressure[:x0_index]:
                diff = y - c_peep
                if diff <= 8:
                    total += 1
            percentage = float(total)/len_press_insp #get percentage
            if percentage >= 0.3: # testing if holo
                loc = 'holo'
            else:
                midp_index = (len_press_insp - 1)/2
                min_p_index = pressure[5:x0_index].index(min_p)
                if min_p_index < midp_index:
                    loc = 'early'
                else:
                    loc = 'late'

        fa_info_dict['rel_bn'] = meta_data[0]
        fa_info_dict['vent_bn'] = meta_data[1]
        fa_info_dict['peep'] = meta_data[17]
        fa_info_dict['c_peep'] = c_peep
        fa_info_dict['min_p'] = meta_data[35]
        fa_info_dict['severity'] = severity
        fa_info_dict['ipAUC'] = meta_data[18]
        fa_info_dict['location'] = loc
        fa_info_list.append(fa_info_dict)
    return fa_info_list