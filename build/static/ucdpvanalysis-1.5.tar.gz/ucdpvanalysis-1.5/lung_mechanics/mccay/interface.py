import numpy as np

from lung_mechanics.mccay.LRC_pc_functions import pc_LRC, pc_LRC_iterate


class McCayInterface(object):
    def __init__(self, fr_range, recon_tolerance, average_c):
        self.fr_range = fr_range
        self.recon_tolerance = recon_tolerance
        self.average_c = average_c
        # XXX in future add patient info so we can track results across patient
        self.results = {}

    def analyze_breath(self, breath, peep):
        # XXX in future add patient info so we can track results across patient
        flow = breath['flow']
        try:
            flr = pc_LRC_iterate(
                self.fr_range,
                self.recon_tolerance,
                breath['flow'],
                breath['pressure'],
                peep,
                average_c=self.average_c
            )
            p_recon, component_dict, interp_dict = pc_LRC(
                flr, breath['flow'], breath['pressure'], peep, average_c=self.average_c
            )
        except:
            interp_dict = {
                'R': [np.nan],
                'C_mean': np.nan,
            }
        self.results[breath['rel_bn']] = {
            'resistance': interp_dict['R'],
            'mean_compliance': interp_dict['C_mean'],
        }
