import argparse
import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from algorithms.breath_meta import get_production_breath_meta
from algorithms.raw_utils import extract_raw_speedup
from algorithms.SAM import al_rawas_calcs, brunner, calc_expiratory_plateau, calc_inspiratory_plateau, least_squares_method, vicario_calcs
from lung_mechanics.mccay.interface import McCayInterface
from lung_mechanics.pressure_ctrl_correction import perform_algo as kannangara
from lung_mechanics.vicario_constrained import optimize
from utilikilt.integrate import fast_integrate


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("file")
    parser.add_argument('--al-rawas-idx', type=int, default=15)
    parser.add_argument('--compliance-max', type=float, default=1.5)
    parser.add_argument('--vicario-co', action='store_true')
    parser.add_argument('--al-rawas-tol', type=float, default=.95)
    parser.add_argument('--no-kannangara', action='store_true')
    parser.add_argument('--gold-not-needed', action='store_true')
    parser.add_argument('--title')
    args = parser.parse_args()
    gen = extract_raw_speedup(open(args.file), False)
    ls_sols = {}
    al_rawas_sols = {}
    vicario_sols = {}
    vicario_co_sols = {}
    kannangara_sols = {}
    kannangara_codes = []
    brunner_tcs = {}
    insp_plats = {}
    gold_calcs = {}
    peeps = []
    peep_max_num = 30
    mccay = McCayInterface([0.5, 15.0], .01, True)
    latest_gold_comp_bn = None
    # make sure we don't catch any vent disconnect breaths
    for b in list(gen)[:-4]:
        flow = np.array(b['flow'])
        pressure = np.array(b['pressure'])
        bm = get_production_breath_meta(b)
        vols = np.array([0] + [fast_integrate(flow[:i]/60.0, 0.02) for i in range(2, len(flow)+1)])
        x0 = bm[28]
        pip = bm[15]
        peeps.append(bm[17])
        if len(peeps) > peep_max_num:
            peeps.pop(0)
        peep = np.median(peeps)
        mccay.analyze_breath(b, peep)
        tvi = bm[9]
        tve = bm[10]
        e_time = bm[7]
        rel_bn = b['rel_bn']
        dt = .02
        insp_plat = calc_inspiratory_plateau(b['flow'], b['pressure'], dt)
        if insp_plat is not np.nan:
            gold_comp = (tvi / 1000.0) / (insp_plat - peep)
            gold_calcs[rel_bn] = gold_comp
            latest_gold_comp_bn = rel_bn

        if latest_gold_comp_bn:
            gold_calcs[rel_bn] = gold_calcs[latest_gold_comp_bn]
        elif args.gold_not_needed:
            gold_calcs[rel_bn] = np.nan

        al_rawas = al_rawas_calcs([v/60.0 for v in flow], pressure, x0, dt, pip, peep, tvi / 1000.0, args.al_rawas_idx, args.al_rawas_tol)
        if al_rawas is not np.nan:
            vicario = vicario_calcs([v/60.0 for v in flow], pressure, x0, peep, tvi/1000.0, al_rawas[0])
        else:
            vicario = np.nan
        ls = least_squares_method([v/60.0 for v in flow], pressure, x0, dt, peep, tvi/1000.0)
        if args.vicario_co:
            vicario_co_sols[rel_bn] = optimize(flow, vols, pressure, x0, 15)
        else:
            vicario_co_sols[rel_bn] = [np.nan] * 4
        if args.no_kannangara:
            kannangara_sols[rel_bn] = [np.nan] * 3
        else:
            sols = kannangara(flow, pressure, x0, peep, 0.05)
            kannangara_codes.append(sols[-1])
            if sols[0] and sols[1] and sols[2]:
                kannangara_sols[rel_bn] = sols
            else:
                kannangara_sols[rel_bn] = [np.nan] * 3


        brun = brunner(tve, e_time, min(flow) / 60.0, 6)
        ls_sols[rel_bn] = ls
        vicario_sols[rel_bn] = vicario
        brunner_tcs[rel_bn] = brun
        al_rawas_sols[rel_bn] = al_rawas
        #if rel_bn > 10:
        #    import IPython; IPython.embed()
        #    import time; time.sleep(5)

    gold_comparison = [[], [], [], [], [], [], []]
    for bn, gold in gold_calcs.items():
        gold_comparison[0].append(gold)
        gold_comparison[1].append(al_rawas_sols[bn][2])
        gold_comparison[2].append(vicario_sols[bn][1])
        gold_comparison[3].append(ls_sols[bn][1])
        gold_comparison[4].append(1/vicario_co_sols[bn][0])
        gold_comparison[5].append(kannangara_sols[bn][0])
        gold_comparison[6].append(mccay.results[bn]['mean_compliance'] * 1000 * 98.07)

    first_breath = min(gold_calcs.keys())
    last_breath = max(gold_calcs.keys())
    for i in range(len(gold_comparison)):
        gold_comparison[i] = pd.Series(([np.nan] * (first_breath-1)) + gold_comparison[i]).fillna(method='ffill')

    labels = {0: 'gold', 1: 'al rawas', 2: 'vicario', 3: 'least squares', 4: 'vicario CO', 5: 'kannangara', 6: 'mccay'}
    if args.vicario_co:
        print("vicario CO compliance:", gold_comparison[-1].iloc[first_breath])
    for i in range(0, max(labels.keys())+1):
        plt.plot(gold_comparison[i], label=labels[i])
    plt.title(args.title if args.title else os.path.basename(args.file))
    plt.ylim([0, args.compliance_max])
    plt.legend()
    plt.ylabel('compliance')
    plt.xlabel('BN')
    plt.xticks(range(0, last_breath+1, 5))
    plt.show()


if __name__ == "__main__":
    main()
