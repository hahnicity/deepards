"""
predator
~~~~~~~~

Follows Redmond's 2014 paper "Pressure reconstruction by eliminating the demand effect
of spontaneous respiration (PREDATOR) method for assessing respiratory mechanics of
reverse-triggered breathing cycles"

XXX For now this work is blocked on hearing back from Redmond on how to select breaths
"""


def perform_predator_algo():
    pass
