import numpy as np
from scipy.ndimage.filters import gaussian_filter1d


class EpochDemarcation(object):
    def get_prox_pressure_bs_idx(in_arr):
        """
        Get beat start indices for normal pressure waveforms.
        Starts to break down during periods of extreme pressure
        changes, signal noise, or deep arrhythmia.
        """
        in_arr = gaussian_filter1d(in_arr, 1)
        valley_idxs = []
        valleys = []
        for i in range(1, len(in_arr) -
            if in_arr[i-1] > in_arr[i] < in_arr[i
                valley_idxs.append(i)
                valleys.append(in_arr[i])
        valleys = np.array(valleys)
        valley_idxs = np.array(valley_idxs)
        mask = valleys < valleys.mean()
        return valleys[mask], valley_idxs[mask]
