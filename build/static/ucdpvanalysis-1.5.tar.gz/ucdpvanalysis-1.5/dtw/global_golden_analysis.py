import argparse

import dtwco
import pandas as pd

from algorithms.raw_utils import extract_raw
from dtw.golden import get_doctor_global_golden_breaths
from dtw.utils import get_ventmode_ground_truth, get_and_link_tor_data


def perform_dtw(gt, golden):
    # XXX this will have to change if we are doing per-patient golden breaths
    vc_golden = golden['vc_decel_press_whole']
    df = pd.DataFrame(columns=['bn', 'mode', 'dtw', 'filename'])
    i = 0
    # Do VC breaths first
    for filename in gt[gt.vc == 1]['x_filename'].unique():
        vc_stretch = gt[(gt.x_filename == filename) & (gt.vc == 1)].BN.values
        gen = extract_raw(open(filename), False)
        for b in gen:
            if b['rel_bn'] not in vc_stretch:
                continue
            dist = dtwco.dtw(b['pressure'], vc_golden)
            df.loc[i] = [b['rel_bn'], 'vc', dist, filename]
            i += 1

    # Then PC
    pc_golden = golden['pc_whole']
    for filename in gt[gt.pc == 1]['x_filename'].unique():
        pc_stretch = gt[(gt.x_filename == filename) & (gt.pc == 1)].BN.values
        gen = extract_raw(open(filename), False)
        for b in gen:
            if b['rel_bn'] not in pc_stretch:
                continue
            dist = dtwco.dtw(b['flow'], pc_golden)
            df.loc[i] = [b['rel_bn'], 'pc', dist, filename]
            i += 1
    return df


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--to-pickle', help='save dtw analysis to pickle file')
    parser.add_argument('-p', '--from-pickle', help='load dtw analysis from pickle file')
    args = parser.parse_args()

    if not args.from_pickle:
        gt = get_ventmode_ground_truth()
        golden = get_doctor_global_golden_breaths()
        dtw_scores = perform_dtw(gt, golden)
        if args.to_pickle:
            dtw_scores.to_pickle(args.to_pickle)
    else:
        dtw_scores = pd.read_pickle(args.from_pickle)

    # A basic analysis told me this appraoch will not work.
    linked_data = get_and_link_tor_data(dtw_scores)


if __name__ == "__main__":
    main()
