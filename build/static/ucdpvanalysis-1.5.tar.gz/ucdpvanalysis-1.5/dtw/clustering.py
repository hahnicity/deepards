import argparse
import os
import pickle

from dtwco import dtw
import numpy as np
import pandas as pd
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

from algorithms.breath_meta import get_production_breath_meta
from algorithms.raw_utils import extract_raw
from dtw.utils import get_ventmode_ground_truth, get_and_link_tor_data, RAW_DIR


def perform_dtw_processing(tor_ventmode_gt):
    """
    XXX for now just do dta vc
    """
    all_breaths = []
    y = []
    for filename in tor_ventmode_gt[tor_ventmode_gt.vc == 1].filename.unique():
        cls1_cols = ['dbl.4', 'su', 'co.noTVi', 'bs.1or2', 'mt']
        asyncs_and_artifacts = tor_ventmode_gt[(tor_ventmode_gt.filename == filename) & (tor_ventmode_gt[cls1_cols].sum(axis=1))]
        normals = tor_ventmode_gt.loc[tor_ventmode_gt.index.difference(asyncs_and_artifacts.index)]

        file_normals = 0
        for breath in extract_raw(open(os.path.join(RAW_DIR, filename)), False):
            if breath['rel_bn'] in asyncs_and_artifacts.bn.values or breath['rel_bn'] in normals.bn.values:
                # get the same amount of normal and asynchronous bns per file
                if breath['rel_bn'] in normals.bn.values and file_normals >= len(asyncs_and_artifacts):
                    continue
                meta = get_production_breath_meta(breath)
                x0 = meta[28]
                insp = breath['pressure'][:x0]
                exp = breath['flow'][x0:]
                all_breaths.append(insp + exp)

                if breath['rel_bn'] in asyncs_and_artifacts.bn.values:
                    y.append(1)
                elif breath['rel_bn'] in normals.bn.values:
                    y.append(0)
                    file_normals += 1

    x_train, x_test, y_train, y_test = train_test_split(all_breaths, y)
    clustering_matrix = []
    predictions = []
    for i in range(len(x_test)):
        breath_arr = []
        if len(clustering_matrix) > 0:
            for ii in range(i):
                breath_arr.append(clustering_matrix[ii][i-1])

        for k in range(i+1, len(x_train)):
            breath_arr.append(dtw(x_test[i], x_train[k]))
        clustering_matrix.append(breath_arr)
        predictions.append(y_train[np.argmin(breath_arr)])
    return np.array(clustering_matrix), np.array(y_test), np.array(predictions)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dtw-to-pickle', help='save dtw analysis to pickle file')
    parser.add_argument('-p', '--dtw-from-pickle', help='load dtw analysis from pickle file')
    args = parser.parse_args()

    if not args.dtw_from_pickle:
        gt = get_ventmode_ground_truth()
        gt = gt.rename(columns={'BN': 'bn', 'x_filename': 'filename'})
        gt = gt.drop(['dtpi', 'BS', 'mt', 'su', 'vd'], axis=1)
        linked = get_and_link_tor_data(gt)
        dtw_dists, y_test, pred = perform_dtw_processing(linked)
        if args.dtw_to_pickle:
            y_test = y_test.reshape((len(y_test), 1))
            pred = pred.reshape((len(pred), 1))
            mat = np.append(dtw_dists, y_test, axis=1)
            mat = np.append(mat, pred, axis=1)
            np.save(args.dtw_to_pickle, mat)
    else:
        mat = np.load(args.dtw_from_pickle)
        dtw_dists = mat[:,:-2]
        y_test = mat[:, -2]
        pred = mat[:, -1]
    print(classification_report(y_test, pred))


if __name__ == "__main__":
    main()
