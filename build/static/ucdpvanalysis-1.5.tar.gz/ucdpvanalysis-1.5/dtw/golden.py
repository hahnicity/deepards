from dtwco import dtw
import numpy as np

from algorithms.raw_utils import extract_raw
from dtw.global_golden import pc, vc_decel


def get_doctor_global_golden_breaths():
    return {
        "vc_decel_press_whole": vc_decel.VC_DECEL_PRESSURE_WHOLE,
        "vc_decel_press_insp": vc_decel.VC_DECEL_PRESSURE_INSP,
        "vc_decel_press_exp": vc_decel.VC_DECEL_PRESSURE_EXP,
        "pc_insp": pc.PC_INSP,
        "pc_exp": pc.PC_EXP,
        "pc_whole": pc.PC_WHOLE,
    }


def get_file_local_golden(filename, window_len, dist_thresh, rel_bns, mode):
    gen = extract_raw(open(filename), False, spec_rel_bns=rel_bns)
    dists = []
    use_pressure_modes = ['vc']
    use_flow_modes = ['pc', 'prvc', 'ps']
    if mode in use_flow_modes:
        metric = 'flow'
    else:
        metric = 'pressure'

    b = gen.next()
    for bp in gen:
        score = dtw(b[metric], bp[metric])
        dists.append(score)
        b = bp

    means = [np.mean(dists[i:i+window_len]) for i in range(len(dists)-window_len)]
    min_idx = np.argmin(means)
    if means[min_idx] > dist_thresh:
        return None

    breath_range = [min_idx+1, min_idx+1+window_len]
    gen = extract_raw(open(filename), False, rel_bn_interval=breath_range)
    # I can take a single breath from the range but then its not guaranteed
    # to be good. I can try to average breaths together, but that has
    # its own complications.
    #
    # Maybe try just picking a breath from the range and see how that works.
    # but this is not a publication worthy method, so it will have to change
    #
    # Maybe a better method would actually be to utilize DTW to choose pathing
    # for items we can average together. This could be interesting because it
    # would automatically find matching between disparate points on the curves
    breaths = [[], []]
    for b in gen:
        breaths[0].append(b['flow'])
        breaths[1].append(b['pressure'])
    # choose breath with # obs closest to mean
    obs_counts = np.array([len(b) for b in breaths[0]])
    mean_breath = np.argmin(np.abs(np.mean(obs_counts) - obs_counts))
    return {'flow': breaths[0][mean_breath], 'pressure': breaths[1][mean_breath]}


def get_file_modes_and_ranges(filename, ventmode_gt):
    # only evaluate these modes for the time
    vm_cols = ['vc', 'pc', 'ps', 'prvc']
    output = {}
    for mode in vm_cols:
        mode_and_range = ventmode_gt[(ventmode_gt.x_filename == filename) & (ventmode_gt[mode] == 1)]
        if len(mode_and_range) == 0:
            continue
        else:
            output[mode] = mode_and_range.BN.values
    return output


def get_all_golden_per_file(ventmode_gt, window_len, dist_thresh):
    golden_dict = {}
    for f in ventmode_gt.x_filename.unique():
        modes_and_ranges = get_file_modes_and_ranges(f, ventmode_gt)
        if not modes_and_ranges:
            continue
        golden_dict[f] = {}
        for mode in modes_and_ranges:
            rel_bns = modes_and_ranges[mode]
            golden_dict[f][mode] = get_file_local_golden(f, window_len, dist_thresh, rel_bns, mode)
    return golden_dict
