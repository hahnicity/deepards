import argparse
import pickle

from dtwco import dtw
import pandas as pd

from algorithms.raw_utils import extract_raw
from dtw.golden import get_all_golden_per_file
from dtw.utils import get_ventmode_ground_truth, get_and_link_tor_data


def perform_dtw(ventmode_gt, golden):
    use_pressure_modes = ['vc']
    use_flow_modes = ['pc', 'prvc', 'ps']
    dists = []
    df = pd.DataFrame(columns=['bn', 'mode', 'dtw', 'filename'])

    i = 0
    for filename in golden:
        for mode in golden[filename]:
            # If we couldn't find a period of stability for a file then just skip.
            if not golden[filename][mode]:
                continue

            if mode in use_flow_modes:
                metric = 'flow'
            else:
                metric = 'pressure'
            golden_breath = golden[filename][mode][metric]

            rel_bns = ventmode_gt[(ventmode_gt.x_filename == filename) & (ventmode_gt[mode] == 1)].BN.values
            gen = extract_raw(open(filename), False, spec_rel_bns=rel_bns)

            for b in gen:
                score = dtw(golden_breath, b[metric])
                df.loc[i] = [b['rel_bn'], mode, score, filename]
                i += 1

    return df


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--window-len', type=int, default=10)
    parser.add_argument('--dist-thresh', type=int, default=100)
    parser.add_argument('--golden-to-pickle', help='save golden breaths to a pickle file')
    parser.add_argument('-g', '--golden-from-pickle', help='load golden breaths from a pickle file')
    parser.add_argument('--dtw-to-pickle', help='save dtw analysis to pickle file')
    parser.add_argument('-p', '--dtw-from-pickle', help='load dtw analysis from pickle file')
    args = parser.parse_args()

    if not args.dtw_from_pickle:
        gt = get_ventmode_ground_truth()
        if args.golden_from_pickle:
            golden = pickle.load(open(args.golden_from_pickle))
        else:
            golden = get_all_golden_per_file(gt, args.window_len, args.dist_thresh)
            if args.golden_to_pickle:
                pickle.dump(golden, open(args.golden_to_pickle, 'w'))

        dtw_scores = perform_dtw(gt, golden)
        if args.dtw_to_pickle:
            dtw_scores.to_pickle(args.dtw_to_pickle)
    else:
        dtw_scores = pd.read_pickle(args.dtw_from_pickle)

    linked_data = get_and_link_tor_data(dtw_scores)
    import IPython; IPython.embed()


if __name__ == "__main__":
    main()
