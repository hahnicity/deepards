#!/usr/bin/env python
# -*- coding: utf-8 -*-
from setuptools import setup, find_packages


setup(name='ucdpvanalysis',
      version="1.5",
      description='analytics for ucdpv',
      packages=find_packages(exclude=["cartographer"]),
      install_requires=[
          'numpy',
          'pandas',
          'scipy',
          'six',
          'ventmap',
      ],
      python_requires='>=2.7',
      entry_points={
          'console_scripts': [
              'clean_datetimed_data=preprocessing.clean_datetimed_data:main',
              'csv_to_sql=schema.csv_to_sql:main',
              'cut_breath_section=preprocessing.cut_breath_section:main',
              'breath_meta=algorithms.breath_meta:main',
              'run_full_cohort=devscripts.run_full_cohort:main',
              'split_meta_file=preprocessing.split_meta_file:main',
              'stack_breath_files=preprocessing.stack_breath_files:main',
              'put_vent_bn_at_start=preprocessing.put_vent_bn_at_start:main',
              'tor3=algorithms.TOR3:main',
              'tor5=algorithms.tor5:main',
              'process_tor_patients=cohort_tools.tor_process_patients:main',
          ]
      },
      include_package_data=True,
      )
