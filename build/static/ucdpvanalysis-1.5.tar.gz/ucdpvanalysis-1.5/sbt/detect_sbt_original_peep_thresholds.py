"""
Hopefully will auto extract sbt region
SBT alg
2016-12-??: min_flow > -40 and max_pressure < 12 and peep < 7
"""

# VERSION 2 like tor5
from __future__ import division
import pandas as pd
from algorithms.constants import SBT_META_HEADER, META_HEADER
from algorithms.raw_utils import extract_raw
from algorithms.breath_meta import get_production_breath_meta
from utilikilt.oz import create_output_path
from utilikilt.custom_time import CreateStopwatch
from algorithms.tor5 import flushArray
import csv
import numpy as np
from argparse import ArgumentParser
import time
import os
import glob
import algorithms.breath_meta as bm

SBT_OUT_HEADER = ["relBN", "ventBN", "rel_time", "abs_time"]
SBT_OUT_ROWS = ["start", "end"]
MIN_BREATH_THRESHOLD = 10
BREATHS_TO_IMPUTE = 1
save_breath_by_breath_to_csv = False
TIME_FORMAT_FROM_STACK = '%Y-%m-%d %H:%M:%S.%f'
TIME_FORMAT_FROM_RAW = '%Y-%m-%d %H-%M-%S.%f'

class SbtLearnThreshold:
    BN_counter = 0
    first_20_number = 0

    def __init__(self, SBT_META_HEADER):
        past_breaths_array = [SBT_META_HEADER]

    def add_breath(self):
        self.BN_counter += 1
        # print "BN", self.BN_counter

class SbtDetect:
    def __init__(self):
        column_names = [
            ['region_number'] + ['bn_length'] + ['start'] * 4 + ['end'] * 4,
            ['region_number'] + ['bn_length'] + ['relBN', 'ventBN', 'rel_time', 'abs_time'] * 2]
        # consider making empty rows first for speed
        self.sbt_counter = 0
        self.non_sbt_counter = 0
        self.was_SBT = False
        self.total_sbt_counter = 0

        EVENT_COL_NAMES = ['relBN', 'ventBN', 'rel_time', 'abs_time']
        self.start_df = pd.DataFrame(columns=EVENT_COL_NAMES, index=np.arange(1, 1500))
        self.end_df = pd.DataFrame(columns=EVENT_COL_NAMES, index=np.arange(1, 1500))

        OTHER_COL_NAMES = ['region_number', 'bn_length', 'dur_sec', 'dur_ts']
        self.other_df = pd.DataFrame(columns=OTHER_COL_NAMES, index=np.arange(1, 1500))

        self.sbt_out = []

    def add_non_breath(self):
        self.non_sbt_counter += 1

    def add_breath(self, breath_meta_data):
        self.sbt_counter += 1
        self.was_SBT = True
        self.sbt_detected = True

        if self.sbt_counter == 1:
            self.start_breath_metadata = breath_meta_data

    def add_sbt_region(self, breath_meta_data, breath_threshold=0):
        "adds data for breath"
        sbt_length = int(breath_meta_data["BN"] - self.start_breath_metadata["BN"])
        if sbt_length > breath_threshold:
            self.total_sbt_counter += 1
            idx = self.total_sbt_counter
            self.other_df.loc[idx, 'region_number'] = idx
            self.other_df.loc[idx, 'bn_length'] = sbt_length
            self.start_df.loc[idx, :] = self.get_breath_time_data(self.start_breath_metadata)
            self.end_df.loc[idx, :] = self.get_breath_time_data(breath_meta_data)

    def get_breath_time_data(self, breath_meta_data):
        """gets relevant breath data to add to dataframe"""
        list_ = [
            breath_meta_data['BN'], breath_meta_data['ventBN'],
            breath_meta_data['rel_time_at_BS'], breath_meta_data['abs_time_at_BS']]
        return list_

    def finalize_initial_detection(self, start_datetime=0):
        """
        removes null values and concatenates
        2017-03-02 12:53:12: original
        2017-03-02 12:53:21: works on separated dfs
        2017-03-03 22:29:07: fix bug with time_format
        2017-03-04 22:29:23: add clause for files with no detection
        """
        start_df = self.start_df.copy()
        end_df = self.end_df.copy()
        other_df = self.other_df.copy()
        rows_with_data = other_df.loc[:, 'region_number'].notnull()

        start_df = start_df.loc[rows_with_data]
        end_df = end_df.loc[rows_with_data]
        other_df = other_df.loc[rows_with_data]

        if start_df.empty:
            self.sbt_out = pd.concat([other_df, start_df, end_df], axis=1, keys=['other', 'start', 'end'])
            return

        if start_datetime != 0:
            start_df['abs_time'] = pd.to_timedelta(start_df['rel_time'], unit='s') + start_datetime
            end_df['abs_time'] = pd.to_timedelta(end_df['rel_time'], unit='s') + start_datetime
            time_format = TIME_FORMAT_FROM_STACK
        # elif type(time_stamps) == pd.tslib.Timestamp: 
        #     time_format = TIME_FORMAT_FROM_RAW
        elif ':' in start_df.loc[1, 'abs_time']:
            time_format = TIME_FORMAT_FROM_STACK
        else:
            time_format = TIME_FORMAT_FROM_RAW

        start_df['abs_time'] = pd.to_datetime(start_df['abs_time'], format=time_format)
        end_df['abs_time'] = pd.to_datetime(end_df['abs_time'], format=time_format)
        other_df['dur_ts'] = end_df['abs_time'] - start_df['abs_time']
        other_df['dur_sec'] = end_df['rel_time'] - start_df['rel_time']

        self.start_df = start_df
        self.end_df = end_df
        self.other_df = other_df        

        self.sbt_out = pd.concat([other_df, start_df, end_df], axis=1, keys=['other', 'start', 'end'])


    def impute_breaths(self, breaths_to_impute):
        """
        2016-??-??: Original version
        2017-03-01: Begin rewrite from scratch
        2017-03-02:
        """

        rows_to_drop = []
        for idx in df.index:
            if idx == df.index[0]:
                pass
            else:
                first_ts = df.loc[idx-1,('end','abs_time')]
                second_ts = df.loc[idx, ('start','abs_time')]
                ts_diff = second_ts - first_ts
                print "({},{}) : {}".format(idx-1, idx, ts_diff)
                if ts_diff < impute:
                    rows_to_drop.append(idx)
        df.loc[:,('other','rows_to_drop')] = 0
        df.loc[rows_to_drop,('other','rows_to_drop')] = 1
        # sbt_out = self.sbt_out
        # final = sbt_out.copy()
        # # orig_idx = 1
        # #  breaths_to_impute = []
        # rows_to_drop = []
        # for idx in sbt_out.index:
        #     #print idx
        #     if idx == 1:
        #         region_1_end_ventBN = final.loc[idx, ('end', 'ventBN')]
        #     else:
        #         print idx-1, idx
        #         region_2_start_ventBN = final.loc[idx, ('start', 'ventBN')]
        #         breath_gap = int(region_2_start_ventBN - region_1_end_ventBN)
        #         print breath_gap
        #         # if breath_gap <= 2:
        #         #     print "<=2"
        #         #     pass
        #         # else:
        #         #     print ">2"
        #         #     # sets up new start
        #         region_1_end_ventBN = final.loc[idx, ('start', 'ventBN')]



        # while idx < final.index[-1]:
        #     # print idx, orig_idx, final.index[-1]
        #     region_1_end_ventBN = final.loc[idx, ('end', 'ventBN')]
        #     region_2_start_ventBN = final.loc[idx + 1, ('start', 'ventBN')]
        #     breath_gap = int(region_2_start_ventBN - region_1_end_ventBN)
        #     # region_1_length = final.loc[idx, ('bn_length', 'bn_length')]
        #     # if region_1_length <= 10:
        #     if breath_gap >= breaths_to_impute:
        #         region_2_end_info = final.loc[idx + 1, ('end',)].tolist()
        #         final.loc[idx, ('end',)] = region_2_end_info
        #         new_start = final.loc[idx, ('start', 'ventBN')]
        #         new_end = final.loc[idx, ('end', 'ventBN')]
        #         final.loc[idx, ('bn_length', 'bn_length')] = int(new_end - new_start)
        #         final.drop(idx + 1, inplace=True)
        #         final.index = range(1, len(final) + 1)
        #         orig_idx += 1
        #     else:
        #         idx += 1
        #         orig_idx += 1
        self.final_sbt_detection = final


# this could be added to the class for cleaner code
def detect_possible_sbt_regions(raw_generator, MIN_BREATH_THRESHOLD, 
                                MIN_FLOW_THRESHOLD, IPAUC_CEILING, PEEP_CEILING,
                                start_datetime=0):
    """
    initial detection
    2017-03-01: created from detect sbt region
    """
    sbt_detect = SbtDetect()
    for breath_data in raw_generator:
        breath_meta_data = pd.Series(
            get_production_breath_meta(breath_data),
            index=META_HEADER)
        x0_index = breath_meta_data['x0_index']
        # iFlow = breath_data['flow'][:x0_index]
        # eFlow = breath_data['flow'][x0_index:]
        iPressure = breath_data['pressure'][:x0_index]
        ePressure = breath_data['pressure'][x0_index:]


        #max_pressure = breath_meta_data['maxP']
        #min_flow = breath_meta_data['minF']
        #ipauc = breath_meta_data['ipAUC']
        peep = breath_meta_data['PEEP']
        if len(iPressure) >= 15:
            likely_pressure_plateau = np.mean(iPressure[5:-5])  # find avg insp pressure with cutting off incr/decr
        elif len(iPressure) > 0 and len(iPressure) < 15:
            likely_pressure_plateau = np.mean(iPressure)
        else:
            likely_pressure_plateau = max_pressure
            # import pdb
            # pdb.set_trace()


        if len(ePressure) >= 15:
            likely_peep = np.mean(ePressure[5:-5])  # find avg insp pressure with cutting off incr/decr
        elif len(ePressure) > 0 and len(ePressure) < 15:
            likely_peep = np.mean(ePressure)
        else:
            pass
            likely_peep = peep
            # import pdb
            # pdb.set_trace()        


        #flow_range = breath_meta_data['maxF'] - breath_meta_data['minF']
        pressure_over_peep = likely_pressure_plateau - likely_peep

        # if breath_meta_data['BN'] >1680:
        #     import pdb
        #     pdb.set_trace()
        # start detection
        # if min_flow > -40 and max_pressure < 12 and peep < 7:
        # if min_flow > MIN_FLOW_THRESHOLD and ipauc < IPAUC_CEILING and peep < PEEP_CEILING:
        if pressure_over_peep < 10: #and peep < PEEP_CEILING:
            sbt_detect.add_breath(breath_meta_data)
            sbt_detect.non_sbt_counter = 0
        # elif (sbt_detect.sbt_counter > 10) & (ipauc < IPAUC_CEILING) & (peep < PEEP_CEILING) & (pressure_over_peep < 10):
        #     sbt_detect.add_breath(breath_meta_data)
        #     sbt_detect.non_sbt_counter = 0                
        #     # import pdb
        #     # pdb.set_trace()
        else:
            sbt_detect.sbt_counter = 0
            sbt_detect.add_non_breath()

        if sbt_detect.sbt_counter == 0 and sbt_detect.non_sbt_counter == 1 and sbt_detect.was_SBT == True:
            sbt_detect.add_sbt_region(breath_meta_data, MIN_BREATH_THRESHOLD)
    sbt_detect.finalize_initial_detection(start_datetime)
    return sbt_detect


def sbt_one_file(waveform_csv, printout=True):
    """
    wrapper for detect_possible_sbt_regions, adds timer
    2017-03-02
    """
    rel_bn_interval = []
    vent_bn_interval = []
    MIN_BREATH_THRESHOLD = 10

    stopwatch = CreateStopwatch()
    raw_generator = extract_raw(open(waveform_csv, "rU"), False, rel_bn_interval=rel_bn_interval,
        vent_bn_interval=vent_bn_interval)
    if printout:
        print stopwatch.lap("\traw gen 1")
    detect = detect_possible_sbt_regions(raw_generator, MIN_BREATH_THRESHOLD, -80, 10, 10)
    if printout:
        print stopwatch.lap("\tinitial sbt detect")
    return detect


def sbt_mult_file(waveform_folder, minute_threshold, 
                  printout=True, print_detailed=True,
                  filtered=True):
    """
    detect possible sbts in multiple files
    2017-03-02
    """
    assert os.path.isdir(waveform_folder)
    file_paths = glob.glob(os.path.join(waveform_folder, "*"))
    stopwatch = CreateStopwatch()
    if printout:
         print "\nfolder: {}".format(waveform_folder)
    list_of_dfs = []
    for index, file_ in enumerate(file_paths):
        if printout:
            percent_done = index / len(file_paths) * 100
            print" {} %% done".format(round(percent_done,1))
        if print_detailed:
            print "\tfile #: {},\n \tfile_name: {}".format(index, os.path.basename(file_))
        # try:
        output_file = sbt_one_file(file_, print_detailed)
        # except:
        #     print "="*30
        #     print "\tthere is an issue with this file: \n\t{}".format(file_)
        #     print "="*30
        list_of_dfs.append(output_file.sbt_out)

    file_number = ['file{}'.format(i) for i in range(len(list_of_dfs))]
    file_names = [os.path.basename(file_path) for file_path in file_paths]
    file_name_dict = {'file{}'.format(index): os.path.basename(file_path) for index, file_path in enumerate(file_paths)}


    try:
        combined = pd.concat(list_of_dfs, axis=0, keys=file_number)
        durations = combined.loc[:, ('other', 'dur_ts')]
        if filtered:
            combined_filtered = combined.loc[durations > np.timedelta64(minute_threshold, 'm'), :].copy()
        else:
            combined_filtered = []
        # import pdb
        # pdb.set_trace()
    except:
        print "NO SBTs detected in {}".format(waveform_folder)
        pass

        combined = list_of_dfs
        combined_filtered = combined
        import pdb
        pdb.set_trace()
    if printout:
        print " 100% done"
        print stopwatch.lap("time elapsed")
    return combined, combined_filtered, file_name_dict

def impute_df(df, imputation_threshold):
    """
    this is the start of a possible imputation alg based on time threshold
    2017-03-02
    """
    start_dfs = df.loc[:,'start']
    end_dfs = df.loc[:,'end']
    other_dfs = df.loc[:,'other']

    file_index = df.index.get_level_values(0).unique()
    for index in file_index:
        if index == file_index[0]:
            pass
        else:
            print end_dfs.loc[index-1,:].tail(1)
            print start_dfs.loc[index,:].head(1)

            first_ts = end_dfs.loc[index-1,'abs_time'].tail(1).values
            second_ts = start_dfs.loc[index, 'abs_time'].head(1).values
            time_diff = pd.to_timedelta(second_ts - first_ts)

            if time_diff < imputation_threshold:
                print time_diff
                print (index - 0.5)


            print ''
            
# imputation_threshold = np.timedelta64(1,'m')
# impute_df(df, imputation_threshold)


def detect_sbt_region(raw_generator, SBT_META_HEADER, MIN_BREATH_THRESHOLD, BREATHS_TO_IMPUTE, output_csv, save_breath_by_breath_to_csv):

    with open(output_csv, 'wb') as out:
        csv_sbt_breath_meta = csv.writer(out, delimiter=",")

        if save_breath_by_breath_to_csv:
            matrix_sbt_breath_meta = flushArray(csv_sbt_breath_meta, SBT_META_HEADER)
        sbt_learn_threshold = SbtLearnThreshold(SBT_META_HEADER)
        sbt_detect = SbtDetect()
        for breath_data in raw_generator:
            breath_meta_data = pd.Series(
                get_production_breath_meta(breath_data),
                index=META_HEADER)
            # x0_index = breath_meta_data['x0_index']
            # iFlow = breath_data['flow'][:x0_index]
            # eFlow = breath_data['flow'][x0_index:]
            # iPressure = breath_data['pressure'][:x0_index]
            # ePressure = breath_data['pressure'][x0_index:]

            max_pressure = breath_meta_data['maxP']
            min_flow = breath_meta_data['minF']
            ipauc = breath_meta_data['ipAUC']
            peep = breath_meta_data['PEEP']

            # start detection
            # if min_flow > -40 and max_pressure < 12 and peep < 7:
            if min_flow > -80 and ipauc < 10 and peep < 10:
                sbt_detect.add_breath(breath_meta_data)
                sbt_detect.non_sbt_counter = 0
            else:
                sbt_detect.sbt_counter = 0
                sbt_detect.add_non_breath()

            if sbt_detect.sbt_counter == 0 and sbt_detect.non_sbt_counter == 1 and sbt_detect.was_SBT == True:
                sbt_detect.add_sbt_region(breath_meta_data, MIN_BREATH_THRESHOLD)

            if save_breath_by_breath_to_csv:
                matrix_sbt_breath_meta.addRow(breath_meta_data.tolist() + [sbt])

            sbt_learn_threshold.add_breath()

        sbt_detect.impute_breaths(BREATHS_TO_IMPUTE)
        # print sbt_detect.sbt_out
        # print sbt_detect.final_sbt_detection
        if not save_breath_by_breath_to_csv:
            pass
            # make sure to delete csv file.

        # determine the largest region by sorting by bn_length 
        # another name could be largest_sbt_region_post_imputation
        largest = sbt_detect.final_sbt_detection.loc[1, ]
        # insert

        sbt_start_ventBN = largest['start', 'ventBN']
        sbt_end_ventBN = largest['end', 'ventBN']

        # could add tail chopping right here
    return [sbt_start_ventBN, sbt_end_ventBN]


def add_shifted_later(grouped, column, group_diff=1):
    shifted= grouped[column].tolist()[group_diff:] + grouped[column].tail(group_diff).tolist()
    new_col_name = 'delta+{}_{}'.format(str(group_diff), str(column))
    grouped[new_col_name] = shifted - grouped[column]


def add_shifted_earlier(grouped, column, group_diff=1):
    
    shifted= grouped[column].head(group_diff).tolist() + grouped[column].tolist()[:len(grouped)-group_diff] 
    new_col_name = 'delta-{}_{}'.format(str(group_diff), str(column))
    grouped[new_col_name] = grouped[column] - shifted


def get_grouped_bm_data(df, group_size):
    df['group']=df.index.map(lambda x: int(x/group_size)) # same as above, perhaps more understandable?

    # df['group']=df['BN'] // 10 # divides into group of 10 (divide BN by number then take whole integer)
    #df['group']=df['BN'].apply(lambda x: int(x/10)) # same as above, perhaps more understandable?
    #df.to_csv(os.path.join(output_dir, os.path.basename(waveform_csv).replace('.csv', '_breath_meta.csv')))

    df2 = df.set_index('group')
    group_first_index = df2['BN'].groupby(level='group').min() - 1
    group_first_ts = df2['abs_time_at_BS'].groupby(level='group').min()
    group_avg_ipauc = df2['ipAUC'].groupby(level='group').mean()
    group_avg_peep= df2['PEEP'].groupby(level='group').mean()
    group_avg_min_flow= df2['minF'].groupby(level='group').mean()
    group_var_RR= df2['inst_RR'].groupby(level='group').var()
    
    list_to_concat = [group_first_index, group_first_ts, group_avg_peep, group_avg_ipauc, 
                      group_avg_min_flow, group_var_RR]
    keys = ['first_index','first_bs_ts', 'avg_peep','avg_ipauc', 'avg_min_flow','var_RR']
    grouped = pd.concat(list_to_concat, axis=1, keys=keys)

    add_shifted_later(grouped, 'avg_ipauc', 1)
    #get_shifted_earlier(grouped, 'avg_ipauc', 2)
    add_shifted_later(grouped, 'avg_ipauc', 3)
    add_shifted_later(grouped, 'avg_min_flow', 1)
    #get_shifted_earlier(grouped, 'avg_min_flow', 2)
    add_shifted_later(grouped, 'avg_min_flow', 3)
    add_shifted_later(grouped, 'var_RR', 1)
    #get_shifted_earlier(grouped, 'avg_min_flow', 2)
    add_shifted_later(grouped, 'var_RR', 3)
    
    
    add_shifted_earlier(grouped, 'avg_ipauc', 1)
    #get_shifted_earlier(grouped, 'avg_ipauc', 2)
    add_shifted_earlier(grouped, 'avg_ipauc', 3)
    add_shifted_earlier(grouped, 'avg_min_flow', 1)
    #get_shifted_earlier(grouped, 'avg_min_flow', 2)
    add_shifted_earlier(grouped, 'avg_min_flow', 3)

    # shifted_ipauc = group_avg_ipauc.tolist()[1:] + group_avg_ipauc.tail(1).tolist()
    # grouped['delta_avg_ipauc'] = shifted_ipauc - grouped['avg_ipauc'] 
    # shifted_min_flow = group_avg_min_flow.tolist()[1:] + group_avg_min_flow.tail(1).tolist()
    # grouped['delta_avg_min_flow'] = shifted_min_flow - grouped['avg_min_flow']
    return grouped

def find_possible_sbt_by_group(waveform_file_path, group_size=20):
    breath_meta_array = bm.get_file_breath_meta(waveform_file_path)
    bm_df = pd.DataFrame(breath_meta_array[1:], columns=breath_meta_array[0])
    df = bm_df.copy()
    df['abs_time_at_BS'] = pd.to_datetime(df['abs_time_at_BS'], format= TIME_FORMAT_FROM_RAW)
    grouped2 = get_grouped_bm_data(df, group_size=group_size)
    return df, grouped2

def calc_rsbi(row):
    """respiratory shallow breathing index"""
    return row['inst_RR'] / (row['tvi'] / 1000)  # need to convert ml/min -> L/min

def calc_time_delta(initial_ts, later_ts):
    """calculate timestamp for bs"""
    later_ts = datetime.strptime(later_ts, FINAL_TS_FORMAT)
    initial_ts = datetime.strptime(initial_ts, FINAL_TS_FORMAT)
    return str(later_ts - initial_ts)


def extract_rsbi_related_calculations():
    pass


##### merge functions
def merge_adj(df, connect_adj_threshold):
    """from 20170307_3_sbt_alg3.ipynb"""
    if ('other', 'merged') not in df.columns:
        df[('other', 'merged')] = 0
        df[('other', 'merged_next_file')] = 0
    drop_list_for_df = []
    pilot_list = df.index.get_level_values(0).unique()
    new_df_list = []
    new_pt_list = []
    for idx, patient in enumerate(pilot_list):
        print idx, patient
        # import pdb
        # pdb.set_trace()
        subdf = df.loc[patient,:] #.copy()
        drop_list_for_pt,subdf = merge_adj_in_pt(subdf, patient, connect_adj_threshold)
        new_df_list.append(subdf)
        new_pt_list.append(patient)
        #df.loc[patient,:] = subdf
        # df.loc[patient] = subdf.values

#         print drop_list_for_df, drop_list_for_pt
        # import pdb
        # pdb.set_trace()
        drop_list_for_df.extend(drop_list_for_pt)
    print drop_list_for_df
    #df.drop(drop_list_for_df,inplace=True)
    new_df = pd.concat(new_df_list, keys=new_pt_list)
    new_df.drop(drop_list_for_df, inplace=True)
    return new_df

def merge_adj_in_pt(subdf, patient, connect_adj_threshold):
    """from 20170307_3_sbt_alg3.ipynb"""
    drop_list_for_pt=[]
    patient_file_list = subdf.index.get_level_values(0).unique()
    for idx, file_ in enumerate(patient_file_list):
        drop_list = merge_adj_in_subfile(subdf, patient, file_, connect_adj_threshold)
        drop_list_for_pt.extend(drop_list)
    return drop_list_for_pt, subdf


def merge_adj_in_subfile(subdf, patient, file_, connect_adj_threshold):
    """from 20170307_3_sbt_alg3.ipynb"""
    drop_list = []
    file_list = subdf.loc[file_,].index.copy()
    reversed_file_list = file_list[::-1]
    # print reversed_file_list
    for region_idx, region in enumerate(reversed_file_list):

        if region_idx == 0:
            pass
        else:
            # if patient == '0320RPI2320160915':
            #     import pdb
            #     pdb.set_trace()
            row1 = subdf.loc[(file_, reversed_file_list[region_idx]), :].copy()
            row2 = subdf.loc[(file_, reversed_file_list[region_idx-1]), :].copy()
            
            row1_end_ts = row1[('end','abs_time')]
            row2_start_ts = row2[('start','abs_time')]
            
            delta = row2_start_ts - row1_end_ts
            # import pdb
            # pdb.set_trace()

            if delta < connect_adj_threshold:
                # print delta
                # print pd.concat([row1, row2], axis=1)
                new_row = calc_new_row(row1, row2)   
                subdf.loc[(file_, reversed_file_list[region_idx]), :] = new_row
                drop_list.append((patient, file_, row2[('other','region_number')]))
    return drop_list

def calc_new_row(row1, row2):
    """moved to sbt.detect sbt"""
    row1[('other', 'merged')] = 1
    row1['end'] = row2['end']
    row1[('other', 'dur_sec')] = row1[('other', 'dur_sec')] + row2[('other', 'dur_sec')]
    row1[('other', 'dur_ts')] = row1[('end', 'abs_time')] - row1[('start', 'abs_time')]
    return row1

# imptuations
def merge_edge_in_one_pt(subdf, connect_adj_file_minute_threshold):
    patient_file_list = subdf.index.get_level_values(0).unique()
    for idx, file_ in enumerate(patient_file_list):
        if idx == 0:
            pass
        else:
            patient_sub_df_a = subdf.loc[patient_file_list[idx-1],:]
            patient_sub_df_b = subdf.loc[patient_file_list[idx],:]
            a_last_index = patient_sub_df_a.index[-1]
            b_first_index = patient_sub_df_b.index[0]

            last_ts_of_file_a = patient_sub_df_a.loc[a_last_index,('end','abs_time')]
            first_ts_of_file_b = patient_sub_df_b.loc[b_first_index,('start','abs_time')]

            delta = first_ts_of_file_b - last_ts_of_file_a
            file_a_numb = int(patient_file_list[idx-1].lstrip('file'))
            file_b_numb = int(patient_file_list[idx].lstrip('file'))

            meets_time_threshold = delta < pd.to_timedelta(connect_adj_file_minute_threshold,'m')
            adjacent_file = (file_b_numb - file_a_numb) == 1
            if meets_time_threshold and adjacent_file:
               # print patient_file_list[idx-1], patient_file_list[idx]
               # print delta
               # print last_ts_of_file_a
               # print first_ts_of_file_b
               # print pd.concat([patient_sub_df_a.loc[a_last_index, :], patient_sub_df_b.loc[b_first_index, :]], axis=1) 
                last_row = patient_sub_df_a.loc[a_last_index, :].copy()
                first_row = patient_sub_df_b.loc[b_first_index, :].copy()
               
                new_row = calc_new_row(last_row, first_row)
                new_row[('other','merged_next_file')] = True 
                patient_sub_df_a.loc[a_last_index, :] = new_row  
                # print patient_sub_df_a.loc[a_last_index, :] 
                # print len(subdf.loc[patient_file_list[idx-1],:])
                # print len(subdf.loc[patient_file_list[idx],:])
                subdf.drop([(patient_file_list[idx], b_first_index)], inplace=True)
                #subdf.drop[].loc[patient_file_list[idx],:].drop(b_first_index,)

                # print len(subdf.loc[patient_file_list[idx-1],:])
                # print len(subdf.loc[patient_file_list[idx],:])         
    return subdf

def merge_edge_of_files(merged, pilot_list, connect_adj_file_minute_threshold):
    edited = merged.copy()
    edited[('other','merged')] = False
    edited[('other','merged_next_file')] = False
    list_of_dfs = []
    for patient in pilot_list:
        subdf = edited.loc[patient,:].copy()
        orig_len =  len(subdf)
        merged_subdf = merge_edge_in_one_pt(subdf, connect_adj_file_minute_threshold)
        list_of_dfs.append(merged_subdf)
        
        # may need to deletion mech for pilot_list if something is empty
        
    edited = pd.concat(list_of_dfs, keys=pilot_list)
#         print len(merged_subdf), '\n'
        
        
#         if orig_len != len(merged_subdf):
#             import pdb
#             pdb.set_trace()
#         edited.loc[patient,:] = merged_subdf
    
    return edited
    


def  detect_mult_from_pilot_list(pilot_list, waveform_folder, minute_threshold, printout=True, print_detailed=True, filtered=True):
    """moved to sbt.detect_sbt
    ex:
        pilot_list = merged_manual_df[('name','patient')].get_values()
        pilot_list=pilot_list[0:3]
        sw = CreateStopwatch()
        merged1, merged2, list_of_file_dicts = detect_mult_from_pilot_list(pilot_list, waveform_folder, 15)
        sw.lap("process 3")
    """
    print "this is with pressure_over_peep < 10"
    initial_detections_list_of_dfs = []
    filtered_detections_list_of_dfs = []
    list_of_file_dicts = []

    assert os.path.isdir(waveform_folder)
    for idx, patient in enumerate(pilot_list):
        patient_waveform_folder = os.path.join(waveform_folder,patient)
        assert os.path.isdir(patient_waveform_folder)
        print idx, patient
        try:
            tempdf1, tempdf2, file_dict = sbt_mult_file(
                patient_waveform_folder, minute_threshold=minute_threshold, 
                printout=printout, print_detailed=print_detailed, filtered=filtered)

            initial_detections_list_of_dfs.append(tempdf1)
            if filtered:
                filtered_detections_list_of_dfs.append(tempdf2)
            list_of_file_dicts.append(file_dict)
        except:
            print "ERROR!!!!need to repeat {}".format(patient)

    try:
        merged = pd.concat(initial_detections_list_of_dfs, keys=pilot_list, names=['patient','file','region'])
        if filtered:
            merged2 = pd.concat(filtered_detections_list_of_dfs, keys=pilot_list, names=['patient','file','region'])
        else:
            merged2 = filtered_detections_list_of_dfs
    except:
        import pdb
        pdb.set_trace()

    return merged, merged2, list_of_file_dicts

if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("-waveform_csv", "-w", help="raw waveform file")
    parser.add_argument("-output_csv", "-o", help="detect sbt ranges")
    args = parser.parse_args()

    waveform_csv = args.waveform_csv

    # waveform_csv = r"/Users/monica/Box Sync/UCD/sandbox2016/4_fall/20161006_SBT/SBT_test_data/0_raw3_copy/0309RPI3020160907-rpi30-2016-09-19-10-11-18.209902.csv"
    # waveform_csv = r"/Users/monica/Box Sync/UCD/sandbox2016/4_fall/20161006_SBT/SBT_test_data/1_output_combine_files/sbt_raw3_combine_all_row_timestamps_shorter.csv"

    # output_csv = r"/Users/monica/Box Sync/UCD/sandbox2016/4_fall/20161006_SBT/SBT_test_data/5_sbt_detect/test_sbt_add_on6.csv"
    output_csv = args.output_csv

    rel_bn_interval = []
    vent_bn_interval = [19167, 19689]
    vent_bn_interval = []



    # output_subdir = r"/Users/monica/Box Sync/UCD/sandbox2016/4_fall/20161006_SBT/SBT_test_data/5_sbt_detect/"

    # outputPath = create_output_path(
    #         waveform_csv, output_subdir, output_name_override,
    #         output_suffix, rel_bn_interval=rel_bn_interval)

   
    stopwatch = CreateStopwatch()

    raw_generator = extract_raw(
        open(waveform_csv, "rU"), False, rel_bn_interval=rel_bn_interval,
        vent_bn_interval=vent_bn_interval)
    stopwatch.lap("raw gen 1")

    if vent_bn_interval == []:
        vent_bn_interval = detect_sbt_region(
            raw_generator, SBT_META_HEADER, MIN_BREATH_THRESHOLD,
            BREATHS_TO_IMPUTE, output_csv, save_breath_by_breath_to_csv)
        stopwatch.lap("detect sbt")

########################
# calculate RSBI stuff
#########################
    sbt_generator = extract_raw(
        open(waveform_csv, "rU"), False,  # rel_bn_interval=rel_bn_interval,
        vent_bn_interval=vent_bn_interval)
    stopwatch.lap("sbt generator")

    sbt_breath_meta_dfs = [
        pd.Series(get_production_breath_meta(breath_data),
                  index=META_HEADER) for breath_data in sbt_generator]
    sbt_breath_meta_df = pd.concat(sbt_breath_meta_dfs, axis=1).transpose()
    sbt_breath_meta_df.loc[522, 'rel_time_at_BE'] - sbt_breath_meta_df.loc[1, 'rel_time_at_BS']
    sbt_breath_meta_df['inst_rsbi'] = sbt_breath_meta_df.apply(calc_rsbi, axis=1)

    from datetime import datetime, timedelta

    FINAL_TS_FORMAT = "%Y-%m-%d %H:%M:%S.%f"
    initial_ts = sbt_breath_meta_df.loc[0, 'abs_time_at_BS']
    sbt_breath_meta_df['sbt_rel_time_at_bs'] = sbt_breath_meta_df['abs_time_at_BS'].apply(lambda x: calc_time_delta(initial_ts, x))

    stopwatch.lap("2nd sbt meta")

    # area for calculating new factors per breath
    for breath_data in sbt_generator:
        breath_meta_data = pd.Series(
            get_production_breath_meta(breath_data),
            index=META_HEADER)
        x0_index = breath_meta_data['x0_index']
        iFlow = breath_data['flow'][:x0_index]
        eFlow = breath_data['flow'][x0_index:]
        iPressure = breath_data['pressure'][:x0_index]
        ePressure = breath_data['pressure'][x0_index:]
        # print breath_meta_data['ventBN']

    # overall new area
    time_elapsed = 0
    idx = 0

    second_ts = datetime.strptime(sbt_breath_meta_df.loc[1, 'abs_time_at_BS'], FINAL_TS_FORMAT)
    first_ts = datetime.strptime(sbt_breath_meta_df.loc[0, 'abs_time_at_BS'], FINAL_TS_FORMAT)
    delta = second_ts - first_ts
    print str(delta)

    RR_std_dev = sbt_breath_meta_df['inst_RR'].std()
    RR_variance = sbt_breath_meta_df['inst_RR'].var()
    # mean RSBI based on instantanous RSBI calculations
    mean_rsbi0 = sbt_breath_meta_df['inst_rsbi'].mean()
    mean_rsbi1 = sbt_breath_meta_df['inst_RR'].mean() / (sbt_breath_meta_df['tvi'].mean() / 1000)

    sbt_duration = sbt_breath_meta_df['sbt_rel_time_at_bs'][sbt_breath_meta_df.index[-1]]
    delta = datetime.strptime(sbt_duration, "%H:%M:%S.%f") - datetime.strptime("0:00:00.0", "%H:%M:%S.%f")
    # http://stackoverflow.com/questions/12155908/convert-datetime-since-a-given-date-to-minutes
    # maybe change to this approach
    sbt_duration_in_minutes = delta.total_seconds() / 60
    mean_rsbi2 = (len(sbt_breath_meta_df) / sbt_duration_in_minutes) / ((sbt_breath_meta_df['tvi'].mean()) / 1000)

    df = sbt_breath_meta_df
    df_at_1 = df[(df['sbt_rel_time_at_bs'] >= '0:01:00') & (df['sbt_rel_time_at_bs'] < '0:02:00')]
    rsbi_at1to2 = len(df_at_1) / ((df_at_1['tvi'].mean()) / 1000)
    # df_at_1['inst_rsbi'].mean()

    df_at_30 = df[(df['sbt_rel_time_at_bs'] >= '0:30:00') & (df['sbt_rel_time_at_bs'] < '0:31:00')]
    rsbi_at30to31 = len(df_at_30) / ((df_at_30['tvi'].mean()) / 1000)

    print rsbi_at1to2
    print rsbi_at30to31
# df_at_30['inst_rsbi'].mean()