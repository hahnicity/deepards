"""
Hosts common functions for working with ehr data
created 2017-02-24 17:48:06
"""
import csv
from os.path import join


class pseudo:
    """
    """
    def __init__(self, input_subdir, pt_id_filename):
        self.input_subdir = input_subdir
        self.pt_id_filename = pt_id_filename
        self.load_ids()

    def load_ids(self):
        """
        loads ID data into a dictionary (2017-02-20)

        2017-02-24: moved from determine_sbt_time.py
        """
        path_pt_ids = join(self.input_subdir, self.pt_id_filename)
        with open(path_pt_ids, mode='r') as infile:
            reader = csv.reader(infile)
            id_dict = {rows[1]: rows[0] for rows in reader}
        self.id_dict = id_dict

        self.reverse_dict = {v: k for k, v in id_dict.iteritems()}

    def anonymize_ids(
            self, df, old_id_column, new_id_column, drop_col=True):
        """
        replaces csn with rpi-based unique identifier (2017-02-20)

        2017-02-24: moved from determine_sbt_time.py
        """
        df[new_id_column] = df[old_id_column].astype(str)
        df[new_id_column].replace(self.id_dict, inplace=True)  # creates new col
        if drop_col:
            df.drop(old_id_column, axis=1, inplace=True)  # removes old column
        return

    def deidentify_ids(self, array):
        """
        2017-02-28: written
        """
        output = []
        for i, j in enumerate(array):
            print i, j, self.reverse_dict[j]
            output.append(self.reverse_dict[j])
        return output

