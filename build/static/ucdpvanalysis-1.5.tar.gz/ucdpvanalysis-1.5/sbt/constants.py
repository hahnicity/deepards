"""
constants for all functions in analytics/sbt
"""
ANON_ID_NAME = 'PATIENT_RPI_ID'