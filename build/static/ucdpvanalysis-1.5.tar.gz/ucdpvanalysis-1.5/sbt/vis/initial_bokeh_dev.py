"""
test vis
"""
import os
import utilikilt.oz as oz
from argparse import ArgumentParser
import glob
import algorithms.breath_meta as bm
import pandas as pd
import datetime
import numpy as np
import bokeh

from bokeh.plotting import figure, show, output_file, ColumnDataSource
from bokeh.sampledata.iris import flowers
from bokeh.charts import Scatter, output_file, show

from nose.tools import nottest
@nottest

def main(input_subdir, output_subdir='', patient_choice=''):
    # notes for start new vis

    # setup_dir(input_subdir, output_subdir)
    raw_subdir = os.path.join(input_subdir, 'raw_waveforms', patient_choice)
    assert os.path.isdir(raw_subdir)
    raw_waveforms_file_paths = glob.glob(os.path.join(input_subdir, 'raw_waveforms', patient_choice, "*.csv"))
    sub_files_dict = {os.path.basename(file_path):file_path for file_path in raw_waveforms_file_paths}
    breath_meta_file_paths = glob.glob(os.path.join(input_subdir, 'breath_meta', patient_choice, "*.csv"))
    bm_files_dict = {os.path.basename(file_name): file_path for file_name, file_path in zip(raw_waveforms_file_paths, breath_meta_file_paths)}
    file_names = [os.path.basename(file_path) for file_path in raw_waveforms_file_paths]
    file_name = file_names[5]
    df = pd.read_csv(bm_files_dict[file_name], index_col=0)
    source = ColumnDataSource(data=df)
    #tools = 'crosshair, xpan, xwheel_zoom, resize, reset'
    # tools = [bokeh.models.ResetTool(), bokeh.models.ResizeTool(), 
    #         bokeh.models.WheelZoomTool(), bokeh.models.CrosshairTool(), bokeh.models.HoverTool()]
    hover = bokeh.models.HoverTool(
        tooltips=[("index", "$index"),("ts", "@abs_time_at_BS"), ("BN","@BN"), ("ventBN","@ventBN"),
        ("peep","@PEEP"), ("ipauc","@ipAUC"), ("minF","@minF")]
        )
    tools = [hover, 'xpan, xwheel_zoom,reset, box_zoom,resize, box_select']
    # wheel_zoom = bokeh.models.WheelZoomTool(dimensions="width")
    # p = figure(tools=[hover, 'xpan, xwheel_zoom,reset, box_zoom,resize'], active_scroll='xwheel_zoom', active_drag='xpan',
    #     y_range=bokeh.models.Range1d(-5,20), title=file_name)
    p = figure(tools=tools, active_scroll='xwheel_zoom', active_drag='xpan',
        y_range=bokeh.models.Range1d(-5,20), title=file_name, plot_height=250)
    p.toolbar.active_scroll = "auto"
    p.toolbar.active_drag = "auto"
    p.line('rel_time_at_BS', 'PEEP', source=source, color='pink', legend='-PEEP')
    p.line('rel_time_at_BS', 'ipAUC', source=source, color='orange', legend='-ipAUC')


    p2 = figure(# tools=tools, active_scroll='xwheel_zoom', active_drag='xpan',
        y_range=bokeh.models.Range1d(-100,10), title=file_name, x_range=p.x_range, plot_height=250)
    p2.line('rel_time_at_BS', 'minF', source=source, color='blue', legend='-minF')
    # add these dashes or else weird things happen (label by color), http://bokeh.pydata.org/en/latest/docs/user_guide/annotations.html

    grid_ = bokeh.layouts.gridplot([[p], [p2]])
    #p.line('abs_time_at_BS', 'PEEP', source=source)
    # p.circle('rel_time_at_BS', 'PEEP', size=3, source=source)
   # p.line(df['rel_time_at_BS'],df['PEEP'])
    # p = Scatter(df, x='ipAUC', y='minF')

    output_file(os.path.join(input_subdir, "output","20170305_{}.html".format(file_name)))
    #show(p)
    show(grid_)
    # colormap = {'setosa': 'red', 'versicolor': 'green', 'virginica': 'blue'}
    # colors = [colormap[x] for x in flowers['species']]

    # p = figure(title = "Iris Morphology")
    # p.xaxis.axis_label = 'Petal Length'
    # p.yaxis.axis_label = 'Petal Width'

    # p.circle(flowers["petal_length"], flowers["petal_width"],
    #          color=colors, fill_alpha=0.2, size=10)
    

    # import pdb
    # pdb.set_trace()


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("-input_dir", "-i", help="Input directory")
    parser.add_argument("-output_dir", "-o", default='', help="Output directory")
    parser.add_argument("-patient_choice", "-pt", default='', help="name of patient directory")
#    p#arser.add_argument("-csv_name", "-c", default="", help="output CSV Name")

    args = parser.parse_args()
    main(args.input_dir, args.output_dir, args.patient_choice)