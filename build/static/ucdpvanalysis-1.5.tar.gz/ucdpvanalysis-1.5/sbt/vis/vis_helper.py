"""
Created 2017-03-03 06:59:55

"""

import os
import utilikilt.oz as oz
from argparse import ArgumentParser
import glob
import algorithms.breath_meta as bm
import pandas as pd
import datetime
import numpy as np

input_subdir = r'/Users/monica/Box Sync/UCD/sandbox2017/1_winter/20170113_sbt/20170303_vis'
# output_subdir = r'/Users/monica/Box Sync/UCD/sandbox2017/1_winter/20170113_sbt/output/output1'
# PATIENT_CHOICE = '0309RPI3020160907'
# PATIENT_CHOICE = '0306RPI3520160830'
TIME_FORMAT_FROM_STACK = '%Y-%m-%d %H:%M:%S.%f'
TIME_FORMAT_FROM_RAW = '%Y-%m-%d %H-%M-%S.%f'
FINAL_TS_FORMAT = "%Y-%m-%d %H:%M:%S.%f"
MIN_FLOW_THRESHOLD = -80
IPAUC_CEILING = 10
PEEP_CEILING = 10
TIME_FORMAT_FROM_RAW_WAVEFORM = '%Y-%m-%d-%H-%M-%S.%f'


def setup_dir(input_subdir):
    """
    versions:
    2017-03-04: originally wrote to help visualization
    """
    list_of_subfolders = ['raw_waveforms', 'waveforms_for_plotting', 'breath_meta', 'output']

    for folder in list_of_subfolders:
        oz.mkdir(os.path.join(input_subdir, folder), overwrite_existing=False, printout=False)

    # if output_subdir != '':
    #     oz.mkdir(output,)


def calc_breath_meta(waveform_file_path):
    """
    versions:
    2017-03-04: originally wrote to help visualization
    2017-03-07: remove tentative sbt and add autodetermine bm
    """
    assert os.path.isfile(waveform_file_path)
    dir_ = os.path.dirname(waveform_file_path)
    patient_choice = os.path.basename(dir_)
    input_subdir = os.path.dirname(os.path.dirname(dir_))
    bm_dir_path = os.path.join(input_subdir, 'breath_meta', patient_choice)
    assert os.path.isdir(bm_dir_path)

    breath_meta_array = bm.get_file_breath_meta(waveform_file_path)
    bm_df = pd.DataFrame(breath_meta_array[1:], columns=breath_meta_array[0])
    # bm_df['maybe_sbt'] = False
    # maybe_sbt_index = bm_df.loc[(bm_df['minF'] > -40) & (bm_df['ipAUC'] < 10) & (bm_df['PEEP'] < 10)].index
    # bm_df.loc[maybe_sbt_index, 'maybe_sbt'] = True
    bm_df['abs_time_at_BS'] = pd.to_datetime(bm_df['abs_time_at_BS'], format=TIME_FORMAT_FROM_RAW)
    bm_df['abs_time_at_x0'] = pd.to_datetime(bm_df['abs_time_at_x0'], format=TIME_FORMAT_FROM_RAW)
    bm_df['abs_time_at_BE'] = pd.to_datetime(bm_df['abs_time_at_BE'], format=TIME_FORMAT_FROM_RAW)
    bm_df['diff_pressure'] = bm_df['maxP'] - bm_df['PIP']
    bm_df['range_flow'] = bm_df['maxF'] - bm_df['minF']

    split_name = os.path.splitext(os.path.basename(waveform_file_path))
    bm_name = "{}_breath_meta{}".format(split_name[0], split_name[1])
    bm_path = os.path.join(bm_dir_path, bm_name)

    bm_df.to_csv(bm_path)


def extract_time_series(waveform_file_path):
    dir_ = os.path.dirname(waveform_file_path)
    patient_choice = os.path.basename(dir_)
    input_subdir = os.path.dirname(os.path.dirname(dir_))

    raw_df = pd.read_csv(waveform_file_path, names=['flow', 'pressure'], index_col=False)
    start_dt = raw_df.loc[0, 'flow']
    start_datetime = datetime.datetime.strptime(start_dt, TIME_FORMAT_FROM_RAW_WAVEFORM)
    df2 = raw_df.drop(0)
    time_series = df2.loc[(df2['flow'] != 'BS') & (df2['flow'] != 'BE'), ].copy()
    time_series['rel_time'] = np.nan
    time_series['abs_time'] = np.nan
    rel_times = np.arange(1, len(time_series) + 1) * 0.02
    time_series['rel_time'] = rel_times
    time_series['abs_time'] = pd.to_timedelta(time_series['rel_time'], unit='s') + start_datetime

    split_name = os.path.splitext(os.path.basename(waveform_file_path))
    time_series_name = "{}_time_series{}".format(split_name[0], split_name[1])
    time_series_path = os.path.join(input_subdir, 'waveforms_for_plotting', patient_choice, time_series_name)
    time_series.to_csv(time_series_path)


    breath_starts = df2.loc[(df2['flow']=='BS'),].copy()
    breath_starts_columns = ['relBN', 'ventBN', 'abs_time', 'rel_time']
    # breath_starts = breath_starts.reindex(columns=np.concatenate(breath_starts.columns.values, breath_starts_columns))

    breath_starts['relBN'] = np.nan
    breath_starts['ventBN'] = np.nan
    breath_starts['abs_time'] = np.nan
    breath_starts['rel_time'] = np.nan

    rel_bns = np.arange(1,len(breath_starts)+1)
    breath_starts['relBN'] = rel_bns
    vent_bns = breath_starts['pressure'].str.replace('S:','')
    breath_starts['ventBN'] = vent_bns
    bs_abs_time = time_series.loc[breath_starts.index + 1, 'abs_time'].copy()
    bs_abs_time.index = bs_abs_time.index -1
    breath_starts['abs_time'] = bs_abs_time
    bs_rel_time = time_series.loc[breath_starts.index + 1, 'rel_time'].copy()
    bs_rel_time.index = bs_rel_time.index -1
    breath_starts['rel_time'] = bs_rel_time

    breath_starts.drop(['flow','pressure'], axis=1,)

    split_name = os.path.splitext(os.path.basename(waveform_file_path))
    breath_meta_short = "{}_breath_meta_short{}".format(split_name[0], split_name[1])
    bm_short_path = os.path.join(input_subdir, 'waveforms_for_plotting', patient_choice, breath_meta_short)
    breath_starts.to_csv(bm_short_path)


def calc_breath_meta_for_one_pt_folder(root_dir, patient_choice, printout=True, print_detailed=True):
    """
    calculates breath meta for one patient folder
    args:
        root_dir: must have subfolders raw_waveforms and breath_meta
        patient_choice: anonymized patient pseudo-ID (ex. 0087RPI1420151122)
        printout: prints out percent done
        print_detailed: prints exact filename etc.

    versions:
    2017-03-07: originally written in 20170307_compare_and_extractRSBI.ipynb

    ex:
        output_subdir = r'/Users/monica/Box Sync/UCD/sandbox2017/1_winter/20170113_sbt/20170303_for_first_draft_submission/20170307_rsbi_combined_pilot11'
        calc_breath_meta_for_one_pt_folder(output_subdir, '0087RPI1420151122')
    """
    raw_waveforms_file_paths = glob.glob(os.path.join(root_dir, 'raw_waveforms', patient_choice, "*.csv"))
    oz.mkdir(os.path.join(root_dir, 'breath_meta', patient_choice), overwrite_existing=False, printout=False)
    if printout:
        print "\n input folder: {}".format(os.path.join(root_dir, 'raw_waveforms', patient_choice))
        print "\n output folder: {}".format(os.path.join(root_dir, 'breath_meta', patient_choice))
    for idx, file_path in enumerate(raw_waveforms_file_paths):
        calc_breath_meta(file_path)

        if printout:
            percent_done = idx / len(raw_waveforms_file_paths) * 100
            print" {} %% done".format(round(percent_done, 1))
        if print_detailed:
            print "\tfile #: {},\n \tfile_name: {}".format(idx, os.path.basename(file_path))


def calc_breath_meta_for_ea_pt_folder(root_dir, printout=True, print_detailed=True):
    """
    moved to sbt.vis.vis_helper
    calculates breath meta for one patient folder
    args:
        root_dir: must have subfolders raw_waveforms and breath_meta
        printout: prints out percent done
        print_detailed: prints exact filename etc.

    versions:
    2017-03-07: originally written in 20170307_compare_and_extractRSBI.ipynb
    
    ex.
        output_subdir = r'/Users/monica/Box Sync/UCD/sandbox2017/1_winter/20170113_sbt/20170303_for_first_draft_submission/20170307_rsbi_combined_pilot11'
        sw1 = CreateStopwatch()    
        mult_pt_calc_breath_meta_for_ea_folder(output_sudir)
        print sw1.lap("total time elapsed for bm calcs")
        """  
    raw_waveforms_dir = os.path.join(root_dir, 'raw_waveforms')
    assert raw_waveforms_dir
    if printout:
        print "root_dir: {}".format(raw_waveforms_dir)
    for subdir in os.listdir(raw_waveforms_dir):
        if os.path.isdir(os.path.join(raw_waveforms_dir, subdir)):
            # print subdir
            patient_choice = subdir
            if printout:
                 print "\nfolder: {}".format(subdir)
            raw_waveforms_file_paths = glob.glob(os.path.join(root_dir, 'raw_waveforms', patient_choice, "*.csv"))
            oz.mkdir(os.path.join(root_dir, 'breath_meta', patient_choice), overwrite_existing=False, printout=False)

            for idx, file_path in enumerate(raw_waveforms_file_paths):
                calc_breath_meta(file_path)
                if printout:
                    percent_done = idx / len(raw_waveforms_file_paths) * 100
                    print" {} %% done".format(round(percent_done, 1))
                if print_detailed:
                    print "\tfile #: {},\n \tfile_name: {}".format(idx, os.path.basename(file_path))
                

  

def main(input_subdir, output_subdir='', patient_choice=''):
    # notes for start new vis

    setup_dir(input_subdir, output_subdir)
    raw_waveforms_file_paths = glob.glob(os.path.join(input_subdir, 'raw_waveforms', patient_choice, "*.csv"))

    oz.mkdir(os.path.join(input_subdir, 'waveforms_for_plotting', patient_choice), overwrite_existing=False, printout=False)
    oz.mkdir(os.path.join(input_subdir, 'breath_meta', patient_choice), overwrite_existing=False, printout=False)

    # need to set up conditions for this to save processing time
    for file_path in raw_waveforms_file_paths:
        calc_breath_meta(file_path)
        extract_time_series(file_path)


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("-input_dir", "-i", help="Input directory")
    parser.add_argument("-output_dir", "-o", default='', help="Output directory")
    parser.add_argument("-patient_choice", "-pt", default='', help="name of patient directory")
#    p#arser.add_argument("-csv_name", "-c", default="", help="output CSV Name")

    args = parser.parse_args()
    main(args.input_dir, args.output_dir, args.patient_choice)
