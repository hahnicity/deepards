"""
2017-03-07 17:36:44
"""
from __future__ import division
import pandas as pd
import numpy as np
import os


def find_rsbi(df):
    """
    gets the three different measurements of rsbi from a dataframe

    2017-03-07: originally written in 20170307_compare_and_extractRSBI.ipynb
    """
    rsbi0 = df['inst_rsbi'].mean()
    rsbi1 = df['inst_RR'].mean()/(df['tvi'].mean()/1000)
    
    duration_in_min = ((df.iloc[-1]['sbt_rel_time_at_bs']) - df.iloc[0]['sbt_rel_time_at_bs'])/60
    rsbi2 = (len(df)/duration_in_min)/((df['tvi'].mean()) / 1000)
    return [rsbi0, rsbi1, rsbi2]

def get_first_minute_df(sbt_df):
    """
    gets df during first minute

    2017-03-07: originally written in 20170307_compare_and_extractRSBI.ipynb
    """
    assert 'delta_since_sbt_start' in sbt_df.columns
    df_1to2_mask = (sbt_df['delta_since_sbt_start'] >= '0:01:00') & (sbt_df['delta_since_sbt_start'] < '0:02:00')
    df_1to2 = sbt_df[df_1to2_mask]    
    return df_1to2

def get_last_minute_df(sbt_df):
    """
    gets df during last whole minute of sbt_df

    2017-03-07: originally written in 20170307_compare_and_extractRSBI.ipynb
    """
    assert 'delta_since_sbt_start' in sbt_df.columns
    assert 'sbt_rel_time_at_bs' in sbt_df.columns
    
    last_rel_time = sbt_df.loc[sbt_df.index[-1], 'sbt_rel_time_at_bs']
    last_whole_minute = pd.to_timedelta(int(last_rel_time/60) - 1, 'm')  # hack to get last whole minute
    last_minute = last_whole_minute + pd.to_timedelta(1,'m')  # get the last minute
    df_last_whole_mask = (sbt_df['delta_since_sbt_start'] >= last_whole_minute) & (sbt_df['delta_since_sbt_start'] < last_minute)
    df_last_whole = sbt_df[df_last_whole_mask]  
    return df_last_whole

def get_rsbi_data_from_sbt_df(sbt_df):
    """
    gets rsbi by 3 different calculations for whole, early, and late portion of sbt
    output:
        dataframe with rsbi_version x time period in df
    2017-03-07: originally written in 20170307_compare_and_extractRSBI.ipynb
    2017-03-09: exception handling for ranges outside of the df
    """
    try:
        avg_rsbi = find_rsbi(sbt_df)
    except:
        avg_rsbi = np.nan

    try:
        early_df = get_first_minute_df(sbt_df)
        early_rsbi = find_rsbi(early_df)
    except:
        early_rsbi=np.NaN

    try:
        late_df = get_last_minute_df(sbt_df)
        late_rsbi = find_rsbi(late_df)
    except:
        late_rsbi = np.nan

    return pd.DataFrame.from_dict({'avg':avg_rsbi, 'early':early_rsbi, 'late':late_rsbi})


def get_sbt_df_by_ts(bm_df, start_ts, end_ts, sbt_columns):
    """

    2017-03-07: originally written in 20170307_compare_and_extractRSBI.ipynb
    """
    bm_df['abs_time_at_BS'] = pd.to_datetime(bm_df['abs_time_at_BS'])

    sbt_mask = (bm_df['abs_time_at_BS'] >= start_ts) & (bm_df['abs_time_at_BS'] <= end_ts)
    sbt_df = bm_df.loc[sbt_mask, sbt_columns]
    sbt_df['inst_rsbi'] = sbt_df['inst_RR'] / (sbt_df['tvi'] / 1000)

    start_rel_BS = sbt_df.iloc[0]['rel_time_at_BS']
    sbt_df['sbt_rel_time_at_bs'] = sbt_df['rel_time_at_BS'] - start_rel_BS
    sbt_df['delta_since_sbt_start'] = pd.to_timedelta(sbt_df['rel_time_at_BS'] - start_rel_BS, 's')

    return sbt_df


def get_sbt_df_by_vent_bn(bm_df, start_vent_bn, end_vent_bn, sbt_columns):
    """moved to sbt.rsbi"""
    sbt_mask = (bm_df['ventBN'] >= start_vent_bn) & (bm_df['ventBN'] <= end_vent_bn)
    sbt_df = bm_df.loc[sbt_mask, sbt_columns]
    sbt_df['inst_rsbi'] = sbt_df['inst_RR'] / (sbt_df['tvi'] /1000)

    start_rel_BS = sbt_df.iloc[0]['rel_time_at_BS']
    sbt_df['sbt_rel_time_at_bs'] = sbt_df['rel_time_at_BS'] - start_rel_BS
    sbt_df['delta_since_sbt_start'] = pd.to_timedelta(sbt_df['rel_time_at_BS'] - start_rel_BS, 's')
    
    return sbt_df

def get_calculated_rsbi_from_waveforms(df, bm_dir, rsbi_method, sbt_columns):
    """moved to sbt.rsbi"""
    df2 = df.set_index(('names','patient'))
    df2[('start','calc_rsbi')] = np.nan
    df2[('end','calc_rsbi')] = np.nan
    df2[('other','calc_rsbi')] = np.nan

    for idx, patient_name in enumerate(df2.index):
        # print idx, patient_name

        start_file = df2.loc[patient_name, ('start','file')]
        end_file = df2.loc[patient_name, ('end','file')]
        # start_vent_bn = df2.loc[patient_name, ('start','ventBN')]
        # end_vent_bn = df2.loc[patient_name, ('end','ventBN')]
        start_ts = df2.loc[patient_name, ('start','abs_time_at_BS')]
        end_ts = df2.loc[patient_name, ('end','abs_time_at_BS')]

        if os.path.isfile(os.path.join(bm_dir, start_file)):
            file_path1 = os.path.join(bm_dir, start_file)
            file_path2 = os.path.join(bm_dir, start_file)
        else:
            file_path1 = os.path.join(bm_dir, patient_name, end_file)
            file_path2 = os.path.join(bm_dir, patient_name, end_file)

        if start_file == end_file:
            bm_df = pd.read_csv(file_path1, index_col=0, header=0)
        else:
            subdf1 = pd.read_csv(file_path1, index_col=0, header=0)
            last_rel_time_subdf1 = subdf1.iloc[-1]['rel_time_at_BE']
            subdf2 = pd.read_csv(file_path2, index_col=0, header=0)
            subdf2['rel_time_at_BS'] = subdf2['BS'] + last_rel_time_subdf1
            bm_df = pd.concat([subdf1, subdf2], ignore_index=True)

        sbt_df = get_sbt_df_by_ts(bm_df, start_ts, end_ts, sbt_columns)
        rsbi_data = get_rsbi_data_from_sbt_df(sbt_df)
        # print rsbi_data.loc[rsbi_method,:]
        df2.loc[patient_name, ('start','calc_rsbi')] = rsbi_data.loc[rsbi_method,'early']
        df2.loc[patient_name, ('end','calc_rsbi')] = rsbi_data.loc[rsbi_method,'late']
        df2.loc[patient_name, ('other','calc_rsbi')] = rsbi_data.loc[rsbi_method,'avg']

    return df2
