"""
Created on 2017-02-18 13:09:53
works with sbt_all_o2dev_phases_20161014.csv
"""


from argparse import ArgumentParser
import pandas as pd
import os
import numpy as np

import ehr
# 2017-05-02: many items moved to ehr_meta.py
from ehr_meta import (
    calc_delta_from_first_phase,
    has_trach,
    has_corrupted_data,
    has_timestamped_data,
    simplify_O2_dev_names,
    simplify_O2_dev_names_by_dict_df)


# 2017-05-02: constants deleted to be part of ipynb


def find_likely_sbt_by_cpap_designation(df):
    """
    determines a likely sbt region based on CPAP designation

    Note, this edits whatever dataframe goes in!

    example:
        new_df = df.copy()
        sbt_df = find_likely_sbt_by_cpap_designation(new_df)
    args:
        df: dataframe
    output:
        subsetted data frame with SBT specific data
    """
    cpap_ambiguous_index = df.loc[df['O2_dev_reduced'] == 'CPAP ambiguous'].index
    # may run into issues with first or last value
    expanded_index = np.concatenate((cpap_ambiguous_index - 1, cpap_ambiguous_index, cpap_ambiguous_index + 1))
    expanded_index = np.sort(np.unique(expanded_index))
    sbt_maybe_index = []
    sbt_likely_index = []

    for i, j in enumerate(cpap_ambiguous_index):

        criterion1 = df.loc[j, 'PATIENT_RPI_ID'] == df.loc[j - 1, 'PATIENT_RPI_ID']
        criterion2 = df.loc[j - 1, 'O2_dev_reduced'] == 'mechanical ventilator'
        duration = df.loc[j, 'PHASE_DURATION']
        if criterion1 and criterion2:
            if duration >= sbt_dur_bounds['likely_lower'] and duration <= sbt_dur_bounds['likely_upper']:
                df.loc[j, 'O2_dev_reduced'] = 'SBT likely'
                sbt_likely_index.append(j)
#                 print j, duration, 'likely'
            elif duration >= sbt_dur_bounds['maybe_lower'] and duration <= sbt_dur_bounds['maybe_upper']:
                df.loc[j, 'O2_dev_reduced'] = 'SBT maybe'
                sbt_maybe_index.append(j)
#                 print j, duration, 'maybe'
    combined_index = sbt_likely_index + sbt_maybe_index
#     print sbt_likely_index
#     print combined_index
    combined_index.sort()
    subset_df = df.loc[combined_index, [
        'PATIENT_RPI_ID', 'O2_DEV_CLEANED', 'O2_dev_reduced',
        'PHASE_DURATION', 'PHASE_START', 'PHASE_END']].copy()
    return subset_df




def find_consecutive_sbi(df, sbi_df):
    """
    finds consecutive sbi measurements from sbi file
    writes results in df

    2017-03-02: originally written in 20170302_sample_v3_patients.ipynb
    """
    sbi_df=sbi_df.set_index(ANON_ID_NAME)
    sbi_df['RECORDED_TIME'] = pd.to_datetime(sbi_df['RECORDED_TIME'])
    df['first_two'] = False
    for patient in sbi_df.index.unique():
        time_stamps = sbi_df.loc[patient,'RECORDED_TIME']
        if type(time_stamps) != pd.tslib.Timestamp: #excludes patients with only one recording
            time_diff_first_two = pd.to_timedelta(time_stamps[1]-time_stamps[0])
            
            rule1 = time_diff_first_two > sbt_dur_bounds['likely_lower']
            rule2 = time_diff_first_two < sbt_dur_bounds['likely_upper']
            rule3 = patient in df.index
            
            if rule1 and rule2 and rule3:
                df.loc[patient, 'first_two']=True
                print time_stamps
    
    return  sbi_df


def get_randomized_patient_list(patient_meta, seed):
    """
    gets a randomzied order list of patients, for use in getting cohort

    2017-03-04: originall written in 20170304_2_compare_intervals_and_sbi_Dev
    """
    patient_list = patient_meta.index
    list_sorted = patient_list.sort_values()
    np.random.seed(20170302)
    randomized_index = np.random.choice(int(len(patient_list)), size=len(patient_list), replace=False)
    return list_sorted[randomized_index]

def get_first_sbt_interval_and_sbi_values(sbi_df, sbt_dur_bounds):
    """
    gets first sbt interval and values
    
    2017-03-04: originally written in 20170304_2_compare_intervals_and_sbi_dev.ipynb
    """
    sbi_df2 = sbi_df.set_index(ANON_ID_NAME)
    sbi_df2['RECORDED_TIME'] = pd.to_datetime(sbi_df2['RECORDED_TIME'])

    sbi_patient_list = sbi_df[ANON_ID_NAME].unique()
    sbi_patient_list.sort()
    first_two_sbt_df = pd.DataFrame(np.nan, 
                                  index=sbi_patient_list, 
                                  columns=['start_ts','start_sbi','end_ts','end_sbi'])
    for patient in sbi_patient_list:
        time_stamps = sbi_df2.loc[patient,'RECORDED_TIME']
        if type(time_stamps) == pd.tslib.Timestamp:
            first_two_sbt_df.loc[patient, 'start_ts'] = time_stamps
            first_two_sbt_df.loc[patient, 'start_sbi'] = sbi_df2.loc[patient,'MEAS_VALUE']

        else:
            time_diff_first_two = pd.to_timedelta(time_stamps[1]-time_stamps[0])

            rule1 = time_diff_first_two > sbt_dur_bounds['likely_lower']
            rule2 = time_diff_first_two < sbt_dur_bounds['likely_upper']

            if rule1 and rule2:
                sbi_values = sbi_df2.loc[patient,'MEAS_VALUE']
                first_two_sbt_df.loc[patient, ['start_ts','end_ts']] = [time_stamps[0], time_stamps[1]]
                first_two_sbt_df.loc[patient, ['start_sbi','end_sbi']] = [sbi_values[0], sbi_values[1]]
    return first_two_sbt_df



def main(input_subdir, output_subdir='', output_name=''):
    """
    stack bunches of raw files


    Versions:
    --------
    20160505 V1.0-Written as function
    20160605 V1.2-Move remove_null_inplace to separate function

    Example:
    -------
    root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/20160516_sampling/pilot0604/'
    os.chdir(root_dir)

    #example without specific out_name
    main(input_subdir='20160604_downloaded_fullFiles/0083RPI1120151120-selected',
        output_subdir=r'20160604_fullFiles_concat_test',
        output_name='')
    """
    assert os.path.isdir(input_subdir)
    if output_subdir != '':
        assert os.path.isdir(output_subdir)
    pseudo = ehr.pseudo(input_subdir, PT_IDS)
    path_all_O2_dev_phases = os.path.join(input_subdir, ALL_O2_DEV_PHASES)
    df = pd.read_csv(path_all_O2_dev_phases)
    pseudo.anonymize_ids(df, OLD_ID_NAME, ANON_ID_NAME)
    # df = ehr.anonymize_ids(df, input_subdir, PT_IDS, OLD_ID_NAME, ANON_ID_NAME)
    # add empty columns for speed
    new_columns = np.concatenate((df.columns.values, NEW_COLUMNS))
    df = df.reindex(columns=np.unique(new_columns))

    # time calculations
    df.loc[:, 'PHASE_START_datetime'] = pd.to_datetime(df['PHASE_START'])
    df.loc[:, 'PHASE_END_datetime'] = pd.to_datetime(df['PHASE_END'])
    df.loc[:, 'PHASE_DURATION'] = df['PHASE_END_datetime'] - df['PHASE_START_datetime']
    df = calc_delta_from_first_phase(df)

    # missing data
    len(df[df['O2_DEV_CLEANED'].isnull()])
    len(df[df['O2_DEV_CLEANED'].isnull()]['PATIENT_RPI_ID'].unique())
    len(df[df['O2_DEV_RAW_PHASE'].isnull()]['PATIENT_RPI_ID'].unique())
    df[df['O2_DEV_RAW_PHASE'].isnull()]['PATIENT_RPI_ID'].unique()  # list

    len(df[df['PHASE_START'].isnull()])
    len(df[df['PHASE_END'].isnull()])

    # device data
    device_list_before = pd.DataFrame(data=df.O2_DEV_CLEANED.value_counts())
    device_list_before.to_csv(os.path.join(output_subdir, DEVICES_INITIAL_COUNT))
    len(device_list_before)
    split = df['O2_DEV_CLEANED'].str.split(';', expand=True)
    device_stacked_list = split.stack().value_counts()
    len(device_stacked_list)
    device_stacked_list.to_csv(os.path.join(output_subdir, DEVICES_COUNT_AFTER_STRING_SPLIT))

    # interaction with oxygen_device_df.sort_index9)
    # oxygen_device_df.sort_index()
    # oxygen_device_df.sort_values('strength')
    # oxygen_device_dict = oxygen_device_df['rename'].to_dict()
    df['O2_dev_reduced'] = df.apply(simplify_O2_dev_names, axis=1)
    print df['O2_dev_reduced'].value_counts()

    leftovers = df['O2_DEV_CLEANED'].loc[df['O2_dev_reduced'] == ''].value_counts()
    # df['O2_dev_reduced'] = df.apply(simplify_O2_dev_names_by_dict, axis=1)
    print len(leftovers)
    print leftovers

    # output
    df.to_csv(os.path.join(output_subdir, ALL_O2_DEV_PHASES_ANON))


    # find likely times with sbt
    new_df = df.copy()
    sbt_df = find_likely_sbt_by_cpap_designation(new_df)
    sbt_df.to_csv(os.path.join(output_subdir, LIKELY_SBT_CSV))


    # patient eligibility
    patient_meta = pd.DataFrame(index=df['PATIENT_RPI_ID'].unique().copy())
    patient_meta['patient_number'] = patient_meta.index.map(lambda x: int(x.split('RPI')[0]))
    patient_meta.loc[:, 'has_corrupted_data'] = patient_meta.apply(has_corrupted_data, axis=1)

    patient_meta.loc[:, 'timestamped2hr_data'] = patient_meta.apply(has_timestamped_data, axis=1)
    patient_meta['has_bad_timestamps'] = 1 - patient_meta['timestamped2hr_data']
    patient_meta['ineligible'] = patient_meta['has_bad_timestamps'] + patient_meta['has_corrupted_data']
    patient_meta['eligible'] = patient_meta['ineligible'] == 0
    patient_meta['eligible'].value_counts()

    df2 = new_df.set_index(ANON_ID_NAME)

    patients_with_trach = df2.loc[df2['O2_dev_reduced'] == 'trach', :].index
    patients_with_trach = patients_with_trach.unique()

    patient_meta.loc[:, 'trach_at_some_point'] = 0
    patient_meta.loc[patients_with_trach, 'trach_at_some_point'] = 1

    trach_patient_df = df2.loc[patients_with_trach, [
        'O2_dev_reduced', 'PHASE_DURATION', 'PHASE_START_rel_time',
        'PHASE_END_rel_time', 'O2_DEV_RAW_PHASE', 'O2_DEV_CLEANED']]

    early_time = np.timedelta64(12, 'h')
    early_trach_index = trach_patient_df.loc[(trach_patient_df['PHASE_START_rel_time'] < early_time) & (trach_patient_df['O2_dev_reduced'] == 'trach'), :].index
    patient_meta.loc[:, 'trach<12'] = 0
    patient_meta.loc[early_trach_index.unique(), 'trach<12'] = 1
    patient_meta['ineligible'] = patient_meta['has_bad_timestamps'] \
        + patient_meta['has_corrupted_data'] + patient_meta['trach<12']
    patient_meta['eligible'] = patient_meta['ineligible'] == 0
    patient_meta['eligible'].value_counts()


    # patient pilot
    patient_meta.loc[patient_meta['patient_number']<25, :]['trach_at_some_point'].value_counts()
    pilot_index_trach = patient_meta.loc[(patient_meta['patient_number'] < 25) & (patient_meta['trach_at_some_point']), :].index

    # pilot_trach.to_csv(os.path.join(output_subdir,"20170228_pilot_trach_at_all.csv"))
    # pseudo.deidentify_ids(pilot_index_trach)

    # incorporate EHR RSBI data
    path_sbi_instances_recorded = os.path.join(input_subdir, SBI_INSTANCES_RECORDED)
    sbi_df = pd.read_csv(path_sbi_instances_recorded)
    pseudo.anonymize_ids(sbi_df, OLD_ID_NAME, ANON_ID_NAME)
    sbi_patient_list = sbi_df['PATIENT_RPI_ID'].unique()
    patient_meta['recorded_sbi'] = 0
    patient_meta.loc[sbi_patient_list, 'recorded_sbi'] = 1

    pilot_trach = df2.loc[pilot_index_trach, [
        'O2_DEV_CLEANED', 'O2_dev_reduced', 'PHASE_START', 'PHASE_START_rel_time', 'PHASE_DURATION', 'O2_DEV_RAW_PHASE']]
    pilot_trach.to_csv(os.path.join(output_subdir, "20170228_pilot_trach_at_all.csv"))

    pilot_df = patient_meta.loc[patient_meta['patient_number']<25, [
        'patient_number', 'trach_at_some_point', 'trach<24', 'trach<12', 'recorded_sbi']]
    pilot_df.sort_index(inplace=True)

    # import pdb
    # pdb.set_trace()

    #pilot_df.to_csv(os.path.join(output_subdir, "20170228_patient_meta_pilot.csv"))

    #patient pilot2
    sbi_occurrences = sbi_df['PATIENT_RPI_ID'].value_counts()
    patient_meta['sbi_occurences']=0
    patient_meta.loc[sbi_occurrences.index, 'sbi_occurences'] = sbi_occurrences.values
    good_ts_and_later_trach = patient_meta.loc[patient_meta['eligible']==True,:].copy()
    good_ts_and_later_trach.index[good_ts_and_later_trach['trach_at_some_point']==1]
    had_trach_at_some_point_index = good_ts_and_later_trach.index[good_ts_and_later_trach['trach_at_some_point']==1].copy()
    good_ts_and_later_trach.drop(had_trach_at_some_point_index, inplace=True)

    sbi_df2 = find_consecutive_sbi(good_ts_and_later_trach, sbi_df)

    final_pm = good_ts_and_later_trach.loc[good_ts_and_later_trach['first_two'],:]

    sbt_from_sbi_data = get_first_sbt_interval_and_sbi_values(sbi_df, SBT_DUR_BOUNDS)
    sbt_from_sbi_data__one_recording = sbt_from_sbi_data.loc[sbt_from_sbi_data['end_sbi'].isnull(), :]
    sbt_from_sbi_data__two_recordings = sbt_from_sbi_data.loc[sbt_from_sbi_data['end_sbi'].notnull(),:]

    # final patinet list
    # patient_list = final_pm.index
    # list_sorted = patient_list.sort_values()
    # len(patient_list)

    # np.random.seed(20170302)
    # randomized_index = np.random.choice(int(len(patient_list)), size=len(patient_list), replace=False)
    # print randomized_index

    # print list_sorted[randomized_index][0:5]
    # print list_sorted[randomized_index][5:20]
    # print list_sorted[randomized_index][20:]

    randomized_pt_list = get_randomized_patient_list(final_pm,20170302)
    # a = list_sorted[randomized_index][0:5]
    # for i in a:
    #     print 'scp -r grehm@152.79.84.175:/Users/retriever/{} /Users/monica/Downloads/downloads20170303/{}/'.format(i,i)

    return final_pm, sbi_df2, df

if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("-input_dir", "-i", help="Input directory")
    parser.add_argument("-output_dir", "-o", help="Output directory")
#    p#arser.add_argument("-csv_name", "-c", default="", help="output CSV Name")

    args = parser.parse_args()
    main(args.input_dir, args.output_dir)
 #   main(args.input_dir, args.output_dir, args.csv_name)
