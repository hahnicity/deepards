# -*- coding: utf-8 -*-
"""
Created on Thu Jun 04 09:40:22 2015

@author: Keiko
note: Every time an abbreviation changes, need to
1) 'abbrev': update abbreviation
2) 'abbrev': add entry for old abbreviation
2) 'codes' and 'colors': update abbreviation

2.0 Update summer 2015
2.1 MATR Update abbrevs and codes to Legend20150812.xslx
"""
__version__= '2.1'
__source__= 'Abbreviation Legend 20150812.xlsx'

abbrev = {
    'normal_breath': 'n',
    'double_trigger': 'dbl',
    'multiple_trigger': 'mt',
    'breath stacking light':'bsl',
    'breath stacking moderate': 'bsm',
    'breath stacking severe': 'bss',

    'delayed_termination_type_1': 'dtpi',
    'delayed_termination_pissed':'dtpi',
    'dti':'dpi',
    'delayed_termination_passive':'dtpa',
    'delayed_termination_type_2': 'dtpa',
    'dta':'dtpa',

    'vent_disconection': 'vd',

    'asynchrony_NOS': 'aNOS',
    'a?': 'aNOS',
    'waveform_NOS': 'wNOS',
    'w?': 'wNOS'
    
    }
 
codes = {
#    'NONE': 0,
    '-':00,
    'n': 1,
    'dbl': 2,
    'mt': 3,
    'bsl': 4,
    'bsm': 5,
    'bss': 6,
    'dtpi':7,
    'dtpa':8,
    'fam':9,
    'fas':10,
    'itp':11,
    'itf':12,
    'at':13,
    'fe':14,
    
    'vd':20, 
    'su':21,  
    'co':22,
    'hi':23,
    'fic':24,

    
    'aNOS':40,
    'wNOS':41,
    
    'tvl':50,
    'tvm':51,
    'tvs':52    
    }
colors = {
    '0':'White',
    'NONE': 1,
    '-': 'black',
    'n': 'LightGrey',
    'dbl': 'Lime',
    'mt': 'LimeGreen',
    'dtpi': 'OrangeRed',
    'dtpa': 'Orange',
    'bs': 'yellow',
    'bsl': '#a1d99b',
    'bsm': '#74c476',
    'bss': '#31a354',
    
    'gold':'yellow',
    'cosuvd':'DimGray',
    'co': 'DimGray',
    'vd': 'DimGray',
    'su': 'DimGray',
    
    'aNOS': 'Linen',
    'wNOS': 'WhiteSmoke',
    
    'tvv':'LightPink',
    'tvl': 'LightPink',
    'tvm': 'DeepPink',
    'tvs': 'Black'

    
    }
colors_eval = {
    'tp': 1,
    'tn': 1,
    'fp': 'Orange',
    'fn': 'Blue'
        }
