"""
removed_annotated_dbl_trig
~~~~~~~~~~~~~~~~~~~~~~~~~~

Remove duplicate double triggers from an already annotated breath file. This script is
REALLY REALLY stupid. All that it does is as advertised; removes the second double trigger.
If its a multi-trigger then don't do anything
"""
import argparse
import os

from pandas import read_csv


def filter_lines(df):
    row_idx_to_drop = []
    last_was_dbl = False

    for row_idx in df.index:
        if last_was_dbl:
            last_was_dbl = False
            row_idx_to_drop.append(row_idx)
        elif df.loc[row_idx].dbl:
            last_was_dbl = True

    for idx in row_idx_to_drop:
        df = df.drop(idx)
    return df


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_file")
    parser.add_argument("--output", required=False, help="path to the output file")
    args = parser.parse_args()
    df = read_csv(args.input_file)
    filtered_df = filter_lines(df)
    if args.output:
        filtered_df.to_csv(args.output)
    else:
        base = os.path.basename(args.input_file)
        non_ext = os.path.splitext(args.input_file)[0]
        dirname = os.path.dirname(args.input_file)
        final_path = os.path.join(dirname, "{}_extra_dbl_removed.csv".format(non_ext))
        filtered_df.to_csv(final_path)


if __name__ == "__main__":
    main()
