import argparse
import csv
import os
import sys

csv.field_size_limit(sys.maxsize)


def parse_and_write(input_file):
    output_file = "{}-vent-bn-at-start.csv".format(
        os.path.basename(os.path.splitext(input_file)[-2])
    )
    with open(input_file) as input, \
            open(output_file, "w") as output:
        input_reader = csv.reader(input)
        output_writer = csv.writer(output)
        # For now just assume 2 column format in version 1 format
        cur_bn = None
        for row in input_reader:
            try:
                row[0]
            except IndexError:
                continue
            if "BE" == row[0]:
                vent_bn += 1  # just increment by one. we can avoid missing BS's this way
                continue
            try:
                row[1]
            except IndexError:
                continue
            if "BS" == row[0]:
                vent_bn = int(row[1].replace("S:", ""))
                continue
            output_writer.writerow([vent_bn] + row)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    args = parser.parse_args()
    parse_and_write(args.input)


if __name__ == "__main__":
    main()
