"""
Created to run tkinter/gold files
"""

import os
import sys

gitPath=r'Users/monica/github/ucdpv/'


#ADDS GIT PATH
if gitPath not in sys.path:
     sys.path.append(gitPath)

import analysis.annotations.compareCSV_tkinter as compare

root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox'
gold_dir=r'20160427_tkinter2/input'
output_dir=r'20160427_tkinter2/output'

csv1='WF_B2CRPi01__2015-02-19__10_17_19.590102799_5_7579to7781_adams_20150901.csv'
csv2='WF_B2CRPi01__2015-02-19__10_17_19.590102799_5_7579to7781_kuhn.csv'
# csv2='WF_B2CRPi01__2015-02-19__10_17_19.590102799_5_7579to7781_kuhn_bad_breath.csv'
# csv2="WF_B2CRPi01__2015-02-19__10_17_19.590102799_5_7579to7781_kuhn_wrong_col_name2.csv"
combined='combined_test1.csv'

csv1="0010_00_17_20_11_20800to20841_vd_new_type_extras.csv"
csv2="0010_00_17_20_11_20800to20841_vd_new_type.csv"




##rest of script don't change
#mismatched BN
os.chdir(root_dir)

#put in future main
def printLog(outputPath, string):
    """
    print and write to designated .txt file
    """
    printFile = open(os.path.join(outputPath,combined+'_logfile.txt'), 'a')
    printFile.write(string+'\n')
    print string

import time
import pandas as pd
import csv
printLog(output_dir, "=="*10)
printLog(output_dir, (time.strftime("Started at %d/%m/%Y  %H:%M:%S")))
printLog(output_dir,"Root Dir: %s"%root_dir)
printLog(output_dir,"Gold subdirectory: %s" %gold_dir)

printLog(output_dir,"CSV1: %s"%csv1)
printLog(output_dir,"CSV2: %s"%csv2)
df1 = pd.read_csv(os.path.join(gold_dir,csv1))
df2 = pd.read_csv(os.path.join(gold_dir,csv2))

printLog(output_dir,"Files imported successfully.")

matchedBN =compare.compareSubDF(df1.BN, df2.BN, 'BN')
matchedColumns =compare.compareSubDF(df1.columns, df2.columns, 'columns')       


class FileError(Exception):
    pass
#error checking
matchedBN = compare.compareSubDF(df1.BN, df2.BN, 'BN')
if matchedBN==False:
    raise FileError("\n\t-->Breath numbers don't match"+
                    "\n\t-->Double check CSVs analyze same breath regions")
matchedColumns = compare.compareSubDF(df1.columns, df2.columns, 'columns')
if matchedColumns==False:
    raise FileError("\n\t-->Columns don't match"+
                    "\n-->Double check CSVS are from same annotation batch")

## instantiate and pop up window
with open(os.path.join(output_dir,combined), 'wb') as outGS:
    csvGS = csv.writer(outGS, delimiter=',', quoting=csv.QUOTE_NONE)
    csvGS.writerow(df1.columns)
    compare.csvTkinter(df1,df2,csvGS,"dbl").mainloop()


printLog(output_dir,'woohoo!! all done')

printLog(output_dir, (time.strftime("Finished at %d/%m/%Y  %H:%M:%S")))
printLog(output_dir, "=="*10)