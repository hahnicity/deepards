
"""
Created on Tue May 24 15:26 PM
@author: Keiko
Based on pool_stats.py
development file.
target file  analytics/aggregate_class_matrices.py

based on 20160524_aggregate_class_matrices
"""
import pandas as pd
import os
import sys

gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.solo_fused as fused; reload(fused)
import utilikilt.oz as oz
import glob

import analytics.aggregate_class_matrices as AGG

root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/20160524_aggregate_for_Sandy'
os.chdir(root_dir)

# input_dir=r'test_build/test_build_inputs'
# output_dir=r'20160524_aggregate_for_Sandy'
# output_dir=r'test_build'
# output_path=r"0526_1.csv"

# input_dir=r'20160513_combined_derivation_gold'

# aggregated=AGG.stack(input_dir=input_dir,
#                     index_col="BN",
#                     keep_col_list=['dbl','bs','co','sumt','vd','cosumtvd'])
# aggregated.to_csv(os.path.join(output_dir,os.path.basename(input_dir)+".csv"))


def stack_auto(input_dir,output_dir,output_name="",keep_col_list=[],
                rename_col_list=[]):
    """
    Automates stack function

    Args:
    -----
    input_dir: input directory path
    output_dir: output directory path


    Versions:
    --------
    20160526-V1.0 Make into function from 20160526_aggregate_matrices_for_sandy

    """

    if output_name=="":
        output_name=os.path.basename(input_dir)+".csv"
    aggregated=AGG.stack(input_dir=input_dir,index_col="BN",
                    keep_col_list=keep_col_list)
    if rename_col_list!=[]:
        aggregated.columns=rename_col_list
    aggregated.to_csv(os.path.join(output_dir,output_name))
    print '-----'*5
    print "Files processed from: %s"%input_dir
    print "To: %s" %str(os.path.join(output_dir,output_name))


#stack 
output_dir=r'20160526_aggregate'
stack_auto(input_dir=r'20160513_gold_files/20160513_combined_derivation_gold',
    output_dir=output_dir,
    keep_col_list=['dbl','bs','co','sumt','vd','cosumtvd'])

stack_auto(input_dir=r'20160513_gold_files/20160513_validation_gold_processed',
    output_dir=output_dir,
    keep_col_list=['dbl','bs','co','sumt','vd','cosumtvd'])



#stack annos adams
stack_auto(input_dir=r'20160524_JB_annotations/20160526_1_processed_comb_cosumtvd/20160524_derivation_adams',
    output_dir=output_dir,
    keep_col_list=['dbl','bs','co','sumt','vd','cosumtvd'])
stack_auto(input_dir=r'20160524_JB_annotations/20160526_1_processed_comb_cosumtvd/20160524_validation_adams',
    output_dir=output_dir,
    keep_col_list=['dbl','bs','co','sumt','vd','cosumtvd'])


#stack annos kuhn
stack_auto(input_dir=r'20160524_JB_annotations/20160526_1_processed_comb_cosumtvd/20160524_derivation_kuhn',
    output_dir=output_dir,
    keep_col_list=['dbl','bs','co','sumt','vd','cosumtvd'])
stack_auto(input_dir=r'20160524_JB_annotations/20160526_1_processed_comb_cosumtvd/20160524_validation_kuhn',
    output_dir=output_dir,
    keep_col_list=['dbl','bs','co','sumt','vd','cosumtvd'])





keep_col_list_TOR=['dbl.4','bs.1or2','co.noTVi','sumt','vd.2','cosumtvd']
rename_col_list=['dbl','bs','co','sumt','vd','cosumtvd']

#stack TOR multi frame
# stack_auto(input_dir=r'20160515_TOR/20160515_TOR3_5_6_derivation_multiframe2',
#     output_dir=output_dir,
#     keep_col_list=keep_col_list_TOR,
#     rename_col_list=rename_col_list)
# stack_auto(input_dir=r'20160515_TOR/20160515_TOR3_5_6_validation_multiframe2',
#     output_dir=output_dir,
#     keep_col_list=keep_col_list_TOR,
#     rename_col_list=rename_col_list)

#stack TOR solo3
stack_auto(input_dir=r'20160515_TOR/20160515_TOR3_5_6_derivation_solo3',
    output_dir=output_dir,
    keep_col_list=keep_col_list_TOR,
    rename_col_list=rename_col_list)

stack_auto(input_dir=r'20160515_TOR/20160515_TOR3_5_6_validation_solo3',
    output_dir=output_dir,
    keep_col_list=keep_col_list_TOR,
    rename_col_list=rename_col_list)
# input_dir=r'20160515_TOR/20160513_TOR3_5_6_derivation_solo3'
# output_name=os.path.basename(input_dir)+".csv"
# aggregated=AGG.stack(input_dir=input_dir,index_col="BN",keep_col_list=keep_col_list)
# aggregated.columns=rename_col_list
# aggregated.to_csv(os.path.join(output_dir,output_name))


# import pdb
# pdb.set_trace()
#stack  TOR output (solo3)
# output_dir=r'20160526_aggregate_for_Sandy'
# stack_auto(input_dir=r'20160515_TOR/20160513_TOR3_5_6_derivation_solo3',
#     output_dir=output_dir,
#     keep_col_list=['dbl.4','bs1.or2','co.noTVi','sumt','vd.2','cosumtvd'])

# output_dir=r'20160526_aggregate_for_Sandy'
# stack_auto(input_dir=r'20160515_TOR/20160515_TOR3_5_6_validation_solo3',
#     output_dir=output_dir,
#     keep_col_list=['dbl','bs','co','sumt','vd','cosumtvd'])

#     aggregated=AGG.stack(input_dir=input_dir,
#                     index_col="BN",
#                     keep_col_list=keep_col_list)
#     aggregated.to_csv(os.path.join(output_dir,output_name))


