# -*- coding: utf-8 -*-
"""
Created on Thu Feb  4 13:39:59 2016

@author: monica
based on 20160225_stats_pipe.py
based on 20160211_stats.py
based on 
20160204-derivation1_stats.py
which is based on 
20160106_Stats2_LocalBokehPlot

version 
1.2 Move calcMultiStats to sta package
1.1 20160211_stats.py
1.0 20160204-derivation1_stats.py
0.0 20160106_Stats2_LocalBokehPlot 
"""

from __future__ import division
import os
import pandas as pd
import sys
import numpy as np
#%% import stats

gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
    sys.path.append(gitPath)
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)

#%%
root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox/'
os.chdir(root_dir )
input_subdir=r'20160307_post_cough2'
output_subdir=r'20160307_post_cough2/accuracies2/'
gold_subdir=r'0TestFiles/2016-02-06-gold_standard'

out_suffix='_TOR3_2_9'

filelist=[
['0002_09_14_38_2400to2700%s_logfile.txt'%out_suffix,   '0002_09_14_38_3_2399to2701_goldstd_dbl_bs_cosumtvd.csv'],
['0004_09_23_46_2200to2500%s_logfile.txt'%out_suffix,   '0004_09_23_46_2_2199to2501_goldstd_dbl_bs_cosumtvd.csv'],
['0007_file_1of1_2804to3202%s_logfile.txt'%out_suffix,  '0007_21_17_20_3_2803to3203_goldstd_dbl_bs_cosumtvd.csv'],
['0008_10_17_20_2692to3030%s_logfile.txt'%out_suffix,   '0008_10_17_20_2_2691to3031_goldstd_dbl_bs_cosumtvd.csv'],
['0009_03_19_47_1825to2125%s_logfile.txt'%out_suffix,   '0009_03_19_47_1_1824to2126_goldstd_dbl_bs_cosumtvd.csv'],
['0010_03_17_19_deleted_first_line_1401to1699%s_logfile.txt'%out_suffix,    '0010_03_17_19_1_1400to1700_goldstd_dbl_bs_cosumtvd.csv'],
['0011_14_17_21_475to773%s_logfile.txt'%out_suffix,   '0011_14_17_21_1_474to774_goldstd_dbl_bs_cosumtvd.csv'],
['0012_19_53_45_first_and_last_line_deleted_35129to35427%s_logfile.txt'%out_suffix,   '0012_19_53_45_17_35128to35428_goldstd_dbl_bs_cosumtvd.csv'],
['0013_15_49_102_27671to27969%s_logfile.txt'%out_suffix,  '0013_15_49_102_10_27670to27970_goldstd_dbl_bs_consumtvd.csv'],
['20151008_gwf2_q2hr_whileloop_expt_17_15_31_950to1248%s_logfile.txt'%out_suffix,  '20151008_gwf2_q2hr_whileloop_expt_17_15_31_1_949to1249_goldstd_dbl_bs_cosumtvd.csv']
]

#process a batch of files
for files in filelist:
    print files[0], files[1]
    print '-----------------'

    try:
        sta.calcMultiStats(logfile=files[0],
            gold_name=files[1],
            det_subdir=input_subdir,output_subdir=output_subdir,gold_subdir=gold_subdir,
            subfiles_list=[
                        '_class_matrix_raw_multi_frame2.csv',
                        '_solo.csv'])
    except IOError:
        print IOError
        print files[0]

    except:
        print "other error"
        print files[0]

#pool results together
from analytics.pool_stats import pool_stats
output_csv = os.path.join(root_dir+output_subdir+"pooled_stats_TOR3_2_9.csv")

pool_stats(output_subdir,ppvi_list=['dbl.4','bs.1','mt','co','co.2','co.3','co.4','vd.2','su'],
        output_csv=output_csv,
        matrix_keywords=["multi_frame2__ACCURACY","solo__ACCURACY"],
        stat_list=['accuracy','sensitivity','specificity','total','events','FNs','FPs','TPs','TNs'])

        # subfiles_list=[
        #             '_class_matrix_raw_multi_frame.csv',
        #             '_class_matrix_raw_multi_frame_buffer2.csv',
        #             '_class_matrix_raw.csv',
        #             '_class_matrix_solo.csv'])