# -*- coding: utf-8 -*-
"""
Created on Wed Nov 25 14:19:43 2015

@author: Keiko

Runme file for algorithms/preTOR
"""

#%%case use for individual files

import sys
import os

algPath=r'C:\allMYfiles\My_Documents\GitHub\ucdpv\algorithms'
rootDir=r'C:\allMYfiles\BOX\BedsideToCloud Pilot Project\PVI\Experiments\20151118_cosumtvd_simulation_expt'
os.chdir(rootDir)

if algPath not in sys.path:
    sys.path.append(algPath)
from preTOR import addBEs

inputSubdir='1.original_files'
outputSubdir='2.pre_processed_addBE'
outputSubdir='3.test'

addBEs('jason-vent-session1.csv',inputSubdir='1.original_files',
       outputSubdir='2.pre_processed_addBE',outputDateTimeRow=False)
addBEs('jason-vent-session3.csv',inputSubdir='1.original_files',
       outputSubdir='2.pre_processed_addBE',outputDateTimeRow=True)
#%% usage for a subdirectory
import sys
import os

algPath=r'C:\allMYfiles\My_Documents\GitHub\ucdpv\algorithms'
rootDir=r'C:\allMYfiles\BOX\BedsideToCloud Pilot Project\PVI\Experiments\20151118_cosumtvd_simulation_expt'
os.chdir(rootDir)

if algPath not in sys.path:
    sys.path.append(algPath)
import preTOR

inputSubdir='1.original_files'
outputSubdir='2.pre_processed_addBE'
outputSubdir='3.test'



print "preTOR version: ", preTOR.__version__

for path,subdirs,files in os.walk(inputSubdir):
    for inputFile in files:
        print '------'
        print inputFile
        
        inputPath=os.path.join(inputSubdir,inputFile)
        
        hasBEs=preTOR.checkFileHasBEs(inputPath)
        if hasBEs==True:
            print str(inputFile)+" already has BEs"
        elif hasBEs==False:
            preTOR.addBEs(inputFile,inputSubdir=inputSubdir,
                   outputSubdir=outputSubdir,outputDateTimeRow=True)
            print "Added BEs to "+str(inputFile)
