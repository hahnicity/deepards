"""
Created on Thu Feb 4 21:00:00 2016

@author: Keiko
based on 20160407_TOR3_dev_pt7_double_frame.py
based on 20160330_dev_pt7_ALG_rounded_ratios.py
based on 20160330_TOR3_3_devpt7_double_frame.py
based on 20160301_TOR3_2_dev.py
based on 20160225_TOR_3_1_RUNME.py
based on 20160202_TOR3_trunc_run_RUNME.py
run in mac
"""

import sys
import os
import pandas as pd

#import custom package
gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.TOR3 as TOR; reload(TOR)
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)


root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox'
os.chdir(root_dir)
output_subdir=r'20160429_merge'
try:
  os.mkdir(output_subdir)
except:
  print "'%s' subdirectory already exists" %output_subdir

altBN,altRelTime=TOR.detectPVI(input_file='0001_10_17_19.csv', 
              outName='',outSuffix='_after_merge',
              #'3_cough_in_middle_frame_threshold',
              #'2_cough_new_thresholds'
              #'1_pre',

              input_subdir=r'0TestFiles/fullFiles',
              output_subdir=output_subdir,
              BNinterval=[4280,4578],
              altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=False,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False,
              anyCosumtvd=True) 




# #stats 
# gold_subdir=r'0TestFiles/2016-02-06-gold_standard'
# sta.calcMultiStats(logfile='0007_file_1of1_2804to3202_3_1_5_smartbuffer_logfile.txt',
#             gold_name='0007_21_17_20_3_2803to3203_goldstd_dbl_bs_cosumtvd.csv',
#             det_subdir=r'20160301_stack_multi',
#             output_subdir=r'20160301_stack_multi',
#             gold_subdir=gold_subdir)