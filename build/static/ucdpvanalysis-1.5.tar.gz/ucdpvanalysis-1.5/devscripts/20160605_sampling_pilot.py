# -*- coding: utf-8 -*-
"""
Created on Thu Jan 14 23:14:55 2016

@author: Keiko

1.1 Add pooled stats as function and df piping
1.2 Add actual poole dstats
1.2.1 det_subdir=r'20160503_TOR3_5_0_group_results_post_merge'
1.2.4 det_subdir=r'20160510_TOR3_5_2_1_new_derivation'
1.2.5 det_subdir=r'20160510_TOR3_5_3_combined_deriv_DBL_BSv5'
1.2.5.1 accuracies2
1.2.6 "TOR 3_5_3" add TOR 1.2.6
1.2.7 Change file output directory structure


based on 20160421_stats_add_true_pooled.py
based on 20160418_TOR3_4_2_group_post_cough
added dynamic list update
based on 20160301_TOR3_group2.py
based on 20160224_TOR3_group.py
based on 20160216_TOR3_derivation_RUNME.py
based on 20160211_TOR3_derivation_RUNME.py
based on 20160202_TOR3_trunc_run_RUNME.py
run in mac
"""
from __future__ import division
__version__="1.2.9"

import sys
import os
import time
import pandas as pd
gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.TOR3 as TOR
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)
import analytics.pool_stats as pool; reload(pool)
import pdb
import utilikilt.oz as oz


start_time = time.time() 
#%%change these!!
root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/20160516_sampling/pilot0604'
input_subdir=r'20160605_fullFiles_concat'
det_root=r'20160605pilot_detected'
aggregated_name = ''
real_pooled_name = ''
out_suffix=''


runTOR = True

#%%remember to use new input directory!!!!

#make subfolder for accuracies
# accuracies_subdir=os.path.join(det_root,'accuracies')
det_subdir=os.path.join(det_root,'detected')
# if aggregated_name=='':
#     aggregated_stats_csv="aggregated_stats_"+det_root+".csv" #optional, change pooled stats_name
# if real_pooled_name=='':
#     real_pooled_stats_csv="pooled_stats_"+det_root+".csv" #optional, change pooled stats_name

#change root_dir
os.chdir(root_dir)

filelist=[
# '0002_09_13_15_02.csv',
# '0012_19_53_45_01.csv',
# '0013_15_49_10_2.csv',
# '0014_08_17_25_1.csv',
## '0083RPI1120151120_first6_concat.csv',
## '0086RPI1920151120_first6_concat.csv'
'0083RPI1120151120_first6_concat_addBE25217.csv',
'0086RPI1920151120_first6_concat_del5762.csv'
]

intervals=[
# [1,7200],
# [1,7200],
# [1,7200],
# [1,7200],
[],
[]]


oz.mkdir(det_root)
oz.mkdir(det_subdir)
 
if runTOR:
    for input_file, BNinterval in zip(filelist,intervals):
           print "*"*20
           print input_file
        
           altBN_pt2,altRelTime_pt2=TOR.detectPVI(
                         input_file=input_file, 
                         outName='',outSuffix=out_suffix,
                         input_subdir=input_subdir,
                         output_subdir=det_subdir,
                         BNinterval=BNinterval,
                         altBNstart=0,altRelTimeStart=0,
                         tvePos=True, dt=0.02,gender="female",ptHeight=67,
                         keepBS=False,addRelTime=True,
                         outSubsets=False,writePlain=False)       

run_time=(time.time() - start_time)
print "-------%s seconds elapsed" %run_time
quit()
