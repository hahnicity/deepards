import pandas as pd
import os
import sys
import scipy.stats

gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)
import analysis.utilikilt.oz as oz

stats_path=r'/Users/monica/github/statsmodels'
if stats_path not in sys.path:
     sys.path.append(stats_path)

import statsmodels as sm

from statsmodels.stats.proportion import proportion_confint

def pool_stats(df):
    """
    Pool data from multiple patients

    Versions:
    --------
    20160426 V1

    Example:
    -------

    """
    #make a copy of current data frame
    df.fillna(0)
    #df = df.convert_objects(convert_numeric=True)
    df=df.apply(pd.to_numeric,errors='coerce') #makes each part numeric
    df = df.groupby(level=0).sum()
    df =df.transpose()
    df['TPandFNs']=df['TPs']+df['FNs']
    df['TNandFPs']=df['TNs']+df['FPs']
    df['all4']=df['TPandFNs']+df['TNandFPs']
    df['TPsandTNs']=df['TPs']+df['TNs']
    df['TPsandFPs']=df['TPs']+df['FPs']
   
    df['accuracy']=df['TPsandTNs']/df['all4']
    df['sensitivity']=df['TPs']/df['TPandFNs']
    df['specificity']=df['TNs']/df['TNandFPs']
    df['PPV']=df['TPs']/df['TPsandFPs']
    df = df.transpose()

    return df

def calc_CI_acc(row,num,denom):
    """calc CI for accuracy column"""
    successes=row[num]
    trials=row[denom]
    try:
        CI=proportion_confint(successes,trials,alpha=0.05,method='wilson')
        formatted_CI=format_CI(CI)
    except: #if the denominator is zero
        if trials==0:
            formatted_CI=float('NaN')
        else:
            pass
    # if row.name[0]=='vd.2':
    #     import pdb
    #     pdb.set_trace()    
    return formatted_CI



def calc_group_CIs(df):
    #http://statsmodels.sourceforge.net/devel/generated/statsmodels.stats.proportion.proportion_confint.html
    df=df.apply(pd.to_numeric,errors='coerce') #makes each part numeric

    df=df.transpose() #must transpose because it takes away headach of multi-index columns

    df['accuracy_CI']=df.apply(calc_CI_acc,num='TPsandTNs',denom='all4',axis=1)
    df['sensitivity_CI']=df.apply(calc_CI_acc,num='TPs',denom='TPandFNs',axis=1)
    df['specificity_CI']=df.apply(calc_CI_acc,num='TNs',denom='TNandFPs',axis=1)
    df['PPV_CI']=df.apply(calc_CI_acc,num='TPs',denom='TPsandFPs',axis=1)
    #test=proportion_confint(5075,5076,alpha=0.05,method='beta')
    #test=proportion_confint(3050,3136,alpha=0.05,method='beta')
    return df.transpose()

def format_CI(test):
    lower=round(test[0],3)*100
    upper=round(test[1],3)*100

    if test[0]==0:
        left="["
    else:
        left="("
    if test[1]==1.0:
        right="]"
    else:
        right=")"

    if test[0]==test[1]:
        right="]"
        left="["
    return left+str(lower)+","+str(upper)+right



if __name__=="__main__":
    root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/3_summer/20160706_AMIA_resubmission/'
    
    input_csv=os.path.join(root_dir+'aggregated_stats_20160515_TOR3_5_6_derivation.csv')
    cleaned_csv=os.path.join(root_dir+'aggregated_stats_20160515_TOR3_5_6_derivation_20160708_1cleaned.csv')
    pooled_csv=os.path.join(root_dir+'aggregated_stats_20160515_TOR3_5_6_derivation_20160708_2pooled.csv')
    output_CI_csv=os.path.join(root_dir+'aggregated_stats_20160515_TOR3_5_6_derivation_20160708_3_CIs.csv')


    os.chdir(root_dir)
    # read csv
    df=pd.read_csv(input_csv,index_col=[0,1],header=[0,1])

    # initial cleaning
    idx = pd.IndexSlice
    keep_rows=['FNs','FPs','TNs','TPs','total']
    keep_PVAs=['dbl.4','bs.1or2','co.noTVi','vd.2','mt','mt.su','sumt','su.2']
    keep_output=['multi_frame2','solo3']
    keep_subjects=['0001_10', '0002_09', '0004_09', '0007_21', '0008_10', '0009_03',
       '0010_combined', '0011_14', '0012_19', '0013_15',
       '0086-2015-11-22-10-52-12_1850to2149', '0099_10',
       '0122_2016-01-28-15-29-25', '0126_2016-01-27-07-04-47',
       '0140-2016-02-08-16-13-46_1900to2199',
       '0149_combined','20151008_gwf2']

    df1=df.apply(pd.to_numeric,errors='coerce') #makes each part numeric
    df1=df1.sort_index(axis=0)
    df1=df1.sort_index(axis=1)
    df1.index.is_lexsorted()
    df2=df1.loc[idx[keep_rows,:],idx[keep_PVAs,keep_output]]
    #http://stackoverflow.com/questions/16833842/assign-new-values-to-slice-from-multiindex-dataframe
    for row in keep_rows:
        new_row=df2.loc[idx[row,'0010_00'],:]+df2.loc[idx[row,'0010_03'],:]
        df2.loc[idx[row,'0010_combined'],:]=new_row.T
        new_row=df2.loc[idx[row,'0149_rpi18-2016-02-17-08-38-13.566218'],:]+df2.loc[idx[row,'0149_rpi18-2016-02-17-08-43-02.524207'],:]
        df2.loc[idx[row,'0149_combined'],:]=new_row.T

    df2=df2.sort_index(axis=0)
    df2=df2.sort_index(axis=1)
    df3=df2.sortlevel(1)
    df2.to_csv(os.path.join(root_dir,'pooled_dev','test4_add2.csv'))
    df3=df3.sortlevel(0)
    df3=df3.loc[idx[keep_rows,keep_subjects],idx[keep_PVAs,keep_output]]
    df3=df3.sortlevel(0)
    df3.to_csv(cleaned_csv)


    #pooling the stats
    pooled_df=pool_stats(df3)
    pooled_df.to_csv(pooled_csv)

    #calculating the stats intervals
    CIs_df=calc_group_CIs(pooled_df)
    CIs_df.to_csv(output_CI_csv)


    #doing the same for just patient 7
    df4=df3.loc[idx[:,'0007_21'],idx[:,:]]
    df4.to_csv(os.path.join(root_dir,'pt7_only_dev','7_1_cleaned.csv'))

    pooled_df2=pool_stats(df4)
    pooled_df2.to_csv(os.path.join(root_dir,'pt7_only_dev','7_2_pooled.csv'))

    #calculating the stats intervals
    CIs_df2=calc_group_CIs(pooled_df2)
    CIs_df2.to_csv(os.path.join(root_dir,'pt7_only_dev','7_3_CIs.csv'))


    import pdb
    pdb.set_trace()
    # pooled_csv=os.path.join(root_dir,'pooled_dev','pooled2_from_cleaned.csv')
    # output_CI_csv=os.path.join(root_dir,'pooled_dev','pooledCIs_for_all.csv')

    # output_csv=os.path.join(root_dir,'pooled_dev','pooledCIs_for1_to_function.csv')
    # df.transpose().to_csv(output_csv)


if __name__=="__original_preprocessing__":
    root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/3_summer/20160706_AMIA_resubmission/'
    os.chdir(root_dir)
    input_csv=os.path.join(root_dir+'aggregated_stats_20160515_TOR3_5_6_derivation.csv')
    # read csv
    df=pd.read_csv(input_csv,index_col=[0,1],header=[0,1])

    # initial cleaning


    
    idx = pd.IndexSlice
    keep_rows=['FNs','FPs','TNs','TPs','total']
    keep_PVAs=['dbl.4','bs.1or2','co.noTVi','vd.2','mt','mt.su','sumt','su.2']
    keep_output=['multi_frame2','solo3']
    keep_subjects=['0001_10', '0002_09', '0004_09', '0007_21', '0008_10', '0009_03',
       '0010_combined', '0011_14', '0012_19', '0013_15',
       '0086-2015-11-22-10-52-12_1850to2149', '0099_10',
       '0122_2016-01-28-15-29-25', '0126_2016-01-27-07-04-47',
       '0140-2016-02-08-16-13-46_1900to2199',
       '0149_combined','20151008_gwf2']

    df1=df.apply(pd.to_numeric,errors='coerce') #makes each part numeric
    df1=df1.sort_index(axis=0)
    df1=df1.sort_index(axis=1)
    df1.index.is_lexsorted()
    df2=df1.loc[idx[keep_rows,:],idx[keep_PVAs,keep_output]]
    #http://stackoverflow.com/questions/16833842/assign-new-values-to-slice-from-multiindex-dataframe
    for row in keep_rows:
        new_row=df2.loc[idx[row,'0010_00'],:]+df2.loc[idx[row,'0010_03'],:]
        df2.loc[idx[row,'0010_combined'],:]=new_row.T
        new_row=df2.loc[idx[row,'0149_rpi18-2016-02-17-08-38-13.566218'],:]+df2.loc[idx[row,'0149_rpi18-2016-02-17-08-43-02.524207'],:]
        df2.loc[idx[row,'0149_combined'],:]=new_row.T
    


    # idx = pd.IndexSlice
    df2=df2.sort_index(axis=0)
    df2=df2.sort_index(axis=1)
    
    df3=df2.sortlevel(1)
    df3=df3.sortlevel(0)
    df2.to_csv(os.path.join(root_dir,'pooled_dev','test4_add2.csv'))
    # df2.index.is_lexsorted()
    df3=df3.sortlevel(0)
    df3=df3.loc[idx[keep_rows,keep_subjects],idx[keep_PVAs,keep_output]]
    df3=df3.sortlevel(0)
    df3.to_csv(os.path.join(root_dir,'pooled_dev','test5_delete_orig2.csv'))


    import pdb
    pdb.set_trace()

    proportion_confint()

if __name__=="__notes__":
    for row in df1.index.levels[0]:
        new_row=df1.loc[idx[row,'0010_00'],:]+df1.loc[idx[row,'0010_03'],:]
        df1.loc[idx[row,'0010'],:]=new_row.T
        new_row=df1.loc[idx[row,'0149_rpi18-2016-02-17-08-38-13.566218'],:]+df1.loc[idx[row,'0149_rpi18-2016-02-17-08-43-02.524207'],:]
        df1.loc[idx[row,'0149'],:]=new_row.T
    idx = pd.IndexSlice
    df1=df1.sort_index(axis=0)
    df1=df1.sort_index(axis=1)
    df1.index.is_lexsorted()
    df2=df1.loc[idx[keep_rows,keep_subjects],idx[keep_PVAs,keep_output]]
    df2.to_csv(os.path.join(root_dir,'pooled_dev','test3_add_2.csv'))


if __name__=="__other__":
    df1=df1.loc[idx[keep_rows,:],idx[keep_PVAs,keep_output]]
    #add two together
    for row in keep_rows:
    #for row in df1.index.levels[0]:
        new_row=df1.loc[idx[row,'0010_00'],:]+df1.loc[idx[row,'0010_03'],:]
        df1.loc[idx[row,'0010'],:]=new_row.T
        new_row=df1.loc[idx[row,'0149_rpi18-2016-02-17-08-38-13.566218'],:]+df1.loc[idx[row,'0149_rpi18-2016-02-17-08-43-02.524207'],:]
        df1.loc[idx[row,'0149'],:]=new_row.T

    df1=df1.sort_index(axis=0)
    df1=df1.sort_index(axis=1)
    df2 = df1.sort_index()
    df1.index.is_lexsorted()
    df1.columns.is_lexsorted()

    import pdb
    pdb.set_trace()
    # df2=df1.loc[idx[keep_rows,:],:]

    # df3=df1.loc[idx[:,'0149_rpi18-2016-02-17-08-38-13.566218'],]+df1.loc[idx[:,'0149_rpi18-2016-02-17-08-43-02.524207'],:]
    


    df2=df1.loc[idx[keep_rows,keep_subjects],idx[keep_PVAs,keep_output]]

    # df2=df1.loc[idx[keep_rows,:],idx[keep_PVAs,keep_output]]
    
    #combine 10

    #combine 149
    # for row in keep_rows:
    #     new_row=df1.loc[idx['TPs','0149_rpi18-2016-02-17-08-38-13.566218'],idx[keep_PVAs,keep_output]]+df1.loc[idx['TPs','0149_rpi18-2016-02-17-08-43-02.524207'],idx[keep_PVAs,keep_output]]
    #     df2.loc[idx[row,'149'],:]=new_row.T


    # 149TNs=df1.loc[idx['TPs','0149_rpi18-2016-02-17-08-38-13.566218'],idx[keep_PVAs,keep_output]]+df1.loc[idx['TPs','0149_rpi18-2016-02-17-08-43-02.524207'],idx[keep_PVAs,keep_output]]
    # df2[('TNs','0149')]=149TNs.T


    df2.to_csv(os.path.join(root_dir,'pooled_dev','test3_add_2.csv'))

    #dfmi.loc[idx[:,:,['C1','C3']],idx[:,'foo']]

    pooled_df=pool_stats(df)

    import pdb
    pdb.set_trace()


    output_csv=os.path.join(root_dir,'pooled_dev','pooled1.csv')
    pooled_df.to_csv(output_csv)





    stats_dir = os.path.join(root_dir+r'accuracies/')
    output_csv = os.path.join(root_dir+r'accuracies/'+"pooled_stats_TOR3_2_8.csv")
    aggregate_stats(stats_dir,ppvi_list=['dbl.4','bs.1','mt','co','co.2','co.3','co.4','vd.2','su'],
        output_csv=output_csv,
        matrix_keywords=["multi_frame2__ACCURACY","solo__ACCURACY"],
        stat_list=['accuracy','sensitivity','specificity','total','events','FNs','FPs','TPs'])

        # pooled_dir=pooled_dir,matrix_keyword="ACCURACY")
        # pooled_dir=pooled_dir,matrix_keyword="solo__ACCURACY")
