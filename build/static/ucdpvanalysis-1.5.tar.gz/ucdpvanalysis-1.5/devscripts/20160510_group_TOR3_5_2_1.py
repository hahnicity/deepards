# -*- coding: utf-8 -*-
"""
Created on Thu Jan 14 23:14:55 2016

@author: Keiko

1.1 Add pooled stats as function and df piping
1.2 Add actual poole dstats
1.2.1 det_subdir=r'20160503_TOR3_5_0_group_results_post_merge'
1.2.4 det_subdir=r'20160510_TOR3_5_2_1_new_derivation'


based on 20160421_stats_add_true_pooled.py
based on 20160418_TOR3_4_2_group_post_cough
added dynamic list update
based on 20160301_TOR3_group2.py
based on 20160224_TOR3_group.py
based on 20160216_TOR3_derivation_RUNME.py
based on 20160211_TOR3_derivation_RUNME.py
based on 20160202_TOR3_trunc_run_RUNME.py
run in mac
"""
from __future__ import division
__version__="1.2.4"

import sys
import os
import time
import pandas as pd
gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.TOR3 as TOR
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)
import analytics.pool_stats as pool; reload(pool)
import pdb

start_time = time.time() 
#%%change these!!
root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/'
input_subdir=r'0TestFiles/20160425_new_derivation'
# gold_subdir=r'0TestFiles/20160425_new_derivation_gold'
gold_subdir=r'0TestFiles/20160510_new_derivation_gold_combine_cosumtvd'
det_subdir=r'20160510_TOR3_5_2_1_new_derivation2'


runTOR = False

#%%remember to use new input directory!!!!


aggregated_stats_csv="aggregated_stats_PIPE_with_sumt"+det_subdir+".csv" #optional, change pooled stats_name
real_pooled_stats_csv="pooled_stats_PIPE_with_sumt"+det_subdir+".csv" #optional, change pooled stats_name

out_suffix=''

#change root_dir
os.chdir(root_dir)
#make subfolder for accuracies
det_analysis_subdir=os.path.join(det_subdir,'accuracies')

#move to an outside function
def fancy_get_file_names(input_subdir,ends_with="",strip_suffix=False,
                        contains=""):
    """
    Gets file names from a directory and returns a list
    Versions 2016-04-14

    Args:
    -----
     input_subdir: path to input subdirectory
     ends_with: suffix that the file should have
     strip_suffix: removes the suffix in the output (ex. print names without ".csv")
     contains: keyword that file should contains

    examples:
    ---------
        #get csv files only and remove ".csv" at the end
        files=fancy_get_file_names(input_subdir=gold_subdir,
                                    ends_with=".csv",strip_suffix=True,
                                    contains="")
        #get log files but keep ".txt" at the end
        files=fancy_get_file_names(input_subdir=gold_subdir,
                                    ends_with=".txt",strip_suffix=False,
                                    contains="logfile")

        #get a list of any file in the directory
        files=fancy_get_file_names(input_subdir=gold_subdir,
                                    ends_with="",strip_suffix=False,
                                    contains="")  
        # or
        files=fancy_get_file_names(gold_subdir)      

    """
    file_list=[]
    suffix = ends_with
    keyword = contains
    copy_file_name = False
    for root,dirs,files in os.walk(input_subdir):
        for file_name in files:
            if file_name.endswith(suffix) and keyword in file_name:
                if strip_suffix:
                    file_name=file_name.rstrip(suffix)
                file_list.append(file_name)

    return file_list

filelist=[
'0086-2015-11-22-10-52-12.csv',
'0099_10_26_59.csv',
'0122_2016-01-28-15-29-25.csv',
'0126-2016-01-28-09-04-51.csv',
'0140-2016-02-08-16-13-46.csv'
]

interval_list=[
[1850,  2149],
[300, 599],
[1, 299],
[1020,  1319],
[1900,  2199],
]

try:
    os.mkdir(det_subdir)
except:
    print "'%s' subdirectory already exists" %det_subdir
try:
    os.mkdir(det_analysis_subdir)
except:
  print "'%s' subdirectory already exists" %det_analysis_subdir
if runTOR:
    for input_file,interval in zip(filelist,interval_list):
           print input_file, interval[0],interval[1]
           altBN_pt2,altRelTime_pt2=TOR.detectPVI(
                         input_file=input_file, 
                         outName='',outSuffix=out_suffix,
                         input_subdir=input_subdir,
                         output_subdir=det_subdir,
                         BNinterval=[interval[0],interval[1]],
                         altBNstart=0,altRelTimeStart=0,
                         tvePos=True, dt=0.02,gender="female",ptHeight=67,
                         keepBS=False,addRelTime=True,
                         outSubsets=False)       

gold_file_list = fancy_get_file_names(input_subdir=gold_subdir,
                    ends_with=".csv",strip_suffix=False)


# for gold in gold_file_list:
#     print gold

log_file_list = fancy_get_file_names(input_subdir=det_subdir,
                    ends_with="logfile.txt",strip_suffix=False)
# for logfile in log_file_list:
#     print logfile

#ensure there are the same number of files in each folder
error_message =  "Different number of gold files(%s) vs. logfiles(%s)"%(len(gold_file_list),len(log_file_list))
assert len(gold_file_list)==len(log_file_list),error_message

log_file_list.sort()
gold_file_list.sort()

# assert len(gold_file_list)==5, "Files do not match up"


for gold_file,log_file in zip(gold_file_list,log_file_list):
    assert gold_file[0:4]==log_file[0:4], "File mismatch: %s, %s" %(gold_file,logfile)
    print '\n',log_file, gold_file
    print '-----------------'


    # try:
    sta.calcMultiStats(logfile=log_file,
        gold_name=gold_file,
        det_subdir=det_subdir,output_subdir=det_analysis_subdir,gold_subdir=gold_subdir,
        subfiles_list=[
                    '_class_matrix_raw.csv',
                    '_class_matrix_raw_multi_frame2.csv',                 
                    '_solo.csv',
                    '_solo2.csv',
                    '_solo3.csv'])

    # except IOError:
    #     print IOError
    #     print log_file
    #     pdb.set_trace()
    # except:
    #     print "other error"
    #     print log_file

#aggregate results together
# from analytics.pool_stats import aggregate_stats
agg_df=pool.aggregate_stats(det_analysis_subdir,ppvi_list=['dbl.2','dbl.4','bs.1','mt','mt.su','co.noTVi','vd.2','su.2','sumt'],

# agg_df=pool.aggregate_stats(det_analysis_subdir,ppvi_list=['dbl.2','dbl.4','bs.1','mt','mt.su','co.orig','co.2thresh','co.noTVi','vd.2','su.2','sumt'],
        # output_csv=output_csv,
        matrix_keywords=["raw__ACCURACY","multi_frame2__ACCURACY","solo3__ACCURACY"],
        stat_list=['accuracy','sensitivity','specificity','total','events','FNs','FPs','TPs','TNs'])


agg_df.to_csv(os.path.join(det_analysis_subdir,aggregated_stats_csv))
#pool results together
new = pool.pool_stats(agg_df)
new.to_csv(os.path.join(det_analysis_subdir,real_pooled_stats_csv))


run_time=(time.time() - start_time)
print "-------%s seconds elapsed" %run_time
quit()
