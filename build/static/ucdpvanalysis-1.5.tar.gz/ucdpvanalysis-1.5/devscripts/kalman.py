# -*- coding: utf-8 -*-
"""
Created on Tue Aug 04 14:18:05 2015

@author: Keiko
@purpose: test feasibility of using preprocess kalman filter
"""

from __future__ import division
#run TOR.py first
import os
import numpy as np
import sys
import csv
sys.path.insert(0, r'C:\allMYfiles\My_Documents\GitHub\ucdpv\analysis')
import dicts; reload(dicts)
import stats; reload(stats)
import pviplot; reload (pviplot)
sys.path.insert(0, r'C:\allMYfiles\My_Documents\GitHub\ucdpv\parse\static\py')
import plot_bokeh; reload(plot_bokeh)
import matplotlib.pyplot as plt
from mpld3 import plugins
import pandas as pd
from collections import Counter

# imports for Bokeh plotting
from bokeh.plotting import figure, gridplot
from bokeh.plotting import figure, output_notebook, show, output_file, ColumnDataSource
from bokeh.models import LinearAxis, Range1d,Circle
from bokeh.models import HoverTool, WheelZoomTool, PanTool,ResizeTool,ResetTool,CrosshairTool, Callback
from bokeh.properties import value
import sklearn.metrics
import statsmodels.stats.inter_rater
from mpl_toolkits.axes_grid1 import make_axes_locatable
# for pylab plotting
import pylab


root_dir=r'C:\allMYfiles\My_Documents\GitHub\sandbox8_kalman'
os.chdir(root_dir )
input_subdir='input'
output_subdir='output'

input_file='WF_B2CRPi01__2015-02-19__10_17_19.590102799.csv'
filename=os.path.splitext(input_file) [0]

#%% import detected


det_path = os.path.join(output_subdir,filename+'_annoM.csv')
det = pd.read_csv(det_path, index_col = 'BN')
det[det>0].describe()
det.head()

clin_path = os.path.join(output_subdir,filename+'_clinM.csv')
clin = pd.read_csv(clin_path, index_col = 'breath #')
breath_dict = {}
for i in range(1,len(clin)+1):
    BS = round(clin.loc[i,'BS'],2)
    IE = round(clin.loc[i,'insp end'],2)
    breath_dict[i]=(BS,IE)

breathList = [round(i,2) for i in clin.BS]
breathList = [0]+breathList
wave_path = (os.path.join(output_subdir, filename+'_plain.csv'))
df_big = pd.read_csv(wave_path, names = ['time', 'flow', 'pressure']) 
t, pressure, flow, tlist = plot_bokeh.splitWave(df_big)
#%%
BSs=breathList[1:]
BNs=range(1,len(breathList))
x = t
y1 = pressure
y2 = flow

startBN = 8400
endBN = 8410

startBS = round(breath_dict[startBN][0],2)
endBS = round(breath_dict[endBN] [0],2)
Lindex = tlist.index(startBS)
Rindex = tlist.index(endBS)   


#%% imported KF filter

# Implements a linear Kalman filter.
class KalmanFilterLinear:
  def __init__(self,_A, _B, _H, _x, _P, _Q, _R):
    self.A = _A                      # State transition matrix.
    self.B = _B                      # Control matrix.
    self.H = _H                      # Observation matrix.
    self.current_state_estimate = _x # Initial state estimate.
    self.current_prob_estimate = _P  # Initial covariance estimate.
    self.Q = _Q                      # Estimated error in process.
    self.R = _R                      # Estimated error in measurements.
  def GetCurrentState(self):
    return self.current_state_estimate
  def Step(self,control_vector,measurement_vector):
    #---------------------------Prediction step-----------------------------
    predicted_state_estimate = self.A * self.current_state_estimate + self.B * control_vector
    predicted_prob_estimate = (self.A * self.current_prob_estimate) * np.transpose(self.A) + self.Q
    #--------------------------Observation step-----------------------------
    innovation = measurement_vector - self.H*predicted_state_estimate
    innovation_covariance = self.H*predicted_prob_estimate*np.transpose(self.H) + self.R
    #-----------------------------Update step-------------------------------
    kalman_gain = predicted_prob_estimate * np.transpose(self.H) * np.linalg.inv(innovation_covariance)
    self.current_state_estimate = predicted_state_estimate + kalman_gain * innovation
    # We need the size of the matrix so we can make an identity matrix.
    size = self.current_prob_estimate.shape[0]
    # eye(n) = nxn identity matrix.
    self.current_prob_estimate = (np.eye(size)-kalman_gain*self.H)*predicted_prob_estimate

#%%
x = t[Lindex:Rindex]
p0 = pressure[Lindex:Rindex]
f0 = flow [Lindex:Rindex]

#from pykalman import KalmanFilter
#kf = KalmanFilter(initial_state_mean=0, n_dim_obs=3)
#means,covariances=kf.filter(p0.tolist())

numsteps = len(x)
A = np.matrix([1])
H = np.matrix([1]) # this is an identity matrix of?
B = np.matrix([0])
Q = np.matrix([0.00001])
R = np.matrix([0.1])
xhat = np.matrix([3])
P    = np.matrix([1])

filter = KalmanFilterLinear(A,B,H,xhat,P,Q,R)
measured = []
p1 = []
for i in range(numsteps):
    measured_i = p0.iloc[i]
    measured.append(measured_i)
    p1.append(filter.GetCurrentState()[0,0])
    filter.Step(np.matrix([0]),np.matrix([measured_i]))

filter = KalmanFilterLinear(A,B,H,xhat,P,Q,R)
measured = []
f1 = []
for i in range(numsteps):
    measured_i = f0.iloc[i]
    measured.append(measured_i)
    f1.append(filter.GetCurrentState()[0,0])
    filter.Step(np.matrix([0]),np.matrix([measured_i]))

#%% plot

pylab.plot(range(numsteps),measured,'b',range(numsteps),p1,'g')
pylab.xlabel('Time')
pylab.ylabel('Pressure')
pylab.title('Pressure with Kalman Filter')
pylab.legend(('measured','kalman'))
pylab.show()

#%%
plotWidths = 1000
source = ColumnDataSource(
    data = dict(
        x  =t[Lindex:Rindex],
        p0 = pressure[Lindex:Rindex],
        f0 = flow [Lindex:Rindex],
        p1=p1,
        f1=f1
        ))
source2 = ColumnDataSource(
    data = dict(
        BSs= BSs[startBN-1:endBN],
        BNs= BNs[startBN-1:endBN],
        ))



#%%graph
output_file(os.path.join(output_subdir, filename +'_plot.html'))
tools = " xpan,  xwheel_zoom, resize,crosshair,box_zoom, reset"



middle = figure(plot_width=plotWidths, plot_height=300,
                tools = tools)
middle.line('x', 'p1', line_width=0.5, legend = 'pressure', line_color="purple", 
            source=source)
middle.scatter('x','p0',legend="pressure",marker="circle",fill_color="purple",
               source=source, size=2, line_alpha=0)
#height = max(y1)-min(y1)
middle.text('BSs', y= 3, text ='BNs', text_font_size=value("10pt"), source=source2)
#middle.rect('BSs', y=0, width=0.02, height=1, fill_alpha=0.2, color='grey', source=source2) 
#
bottom = figure(plot_width=plotWidths, plot_height=300,
                tools = tools, x_range=middle.x_range)
bottom.line('x', 'f1', line_width=0.5, legend='flow', line_color="blue", 
            source=source)
bottom.scatter('x','f0',legend="flow",marker="circle",fill_color="blue",
               source=source, size=2, line_alpha=0)

bottom.xaxis.axis_label = "Time(s)"


g = gridplot([[middle],[bottom]])
show(g)

#
##%%graph (bigger)
#output_file(os.path.join(output_subdir, filename +'_plot.html'))
#tools = " xpan,  xwheel_zoom, resize,crosshair,hover, reset"
#
#
#
#middle = figure(plot_width=plotWidths, plot_height=300,
#                tools = tools)
#middle.line('x', 'p0', line_width=0.5, legend = 'pressure', line_color="purple", 
#            source=source)
#middle.scatter('x','p0',legend="pressure",marker="circle",fill_color="purple",source=source)
##height = max(y1)-min(y1)
##middle.text('BSs', y= 30, text ='BNs', text_font_size=value("10pt"), source=source2)
##middle.rect('BSs', y=0, width=0.02, height=1, fill_alpha=0.2, color='grey', source=source2) 
##
#bottom = figure(plot_width=plotWidths, plot_height=300,
#                tools = tools, x_range=middle.x_range)
#bottom.line('x', 'f0', line_width=0.5, legend='flow', line_color="blue", 
#            source=source)
#bottom.xaxis.axis_label = "Time(s)"
#
#
#g = gridplot([[middle],[bottom]])
#show(g)
