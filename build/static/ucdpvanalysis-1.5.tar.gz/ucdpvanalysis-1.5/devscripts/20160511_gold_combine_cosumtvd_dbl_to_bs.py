"""
Created on Mon Apr 11 
@author: Keiko

from 20160411_gold_combine_cosumtvd.py
from 
"""

import os
import pandas as pd
import numpy as np
import pdb
# import sys

# gitPath=r'/Users/monica/github/ucdpv/analysis/'
# if gitPath not in sys.path:
#      sys.path.append(gitPath)
# import annotations.add_vent_bn_and_ts as add_vent_bn_and_ts;reload(add_vent_bn_and_ts)
# #TODO eventually add timestamp adding


def fancy_get_file_names(input_subdir,onlyCSV=True,stripCSV=True):
    """
    Versions 2016-04-14
    """
    file_list=[]
    copy_file_name = False
    for root,dirs,files in os.walk(input_subdir):
        for file_name in files:
            if file_name.endswith('.csv'):
                if stripCSV:
                    file_name=file_name.rstrip('.csv')
                file_list.append(file_name)
                # copy_file_name=True
            elif onlyCSV==False:
                file_list.append(file_name)
                # copy_file_name=True

    if copy_file_name:
        file_list.append(file_name)
    return file_list
def get_file_names(input_subdir):
    file_list=[]
    for root,dirs,files in os.walk(input_subdir):
        for file_name in files:
            file_list.append(file_name.rstrip('.csv'))
    return file_list
def get_csv_files(input_subdir):
    file_list=[]
    for root,dirs,files in os.walk(input_subdir):
        for full_file_name in files:
            if full_file_name.endswith('.csv'):
                file_list.append(full_file_name)
    return file_list    
    #print file_list
    #http://stackoverflow.com/questions/21702342/creating-a-new-column-based-on-if-elif-else-condition
def is_sumt(row):
    "new value for sumt column"
    if row['su']>0 or row['mt']>0:
        val = 1
    else:
        val = 0
    return val

def is_cosumtvd(row):
    "new value for cosumtvd column"
    if row['co']>0 or row['su']>0 or row['mt'] or row['vd']>0:
        val = 1
    else:
        val = 0
    return val

def change_dbl_to_bs(temp_df):
    """
    change DBL -> BS if e-time is 0.3
    for files coming off the new pipeline
    """
    if 'e-time' in temp_df.columns and 'abs time' in temp_df.columns:
        for idx in temp_df.index:
            notLast = idx<temp_df.index[-1] # PROBABLY should change the index values to make this unneccessary

            if temp_df.loc[idx,'e-time']==0.3 and temp_df.loc[idx,'dbl']==1 and notLast:
                temp_df.loc[idx,'dbl']=0
                temp_df.loc[idx+1,'dbl']=0
                temp_df.loc[idx,'bs']=1

    return temp_df


def process_file (input_csv,output_csv):
    """
    process_file
    Versions
    20160512 V1.0 Make SUMT and COSUMT into a function
    """
    #read the csv
    temp_df = pd.read_csv(input_csv,index_col="BN")
    #determine if sumt is present
    temp_df['sumt']=temp_df.apply(is_sumt,axis=1)
    #determine if cosumtvd is present
    temp_df['cosumtvd']=temp_df.apply(is_cosumtvd,axis=1)  
    #change DBL -> BS if e-time is 0.3
    temp_df=change_dbl_to_bs(temp_df=temp_df)
    #output to csv
    temp_df.to_csv(output_csv)

#an example 1 running from command line
if __name__ == "__notmain__": #change this to main
    root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/'
    os.chdir(root_dir)
    
    gold_subdir=r'0TestFiles/20160425_new_derivation_gold'
    output_subdir=r'0TestFiles/20160511_new_derivation_gold_add_cosumtvd_dbl_to_bs'

    try:
      os.mkdir(output_subdir)
    except OSError:
      print "/--'%s' subdirectory already exists-- \n" %output_subdir

    input_csv=os.path.join(gold_subdir,'0099_10_26_59_datetime_removed_1_300to600_goldstd_dbl_bs_cosumtvd.csv')
    output_path=os.path.join(output_subdir,'test.csv')

    process_file(input_csv,output_path)
    print "%s --processed" %(output_path)


# #example 2, multiple files
if __name__=="__main__":
    root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/'
    os.chdir(root_dir)
    
    gold_subdir=r'0TestFiles/20160425_new_derivation_gold'
    output_subdir=r'0TestFiles/20160511_new_derivation_gold_add_cosumtvd_dbl_to_bs'

    try:
        os.mkdir(output_subdir)
    except OSError:
        print "--/'%s' subdirectory already exists \n" %output_subdir

    files=fancy_get_file_names(input_subdir=gold_subdir,onlyCSV=True)
    
    for gold_file in files:
        #create paths for the input and output csv
        input_csv = os.path.join(gold_subdir,gold_file+".csv")
        print input_csv
        output_csv = os.path.join(output_subdir,gold_file+"_comb_cosumtvd.csv")
        
        process_file(input_csv,output_csv)

        print "%s --processed" %(gold_file+"_comb_cosumtvd.csv")
