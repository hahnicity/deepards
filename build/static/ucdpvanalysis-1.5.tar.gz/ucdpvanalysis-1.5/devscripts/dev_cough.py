# -*- coding: utf-8 -*-
"""
Created on Tue Aug 25 13:25:20 2015

@author: Keiko

This script is originally based on TVviol and is used for developing 
the cough algorithm. Output only contains heatmap.
"""
from __future__ import division
#run TOR.py first
import os
import numpy as np
import sys
import csv
sys.path.insert(0, r'C:\allMYfiles\My_Documents\GitHub\ucdpv\analysis')
import dicts
reload(dicts)
import stats
reload(stats)
import pviplot
reload (pviplot)
sys.path.insert(0, r'C:\allMYfiles\My_Documents\GitHub\ucdpv\parse\static\py')
import plot_bokeh; reload(plot_bokeh)
import matplotlib.pyplot as plt
from mpld3 import plugins
import pandas as pd
from collections import Counter

# imports for Bokeh plotting
from bokeh.plotting import figure, gridplot
from bokeh.plotting import figure, output_notebook, show, output_file, ColumnDataSource
from bokeh.models import LinearAxis, Range1d,Circle
from bokeh.models import HoverTool, WheelZoomTool, PanTool,ResizeTool,ResetTool,CrosshairTool, Callback
from bokeh.properties import value
import sklearn.metrics
import statsmodels.stats.inter_rater
from mpl_toolkits.axes_grid1 import make_axes_locatable

root_dir=r'C:\allMYfiles\My_Documents\GitHub\sandbox11_cough'
os.chdir(root_dir )
input_subdir='input'
output_subdir='output'


input_file='rpi3.csv'
filename=os.path.splitext(input_file) [0]
input_path=os.path.join (output_subdir, input_file) 
gs_path = os.path.join (input_subdir,filename+'_gold_standard.csv')

#root_dir=r'C:\allMYfiles\My_Documents\GitHub\sandbox7_TVviol'
#os.chdir(root_dir )
#input_subdir='input'
#output_subdir='output'
#
#
#input_file='2015-01-07__dla_term2.csv'
#filename=os.path.splitext(input_file) [0]
#input_path=os.path.join (output_subdir, input_file) 
#gs_path = os.path.join (input_subdir,filename+'_gold_standard.csv')
#%% import detected


det_path = os.path.join(output_subdir,filename+'_detectedCombined.csv')
det = pd.read_csv(det_path, index_col = 'BN')
det[det>0].describe()
det.head()

clin_path = os.path.join(output_subdir,filename+'_clinValues.csv')
clin = pd.read_csv(clin_path, index_col = 'BN')
#breath_dict = {}
#for i in range(1,len(clin)+1):
#    BS = round(clin.loc[i,'BS'],2)
#    IE = round(clin.loc[i,'insp end'],2)
#    breath_dict[i]=(BS,IE)

breathList = [round(i,2) for i in clin.BS]
breathList = [0]+breathList
wave_path = (os.path.join(output_subdir, filename+'_plain.csv'))
df_big = pd.read_csv(wave_path, names = ['time', 'flow', 'pressure']) 
t, pressure, flow, tlist = plot_bokeh.splitWave(df_big)


#%%import cviz anns
#gs_path = os.path.join (input_subdir, '2015-01-07__dla_term2_gold_standard.csv')

#gs = stats.readCvizAnns(gs_path, 'gold standard', input_file)
#gs.replNames(dicts.abbrev)
#gs.removeNormals()
#gs.byBreath(breathList)
#newIndex = [int(j) for j in gs.byBreath_a[1:,0]]
#gold = pd.DataFrame(gs.byBreath_a[1:,1], index=newIndex, columns=["gs"])




#%%preprocess

det = det.replace(0,np.nan)



#%%plotting waveform
output_file(os.path.join(output_subdir, filename +'_plot.html'))

x=t
y1 = pressure
y2 = flow
BSs=breathList[1:]
BNs=range(1,len(breathList))

plotWidths = 1000
source = ColumnDataSource(
    data = dict(
        x  =t,
        y1 = pressure,
        y2 = flow,
        BSs= BSs,
        ))

hover = HoverTool(tooltips=[
    ("index",'$index'),
#    ("(x,y)", "($x, $y)"),
    ("t",'@x'),
    ("pressure: ", '@y1'),
    ("flow: ", '@y2')
    ])
zoom = WheelZoomTool(dimensions=['width'])
pan = PanTool(dimensions=['width'])
resize = ResizeTool()
reset = ResetTool()
crosshair = CrosshairTool()
TOOLS = [pan, zoom, hover, resize, crosshair, reset]
tools = " xpan,  xwheel_zoom, resize, box_zoom,crosshair, reset"


##%% plotting annotations
#
#
#toPlot = {}
#
#anns = det.columns[1:].tolist()
#ylabel = ['gs', 'comb', ''] + anns + ['BNs'] + ['']
##ylabel = ylabel[::-1] #reverses order
#
##establishes the plot
#top = figure(plot_width=plotWidths, plot_height=300, tools = tools,
#              title = input_file, y_range=ylabel, x_range=middle.x_range)
#
#ylocBN = ['BNs']*len(BSs)
#top.text(x=BSs, y= ylocBN, text =BNs, text_font_size=value("10pt")) 
#
#toPlot['ylocBN']=['BNs']*len(BSs)
#toPlot['BSs']=BSs
#source2 = ColumnDataSource(toPlot)
#top.text(x='BSs', y= 'ylocBN', text =BNs, text_font_size=value("10pt"), source=source2)
#
#
##gs
#text = gold['gs'].tolist()
##xloc = gold['gs'].index
#xloc = [breathList[int(j)] for j in gold['gs'].index]
#yloc = ['gs']*len(xloc)
#color = [dicts.colors[j] for j in text]
#top.text(x=xloc, y=yloc, text=text, text_font_size=value("10pt"), text_color="gray")
#top.circle(x=xloc, y=yloc, size=10, alpha=0.5, color=color)
##top.rect(x=xloc, y=yloc, width=1, height=1, alpha=0.5, color=color )
#
##combined
#text = det['comb'].tolist()
#xloc = [breathList[j] for j in det['comb'].index]
##xloc = det['comb'].index
#yloc = ['comb']*len(xloc)
#color = [dicts.colors[j] for j in text]
#top.text(x=xloc, y=yloc, text=text, text_font_size=value("10pt"), text_color="gray")
#top.circle(x=xloc, y=yloc, size=10, alpha=0.5, color=color)
##top.rect(x=xloc, y=yloc, width=1, height=1, alpha=0.5, color=color )
#
##rest of the matrix
#for i in range(1,len(det.columns)):
#    origCol = det.columns[i]
#    col=origCol.split('.')[0]
##    print col
#    if col == 'bs':
#        det[origCol]= det[origCol].replace(1,'bsl')
#        det[origCol]= det[origCol].replace(2,'bsm')
#        det[origCol]= det[origCol].replace(3,'bss')
#    elif col == 'tvv':
#        det[origCol]= det[origCol].replace(49,'tvl')
#        det[origCol]= det[origCol].replace(51,'tvh')
#        det[origCol]= det[origCol].replace(52,'tvs')
#    elif col in ['mt', 'su']:
##        a = det[col]
##        det.loc[:,(origCol)]=col
##        det.loc[:,origCol][det.loc[:,origCol]!=0]=col
##        det[origCol][det[origCol]!=0]=col
#        mask=det.loc[:,origCol]>0
#        det.loc[mask,origCol]=origCol
##        print det[col]   
#    else:   
#        det[origCol]= det[origCol].replace(1,col)
##    masked = det[origCol][det[origCol]>0]
##    text = masked.tolist()
###    xloc=masked.index
##    xloc = [breathList[j] for j in masked.index]
##    color = [dicts.colors[j] for j in text]
###    print(color)
#    
#    # maintains NaN placeholders
#    text=det[origCol].tolist()
#    color=stats.repl_names(text, dicts.colors)
#    xloc,yloc=stats.makeCoords(text,origCol,BSs)
#
#
##    top.text(x=xloc, y=yloc, text=text, text_font_size=value("10pt"), text_color="gray")
#    top.circle(x=xloc, y=yloc, size=10, alpha=0.5, color=color)
##    top.rect(x=xloc, y=yloc, width=1, height=1, alpha=0.5, color=color )
#    #y can also be -i    
#    



#%% plotting annotations as hm

hmPlot = {}

anns = det.columns[1:].tolist()
ylabel = ['gs', 'comb', ''] + anns + ['BNs'] + ['']
#ylabel = ylabel[::-1] #reverses order

#establishes the pot
hm = figure(plot_width=plotWidths, plot_height=300, tools = " xpan,  xwheel_zoom, resize, reset",
              title = input_file, y_range=ylabel) #x_range=bottom.x_range

#ylocBN = ['BNs']*len(BSs)
#hm.text(x=BSs, y= ylocBN, text =BNs, text_font_size=value("10pt")) 

hmPlot['ylocBN']=['BNs']*len(BSs)
hmPlot['BSs']=BSs
source4 = ColumnDataSource(hmPlot)

#gs
text = gold['gs'].tolist()
xloc = gold['gs'].index
#xloc = [breathList[int(j)] for j in gold['gs'].index]
yloc = ['gs']*len(xloc)
color = [dicts.colors[j] for j in text]
hm.text(x=xloc, y=yloc, text=text, text_font_size=value("10pt"), text_color="gray")
hm.rect(x=xloc, y=yloc, width=1, height=1, alpha=0.5, color=color )

#combined
text = det['comb'].tolist()
xloc = det['comb'].index
yloc = ['comb']*len(xloc)
color = [dicts.colors[j] for j in text]
hm.text(x=xloc, y=yloc, text=text, text_font_size=value("10pt"), text_color="gray")
hm.rect(x=xloc, y=yloc, width=1, height=1, alpha=0.5, color=color )

#rest of the matrix
for i in range(1,len(det.columns)):
    origCol = det.columns[i]
    col=origCol.split('.')[0]
    if col == 'bs':
        det[origCol]= det[origCol].replace(1,'bsl')
        det[origCol]= det[origCol].replace(2,'bsm')
        det[origCol]= det[origCol].replace(3,'bss')
    elif col == 'tvv':
        det[origCol]= det[origCol].replace(49,'tvl')
        det[origCol]= det[origCol].replace(51,'tvh')
        det[origCol]= det[origCol].replace(52,'tvs')
    elif col in ['mt', 'su']:
        mask=det.loc[:,origCol]>0
        det.loc[mask,origCol]=origCol
#        det[origCol][det[origCol]!=0]=col
    else:   
        det[origCol]= det[origCol].replace(1,col)
    
    masked = det[origCol][det[origCol]>0]
    text = masked.tolist()
    xloc=masked.index
    color = [dicts.colors[j] for j in text]
    yloc = [origCol]*len(xloc)
#    hm.text(x=xloc, y=yloc, text=text, text_font_size=value("10pt"), text_color="gray")
    hm.rect(x=xloc, y=yloc, width=1, height=1, alpha=0.5, color=color )

#%% TV plot
tvPlotData = ColumnDataSource(
    data = dict(
        BNs=BNs,
        BSs= BSs,
        TVis = clin.TVi.values
        ))
        
bottom = figure(plot_width=plotWidths, plot_height=300,
                 tools = " xpan,  xwheel_zoom, resize,crosshair, reset", x_range=hm.x_range )
bottom.line('BSs', 'TVis', line_width=1, source=tvPlotData, line_color="Grey")

# circle colors based on values
tvvs = det['tvv'].replace(np.nan,'n')
color = [dicts.colors[j] for j in tvvs] #creates new list with corresponding colors
tvPlotData.data['colors']=color
bottom.circle('BSs', 'TVis', color='colors', size=5, source=tvPlotData)

#adds rudimentary hovertool
bottom.add_tools(HoverTool(
    tooltips="""
    <div>
            TV:<span style="font-size: 17px; font-weight: bold;">[@TVis]</span><BR>
            BN:<span style="font-size: 15px; color: #966;">@BNs</span><BR>
            time: @BSs (sec)
        </div>    
    """))


# adds color bars to plot
maxBS=max(BSs)
maxTVi=max(clin.TVi.values)
bottom.quad(0,maxBS, TVcut1,0, fill_color='cyan', fill_alpha=0.1, line_alpha=0)
bottom.quad(0,maxBS, TVcut3,TVcut2, fill_color='red', fill_alpha=0.1, line_alpha=0)
bottom.quad(0,maxBS, maxTVi,TVcut3, fill_color='black', fill_alpha=0.1, line_alpha=0)

# adds text labels
TVcuts = [round(TVcut1,2), round(TVcut2,2), round(TVcut3,2)]
yloc = [0, TVcut2, TVcut3]
bottom.text([0,0,0],yloc, text = TVcuts )
bottom.yaxis.axis_label = "insp TVs (mL)"
bottom.xaxis.axis_label = "Gender:%s, height:%s in., PBW:%s kg" %(gender,str(ptHeight),str(PBW))
#%% render bokeh graph
show(hm)
#g = gridplot([[bottom], [hm]])
#show(g)


