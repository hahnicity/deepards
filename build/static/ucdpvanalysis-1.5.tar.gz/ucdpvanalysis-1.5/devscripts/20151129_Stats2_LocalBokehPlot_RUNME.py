# -*- coding: utf-8 -*-
"""
Created on Sun Nov 29 18:22:42 2015

@author: Keiko

Runme/driver file for algorithms/stats2

2015-12-08 Linked plotting
"""

from __future__ import division
import os
import pandas as pd
import sys
import numpy as np
#%% import files
root_dir=r'C:\allMYfiles\BOX\BedsideToCloud Pilot Project\PVI\Sandbox\20151114_Stats'
os.chdir(root_dir )

analyticsPath=r'C:\allMYfiles\My_Documents\GitHub\ucdpv\analysis'
if analyticsPath not in sys.path:
    sys.path.append(analyticsPath)
import stats2 as sta; reload(sta)
import dicts; reload(dicts)
#%%import
inputSubdir='input'
outputSubdir=r'output'
outputSubdir=r'output1208_twoDouble'

waveFile='0007_file_1of1__588to794_plain_v5_reltime_plain.csv'
goldFile='0007_file_1of1_1_587to795_gold_std_dbl_bs_cosumtvd.csv'
detFile = '0007_file_1of1__588to794_plain_v5_reltime_detected.csv'
filename='0007_file_1of1__588to794_plain_v5_reltime'

inputSubdir=r'output1208_twoDouble'
outputSubdir=r'output1208_twoDouble\stats_output'
waveFile='0007_file_1of1__588to794_plain_2.4.3_plain.csv'
goldFile='0007_file_1of1_1_587to795_gold_std_dbl_bs_cosumtvd.csv'
filename='0007_file_1of1__588to794_plain_2.4.3'

inputSubdir=r'output1208_twoDouble'
outputSubdir=r'output1208_twoDouble\stats_output'
waveFile='0008_10_17_20__2692to3031_plain_2.4.3_plain.csv'
goldFile='0008_10_17_20_2_2691to3031_gold_std_dbl_bs_cosumtvd.csv'
filename='0008_10_17_20__2692to3031_plain_2.4.3'

inputSubdir=r'output1208_twoDouble'
outputSubdir=r'output1208_twoDouble\stats_output'
waveFile='0008_10_17_20__3033to3076_plain_2.4.3_plain.csv'
goldFile='0008_10_17_20_2_3032to3077_gold_std_dbl_bs_cosumtvd.csv'
filename='0008_10_17_20__3033to3076_plain_2.4.3'



accFile=filename+"_accuracy.csv"

detPath =os.path.join(inputSubdir, filename+'_detected.csv')
dfDet=pd.read_csv(detPath,  index_col='BN')
dfPath =os.path.join(inputSubdir, goldFile)
dfGold=pd.read_csv(dfPath,  index_col='BN')


#%%call functions    
dfStats,dfCompared=sta.calcStats(dfDet,dfGold)
dfStatsShort=dfStats[0:3]
dfCounts=dfStats[5:]    
dfStats.to_csv(os.path.join(outputSubdir,accFile))

#converting to binary first
dfDetBinary=sta.convertAllBinary(dfDet)
dfStats2,dfCompared2=sta.calcStats(dfDetBinary,dfGold)
dfStats2.to_csv(os.path.join(outputSubdir,accFile))

print(dfStats2)

#%%
#%%
#%%new functions
def replace1swithName(dfDet,colPrefix='',printout=False):
    """
    
    Written:2015-11-29
    Updated:2015-12-08 Added ability to change name  
    """
    newDF=pd.DataFrame(index=dfDet.index, columns=dfDet.columns)
    newDF.ventBN=dfDet.ventBN
    newDF.BS=dfDet.BS

    for col in dfDet.columns.tolist():
        if colPrefix!='':
            newName=colPrefix+col
        else:
            newName=col
        if col not in ['BN','ventBN','BS']:
            if printout:
                print col, '--'
            newDF[col]=dfDet[col].replace(1,newName)
            newDF[col]=newDF[col].replace(0,np.NaN)
            if printout:
                list=newDF[col].tolist()
                print list
                
    return newDF

dfDetNames=replace1swithName(dfDetBinary)
#dfNewGold=replace1swithName(dfGold,colPrefix='GOLD-',printout=True)

#%%plot
from bokeh.plotting import figure, show, output_file, ColumnDataSource, gridplot

wavePath = (os.path.join(inputSubdir, filename+'_plain.csv'))
df_big = pd.read_csv(wavePath, names = ['time', 'flow', 'pressure']) 

title=filename
#%%
plotData=ColumnDataSource(df_big)

output_file(os.path.join(outputSubdir, filename +'_plot.html'), title=filename)
wavePlot = figure(webgl=True, title=title,plot_width=800,plot_height=400,
                tools="xpan, xwheel_zoom,resize,crosshair,reset")
wavePlot.line(x='time', y='flow', source=plotData)
wavePlot.line('time', 'flow', line_width=0.5, legend = 'pressure', 
            line_color="purple", source=plotData)
wavePlot.xaxis.axis_label = "Time(s)"
wavePlot.line('time', 'pressure', line_width=0.5, legend='flow', 
            line_color="blue", 
            source=plotData)
            
#show(wavePlot)

#%% heatmap
#future variables
PVItoGraph=[]
PVItoGraph=['GOLD-dbl','dbl','GOLD-mt','mt',
            'dbl.2','GOLD-bs','bs','GOLD-co','co','co.2','co.3','vd']

reload(dicts)
hmData=ColumnDataSource(dfDetNames)



#xlocation based on index
BNs=dfDetNames.index.tolist()
xloc=BNs
#xlocation based on time
xloc=dfDetNames.BS.tolist()
# add breath numbers
wavePlot.text(x='BS',y=50,text=BNs,source=hmData)

#default things to graph
if PVItoGraph==[]:
    ylabel=dfDetNames.columns.tolist()
    ylabel.remove('ventBN')
    ylabel.remove('BS')
#    ylabel.append('gold')
else:
    ylabel=PVItoGraph

hm = figure(webgl=True, title=title,plot_width=800,plot_height=400,
                tools="xpan, xwheel_zoom,resize,crosshair,reset",
                y_range=ylabel, x_range=wavePlot.x_range)


for pvi in ylabel:
    notGold=pvi.split('-')[0]!='GOLD'
    if pvi not in ['BN','ventBN','BS'] and notGold:
#        print pvi
        shortPVI=pvi.split('.')[0]
        color= dicts.colors[shortPVI]
#        hm.circle(x=xloc,y=pvi,source=hmData,alpha=0.5,color=color) 
        hm.rect(x=xloc,y=pvi,width=1,height=1,source=hmData,alpha=0.5,color=color) 

newGold=dfGold.replace(0,np.nan)
newGold.dbl=newGold.dbl.replace(1,'GOLD-dbl')
newGold.mt=newGold.mt.replace(1,'GOLD-mt')
newGold.co=newGold.co.replace(1,'GOLD-co')
newGold.co=newGold.bs.replace(1,'GOLD-bs')
hm.rect(x=xloc, y=newGold.dbl.tolist(), width=1,height=1,color='black')
hm.rect(x=xloc, y=newGold.mt.tolist(), width=1,height=1,color='black')
#hm.rect(x=xloc, y=newGold.co.tolist(), width=1,height=1,color='black')
#hm.rect(x=xloc, y=newGold.bs.tolist(), width=1,height=1,color='black')


both=gridplot([[hm],[wavePlot]]) 
show(both)
