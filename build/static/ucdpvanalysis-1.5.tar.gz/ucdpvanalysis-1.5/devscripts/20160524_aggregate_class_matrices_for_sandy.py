
"""
Created on Tue May 24 15:26 PM
@author: Keiko
Based on pool_stats.py
development file.
target file  analytics/aggregate_class_matrices.py

based on 20160524_aggregate_class_matrices
"""
import pandas as pd
import os
import sys

gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.solo_fused as fused; reload(fused)
import utilikilt.oz as oz
import glob

import analytics.aggregate_class_matrices as AGG

root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/20160524_aggregate_for_Sandy'
os.chdir(root_dir)

input_dir=r'test_build/test_build_inputs'
output_dir=r'20160524_aggregate_for_Sandy'
output_dir=r'test_build'
output_path=r"0526_1.csv"

# aggregated = AGG.stack(input_dir=input_dir,
#                         index_col="BN",
#                         keep_col_list=['dbl','bs','co','sumt','vd','cosumtvd'])


# aggregated.to_csv(output_path)

input_dir=r'20160513_combined_derivation_gold'
# input_dir=r'test_build/test_build_inputs'
# input_dir=r'half'

aggregated=AGG.stack(input_dir=input_dir,
                    index_col="BN",
                    keep_col_list=['dbl','bs','co','sumt','vd','cosumtvd'])
aggregated.to_csv(os.path.join(output_dir,os.path.basename(input_dir)+"TEST3.csv"))