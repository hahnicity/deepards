# -*- coding: utf-8 -*-
"""
Created on Thu Jan 14 23:14:55 2016

@author: Keiko

based on 20160202_TOR3_trunc_run_RUNME.py
run in mac
"""
import sys
import os
import time
import pandas as pd
gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.TOR3 as TOR
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)


start_time = time.time() 
#%%change these!!
root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox'
os.chdir(root_dir)
input_subdir=r'0TestFiles/fullFiles'
output_subdir=r'20160206_Derivation'
out_suffix='_TOR3_1_0'

filelist=[
'0001_10_17_19.csv',
'0002_09_14_38.csv',
'0004_09_23_46.csv',
'0007_file_1of1.csv',
'0008_10_17_20.csv',
'0009_03_19_47.csv',
'0010_03_17_19_deleted_first_line.csv',
'0011_14_17_21.csv',
'0012_19_53_45_first_and_last_line_deleted.csv',
'0013_15_49_102.csv',
'20151008_gwf2_q2hr_whileloop_expt_17_15_31_first_line_deleted.csv'
]

interval_list=[
[4280,   4578],
[2400,   2700],
[2200,   2500],
[2804,   3202],
[2692,   3030],
[1825,   2125],
[1401,   1699],
[475,    773],
[35129,  35427],
[27671,  27969],
[950,    1248]
]
for input_file,interval in zip(filelist,interval_list):
       print input_file, interval[0],interval[1]
       altBN_pt2,altRelTime_pt2=TOR.detectPVI(
                     input_file=input_file, 
                     outName='',outSuffix=out_suffix,
                     input_subdir=input_subdir,
                     output_subdir=output_subdir,
                     BNinterval=[interval[0],interval[1]],
                     altBNstart=0,altRelTimeStart=0,
                     tvePos=True, dt=0.02,gender="female",ptHeight=67,
                     printout=True,
                     writePlain=True,keepBS=False,addRelTime=True)       






# #%%truncation pt 2
# altBN_pt2,altRelTime_pt2=TOR.detectPVI(
#               input_file='0002_09_14_38.csv', 
#               outName='',outSuffix=out_suffix,
#               input_subdir=input_subdir,
#               output_subdir=output_subdir,
#               BNinterval=[2400,2700],altBNstart=0,altRelTimeStart=0,
#               tvePos=True, dt=0.02,gender="female",ptHeight=67,
#               printout=True,
#               writePlain=True,keepBS=False,addRelTime=True)

# #%%truncation pt 4
# altBN_pt4,altRelTime_pt4=TOR.detectPVI(
#               input_file='0004_09_23_46.csv', 
#               outName='',outSuffix=out_suffix,
#               input_subdir=input_subdir,
#               output_subdir=output_subdir,
#               BNinterval=[2200,2500],altBNstart=0,altRelTimeStart=0,
#               tvePos=True, dt=0.02,gender="female",ptHeight=67,
#               printout=True,
#               writePlain=True,keepBS=False,addRelTime=True)


# #%%truncation pt 7
# altBN_pt7,altRelTime_pt7=TOR.detectPVI(  
#               input_file='0007_file_1of1.csv', 
#               outName='',outSuffix=out_suffix,
#               input_subdir=input_subdir,
#               output_subdir=output_subdir,
#               BNinterval=[2804,3202],altBNstart=0,altRelTimeStart=0,
#               tvePos=True, dt=0.02,gender="female",ptHeight=67,
#               printout=True,
#               writePlain=True,keepBS=False,addRelTime=True)

# #%%truncation pt 8
# altBN_pt8,altRelTime_pt8=TOR.detectPVI(
#               input_file='0008_10_17_20.csv', 
#               outName='',outSuffix=out_suffix,
#               input_subdir=input_subdir,
#               output_subdir=output_subdir,
#               BNinterval=[2692,3030],altBNstart=0,altRelTimeStart=0,
#               tvePos=True, dt=0.02,gender="female",ptHeight=67,
#               printout=True,
#               writePlain=True,keepBS=False,addRelTime=True)


# #%%truncation pt 9
# altBN_pt9,altRelTime_pt9=TOR.detectPVI(
#               input_file='0009_03_19_47.csv', 
#               outName='',outSuffix=out_suffix,
#               input_subdir=input_subdir,
#               output_subdir=output_subdir,
#               BNinterval=[1825,2125],altBNstart=0,altRelTimeStart=0,
#               tvePos=True, dt=0.02,gender="female",ptHeight=67,
#               printout=True,
#               writePlain=True,keepBS=False,addRelTime=True)

# #%%truncation pt 10
# altBN_pt10,altRelTime_pt10=TOR.detectPVI(
#               input_file='0010_03_17_19_deleted_first_line.csv', 
#               outName='',outSuffix=out_suffix,
#               input_subdir=input_subdir,
#               output_subdir=output_subdir,
#               BNinterval=[1401,1699],altBNstart=0,altRelTimeStart=0,
#               tvePos=True, dt=0.02,gender="female",ptHeight=67,
#               printout=True,
#               writePlain=True,keepBS=False,addRelTime=True)

# #%%truncation pt 11
# altBN_pt10,altRelTime_pt10=TOR.detectPVI(
#               input_file='0011_14_17_21.csv', 
#               outName='',outSuffix=out_suffix,
#               input_subdir=input_subdir,
#               output_subdir=output_subdir,
#               BNinterval=[475,773],altBNstart=0,altRelTimeStart=0,
#               tvePos=True, dt=0.02,gender="female",ptHeight=67,
#               printout=True,
#               writePlain=True,keepBS=False,addRelTime=True)


# #%%truncation pt 12
# altBN_pt10,altRelTime_pt10=TOR.detectPVI(
#               input_file='0012_19_53_45_first_and_last_line_deleted.csv', 
#               outName='',outSuffix=out_suffix,
#               input_subdir=input_subdir,
#               output_subdir=output_subdir,
#               BNinterval=[1401,1699],altBNstart=0,altRelTimeStart=0,
#               tvePos=True, dt=0.02,gender="female",ptHeight=67,
#               printout=True,
#               writePlain=True,keepBS=False,addRelTime=True)


# #%%truncation pt 13
# altBN_pt10,altRelTime_pt10=TOR.detectPVI(
#               input_file='0013_15_49_102.csv', 
#               outName='',outSuffix=out_suffix,
#               input_subdir=input_subdir,
#               output_subdir=output_subdir,
#               BNinterval=[1401,1699],altBNstart=0,altRelTimeStart=0,
#               tvePos=True, dt=0.02,gender="female",ptHeight=67,
#               printout=True,
#               writePlain=True,keepBS=False,addRelTime=True)


# #%%truncation pt ??
# altBN_pt10,altRelTime_pt10=TOR.detectPVI(
#               input_file='20151008_gwf2_q2hr_whileloop_expt_17_15_31_first_line_deleted.csv', 
#               outName='',outSuffix=out_suffix,
#               input_subdir=input_subdir,
#               output_subdir=output_subdir,
#               BNinterval=[1401,1699],altBNstart=0,altRelTimeStart=0,
#               tvePos=True, dt=0.02,gender="female",ptHeight=67,
#               printout=True,
#               writePlain=True,keepBS=False,addRelTime=True)

run_time=(time.time() - start_time)
print "-------%s seconds elapsed" %run_time