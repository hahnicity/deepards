"""
Created on Thu Feb 4 21:00:00 2016

@author: Keiko
based on 20160303_cough_dev_pt2.py
baesd on 201603 _ cough_dev_pt12.py
based on 20160225_TOR_3_1_RUNME.py
based on 20160202_TOR3_trunc_run_RUNME.py
run in mac
"""

import sys
import os
import pandas as pd

#import custom package
gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.TOR3 as TOR; reload(TOR)
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)


root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox'
os.chdir(root_dir)

#%%truncation pt 2
reload(TOR)

#graph this file 
# file is "/static/output/WF_B2CRPi03__2015-02-15__21_17_20.798541945_3.csv" 
#pt 7 0007_21_17_20_3_2803to3203_goldstd_dbl_bs_cosumtvd

altBN,altRelTime=TOR.detectPVI(input_file='0002_09_14_38.csv', 
              outName='',outSuffix='_3_2_8_stats',
              input_subdir=r'0TestFiles/fullFiles',
              output_subdir=r'20160307_post_cough',
              BNinterval=[2400,2700],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=False,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False,
              anyCosumtvd=True, outSubsets=False) 




# altBN,altRelTime=TOR.detectPVI(input_file='0012_19_53_45_first_and_last_line_deleted.csv', 
#               outName='',outSuffix='_3_2_8_stats',
#               input_subdir=r'0TestFiles/fullFiles',
#               output_subdir=r'20160307_post_cough',
#               BNinterval=[35129,35427],altBNstart=0,altRelTimeStart=0,
#               tvePos=True, dt=0.02,gender="female",ptHeight=67,
#               printout=True,
#               writePlain=False,keepBS=True,addRelTime=False,
#               outAbsTime=True,outAbsSep=False,
#               anyCosumtvd=True, outSubsets=False) 

"""
past out suffixes
_3_2_6_newoutput/ outSubsets=True
"""

#stats 
# gold_subdir=r'0TestFiles/2016-02-06-gold_standard'
# sta.calcMultiStats(logfile='0012_19_53_45_first_and_last_line_deleted_35129to35427_TOR3_2_8_stats_logfile.txt',
#             gold_name='0012_19_53_45_17_35128to35428_goldstd_dbl_bs_cosumtvd.csv',
#             det_subdir=r'20160307_post_cough',
#             output_subdir=r'20160307_post_cough',
#             gold_subdir=gold_subdir,
#             subfiles_list=[
#                     '_class_matrix_raw_multi_frame2.csv',
#                     '_solo.csv'])