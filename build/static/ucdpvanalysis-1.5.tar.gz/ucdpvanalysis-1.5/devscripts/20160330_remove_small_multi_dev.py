"""
Created on Wed Mar 30 9:51PM
@author: Keiko
"""

import sys
gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

from algorithms.remove_small_multi_events import remove

# attempt 1
# from os import chdir, path
# root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox/20160330_double_frame/'
# chdir(root_dir)
# input_csv=path.join(root_dir+'0007_file_1of1_2804to3202_3_3_1_remove_first_mt_count_solo_FAKE.csv')
# output_csv=path.join(root_dir+'0007_file_1of1_2804to3202_3_3_1_remove_first_mt_count_solo_FAKE_post.csv')
# remove(input_csv,"dbl.4",output_csv,min_frame_threshold=2)



#attempt 2 WORKS!
from algorithms.solo import remove_residual_dbl_single_frames
import pandas as pd
from os import chdir, path
root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox/20160330_double_frame/'
chdir(root_dir)
input_csv=path.join(root_dir+'0007_file_1of1_2804to3202_3_3_1_remove_first_mt_count_solo_FAKE.csv')
output_csv=path.join(root_dir+'0007_file_1of1_2804to3202_3_3_1_remove_first_mt_count_solo_FAKE_post2.csv')

raw_df=pd.read_csv(input_csv)
output_df=remove_residual_dbl_single_frames(
    input_df=raw_df,pva="dbl.4")
output_df.to_csv(output_csv)



# attempt 3 NOT WORKING
# from algorithms.solo import remove_small_multi_events
# import pandas as pd
# from os import chdir, path
# root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox/20160330_double_frame/'
# chdir(root_dir)
# input_csv=path.join(root_dir+'0007_file_1of1_2804to3202_3_3_1_remove_first_mt_count_solo_FAKE.csv')
# output_csv=path.join(root_dir+'0007_file_1of1_2804to3202_3_3_1_remove_first_mt_count_solo_FAKE_post3.csv')

# raw_df=pd.read_csv(input_csv)
# output_df=remove_small_multi_events(
#     input_df=raw_df,pvi="dbl.4",min_frame_threshold=2)
# output_df.to_csv(output_csv)