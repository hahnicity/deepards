"""
Created on Mon Apr 11 
@author: Keiko

from 20160411_gold_combine_cosumtvd.py
from 20160513_gold_processed_valid_files.py
"""

import os
import pandas as pd
import numpy as np

import sys

gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

# import annotations.add_vent_bn_and_ts as add_vent_bn_and_ts;reload(add_vent_bn_and_ts)
# #TODO eventually add timestamp adding

import annotations.post_process_anno as ANN; reload(ANN)



root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/20160524_aggregate_for_Sandy/20160524_JB_annotations'
os.chdir(root_dir)

# gold_subdir=r'0TestFiles/20160513_validation_gold'
# output_subdir=r'0TestFiles/20160513_validation_gold_processed'


ANN.process_multi_files(
    input_subdir=r'20160524_TOR_output_for_Sandy/20160524_output_for_Sandy_derivation/20160524_output_for_Sandy_derivation_adams',
    output_subdir=r'20160526_1_processed_comb_cosumtvd/20160524_derivation_adams',
    output_suffix="_processed_comb_cosumtvd.csv")
ANN.process_multi_files(
    input_subdir=r'20160524_TOR_output_for_Sandy/20160524_output_for_Sandy_derivation/20160524_output_for_Sandy_derivation_kuhn',
    output_subdir=r'20160526_1_processed_comb_cosumtvd/20160524_derivation_kuhn',
    output_suffix="_processed_comb_cosumtvd.csv")
ANN.process_multi_files(
    input_subdir=r'20160524_TOR_output_for_Sandy/20160524_output_for_Sandy_validation/20160524_output_for_Sandy_validation_adams',
    output_subdir=r'20160526_1_processed_comb_cosumtvd/20160524_validation_adams',
    output_suffix="_processed_comb_cosumtvd.csv")
ANN.process_multi_files(
    input_subdir=r'20160524_TOR_output_for_Sandy/20160524_output_for_Sandy_validation/20160524_output_for_Sandy_validation_kuhn',
    output_subdir=r'20160526_1_processed_comb_cosumtvd/20160524_validation_kuhn',
    output_suffix="_processed_comb_cosumtvd.csv")
