# -*- coding: utf-8 -*-
"""
Created on Tue Jul 29 11:32:29 2015

@author: Keiko

This script is originally based on DLA_dev and is used for developing 
visualization of TV violations.

There are 4 graphs: 
-circle/linked detected PVIs
-waveform (on one plot)
-TVs
-heatmap version of PVIs

"""
from __future__ import division
#run TOR.py first
import os
import numpy as np
import sys
import csv
sys.path.insert(0, r'C:\allMYfiles\My_Documents\GitHub\ucdpv\analysis')
import dicts
reload(dicts)
import stats
reload(stats)
import pviplot
reload (pviplot)
sys.path.insert(0, r'C:\allMYfiles\My_Documents\GitHub\ucdpv\parse\static\py')
import plot_bokeh; reload(plot_bokeh)
import matplotlib.pyplot as plt
from mpld3 import plugins
import pandas as pd
from collections import Counter

# imports for Bokeh plotting
from bokeh.plotting import figure, gridplot
from bokeh.plotting import figure, output_notebook, show, output_file, ColumnDataSource
from bokeh.models import LinearAxis, Range1d,Circle
from bokeh.models import HoverTool, WheelZoomTool, PanTool,ResizeTool,ResetTool,CrosshairTool, Callback
from bokeh.properties import value
import sklearn.metrics
import statsmodels.stats.inter_rater
from mpl_toolkits.axes_grid1 import make_axes_locatable

#double check with dicts2.1
root_dir=r'C:\allMYfiles\My_Documents\GitHub\sandbox5_matrix'
os.chdir(root_dir )
input_subdir='input'
output_subdir='output2.1.2'


input_file='2014_06_11_PB840_DBL_TRIG.csv'
filename=os.path.splitext(input_file) [0]
input_path=os.path.join (output_subdir, input_file) 
gs_path = os.path.join (input_subdir,filename+'_gold_standard.csv')

#root_dir=r'C:\allMYfiles\My_Documents\GitHub\sandbox7_TVviol'
#os.chdir(root_dir )
#input_subdir='input'
#output_subdir='output'
#
#
#input_file='2015-01-07__dla_term2.csv'
#filename=os.path.splitext(input_file) [0]
#input_path=os.path.join (output_subdir, input_file) 
#gs_path = os.path.join (input_subdir,filename+'_gold_standard.csv')
#%% import detected


det_path = os.path.join(output_subdir,filename+'_detectedCombined.csv')
det = pd.read_csv(det_path, index_col = 'BN')
det[det>0].describe()
det.head()

clin_path = os.path.join(output_subdir,filename+'_clinValues.csv')
clin = pd.read_csv(clin_path, index_col = 'BN')
#breath_dict = {}
#for i in range(1,len(clin)+1):
#    BS = round(clin.loc[i,'BS'],2)
#    IE = round(clin.loc[i,'insp end'],2)
#    breath_dict[i]=(BS,IE)

breathList = [round(i,2) for i in clin.BS]
breathList = [0]+breathList
wave_path = (os.path.join(output_subdir, filename+'_plain.csv'))
df_big = pd.read_csv(wave_path, names = ['time', 'flow', 'pressure']) 
t, pressure, flow, tlist = plot_bokeh.splitWave(df_big)


#%%import cviz anns
#gs_path = os.path.join (input_subdir, '2015-01-07__dla_term2_gold_standard.csv')

gs = stats.readCvizAnns(gs_path, 'gold standard', input_file)
gs.replNames(dicts.abbrev)
gs.removeNormals()
gs.byBreath(breathList)
newIndex = [int(j) for j in gs.byBreath_a[1:,0]]
gold = pd.DataFrame(gs.byBreath_a[1:,1], index=newIndex, columns=["gs"])




#%%preprocess

det = det.replace(0,np.nan)



#%%plotting waveform
output_file(os.path.join(output_subdir, filename +'_plot.html'))

x=t
y1 = pressure
y2 = flow
BSs=breathList[1:]
BNs=range(1,len(breathList))

plotWidths = 1000
source = ColumnDataSource(
    data = dict(
        x  =t,
        y1 = pressure,
        y2 = flow,
        BSs= BSs,
        ))

hover = HoverTool(tooltips=[
    ("index",'$index'),
#    ("(x,y)", "($x, $y)"),
    ("t",'@x'),
    ("pressure: ", '@y1'),
    ("flow: ", '@y2')
    ])
zoom = WheelZoomTool(dimensions=['width'])
pan = PanTool(dimensions=['width'])
resize = ResizeTool()
reset = ResetTool()
crosshair = CrosshairTool()
TOOLS = [pan, zoom, hover, resize, crosshair, reset]

tools = " xpan,  xwheel_zoom, resize,crosshair, hover, reset"
#bottom = figure(plot_width=plotWidths, plot_height=300,
#                tools = tools)
#bottom.line('x', 'y2', line_width=1, legend = 'flow', line_color="blue", source=source)
#bottom.xaxis.axis_label = "Time(s)"
#bottom.yaxis.axis_label = "Flow"
##bottom.line('x', 'y1', line_width=1, legend='pressure', line_color=)
#
##bottom.extra_y_ranges = {"pressure": Range1d(start = -70, end =30)}
##bottom.add_layout(LinearAxis(y_range_name="pressure", axis_label = "Pressure"), 'right')
##bottom.line(x, y2, line_width=1, legend = 'flow')
##bottom.add_layout(LinearAxis(y_range_name="flow", axis_label = "flow"), 'left')
#bottom.text('BSs', y= max(y2)-1, text =BNs, text_font_size=value("10pt"), source=source)
##yloc = np.mean(y2)
##height = max(y2)-min(y2)
#bottom.rect('BSs', y=0, width=0.02, height=1, fill_alpha=0.2, color='grey', source=source) 



middle = figure(plot_width=plotWidths, plot_height=300,
                tools = TOOLS, y_range=(-70,40))
middle.line('x', 'y1', line_width=0.5, legend = 'pressure', line_color="purple", source=source)
#middle.xaxis.axis_label = "Time(s)"
middle.yaxis.axis_label = "Pressure"
middle.extra_y_ranges = {"foo": Range1d(start = -100, end =150)}
middle.line('x', 'y2', line_width=0.5, legend='flow', line_color="blue", 
            source=source, y_range_name="foo")
middle.add_layout(LinearAxis(y_range_name="foo", axis_label = "Flow"), 'right')

#middle.line(x, y2, line_width=1, legend = 'flow')
#        middle.add_layout(LinearAxis(y_range_name="flow", axis_label = "flow"), 'left')
#yloc = np.mean(y1)
height = max(y1)-min(y1)
middle.text('BSs', y= 30, text =BNs, text_font_size=value("10pt"), source=source)
middle.rect('BSs', y=0, width=0.02, height=1, fill_alpha=0.2, color='grey', source=source) 

#%% plotting annotations


toPlot = {}

anns = det.columns[1:].tolist()
ylabel = ['gs', 'comb', ''] + anns + ['BNs'] + ['']
#ylabel = ylabel[::-1] #reverses order

#establishes the plot
top = figure(plot_width=plotWidths, plot_height=300, tools = tools,
              title = input_file, y_range=ylabel, x_range=middle.x_range)

ylocBN = ['BNs']*len(BSs)
top.text(x=BSs, y= ylocBN, text =BNs, text_font_size=value("10pt")) 

toPlot['ylocBN']=['BNs']*len(BSs)
toPlot['BSs']=BSs
source2 = ColumnDataSource(toPlot)
top.text(x='BSs', y= 'ylocBN', text =BNs, text_font_size=value("10pt"), source=source2)


#gs
text = gold['gs'].tolist()
#xloc = gold['gs'].index
xloc = [breathList[int(j)] for j in gold['gs'].index]
yloc = ['gs']*len(xloc)
color = [dicts.colors[j] for j in text]
top.text(x=xloc, y=yloc, text=text, text_font_size=value("10pt"), text_color="gray")
top.circle(x=xloc, y=yloc, size=10, alpha=0.5, color=color)
#top.rect(x=xloc, y=yloc, width=1, height=1, alpha=0.5, color=color )

#combined
text = det['comb'].tolist()
xloc = [breathList[j] for j in det['comb'].index]
#xloc = det['comb'].index
yloc = ['comb']*len(xloc)
color = [dicts.colors[j] for j in text]
top.text(x=xloc, y=yloc, text=text, text_font_size=value("10pt"), text_color="gray")
top.circle(x=xloc, y=yloc, size=10, alpha=0.5, color=color)
#top.rect(x=xloc, y=yloc, width=1, height=1, alpha=0.5, color=color )

#rest of the matrix
for i in range(1,len(det.columns)):
    origCol = det.columns[i]
    col=origCol.split('.')[0]
#    print col
    if col == 'bs':
        det[origCol]= det[origCol].replace(1,'bsl')
        det[origCol]= det[origCol].replace(2,'bsm')
        det[origCol]= det[origCol].replace(3,'bss')
    elif col == 'tvv':
        det[origCol]= det[origCol].replace(49,'tvl')
        det[origCol]= det[origCol].replace(51,'tvh')
        det[origCol]= det[origCol].replace(52,'tvs')
    elif col in ['mt', 'su']:
#        a = det[col]
#        det.loc[:,(origCol)]=col
#        det.loc[:,origCol][det.loc[:,origCol]!=0]=col
#        det[origCol][det[origCol]!=0]=col
        mask=det.loc[:,origCol]>0
        det.loc[mask,origCol]=origCol
#        print det[col]   
    else:   
        det[origCol]= det[origCol].replace(1,col)
#    masked = det[origCol][det[origCol]>0]
#    text = masked.tolist()
##    xloc=masked.index
#    xloc = [breathList[j] for j in masked.index]
#    color = [dicts.colors[j] for j in text]
##    print(color)
    
    # maintains NaN placeholders
    text=det[origCol].tolist()
    color=stats.repl_names(text, dicts.colors)
    xloc,yloc=stats.makeCoords(text,origCol,BSs)


    top.text(x=xloc, y=yloc, text=text, text_font_size=value("10pt"), text_color="gray")
    top.circle(x=xloc, y=yloc, size=10, alpha=0.5, color=color)
#    top.rect(x=xloc, y=yloc, width=1, height=1, alpha=0.5, color=color )
    #y can also be -i    
    


#%% stats stuff
#merging into one data frame

aligned = pd.concat([gold,det], axis=1)
aligned=aligned.replace(np.nan, 'n')

xloc = [-25,-20,-15,-10,-5]
labels = ['frac','ACC','TPR','TNR','PPV','NPV']
labels2 = ['tp','fp','tn','fn']+labels
yloc=['BNs']*len(xloc)
#top.text(x=xloc, y=yloc, text=labels, text_font_size=value("10pt")) #graphs on pvi plot
metrics = pd.DataFrame(index=labels)

for i in range(len(det.columns)):
    origCol = det.columns[i]
    col=origCol.split('.')[0]
    if col in ['comb','bs']:
        pred = aligned[col]
        pred = pred.replace(0,'n').values
        true = aligned.gs.values
        
        tp, fp, tn, fn, mc, annEval = stats.countTP(true,pred )
        # count misclassified algs as true positives
        annEval = stats.repl_names(annEval, {'mc':'tp'})
        tp= tp+mc
        # calculate metrics
        ACC,TPR,TNR,PPV,NPV = stats.binaryMetrics(tp,fp,tn,fn)
        if col =='comb':
            evalDF = pd.DataFrame(annEval,index=BNs,columns=["comb"],dtype=object)
        else:
            colDF = pd.DataFrame(annEval, index=BNs, columns=[origCol], dtype=object)
            evalDF = pd.concat([evalDF,colDF],axis=1)           
    else:
        pred = aligned[origCol]
        pred = pred.replace(0,'n').values
        true = aligned.gs.values
        
        tp, fp, tn, fn, annEval = stats.evalAlg(true,pred,col)
        ACC,TPR,TNR,PPV,NPV = stats.binaryMetrics(tp,fp,tn,fn)
    frac = '(%s/%s)'%(str(tp),str(tp+fn))
    results =  [frac,ACC,TPR,TNR,PPV,NPV]
    results2 = [int(tp),int(fp),int(tn),int(fn)]+results
    # add results to aggregated DFs
    colDF = pd.DataFrame(annEval, index=BNs, columns=[origCol])
    evalDF = pd.concat([evalDF,colDF],axis=1)
    metrics_i = pd.DataFrame(results2,index=labels2, columns = [origCol],dtype=object)
    metrics = pd.concat([metrics,metrics_i],axis=1)
    metrics = metrics.reindex(["tp","fp","tn","fn","frac","ACC","TPR","TNR","PPV","NPV"])
    # plot results
#    yloc=[col]*len(xloc)
#    top.text(x=xloc, y=yloc, text =results, text_font_size=value("10pt"))

#%%add stats results to the output

#%print metrics
print(metrics)
met_path = os.path.join(output_subdir,filename+'_metrics.csv')
metrics.to_csv(met_path)
frame3 =pd.concat([aligned,metrics])
frame4=aligned.append(metrics)
#%%cohen analysis
true = aligned.gs.values
pred = aligned.comb.values
title = 'gs vs. combined'
cmap = 'OrRd'

y_true = stats.repl_names(true,dicts.codes)
y_pred = stats.repl_names(pred,dicts.codes)
cm = sklearn.metrics.confusion_matrix(y_true, y_pred)
ckap_results=  statsmodels.stats.inter_rater.cohens_kappa(cm) 


reverse_codes = {v:k for k, v in dicts.codes.items()}
accuracy = sklearn.metrics.accuracy_score(true,pred)

both = y_true + y_pred
legend, axis_labels = stats.extractLegend(both, dicts.codes)        
a = np.array(legend)
xloc=a[:,0]

#plot heatmap
fig = plt.figure(figsize=(10,5))

ax1=plt.subplot(1, 3, 1, aspect=1)
ax1.matshow(cm, cmap=cmap)

# adds labels
ax1.set_title('Confusion Matrix: '+'\n'  +title + '\n')
ax1.set_ylabel('True')
ax1.set_xlabel('Pred')

# plots the diagonal line
x1, x2 = ax1.get_xlim()
y1, y2 = ax1.get_ylim()
ax1.plot([x1,x2], [y2,y1], color = 'gray')
plt.sca(ax1)

# plots the axis ticks
ax1.axes.get_xaxis().set_visible(False)
ax1.axes.get_yaxis().set_visible(False)
for i in range(1,len(axis_labels)):
    plt.text(-2, i-1, axis_labels[i])
for i in range(1,len(axis_labels)):
    plt.text(i-1.25, -1, axis_labels[i], fontsize=9)    

#overlay confusion matrix values
for y in range(cm.shape[0]):
    for x in range(cm.shape[1]):
        plt.text(x, y, '%d' % cm[y, x],
                 horizontalalignment='center',
                 verticalalignment='center',
                 color='Gainsboro')

#colorbar
divider = make_axes_locatable(plt.gca())
cax = divider.append_axes("right", size="10%", pad=0.2)
plt.colorbar(ax1.matshow(cm, cmap=cmap),cax=cax)

#print key in box 2
plt.subplot(1, 3, 2, aspect=1)
plt.axis('off')
plt.text(0, 1, 'accuracy: '+ str(accuracy*100)+ '%')

plt.text(0,0.9, 'legend\n-----------', ha='left', va='top')
i=0.7
for row in legend:
    row_formated=str(row[0])+': '+str(row[1])
    plt.text(0,i, row_formated, fontsize=10, ha='left', va='top')
    i=i-0.1
#plt.text(0.5,1,cm, fontsize=12)     

#print cohen's kappa results in 3rd box
plt.subplot(1, 3, 3, aspect=1)
plt.text(0,0, ckap_results, fontsize=10)
plt.axis('off')
fig.show()   
   
#%%bokeh heatmap
from bokeh.charts import HeatMap, output_file, show
from bokeh.palettes import YlOrRd9 as palette
a = np.array(legend)
df = pd.DataFrame(cm, index=a[:,1], columns=a[:,1])
#df =df.transpose()

#output_file("heatmap.html")
palette = palette[::-1]  # Reverse the color order so dark red is largest value
hm2 = HeatMap(df, title="true vs. predicted confusion matrix", width=400, palette=palette)
#show(hm) 


#%% plotting annotations as hm

hmPlot = {}

anns = det.columns[1:].tolist()
ylabel = ['gs', 'comb', ''] + anns + ['BNs'] + ['']
#ylabel = ylabel[::-1] #reverses order

#establishes the pot
hm = figure(plot_width=plotWidths, plot_height=300, tools = " xpan,  xwheel_zoom, resize, reset",
              title = input_file, y_range=ylabel) #x_range=bottom.x_range

#ylocBN = ['BNs']*len(BSs)
#hm.text(x=BSs, y= ylocBN, text =BNs, text_font_size=value("10pt")) 

hmPlot['ylocBN']=['BNs']*len(BSs)
hmPlot['BSs']=BSs
source4 = ColumnDataSource(hmPlot)

#gs
text = gold['gs'].tolist()
xloc = gold['gs'].index
#xloc = [breathList[int(j)] for j in gold['gs'].index]
yloc = ['gs']*len(xloc)
color = [dicts.colors[j] for j in text]
hm.text(x=xloc, y=yloc, text=text, text_font_size=value("10pt"), text_color="gray")
hm.rect(x=xloc, y=yloc, width=1, height=1, alpha=0.5, color=color )

#combined
text = det['comb'].tolist()
xloc = det['comb'].index
yloc = ['comb']*len(xloc)
color = [dicts.colors[j] for j in text]
hm.text(x=xloc, y=yloc, text=text, text_font_size=value("10pt"), text_color="gray")
hm.rect(x=xloc, y=yloc, width=1, height=1, alpha=0.5, color=color )

#rest of the matrix
for i in range(1,len(det.columns)):
    origCol = det.columns[i]
    col=origCol.split('.')[0]
    if col == 'bs':
        det[origCol]= det[origCol].replace(1,'bsl')
        det[origCol]= det[origCol].replace(2,'bsm')
        det[origCol]= det[origCol].replace(3,'bss')
    elif col in ['mt', 'su']:
        det[origCol][det[origCol]!=0]=col
    else:   
        det[origCol]= det[origCol].replace(1,col)
    
    masked = det[origCol][det[origCol]>0]
    text = masked.tolist()
    xloc=masked.index
    color = [dicts.colors[j] for j in text]
    yloc = [origCol]*len(xloc)
#    hm.text(x=xloc, y=yloc, text=text, text_font_size=value("10pt"), text_color="gray")
    hm.rect(x=xloc, y=yloc, width=1, height=1, alpha=0.5, color=color )

#%% TV plot
tvPlotData = ColumnDataSource(
    data = dict(
        BNs=BNs,
        BSs= BSs,
        TVis = clin.TVi.values
        ))
        
bottom = figure(plot_width=plotWidths, plot_height=300,
                 tools = " xpan,  xwheel_zoom, resize,crosshair, reset", x_range=middle.x_range )
bottom.line('BSs', 'TVis', line_width=1, source=tvPlotData, line_color="Grey")

# circle colors based on values
tvvs = det['tvv'].replace(np.nan,'n')
color = [dicts.colors[j] for j in tvvs] #creates new list with corresponding colors
tvPlotData.data['colors']=color
bottom.circle('BSs', 'TVis', color='colors', size=5, source=tvPlotData)

#adds rudimentary hovertool
bottom.add_tools(HoverTool(
    tooltips="""
    <div>
            TV:<span style="font-size: 17px; font-weight: bold;">[@TVis]</span><BR>
            BN:<span style="font-size: 15px; color: #966;">@BNs</span><BR>
            time: @BSs (sec)
        </div>    
    """))


# adds color bars to plot
maxBS=max(BSs)
maxTVi=max(clin.TVi.values)
bottom.quad(0,maxBS, TVcut1,0, fill_color='cyan', fill_alpha=0.1, line_alpha=0)
bottom.quad(0,maxBS, TVcut3,TVcut2, fill_color='red', fill_alpha=0.1, line_alpha=0)
bottom.quad(0,maxBS, maxTVi,TVcut3, fill_color='black', fill_alpha=0.1, line_alpha=0)

# adds text labels
TVcuts = [round(TVcut1,2), round(TVcut2,2), round(TVcut3,2)]
yloc = [0, TVcut2, TVcut3]
bottom.text([0,0,0],yloc, text = TVcuts )
bottom.yaxis.axis_label = "insp TVs (mL)"
bottom.xaxis.axis_label = "Gender:%s, height:%s in., PBW:%s kg" %(gender,str(ptHeight),str(PBW))
#%% render bokeh graph
g = gridplot([[top],[middle],[bottom], [hm,hm2]])
show(g)




