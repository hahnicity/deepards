"""
Created on Thu Feb 4 21:00:00 2016

@author: Keiko

based on 20160202_TOR3_trunc_run_RUNME.py
run in mac
"""

import sys
import os
import pandas as pd

#import custom package
gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.TOR3 as TOR; reload(TOR)
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)


root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox'
os.chdir(root_dir)

#%%truncation pt 2
reload(TOR)

altBN,altRelTime=TOR.detectPVI(input_file='0002_09_14_38.csv', 
              outName='',outSuffix='_3_1_0_restart',
              input_subdir=r'0TestFiles/fullFiles',
              output_subdir=r'20160204_TOR3_2',
              BNinterval=[2200,2500],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False,
              anyCosumtvd=False) 