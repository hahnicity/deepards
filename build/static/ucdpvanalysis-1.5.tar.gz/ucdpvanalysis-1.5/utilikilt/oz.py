import os
import sys
import shutil


def mkdir(directory_path, overwrite_existing=[], printout=True):
    """
    make subdirectory automatically. Checks if folder already exists

    20150512 V1.1 Written
    2017-03-03 V1.1 Expanded on the manual override
    """
    try:
        os.mkdir(directory_path)
    except:
        if printout:
            print("'%s' subdirectory already exists" % directory_path)
        if overwrite_existing == []:
            manual_override = raw_input('Overwrite previous files? (y/n): ')

        else:
            assert isinstance(overwrite_existing, bool)
            if overwrite_existing:
                manual_override = 'y'
            else:
                manual_override = 'n'

        if manual_override == 'n':
            if printout:
                print("Change directory parameter for :'%s'" % directory_path)
            # sys.exit(0)
            pass
        elif manual_override == 'y':
            # http://stackoverflow.com/questions/6996603/delete-a-file-or-folder-in-python

            shutil.rmtree(directory_path)
            if printout:
                print("'%s' subdirectory deleted" % directory_path)
            os.mkdir(directory_path)
            if printout:
                print("'%s' subdirectory created" % directory_path)
        else:
            if printout:
                print("Wrong input, only type 'y' or 'n'")
            sys.exit(0)



#move to an outside function from 2016-04-14_fancy_get_file_names
def fancy_get_file_names(input_subdir,ends_with="",strip_suffix=False,
                        contains=""):
    """
    Gets file names from a directory and returns a list
    Versions 2016-04-14

    Args:
    -----
     input_subdir: path to input subdirectory
     ends_with: suffix that the file should have
     strip_suffix: removes the suffix in the output (ex. print names without ".csv")
     contains: keyword that file should contains

    examples:
    ---------
        #get csv files only and remove ".csv" at the end
        files=fancy_get_file_names(input_subdir=gold_subdir,
                                    ends_with=".csv",strip_suffix=True,
                                    contains="")
        #get log files but keep ".txt" at the end
        files=fancy_get_file_names(input_subdir=gold_subdir,
                                    ends_with=".txt",strip_suffix=False,
                                    contains="logfile")

        #get a list of any file in the directory
        files=fancy_get_file_names(input_subdir=gold_subdir,
                                    ends_with="",strip_suffix=False,
                                    contains="")
        # or
        files=fancy_get_file_names(gold_subdir)

    """
    file_list=[]
    suffix = ends_with
    keyword = contains
    for root,dirs,files in os.walk(input_subdir):
        for file_name in files:
            if file_name.endswith(suffix) and keyword in file_name:
                if strip_suffix:
                    file_name=file_name.rstrip(suffix)
                file_list.append(file_name)

    return file_list

def create_output_path(input_file, output_subdir="",
        output_name_override="", output_suffix="", version="",
        relBNinterval=[]):
    """
    creates output path for a file without the suffix

    first used in solo_fused
    """
    input_dir, file_name = os.path.split(input_file)
    file_name = os.path.splitext(file_name)[0]  #  removes .csv or .csv_test

    if output_name_override != "":
        outName = output_name_override
    else:
        outName = file_name

    if output_subdir == "":
        output_subdir = input_dir

    if version != "":
        version = "_v" + version.replace('.','_')

    if relBNinterval != []:
        truncated_suffix = '_%dto%d'%(relBNinterval[0], relBNinterval[1])
    else:
        truncated_suffix = ""


    output_suffix = truncated_suffix + version + '_' + output_suffix

    outputPath = os.path.join(output_subdir, outName) + output_suffix
    return outputPath


def get_file_name_from_path(path):
    input_dir, file_name = os.path.split(path)
    file_name = os.path.splitext(file_name)[0]  # removes .csv or .csv_test
    return file_name
