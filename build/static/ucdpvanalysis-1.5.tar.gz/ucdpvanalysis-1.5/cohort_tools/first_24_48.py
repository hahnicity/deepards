from argparse import ArgumentParser
from warnings import warn

import numpy as np
import pandas as pd

import lib

# Note to self: Look into patient 0321; they have the weirdest vent documentation
# I've seen yet.
#
# this is fairly common; they get put on the vent, taken off, then
# reintubated. Have to ask what we want to do in this scenario.
# - Brooks: trache patients have this commonly, they're popped on vent
# for a bit then placed back on room air to re-adjust.
#
# I have another patient who was recorded as being taken off the
# vent for 15 minute intervals... sigh
# - Brooks: probably a trache where they're working them during the day
#
# Question: why do ventilator devices cycle so rapidly? Are RT's noting when
# the cleaning occurred?
# - Brooks: life inside hospital; 40 different ways to say same thing

# XXX deprecated var
SBT_O2_DEV_FILE = "SBT_STUDY_DATA/sbt_all_o2dev_phases_20161014.csv"


class BinCalculations(object):
    def __init__(self, full_df, hour_idxs):
        self.full_df = full_df
        self.hour_idxs = hour_idxs

    def find_async_freq(self, pt_df, colnames, hour_iterable):
        """
        Since asynchrony frequency is counted every breath for each previous
        hour this function finds the slice of a patient df corresponding to
        a particular hour, and then gets the sum of all asynchrony counts across
        all hours we are examining.
        """
        count = {col: 0 for col in colnames}
        # Need to break these into hour slices because otherwise we won't get
        # an accurate count.
        for low_idx, high_idx in hour_iterable:
            row = pt_df.loc[high_idx]
            for col in colnames:
                if col + '_indexed' not in row.index or row[col + '_indexed'] is np.nan:
                    raise Exception('You need to analyze your data frame with software that performs async frequency counts with accordance to your hour indexer! Look at non_phasic_analysis.py for an example.')
                count[col] += row[col + '_indexed']
        return count

    def find_asyncis(self, freq_counts, hour_iterable):
        """
        Get all the asynci's for a dict of freq stats eg: dblf -> dbli
        """
        asyncis = {}
        total_breaths = hour_iterable[-1][1] - hour_iterable[0][0] + 1
        for k, v in freq_counts.items():
            asyncis[k.replace("f", "i")] = (float(v) / total_breaths) * 100
        return asyncis

    def get_hour_bin_iterable(self, low_hours, high_hours, patient):
        """
        Get the slice of patient data for a particular hour. Since there are
        a bunch of corner cases involved this function looks much more complicated
        than it actually is.

        Mainly the rest of the logic lies in trying to find an appropriate location
        to look for data if there is some 'skip' in place.
        """
        # Check if low idx is too high. If so, return an empty list
        try:
            self.hour_idxs[patient]['hour_idxs'][low_hours]
        except KeyError:
            return []
        # Check if high idx is too high. If so, use the next highest hour possible
        try:
            self.hour_idxs[patient]['hour_idxs'][high_hours - 1]
            high_hours = high_hours - 1
        except KeyError:
            for i in range(low_hours+1, high_hours)[::-1]:
                if i in self.hour_idxs[patient]['hour_idxs']:
                    high_hours = i
                    break
            else:
                high_hours = low_hours
        hour_range = range(low_hours, high_hours+1)
        hour_iterable = [self.hour_idxs[patient]['hour_idxs'][i] for i in hour_range]
        return filter(lambda x: x[0] != lib.SKIP_HOUR, hour_iterable)

    def get_vent_phase_index_iterable(self, phase_idx, patient):
        """
        Get an iterable of indices, broken down by hour for a vent phase
        """
        iterable = []
        phase_start_idx, phase_end_idx = self.hour_idxs[patient]['vent_phase_idxs'][phase_idx]
        if phase_start_idx == lib.SKIP_HOUR:
            return []

        for hour, hour_idxs in self.hour_idxs[patient]['hour_idxs'].iteritems():
            if hour_idxs[0] <= phase_start_idx <= hour_idxs[1]:
                start_hour = hour
                break

        for hour in range(start_hour, max(self.hour_idxs[patient]['hour_idxs'].keys())+1):
            hour_start_idx, hour_end_idx = self.hour_idxs[patient]['hour_idxs'][hour]
            if hour_start_idx == lib.SKIP_HOUR:
                continue
            cur_iterable_start_idx = hour_start_idx
            if hour_end_idx >= phase_end_idx:
                cur_iterable_end_idx = phase_end_idx
                iterable.append((cur_iterable_start_idx, cur_iterable_end_idx))
                return iterable
            else:
                cur_iterable_end_idx = hour_end_idx
            iterable.append((cur_iterable_start_idx, cur_iterable_end_idx))

        # in one case execution got here because there was a missing hour
        # that only had 1 observation in it. This case actually seems more
        # common than expected. Probably due to some inequality mismatch somewhere
        return iterable

    def calc_by_hour_binning(self, low_hours, high_hours):
        """
        Calculates all analytics for all patients within a certain hour range
        """
        patients = self.full_df.patient.unique()
        frame = None
        # kinda a problem here; we can have 1 to many csn to patient ids.
        for patient in patients:
            if patient not in self.hour_idxs:
                continue

            hour_iterable = self.get_hour_bin_iterable(low_hours, high_hours, patient)
            if len(hour_iterable) != 0:
                patient_df = self.full_df[self.full_df.patient == patient].loc[hour_iterable[0][0]:hour_iterable[-1][1]]
            else:
                patient_df = []
            tmp = self.perform_slice_analytics(patient_df, hour_iterable, low_hours, high_hours, patient)
            if isinstance(frame, type(None)):
                frame = tmp
            else:
                frame = frame.append(tmp)
        return frame

    def calc_vent_phase_analytics(self):
        """
        Calculate analytics on each of the patient's vent phases
        """
        frame = None
        for patient in self.full_df.patient.unique():
            vent_phase_hours = self.hour_idxs[patient]['vent_phase_hours']
            if len(vent_phase_hours) == 0:
                continue
            for phase_idx in range(len(vent_phase_hours)):
                vent_phase_iterable = self.get_vent_phase_index_iterable(phase_idx, patient)
                if len(vent_phase_iterable) != 0:
                    patient_df = self.full_df[self.full_df.patient == patient].loc[vent_phase_iterable[phase_idx][0]:vent_phase_iterable[-1][1]]
                else:
                    patient_df = []
                tmp = self.perform_slice_analytics(patient_df, vent_phase_iterable, vent_phase_hours[phase_idx][0], vent_phase_hours[phase_idx][-1], patient)
                if isinstance(frame, type(None)):
                    frame = tmp
                else:
                    frame = frame.append(tmp, ignore_index=True)
        return frame

    def perform_slice_analytics(self, patient_df, hour_iterable, low_hours, high_hours, patient):
        """
        Perform analytics on a specific slice of patient data.

        :param patient_df: a particular slice of patient data
        :param hour_iterable: iterable of indices corresponding to each hour
        :param low_hours: The starting hour
        :param high_hours: The ending hour
        :param patient: The patient we are analyzing
        """
        if len(patient_df) == 0:
            vals = [patient, low_hours, high_hours, len(patient_df)] + [np.nan for _ in range(0, 22)]
        else:
            patient_df["dblf"] = patient_df["asyncf_mms"] - patient_df["bsf_mms"]
            freq_counts = self.find_async_freq(
                patient_df,
                ["bsf_ms", "bsf_mms", "asyncf_ms", "asyncf_mms", "tvvf_s", "tvvf_ms", "tvvf_mms", "dblf"],
                hour_iterable
            )
            indices_vals = self.find_asyncis(freq_counts, hour_iterable)
            # XXX need to add % coverage to this.
            vals = [
                patient,
                low_hours,
                high_hours,
                len(patient_df),
                freq_counts["bsf_ms"],
                freq_counts["bsf_mms"],
                indices_vals["bsi_ms"],
                indices_vals["bsi_mms"],
                freq_counts["asyncf_ms"],
                freq_counts["asyncf_mms"],
                indices_vals["asynci_ms"],
                indices_vals["asynci_mms"],
                sum(patient_df.tvi.values) / len(patient_df.tvi),
                sum(patient_df.tve.values) / len(patient_df.tve),
                freq_counts["tvvf_mms"],
                freq_counts["tvvf_ms"],
                freq_counts["tvvf_s"],
                indices_vals["tvvi_mms"],
                indices_vals["tvvi_ms"],
                indices_vals["tvvi_s"],
                sum(patient_df.peep.dropna().values) / len(patient_df.peep.dropna()),
                sum(patient_df.maw.dropna().values) / len(patient_df.maw.dropna()),
                sum(patient_df.pip.dropna().values) / len(patient_df.pip.dropna()),
                sum(patient_df.ip_auc.dropna().values) / len(patient_df.ip_auc.dropna()),
                freq_counts["dblf"],
                indices_vals["dbli"],
            ]

        frame = pd.DataFrame([vals])
        frame.columns = [
            "patient",
            "low_hour",
            "high_hour",
            "n_obs",
            "bsF_ms",
            "bsF_mms",
            "mean_bsI_ms",
            "mean_bsI_mms",
            "asyncF_ms",
            "asyncF_mms",
            "mean_asyncI_ms",
            "mean_asyncI_mms",
            "mean_tvi",
            "mean_tve",
            "tvvF_mms",
            "tvvF_ms",
            "tvvF_s",
            "mean_tvvI_mms",
            "mean_tvvI_ms",
            "mean_tvvI_s",
            "mean_peep",
            "mean_maw",
            "mean_pip",
            "mean_ip_auc",
            "dblF",
            "mean_dblI",
        ]
        frame['mean_dyn_compliance'] = frame.mean_tvi / (frame.mean_pip - frame.mean_peep)
        return frame

    def perform_full_dataset_analysis(self, perform_hourly_binning):
        max_hour = max([
            hour for patient in self.hour_idxs.keys()
            for hour in self.hour_idxs[patient]['hour_idxs']
        ])

        multi_hour_df = self.calc_by_hour_binning(0, 24)
        multi_hour_df = multi_hour_df.append(self.calc_by_hour_binning(24, 48))
        multi_hour_df = multi_hour_df.append(self.calc_by_hour_binning(0, 48))
        multi_hour_df = multi_hour_df.append(self.calc_by_hour_binning(48, 72))
        multi_hour_df = multi_hour_df.append(self.calc_by_hour_binning(0, 72))
        multi_hour_df = multi_hour_df.append(self.calc_by_hour_binning(72, max_hour))
        multi_hour_df = multi_hour_df.append(self.calc_by_hour_binning(0, max_hour))
        multi_hour_df = multi_hour_df.sort_values(by=['patient', 'low_hour', 'high_hour'])
        multi_hour_df = multi_hour_df[~multi_hour_df.n_obs.isnull()]
        multi_hour_df.index = range(len(multi_hour_df))

        single_hour_df = None
        if perform_hourly_binning:
            for i in range(max_hour+1):
                low = i
                high = i + 1
                low_to_high = self.calc_by_hour_binning(low, high)
                if isinstance(single_hour_df, type(None)):
                    single_hour_df = low_to_high
                else:
                    single_hour_df = single_hour_df.append(low_to_high)

            single_hour_df = single_hour_df.sort_values(by=['patient', 'low_hour', 'high_hour'])
            single_hour_df = single_hour_df[~single_hour_df.n_obs.isnull()]
            single_hour_df.index = range(len(single_hour_df))

        vent_phase_df = self.calc_vent_phase_analytics()
        vent_phase_df = vent_phase_df.sort_values(by=['patient', 'low_hour', 'high_hour'])
        return single_hour_df, multi_hour_df, vent_phase_df


def perform_binning_calculations(mapping, processed, vent_phases, perform_hourly_binning):
    """
    Perform analytics on a processed dataset

    :param mapping: mapping of patients to csn ids
    :param processed: processed dataset in dataframe format
    :param vent_phases: dataset of vent phases for each patient
    :param perform_hourly_binning: bool of whether or not we want to do hourly bins
    """
    vent_phases = lib.clean_o2dev_data(vent_phases)
    hour_idxs = lib.perform_patient_hour_mapping(processed, mapping, vent_phases)
    calcs = BinCalculations(processed, hour_idxs)
    return calcs.perform_full_dataset_analysis(perform_hourly_binning)


def main():
    parser = ArgumentParser()
    parser.add_argument("map_file")
    parser.add_argument("processed_file")
    parser.add_argument("cohort_type", choices=lib.COHORT_CHOICES)
    parser.add_argument("--no-hourly-bins", action='store_false')
    args = parser.parse_args()
    mapping = lib.clean_mapping(pd.read_csv(args.map_file))
    processed = lib.read_processed_file(args.processed_file)
    vent_phases = pd.read_csv(SBT_O2_DEV_FILE)
    single_hour_df, multi_hour_df, _ = perform_binning_calculations(mapping, processed, vent_phases, args.no_hourly_bins)
    if isinstance(single_hour_df, pd.DataFrame):
        single_hour_df.to_csv('cohort_results/single_hour_{}_cohort_analysis.csv'.format(args.cohort_type), index=False)
    multi_hour_df.to_csv('cohort_results/multi_hour_{}_cohort_analysis.csv'.format(args.cohort_type), index=False)


if __name__ == "__main__":
    main()
