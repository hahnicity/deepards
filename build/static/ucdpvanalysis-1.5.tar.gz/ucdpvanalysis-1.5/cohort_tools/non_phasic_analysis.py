"""
non_phasic_analysis
~~~~~~~~~~~~~~~~~~~

Analyze information in a simpler format than phasic analysis without any legacy
TDAP headaches. Vent information file should just look like

patient,vent_start
0227, 06/30/2018 01:01:00
...
"""
import math
from warnings import warn

import numpy as np
import pandas as pd

from cohort_tools.constants import SKIP_HOUR


def get_slice_indexes(slice):
    low_idx = slice.iloc[0].name
    high_idx = slice.iloc[-1].name
    if isinstance(low_idx, tuple):
        low_idx = low_idx[-1]
    if isinstance(high_idx, tuple):
        high_idx = high_idx[-1]
    return low_idx, high_idx


def find_asyncs_by_indexed_hour(full_df, hour_idxs):
    """
    Because hour indexing can mismatch with calculated asynchronies in the past hour
    if we don't stop collecting data directly on the hour we need to calculate the
    number of asynchronies that occured in the hour_idx frames.
    """
    basic_rows = [
        ('bs_1or2', 'bsf_mms'),
        ('bs_1or2', 'bsf_ms'),
        ('bs_1or2', 'bsf_s'),
        ('dbl_4', 'dblf'),
        ('tvv', 'tvvf_mms'),
        ('tvv', 'tvvf_ms'),
        ('tvv', 'tvvf_s'),
    ]
    for patient in hour_idxs:
        hour_iterable = hour_idxs[patient]['hour_idxs']
        patient_df = full_df[full_df.patient == patient]
        for k, (low, high) in hour_iterable.items():
            if low == SKIP_HOUR and high == SKIP_HOUR:
                continue
            slice = patient_df.loc[low:high]
            for lookup, row in basic_rows:
                if "ms" in row:
                    severity = 1
                elif "s" in row:
                    severity = 2
                else:
                    severity = 0
                full_df.loc[high, row + '_indexed'] = len(slice[slice[lookup] > severity])
            full_df.loc[high, 'last_hour_n_indexed'] = len(slice)

    for row in ['asyncf_mms', 'asyncf_ms', 'asyncf_s']:
        suffix = row.split('_')[-1]
        bs_row = 'bsf_{}_indexed'.format(suffix)
        full_df[row + '_indexed'] = full_df[bs_row] + full_df['dblf_indexed']

    return full_df


def find_extended_data_out_of_bounds(patient_df, phases_row):
    basics = find_basic_data_out_of_bounds(patient_df, phases_row)
    metaphase_start = phases_row.mphase_start
    metaphase_end = phases_row.mphase_end
    data_before_first_meta = patient_df[patient_df.abs_bs < metaphase_start]
    data_after_first_meta = patient_df[patient_df.abs_bs > metaphase_end]
    updates = {'len_before_first_meta': len(data_before_first_meta), 'len_after_first_meta': len(data_after_first_meta)}
    basics.update(updates)
    return basics


def find_basic_data_out_of_bounds(patient_df, phases_row):
    vent_end = phases_row.vent_end
    vent_start = phases_row.vent_start
    data_before_start = patient_df[patient_df.abs_bs < vent_start]
    data_after_end = patient_df[patient_df.abs_bs > vent_end]
    return {'len_before_start': len(data_before_start), 'len_after_end': len(data_after_end)}


def get_hour_idxs(patient_df, patient_id, phases_row):
    """
    Get hour indexing for our patient.

    Returns a dictionary of data in the form

    {
        "vent_phase_hours": [
            (0, 1, 2, 3, 4, 5, 6),
            (6, 7, 8, 9, ...),
            ...
        ],
        "vent_phase_idxs": [
            (0, 10000),
            (10001, 20000),
            ...
        ],
        "hour_start_end": {
            0: (<time start>, <time end>),
            1: (<time start>, <time end>),
            ...
        },
        "hour_idxs": {
            0: (0, 1000)
            1: (1001, 2000),
            ...
        }
    }

    :param patient_df: The df of specific patient data we wish to analyze. All data should be sorted by absolute breath start before input!
    :param patient_id: The ID of the patient we are analyzing
    :param phases_row: Row with all vent phases and relevant information
    """
    patient_hour_locs = {
        "vent_phase_hours": [],
        "vent_phase_idxs": [],
        "hour_start_end": {},
        "hour_idxs": {},
    }

    vent_start = phases_row.vent_start
    vent_end = phases_row.vent_end
    data_in_range = patient_df[(patient_df.abs_bs >= vent_start) & (patient_df.abs_bs < vent_end)]

    if len(data_in_range) == 0:  # If theres no data then just skip
        patient_hour_locs["vent_phase_idxs"].append((SKIP_HOUR, SKIP_HOUR))
    else:
        patient_hour_locs['vent_phase_idxs'].append(get_slice_indexes(data_in_range))

    hour_offset = 0
    phase_hours = [[]]
    recording_end = patient_df.iloc[-1].abs_bs
    n_hours_on_vent = math.ceil((vent_end - vent_start).total_seconds() / 60.0 / 60.0)

    for hour in range(int(n_hours_on_vent)):
        phase_hours[0].append(hour)
        bin_start = vent_start + pd.Timedelta(hours=hour-hour_offset)
        bin_end = vent_start + pd.Timedelta(hours=hour+1-hour_offset)
        if bin_start > recording_end:
            break
        if bin_end > vent_end:
            bin_end = vent_end

        patient_hour_locs['hour_start_end'][hour] = (bin_start, bin_end)
        slice = data_in_range[
            (data_in_range.abs_bs >= bin_start) &
            (data_in_range.abs_bs < bin_end)
        ]
        if len(slice) == 0:
            patient_hour_locs["hour_idxs"][hour] = (SKIP_HOUR, SKIP_HOUR)
        else:
            patient_hour_locs["hour_idxs"][hour] = get_slice_indexes(slice)

    patient_hour_locs['vent_phase_hours'] = phase_hours
    return patient_hour_locs


def perform_patient_hour_mapping(processed, vent_phases, error_if_patient_not_found_in_vent_phases=False):
    patient_hour_locs = {}
    vent_phase_pts = vent_phases.patient.unique()
    for patient in processed.patient.unique():
        if patient not in vent_phase_pts and error_if_patient_not_found_in_vent_phases:
            raise Exception('Patient {} not found in vent_phase data!'.format(patient))
        elif patient not in vent_phase_pts:
            continue
        patient_df = processed[processed.patient == patient]
        if len(vent_phases[vent_phases.patient == patient]) > 1:
            raise Exception('found more than 1 code key row for patient {}'.format(patient))
        phases_row = vent_phases[vent_phases.patient == patient].iloc[0]
        if not isinstance(phases_row.vent_start, str) and np.isnan(phases_row.vent_start):
            continue
        phases_row['vent_end'] = pd.to_datetime(phases_row.vent_end)
        phases_row['vent_start'] = pd.to_datetime(phases_row.vent_start)
        patient_hour_locs[patient] = get_hour_idxs(patient_df, patient, phases_row)
        patient_hour_locs[patient]
    return patient_hour_locs
