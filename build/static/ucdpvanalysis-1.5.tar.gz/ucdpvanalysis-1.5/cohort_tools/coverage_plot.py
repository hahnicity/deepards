from argparse import ArgumentParser

import matplotlib.pyplot as plt
import pickle

import numpy as np

import lib


def main():
    parser = ArgumentParser()
    parser.add_argument("processed_file")
    parser.add_argument("cohort", choices=["exa", "copd", "other", "ards", "non_ards", "testing"])
    parser.add_argument("--no-plot", action="store_true")
    parser.add_argument("--limit", default=100, type=int)
    args = parser.parse_args()
    df = lib.read_processed_file(args.processed_file)
    df.loc[df[df.is_covered.isnull()].index, "is_covered"] = 0
    coverage = np.array([])
    ticks = []
    for patient in df.patient.unique():
        patient_df = df[df.patient == patient]
        if (len(patient_df[patient_df.is_covered == 1]) / float(len(patient_df))) * 100 <= args.limit:
            coverage = np.append(coverage, [len(patient_df[patient_df.is_covered == 1]) / float(len(patient_df))])
            ticks.append(patient)
    ind = np.arange(len(coverage))
    coverage = coverage * 100
    if args.no_plot:
        with open("{}_coverage_report_raw.pickle".format(args.cohort), "w") as f:
            pickle.dump([ind, ticks, coverage, args.cohort], f)
    else:
        plt.bar(ind, coverage)
        plt.xticks(ind, ticks, size="small")
        plt.title("{} cohort Percentage RPi data covered by TDAP".format(args.cohort.upper()))
        plt.xlabel("Patient")
        plt.ylabel("Percentage")
        plt.show()


if __name__ == "__main__":
    main()
