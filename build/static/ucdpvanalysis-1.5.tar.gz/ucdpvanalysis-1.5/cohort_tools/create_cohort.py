from argparse import ArgumentParser
import random

import numpy as np
import pandas as pd

import lib


def testing_func(key, df):
    to_drop = []
    patients = key["patient"].unique().tolist()
    for patient in df.iloc[:,0].str[:4].unique():
        to_drop.extend(df[df.iloc[:,0].str[:4] == patient].iloc[1000:].index.tolist())
    return df.drop(to_drop)


def ards_func(key, df):
    is_ards = key[(key["ards"] == "1")]["patient"]
    df = df[df.iloc[:,0].str[:4].isin(is_ards)]
    return df


def non_ards_func(key, df):
    is_ards = key[(key["ards"] != "1") & (key['ards'] != "1?")]["patient"]
    df = df[df.iloc[:,0].str[:4].isin(is_ards)]
    return df


def exa_func(key, df):
    is_exa = key[(key["copd"] == 1) & (key["exacerbation"] == 1)]["patient"]
    df = df[df.iloc[:,0].str[:4].isin(is_exa)]
    return df


def control_func(key, df):
    is_copd = key[(key["copd"] != "1") & (key.ards != 1)]["patient"]
    df = df[np.logical_not(df.iloc[:,0].str[:4].isin(is_copd))]
    return df


def copd_func(key, df):
    is_copd = key[(key["copd"] == 1) & (key["exacerbation"] != 1)]["patient"]
    df = df[df.iloc[:,0].str[:4].isin(is_copd)]
    return df


def main():
    parser = ArgumentParser()
    parser.add_argument("breath_file")
    parser.add_argument("output_file")
    parser.add_argument("key_file")
    subparsers = parser.add_subparsers()
    exa_parser = subparsers.add_parser("exa")
    exa_parser.set_defaults(func=exa_func)
    control_parser = subparsers.add_parser("control")
    control_parser.set_defaults(func=control_func)
    copd_parser = subparsers.add_parser("copd")
    copd_parser.set_defaults(func=copd_func)
    ards_parser = subparsers.add_parser("ards")
    ards_parser.set_defaults(func=ards_func)
    non_ards_parser = subparsers.add_parser("non_ards")
    non_ards_parser.set_defaults(func=non_ards_func)
    testing_parser = subparsers.add_parser("testing")
    testing_parser.set_defaults(func=testing_func)
    args = parser.parse_args()

    key = pd.read_csv(args.key_file)
    df = lib.read_raw_fused_file(args.breath_file)
    df = args.func(key, df)
    file = open(args.output_file, "w")
    df.to_csv(file, index=False, header=False)


if __name__ == "__main__":
    main()
