"""
tor_process_patients
~~~~~~~~~~~~~~~~~~~~

process every single patient that can be found in a given directory.
This script keeps track of the patients that have been previously completed
so it does not run them multiple times.

Output from this script is placed into a new directory, from there this
output can be uploaded to a database, and is the provenance of another
script.
"""

from argparse import ArgumentParser
from glob import glob
from os import mkdir
from os.path import join
import re
from warnings import warn

import numpy as np
import pandas as pd

from algorithms.raw_utils import extract_raw
from algorithms.tor5 import perform_tor_with_bs_be


def iterate_over_patient(patient_dir, out_dir, height, gender, pbw):
    patient = patient_dir.rstrip("/").split("/")[-1]
    files = glob("{}/*.csv".format(patient_dir))
    out_dir = join(out_dir, patient)
    try:
        mkdir(out_dir)
    except OSError:
        pass
    for file in files:
        perform_tor_with_bs_be(file, [], out_dir, height, gender, pbw)


def process_height_and_gender():
    try:
        gender = int(gender)
        if gender == 1:
            gender = "M"
        else:
            gender = "F"
    except:
        pass

    if height is np.nan and gender is np.nan:
        return height, gender
    elif height is np.nan and gender is not np.nan:
        height = {"M": 69.7 * 2.54, "F": 64 * 2.54}[gender.upper()]
    # convert cm to inches.
    try:
        height = float(height) / 2.54
    except:  # If height is a string
        height = np.nan
        gender = np.nan

    return height, gender


def main():
    parser = ArgumentParser()
    parser.add_argument(
        "range_start",
        type=int,
        help=("The first patient that we want to start with. For example if we wanted "
        "to start with 0001RPIXXXX then this input would be 1")
    )
    parser.add_argument(
        "range_end",
        type=int,
        help=("The first patient that we want to start with. For example if we wanted "
        "to end with 0100RPIXXXX then this input would be 100")
    )
    parser.add_argument(
        "code_key",
        help="The path to the file that contains patient height, and sex. The code key can also just have the predicted body weight only."
    )
    parser.add_argument(
        "--pt-dir",
        default=".",
        help=("Path to the directory that contains all patient data. "
        "The directory should be the directory that has subfolders that "
        "look like 0001RPIXXXX, 0002RPIXXXX, and should not be the "
        "individual patient directories.")
    )
    parser.add_argument(
        "--out-dir",
        default=".",
        help=("Path to the directory that we want to output TOR and breath_meta results in.")
    )
    args = parser.parse_args()
    code_key = pd.read_csv(args.code_key)
    patient_dirs = glob(join(args.pt_dir, "*RPI*"))
    completed_file = "completed.list"
    for pt_dir in patient_dirs:
        completed = open(completed_file, "r")
        completed.seek(0)
        completed_list = map(lambda x: x.strip("\n"), completed.readlines())
        patient = pt_dir.rstrip("/").split("/")[-1]
        if patient in completed_list:
            continue
        match = re.search("0(\d\d\d)RPI", patient)
        if not match:
            continue
        pt_num = int(match.groups()[0])
        if not args.range_start <= pt_num <= args.range_end:
            continue
        unique_iden_colnames = ['Patient Unique Identifier', 'PATIENT_UNIQUE_IDENTIFIER']
        for colname in unique_iden_colnames:
            if colname in code_key.columns:
                pt_row = code_key[code_key[colname] == patient]
                break
        if len(pt_row) == 0:
            warn("patient {} was not found in the code key".format(patient))
            continue
        pt_row = code_key.loc[pt_row.index[0]]

        if 'PREDICTED_BODY_WEIGHT' in pt_row.index:
            pbw = float(pt_row['PREDICTED_BODY_WEIGHT'])
            height = None
            gender = None
        else:
            pbw = None
            height = pt_row['Height (cm)']
            gender = pt_row['Sex']
            height, gender = process_height_and_gender(height, gender)
            if np.isnan(height) or np.isnan(gender):
                continue

        iterate_over_patient(pt_dir, args.out_dir, height, gender, pbw)
        with open(completed_file, "a") as comp_writer:
            comp_writer.write(patient + "\n")
        completed.close()


if __name__ == "__main__":
    main()
