SKIP_HOUR = "skip"
