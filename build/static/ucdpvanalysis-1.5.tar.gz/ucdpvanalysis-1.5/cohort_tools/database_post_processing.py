"""
database_post_processing
~~~~~~~~~~~~~~~~~~~~~~~~

Perform post processing on the cohort database. Basic usage of this script would look like

    python database_post_processing.py db-post-processed.pkl
"""
import argparse
from collections import OrderedDict
import gc
import getpass
import os
import subprocess

import numpy as np
import pandas as pd

PROCESSED_MAPPING = OrderedDict()
PROCESSED_MAPPING["patient"] = "object"
PROCESSED_MAPPING["abs_bs"] = "float16"
PROCESSED_MAPPING["tve"] = "float16"
PROCESSED_MAPPING["tvi"] = "float16"
PROCESSED_MAPPING["tve_tvi_ratio"] = "float16"
PROCESSED_MAPPING["bs_1"] = "int8"
PROCESSED_MAPPING["dbl_2"] = "int8"
PROCESSED_MAPPING["dbl_3"] = "int8"
PROCESSED_MAPPING["dbl_4"] = "int8"
PROCESSED_MAPPING["tvv"] = "int8"
PROCESSED_MAPPING["bs_2"] = "int8"
PROCESSED_MAPPING["bs_1or2"] = "int8"
PROCESSED_MAPPING["last_hour_all"] = "int16"
PROCESSED_MAPPING["bsf_ms"] = "int16"
PROCESSED_MAPPING["bsf_mms"] = "int16"
PROCESSED_MAPPING["dblf"] = "int16"
PROCESSED_MAPPING["bsi_ms"] = "float16"
PROCESSED_MAPPING["bsi_mms"] = "float16"
PROCESSED_MAPPING["asyncf_ms"] = "int16"
PROCESSED_MAPPING["asyncf_mms"] = "int16"
PROCESSED_MAPPING["asynci_ms"] = "float16"
PROCESSED_MAPPING["asynci_mms"] = "float16"
PROCESSED_MAPPING["tvvf_mms"] = "int16"
PROCESSED_MAPPING["tvvf_ms"] = "int16"
PROCESSED_MAPPING["tvvf_s"] = "int16"
PROCESSED_MAPPING["tvvi_mms"] = "float16"
PROCESSED_MAPPING["tvvi_ms"] = "float16"
PROCESSED_MAPPING["tvvi_s"] = "float16"
PROCESSED_MAPPING["breath_time"] = "float16"
PROCESSED_MAPPING["peep"] = "float16"
PROCESSED_MAPPING["maw"] = "float16"
PROCESSED_MAPPING["pip"] = "float16"
PROCESSED_MAPPING["ip_auc"] = "float16"
PROCESSED_MAPPING['n_past_10'] = 'int16'
PROCESSED_MAPPING['bsf_ms_past_10'] = 'int16'
PROCESSED_MAPPING['bsf_mms_past_10'] = 'int16'
PROCESSED_MAPPING['dblf_past_10'] = 'int16'
PROCESSED_MAPPING['tvvf_s_past_10'] = 'int16'
PROCESSED_MAPPING['tvvf_ms_past_10'] = 'int16'
PROCESSED_MAPPING['tvvf_mms_past_10'] = 'int16'
PROCESSED_MAPPING["asyncf_ms_past_10"] = "int16"
PROCESSED_MAPPING["asyncf_mms_past_10"] = "int16"
PROCESSED_COLS = PROCESSED_MAPPING.keys()


def create_bs2(df):
    bs_2 = pd.Series([0] * len(df), index=df.index, dtype=np.int8)
    is_2 = df[df["bs_1"] == 0]
    severity_3 = is_2[is_2.tve_tvi_ratio < .33]
    severity_2 = is_2[(is_2.tve_tvi_ratio < .66) & (is_2.tve_tvi_ratio >= .33)]
    severity_1 = is_2[(is_2.tve_tvi_ratio >= .66) & (is_2.tve_tvi_ratio < .9)]
    bs_2.loc[severity_3.index] = 3
    bs_2.loc[severity_2.index] = 2
    bs_2.loc[severity_1.index] = 1
    df['bs_2'] = bs_2
    df['bs_1or2'] = (df.bs_1 | df.bs_2).astype(np.int8)
    return df


def read_raw_fused_file(filename):
    mapping = {
        0: ("object", "patient"),
        1: ("float16", "abs_bs"),
        2: ("float16", "tve"),
        3: ("float16", "tvi"),
        4: ("float16", "tve_tvi_ratio"),
        5: ("float16", "e_time"),
        6: ("float16", "i_time"),
        7: ("float16", "peep"),
        8: ("float16", "maw"),
        9: ("float16", "pip"),
        10: ("float16", "ip_auc"),
        11: ("int8", "bs_1"),
        12: ("int8", "dbl_2"),
        13: ("int8", "dbl_3"),
        14: ("int8", "dbl_4"),
        15: ("int8", "tvv"),
    }
    df = pd.read_csv(
        filename,
        dtype={k: v[0] for k, v in mapping.items()},
        header=None,
        parse_dates=[1]
    )
    return df.rename(columns={k: v[1] for k, v in mapping.items()})


def read_processed_file(filename):
    processed = pd.read_csv(filename, dtype=PROCESSED_MAPPING, parse_dates=[1])
    processed.patient = processed.patient.str[:4]
    processed.sort_values(by=["patient", "abs_bs"], inplace=True)
    processed.index = pd.MultiIndex.from_tuples(zip(processed.patient, processed.index))
    return processed


def timedelta_pva_func(df, type_, severity_condition, timedelta_col):
    """
    Determine number of pva events within the past time window

    :param df: DataFrame with breath information
    :param type_: The type of pva we wish to analyze
    :param severity_condition: severity of the pva
    :param timedelta_col: name of the column that records number of breaths in past <timedelta>
    """
    result = []
    td = pd.Timedelta(hours=1)
    cols = list(df.columns)
    type_idx = {
        "dbl": cols.index("dbl_4"),
        "bs": cols.index("bs_1or2"),
        "tvv": cols.index("tvv")
    }[type_]
    # last_hour_all_index = lhai
    lhai = cols.index(timedelta_col)
    condition = {"dbl": 0, "bs": severity_condition, "tvv": severity_condition}[type_]
    for patient in df.patient.unique():
        patient_frame = df[df.patient == patient].values
        cur_count = 0
        for idx_cur, row in enumerate(patient_frame):
            if row[type_idx] > condition:
                cur_count += 1
            # the AND condition is present so we don't loop around to the back of array
            if row[lhai] <= patient_frame[idx_cur - 1][lhai] and idx_cur - 1 > 0:
                diff = patient_frame[idx_cur - 1][lhai] - row[lhai]
                for i in range(idx_cur - row[lhai] - diff, idx_cur - row[lhai] + 1):
                    if patient_frame[i][type_idx] > condition:
                        cur_count -= 1
            result.append(cur_count)
    return np.array(result).astype(np.int16)


def find_number_breaths_in_delta(df, td):
    if not isinstance(td, pd.Timedelta):
        raise ValueError("td must be an instance of pandas.Timedelta!")
    result = []
    for patient in df.patient.unique():
        patient_frame = df[df.patient == patient].values
        idx_last = 0
        cur_count = 0
        for idx_cur, row in enumerate(patient_frame):
            cur_count += 1
            for i in range(idx_last, idx_cur):
                if row[1] - td <= patient_frame[i][1] <= row[1]:
                    result.append(cur_count)
                    break
                cur_count -= 1
                idx_last += 1
            else:
                result.append(cur_count)
    return np.array(result).astype(np.int16)


def perform_all_post_processing(df):
    """
    Determine the number of breaths in the last hour and then derive other
    last hour stats from that
    """
    df = create_bs2(df)
    df = df.sort_values(by=['patient', 'abs_bs'])
    # re-index after sorting
    df.index = range(len(df))
    df = df[np.logical_not(df.abs_bs.isnull())]
    time_cols = [('n_past_10', '_past_10', pd.Timedelta(minutes=10)), ('last_hour_all', '', pd.Timedelta(hours=1))]

    for col_name, col_suffix, delta in time_cols:
        df[col_name] = find_number_breaths_in_delta(df, delta)
        df['bsf_ms{}'.format(col_suffix)] = timedelta_pva_func(df, "bs", 1, col_name)
        df['bsf_mms{}'.format(col_suffix)] = timedelta_pva_func(df, "bs", 0, col_name)
        df['dblf{}'.format(col_suffix)] = timedelta_pva_func(df, "dbl", None, col_name)
        df['tvvf_mms{}'.format(col_suffix)] = timedelta_pva_func(df, "tvv", 0, col_name)
        df['tvvf_ms{}'.format(col_suffix)] = timedelta_pva_func(df, "tvv", 1, col_name)
        df['tvvf_s{}'.format(col_suffix)] = timedelta_pva_func(df, "tvv", 2, col_name)
        df['asyncf_ms{}'.format(col_suffix)] = (df['bsf_ms{}'.format(col_suffix)] + df['dblf{}'.format(col_suffix)]).astype(np.int16)
        df['asyncf_mms{}'.format(col_suffix)] = (df['bsf_mms{}'.format(col_suffix)] + df['dblf{}'.format(col_suffix)]).astype(np.int16)

    df['bsi_ms'] = (df['bsf_ms'] / df['last_hour_all']).astype(np.float16)
    df['bsi_mms'] = (df['bsf_mms'] / df['last_hour_all']).astype(np.float16)
    df['asynci_ms'] = (df['asyncf_ms'] / df['last_hour_all']).astype(np.float16)
    df['asynci_mms'] = (df['asyncf_mms'] / df['last_hour_all']).astype(np.float16)
    df['tvvi_mms'] = (df['tvvf_mms'] / df['last_hour_all']).astype(np.float16)
    df['tvvi_ms'] = (df['tvvf_ms'] / df['last_hour_all']).astype(np.float16)
    df['tvvi_s'] = (df['tvvf_s'] / df['last_hour_all']).astype(np.float16)
    df['breath_time'] = (df['e_time'] + df['i_time']).astype(np.float16)
    return df[PROCESSED_MAPPING.keys()]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('filename', help='name of final dataset file')
    parser.add_argument('-t', '--tmp-database-export-name', default='raw-db.csv')
    args = parser.parse_args()

    metadata_file = os.path.join('pvi_metadata/', args.tmp_database_export_name.replace('.csv', '.pkl'))
    if not os.path.exists(metadata_file):
        db_pass = getpass.getpass("Enter mysql password: ")
        print('Begin database export. This will take awhile')
        cmd = subprocess.Popen(['./database_export.sh', args.tmp_database_export_name, db_pass], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = cmd.communicate()
        df = read_raw_fused_file(metadata_file)
        df.to_pickle(metadata_file)
    else:
        df = pd.read_pickle(metadata_file)

    print('Performing post-processing on database export')
    post_proc = perform_all_post_processing(df)
    post_proc.to_pickle(args.filename)


if __name__ == '__main__':
    main()
