from argparse import ArgumentParser
from glob import glob
from multiprocessing import cpu_count, Pool
import os

import pandas as pd

COL_RENAMING = {
    "abs_time_at_BS": "abs_bs",
    "iTime": "i_time",
    "eTime": "e_time",
    "inst_RR": "inst_rr",
    "PIP": "pip",
    "Maw": "maw",
    "PEEP": "peep",
    "tvi": "tvi",
    "tve": "tve",
    "dbl.4": "dbl_4",
    "bs.1": 'bs_1',
    "bs.2": 'bs_2',
    'cosumtvd': 'cosumtvd',
    'sumt': 'sumt',
    'vd.2': 'vd_2',
    'tvv': 'tvv',
}


def post_process_db(array, patient_id):
    lens = sum([len(x) for x in array])
    if lens == 0:
        return
    frame = pd.concat(array, sort=True)
    frame.index = range(len(frame))
    cols_to_drop = set(frame.columns).difference(set(COL_RENAMING.keys()))
    frame = frame.drop(cols_to_drop, axis=1)
    frame = frame.rename(columns=COL_RENAMING)
    frame['patient'] = patient_id
    return frame


def process_patient(patient_dirname, output_dir, force_overwrite):
    patient_id = patient_dirname.split('/')[-1]
    fused_files = glob(os.path.join(patient_dirname, '*_solo3_FUSED_tvv.csv'))
    pt_output_dir = os.path.join(output_dir, patient_id)
    try:
        os.mkdir(pt_output_dir)
    except OSError:
        if force_overwrite:
            pass
        else:
            return

    # could probably make this into a separate function but whatever
    fused_output = []
    reg_output = []
    for file in fused_files:
        breath_meta_fused_filename = file.replace('solo3_FUSED_tvv', 'breath_meta_FUSED')
        solo_fused = pd.read_csv(file)
        bm_fused = pd.read_csv(breath_meta_fused_filename)
        solo_fused = solo_fused.rename(columns={'abs_bs': 'abs_time_at_BS'})
        fused_output.append(bm_fused.merge(solo_fused, on=['abs_time_at_BS', 'BN', 'ventBN', 'BS']))
    all_fused = post_process_db(fused_output, patient_id)
    if all_fused is None:
        return
    all_fused.to_csv(os.path.join(pt_output_dir, 'all_fused.csv'), index=None)

    solo3_tvv_files = glob(os.path.join(patient_dirname, '*_solo3_tvv.csv'))
    for file in solo3_tvv_files:
        breath_meta_filename = file.replace('solo3_tvv', 'breath_meta')
        solo = pd.read_csv(file)
        bm = pd.read_csv(breath_meta_filename)
        solo = solo.rename(columns={'abs_bs': 'abs_time_at_BS'})
        reg_output.append(bm.merge(solo, on=['abs_time_at_BS', 'BN', 'ventBN', 'BS']))
    all_reg = post_process_db(reg_output, patient_id)
    if all_reg is None:
        return
    all_reg.to_csv(os.path.join(pt_output_dir, 'all_non_fused.csv'), index=None)


def func_star(args):
    process_patient(*args)


def main():
    parser = ArgumentParser()
    parser.add_argument("main_data_dir", help='base dir where all patient directories are')
    parser.add_argument('out_dir', help='output directory path')
    parser.add_argument('--threads', default=cpu_count(), type=int)
    parser.add_argument('--debug', action='store_true', help='debug script and dont run with multiprocessing')
    parser.add_argument('--force-overwrite', action='store_true', help='overwrite any data in db directory')
    parser.add_argument('--only-patient', help='only run on a single, specified patient')
    args = parser.parse_args()

    if not args.only_patient:
        patient_dirs = glob(os.path.join(args.main_data_dir, '0*RPI*'))
    else:
        patient_dirs = glob(os.path.join(args.main_data_dir, args.only_patient))

    run_args = [(dirname, args.out_dir, args.force_overwrite) for dirname in patient_dirs]
    if not args.debug:
        pool = Pool(args.threads)
        pool.map(func_star, run_args)
        pool.close()
        pool.join()
    else:
        for args in run_args:
            func_star(args)


if __name__ == "__main__":
    main()
