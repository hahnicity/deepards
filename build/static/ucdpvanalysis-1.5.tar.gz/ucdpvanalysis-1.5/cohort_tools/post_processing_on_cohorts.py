"""
This file should go away soon
"""
from argparse import ArgumentParser

import lib


def main():
    parser = ArgumentParser()
    parser.add_argument("breath_file")
    parser.add_argument("outfile")
    args = parser.parse_args()
    df = read_raw_fused_file(args.breath_file)
    lib.perform_all_post_processing(df)
    df.to_csv(args.outfile, index=False)


if __name__ == "__main__":
    main()
