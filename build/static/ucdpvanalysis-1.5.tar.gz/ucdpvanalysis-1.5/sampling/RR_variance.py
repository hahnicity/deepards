# -*- coding: utf-8 -*-
"""
Created on Thu Jun 11 17:14:01 2015

@author: Keiko
"""

from __future__ import division
import os
import numpy as np
import sys
import csv
sys.path.insert(0, r'C:\allMYfiles\My_Documents\GitHub\ucdpv\algorithms')
import SAM; reload(SAM)
sys.path.insert(0, r'C:\allMYfiles\My_Documents\GitHub\ucdpv\analysis')
#import dicts; 
#reload(dicts)
import stats; 
reload(stats)
#import pviplot;
#reload (pviplot)
#import matplotlib.pyplot as plt
#import mpld3
#from mpld3 import plugins
import time
import pandas as pd
import shutil

from bokeh.plotting import figure, output_notebook, show, output_file
from bokeh.models import NumeralTickFormatter
from bokeh.models import LinearAxis, Range1d 

#%% starting
realstart = time.time()
root_dir=r'C:\allMYfiles\My_Documents\GitHub\sandbox4_sampling'
os.chdir(root_dir)
input_subdir='input'
output_subdir='output'
input_file='rpi3.csv'

parseMethod = 'RRvariance' #'RRvariance', 'sequential', or 'random'
subsetSample = 4 #of subsets to keep

temp_folder = 'temp'
temp_path = os.path.join(output_subdir, temp_folder)
folderExists = os.path.isdir(temp_path)

if folderExists == False:
    os.mkdir(temp_path)

filename=os.path.splitext(input_file) [0]
input_path = os.path.join(input_subdir, input_file)

#%%read/split up files
startTime = time.time()

dt = 0.02

copy = False

count200 = 0
i = 0
row_n = 0
breath_dict = {}
BN = 0
t_i =0

plain = []

#200-subset
subset200 = []
RRs = []
startBN= 1

#frame variables
BS = 0
N = []

def calcRR(RR):
    meanRR = np.mean(RR, dtype = np.float64)
    sdRR = np.std(RR, dtype = np.float64)
    varRR = np.var(RR, dtype = np.float64)
    return meanRR, sdRR, varRR

with open(input_path, 'rU') as read, open(filename + '_RR.csv', 'wb') as f:
    rawCSV = csv.reader(read, delimiter=',')
    rrCSV = csv.writer(f, delimiter = ',')
    RRindex = ['subset','startBreath#', 'endBreath#', 'startTime', 'endTime', 
                'meanRR', 'sdRR', 'varRR']    
    rrCSV.writerow(RRindex)    
    
    for row in rawCSV:
        row_n +=1
        
        if row[0] in ['BS']:
            BN += 1
            copy = True           
            
            if BN ==1:
                BS = float(i*dt)
            else:
                BS = t_i + 0.02
                #breath_dict[BN] = BS
            
        elif row[0] in ['BE'] and copy ==True:
            frame_dur = (t_i - BS) + 0.02
            instRR = 60/frame_dur
            RRs.append(instRR)
            
            t, flow, pressure =zip(*N)
            # extraction inhalation and exhalation
            # -----------------------------------            
            x0 = SAM.findx0(t, flow, 0.5)
            if x0!=[]: #if x0 has multiple values, use the first value to mark end of breath
                i_end = (x0[0])
            else: #if breath doesn't cross 0 (eg. double trigger)
                i_end = t_i
            # set end of inhalation to where x crosses 0            
                        
            breath_dict[BN]=(BS,i_end)
            plain.append(N)
            if BN % 5 ==0 and BN !=0:
                count200 +=1
                endBN = BN
                outName= "%s__split%s.csv"% (filename, str(count200))
                out_path = os.path.join(temp_path, outName)
                SAM.writecsv(subset200, out_path)
                
                meanRR, sdRR, varRR = calcRR(RRs)
                outRR = [count200, startBN, endBN, breath_dict[startBN][0], breath_dict[endBN][0],
                         meanRR, sdRR, varRR]
                rrCSV.writerow(outRR)                
                
                #reset subset200 variables
                subset200 = []
                RRs = []
                #setup variables for next subset
                startBN = BN +1
                
            
            #reset frame variables
            N = []
        elif copy == True:
            fullrow=len(row)==2
            if fullrow:
                t_i =  float(i*dt)
                flow_i = float (row[0])
                pressure_i = float(row[1])
               
                N +=[(t_i, flow_i, pressure_i)]
                subset200 +=[(t_i, flow_i, pressure_i)]
                
                lastT = t_i
                
                i += 1
            else:
                count200 +=1
                outName= "%s__split%s.csv"% (filename, str(count200))
                out_path = os.path.join(temp_path, outName)
                meanRR, sdRR, varRR = calcRR(RRs)
                outRR = [count200, startBN, endBN, breath_dict[startBN][0], breath_dict[endBN][0],
                        meanRR, sdRR, varRR]
                rrCSV.writerow(outRR)    
                SAM.writecsv(subset200, out_path)
  
        
#        else:
#            print "Big issue!"--these are rows that are before the first BS
                
        
runtime = time.time() - startTime
print("--- %s seconds elapsed, %s rows processed---" % (runtime, row_n))
print (time.strftime("Finished at %d/%m/%Y  %H:%M:%S"))
print "Divided %d breaths into %d temp csv files" %(BN, count200)

#%%choose which subsets

#readCSV file
df = pd.read_csv(filename + '_RR.csv', index_col=0)
#df.head()


if parseMethod == 'RRvariance':
    df = df.sort(columns='varRR', ascending = False)    
    df_keep = df[0:subsetSample]    
    subsetsKeepList = list(df_keep.index)
    print "parseMethod = RRvariance"
elif parseMethod == 'sequential':
    subsetsKeepList = np.linspace(1, count200, subsetSample, dtype =int)
    df_keep= df.loc[subsetsKeepList,:]
    print "parseMethod = sequential"
elif parseMethod == 'random':
    subsetsKeepList = np.random.random_integers(1, count200, subsetSample)
    df_keep= df.loc[subsetsKeepList,:]
    print "parseMethod = random"
elif parseMethod == 'manual':
    pass
else:
    print "ERROR: '%s' is not a parseMethod. Try 'RRvariance', 'sequential', or 'random'"
subsetsKeepList.sort()
print"subsets to keep", subsetsKeepList
df_keep
#subsetsKeepList

#%%concatenate subsets + move to output folder
reverse = reverseBreath(breath_dict)   #necessary for plot 
keepFolder = filename + 'subsets'
keepPath = os.path.join(output_subdir, keepFolder)
folderExists = os.path.isdir(keepPath)

if folderExists == False:
    os.mkdir(keepPath)
    #initiate blank dataframes
    
#df_mult3 = pd.DataFrame(columns = ['time', 'flow', 'pressure'])
df_mult = pd.DataFrame(columns = ['time', 'flow', 'pressure'])
df_ann = pd.DataFrame(columns = [ 'BN', 'BS', 'anns'])

for subsetN in subsetsKeepList:
    name= "%s__split%s.csv"% (filename, str(subsetN))
    path = os.path.join(temp_path, name) 
#    df_mult3 = df_mult3.append(df_sub)
    insert = [['----','subset '+str(subsetN),'----']]
    #creates/concat waveforms
    df_mult = df_mult.append(pd.DataFrame(insert, columns = ['BN', 'BS', 'anns']), ignore_index = True)  #inserts subsetN   
    df_sub = pd.read_csv(path, names = ['time', 'flow', 'pressure']) #reads subset
    df_mult = pd.concat([df_mult, df_sub]) #concatenates subset
    shutil.move(path, keepPath)
    
    # shows subset plot
    plot,BNs, BSs = plot_bokeh_subset(df_sub, subsetN, keepPath)
    show(plot)    
    
    # creates annotation/concat files
    df_ann = df_ann.append(pd.DataFrame(insert, columns = ['BN', 'BS', 'anns']), ignore_index = True)     
    df_ann_sub = pd.DataFrame({'BN': BNs, 'BS': BSs, 'anns': ''})
    df_ann = pd.concat([df_ann, df_ann_sub])    
    
    
df_mult.to_csv(os.path.join(output_subdir, filename + '_concat.csv'), 
                index = False, index_label = False) 
df_ann.to_csv(os.path.join(output_subdir, filename + '__Brooks__tofill.csv'), 
                index = False) 
df_ann.to_csv(os.path.join(output_subdir, filename + '__Adams__tofill.csv'), 
                index = False) 

#delete remaining subsets
#shutil.rmtree(temp_path)




#%%  original plot
#for subsetN in subsetsKeepList[0:1]:
#    name= "%s__split%s.csv"% (filename, str(subsetN))
#    path = os.path.join(keepPath, name) 
#    df_sub = pd.read_csv(path, names = ['time', 'flow', 'pressure'])
#    
#    
#    t= df_sub['time']
#    pressure = df_sub['pressure']
#    flow = df_sub['flow']
#    
#    startBN, endBN, startBS, endBS = extractBreathinfo(df, subsetN)
#    
#    
#    title = "subset %s-breaths %d : %d" % (subsetN, startBN, endBN)
#    
#    BNs = []
#    BSs = []
#    for BN in range(startBN, endBN+1):
#        BNs.append(BN)
#        BSs.append(breath_dict[BN][0])




#show (plot)
#%% supporting functions

def reverseBreath (breath_dict):
    reverse ={}
    for k, v in breath_dict.items():
        BS,IE = v
        newK = round(BS,2)
        reverse[newK]=k
    return reverse
    
def extractBreathinfo(df, subsetN):
    startBN = int(df.loc[subsetN,'startBreath#'])
    endBN = int(df.loc[subsetN, 'endBreath#'])
    startBS = round(df.loc[subsetN, 'startTime'],2)
    endBS = round(df.loc[subsetN, 'endTime'],2)
    return startBN, endBN, startBS, endBS 

def extractBreathByDict (time_df, reverseBreathDict):
    t = time_df
    reverse = reverseBreathDict
    startBS = t[0]
    endIE = t.iloc[-1] + 0.02
    
    startBN = reverse[startBS]
    endBN = reverse[endIE]-1
    endBS = breath_dict[endBN]
    return startBN, endBN, startBS, endBS

def plot_bokeh_subset(df_sub, subsetN, outputPath):
    keepPath = outputPath
    t= df_sub['time']
    pressure = df_sub['pressure']
    flow = df_sub['flow']
    
    startBN, endBN, startBS, endBS = extractBreathinfo(df, subsetN)
    
    
    title = "subset %s-breaths %d : %d" % (subsetN, startBN, endBN)
    
    BNs = []
    BSs = []
    for BN in range(startBN, endBN+1):
        BNs.append(BN)
        BSs.append(breath_dict[BN][0])    
    
    plot_name = "%s__split%s.html"% (filename, str(subsetN))
    output_file(os.path.join(keepPath, plot_name))
#    start_time = time.time()
    p = figure(plot_width=700, plot_height=300, tools = " pan,  xwheel_zoom, reset",
              title = title, y_range=(-100,200))
    endpt= len(t)
    x = t[0:endpt]
    y1 = pressure[0:endpt]
    y2 = flow [0:endpt]
    
    p.line(x, y1, line_width=2, legend = 'pressure', line_color="purple",
           y_range_name = "pressure")
    p.extra_y_ranges = {"pressure": Range1d(start = -70, end =30)}
    p.add_layout(LinearAxis(y_range_name="pressure"), 'left')
    p.line(x, y2, line_width=2, legend = 'flow')
    
    
    #p.xaxis[0].formatter = NumeralTickFormatter(format="00:00:00")
    p.text(x=BSs, y= 180, text =BNs, text_font_size="10pt")
    #p.multi_line([x, y1], [x, y2],
    #             color=["firebrick", "navy"], alpha=[0.8, 0.3], line_width=4)
#    run_time=(time.time() - start_time)
#    print("--- %s seconds elapsed, %s rows graphed---" % (run_time, endpt))
    return p, BNs, BSs
    
runtime = time.time()-realstart
print runtime