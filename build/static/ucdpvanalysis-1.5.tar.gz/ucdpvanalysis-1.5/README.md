# ucdpvanalytics
Analytics libraries for UCDPV

[https://github.com/flipcorp/ucdpv/wiki](https://github.com/flipcorp/ucdpv/wiki)

## Installation
Set up a virtualenv and install dependencies

    cd /path/to/ucdpvanalytics/
    pip install virtualenv
    virtualenv venv
    source venv/bin/activate

    pip install -e .
    python setup.py develop

## Running full cohort
By running the cohort we mean processing all raw ventilator data and passing it
through breath_meta and TOR algorithms. breath_meta will output some breath metadata
matrix that contains information regarding each breath, and TOR will determine whether or
not each breath is asynchronous. There are multiple scripts in this pipeline that each
perform different actions. First is the `run_full_cohort` script.

### run_full_cohort
This script processes every single patient that can be found in a given directory.
It also keeps track of the patients that have been previously completed
so it does not run them multiple times.

Output from this script is placed into a new directory, from there this
output can be uploaded to a database, and is the provenance of the `csv_to_sql`
script.

Usage:

    run_full_cohort 10 100 --pt-dir /path/to/rpi-data --out-dir /path/to/output

### csv_to_sql
The `csv_to_sql` script takes input from a single patient directory and inputs
it into the database. To prevent patient data from being duplicated in the
database there is a guardfile `db_complete.list` that is created and contains a
list of all patients who had their data input into the database. Data is input
into the database in format described in `schema/schema.py` which defines a
`SQLAlchemy` ORM model of inputting data into the database.

Usage:

    csv_to_sql /path/to/single/patient/0001RPIXXXX -u db_user -p password

For inputting multiple patients into the database at once you can use some
additional shell scripting to assist.

    for $patient_dir in /path/to/data/dir
    do
        csv_to_sql $patient_dir -u db_user -p password
    done

The reason these two scripts differ in format is because, I don't know, I
was indecisive one day and liked both formats at different times; I'm so sorry.
