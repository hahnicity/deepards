from argparse import ArgumentParser
from glob import glob
import os

import numpy as np
import pandas as pd
from sqlalchemy import create_engine

from schema import metadata

BREATH_META_TO_SQL_RENAMING = {
    "BN": "rel_bn",
    "ventBN": "vent_bn",
    "BS": "rel_bs",
    "abs_time_at_BS": "abs_bs",
    "IEnd": "i_end",
    "BE": "be",
    "I:E ratio": "ie_ratio",
    "iTime": "i_time",
    "eTime": "e_time",
    "inst_RR": "inst_rr",
    "tve:tvi ratio": "tve_tvi_ratio",
    "maxF": "max_f",
    "minF": "min_f",
    "maxP": "max_p",
    "PIP": "pip",
    "Maw": "maw",
    "PEEP": "peep",
    "ipAUC": "ip_auc",
    "epAUC": "ep_auc",
    "tvi": "tvi",
    "tve": "tve",
}

SOLO_TO_SQL_RENAMING = {
    "BN": "rel_bn",
    "ventBN": "vent_bn",
    "dbl.2": "dbl_2",
    "dbl.3": "dbl_3",
    "dbl.4": "dbl_4",
    "bs.1": "bs_1",
    "bs.2": "bs_2",
    "bs.1or2": 'bs_1or2',
    "bs.sudo": 'bs_sudo',
    "co.sudo": 'co_sudo',
    "dtpi": 'dtpi',
    "dtpa.1": 'dtpa_1',
    'dtpa.2': 'dtpa_2',
    'dtpa.3': 'dtpa_3',
    'cosumtvd': 'cosumtvd',
    'sumt': 'sumt',
    'mt': 'mt',
    'mt.su': 'mt_su',
    'co.orig': 'co_orig',
    'co.2thresh': 'co_2thresh',
    "co.noTVi": "co_no_tvi",
    'vd': 'vd',
    'vd.2': 'vd_2',
    'su': 'su',
    'su.2': 'su_2',
    'tvv': 'tvv',
}


def do_breath_meta_and_solo(patient, breath_meta_files, engine):
    if "FUSED" in breath_meta_files[0]:
        bm_suffix = "breath_meta_FUSED"
        solo_suffix = "solo3_FUSED_tvv"
        bm_table = "breath_meta_fused"
        solo_table = "classifications_fused"
    else:
        bm_suffix = "breath_meta"
        solo_suffix = "solo3_tvv"
        bm_table = "breath_meta"
        solo_table = "classifications"

    for file_ in breath_meta_files:
        bm = pd.read_csv(file_)
        solo_name = file_.replace(bm_suffix, solo_suffix)
        solo_tvv = pd.read_csv(file_.replace(bm_suffix, solo_suffix))
        bm_to_drop = bm.columns.difference(BREATH_META_TO_SQL_RENAMING.keys())
        solo_to_drop = solo_tvv.columns.difference(SOLO_TO_SQL_RENAMING.keys())
        bm = bm.rename(columns=BREATH_META_TO_SQL_RENAMING)
        bm = bm.drop(bm_to_drop, axis=1)
        bm['patient'] = [patient for _ in range(len(bm))]
        bm = bm.replace("-", np.nan)
        bm = bm.replace("inf", np.nan)
        solo_tvv = solo_tvv.rename(columns=SOLO_TO_SQL_RENAMING)
        solo_tvv = solo_tvv.drop(solo_to_drop, axis=1)
        solo_tvv['abs_bs'] = bm['abs_bs']
        solo_tvv['patient'] = bm['patient']
        solo_tvv = solo_tvv.replace("-", np.nan)
        solo_tvv = solo_tvv.replace("inf", np.nan)
        if len(solo_tvv) != len(bm):
            raise Exception(
                "breath meta and solo files are of unequal length! "
                "bm: {}, solo: {}".format(file_, solo_name)
            )
        solo_tvv.to_sql(solo_table, engine, if_exists='append', index=False, chunksize=10000)
        bm.to_sql(bm_table, engine, if_exists='append', index=False, chunksize=10000)


def insert_files_into_db(dir_, host, user, password, db):
    patient = dir_.rstrip("/").split("/")[-1]
    engine = create_engine("mysql://{}:{}@{}:3306/{}".format(user, password, host, db))
    metadata.create_all(engine, checkfirst=True)
    # non fused files first
    breath_meta_files = glob(os.path.join(dir_, "*breath_meta.csv"))
    do_breath_meta_and_solo(patient, breath_meta_files, engine)
    breath_meta_fused_files = glob(os.path.join(dir_, "*breath_meta_FUSED.csv"))
    do_breath_meta_and_solo(patient, breath_meta_fused_files, engine)


def main():
    parser = ArgumentParser()
    parser.add_argument("dir")
    parser.add_argument("-u", "--user", default="root")
    parser.add_argument("-p", "--password", required=True)
    parser.add_argument("--db", default="ventmap")
    parser.add_argument("--host", default="localhost")
    args = parser.parse_args()
    with open("db_complete.list", "r+a") as completed:
        completed_list = map(lambda x: x.strip("\n"), completed.readlines())
        if args.dir in completed_list:
            return
        insert_files_into_db(args.dir, args.host, args.user, args.password, args.db)
        completed.write(args.dir + "\n")


if __name__ == "__main__":
    main()
