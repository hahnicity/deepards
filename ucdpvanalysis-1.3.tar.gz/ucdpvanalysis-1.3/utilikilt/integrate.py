

def fast_integrate(series, dx):
    """
    40x faster than scipy simpsons rule. Just uses formula:

    dx * (1/2 * (y1 + yn) + sum_1^{n-1}(y_i))

    This loses precision in comparison to simps because no smoothing is
    actually performed on the function, but works well enough because
    our sampling rate is high (50 hz). Also the precision lost is usually on a
    hundredth or thousandth of a digit, so not a big deal at all.
    """
    first_last = (1.0 / 2) * (series[0] + series[-1])
    return dx * (first_last + sum(series[1:-1]))


def window_fast_update(previous, series, dx):
    """
    Given the previous result from fast_integrate, we can update a rolling window
    using the formula

    I_new = I_new - I_old + I_old = (dx / 2) * (y_n+1 + y_n - y_2 - y_1)

    :param previous: The previous sum
    :param series: The series, with new observation appended, old one left
    :param dx: the delta x
    """
    diff = (dx / 2) * (series[-1] + series[-2] - series[1] - series[0])
    return previous + diff
