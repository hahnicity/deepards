"""
Creates a stopwatch

2017-03-02 11:54:44

"""
import time
from pandas import Timedelta


class CreateStopwatch:
    def __init__(self):

        self.stopwatch = time.time()

    def lap(self, print_message):
        time_elapsed = time.time() - self.stopwatch

        message = " {}: {} elapsed".format(
            print_message,
            Timedelta(time_elapsed, unit='s'))
        # message = " {}: {} seconds".format(print_message, time_elapsed)
        self.stopwatch = time.time()
        return message