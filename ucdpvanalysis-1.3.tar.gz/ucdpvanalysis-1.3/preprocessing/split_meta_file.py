from argparse import ArgumentParser
import csv


def split_and_write(to_read, writer, days):
    lines = []
    for line in to_read:
        try:
            bs_time = float(line[2])
        except ValueError:
            lines.append(line)
            continue
        if bs_time > days * 60 * 60 * 24:
            break
        else:
            lines.append(line)
    writer.writerows(lines)


def main():
    parser = ArgumentParser()
    parser.add_argument('input_file')
    parser.add_argument('--output-file')
    parser.add_argument('--days', required=True, type=int)
    args = parser.parse_args()
    if not args.output_file:
        output_file = '{}-{}-day.csv'.format(args.input_file.rstrip(".csv"), args.days)
    elif args.output_file == args.input_file:
        raise Exception("output file cannot be the same file as the input!")
    else:
        output_file = args.output_file

    with open(args.input_file) as in_desc:
        reader = csv.reader(in_desc)
        with open(output_file, 'w') as out_desc:
            writer = csv.writer(out_desc)
            split_and_write(reader, writer, args.days)


if __name__ == '__main__':
    main()
