"""
stack_breath_files
~~~~~~~~~~~~~~~~~~

This post-processing script takes care of a problem that we might have with
processing a ton of different vent files through the annotation pipeline. We
don't necessarily want to only view 50 breaths in APL so this script will take
a desired number of vent files and then push them to a certain size
measured in number of breaths.

20161013--Add optional cut off point for time
"""
from argparse import ArgumentParser
import csv
from datetime import datetime, timedelta
import glob
import os
import re
from StringIO import StringIO
from warnings import warn

TS_INCREMENT = timedelta(seconds=0.02)
CUR_FILE_DATE_FORMAT = "%Y-%m-%d-%H-%M-%S"
OLD_FILE_DATE_FORMAT = "%Y-%m-%d__%H:%M:%S"
VENT_TS_FORMAT = "%Y-%m-%d-%H-%M-%S.%f"
FINAL_TS_FORMAT = "%Y-%m-%d %H:%M:%S.%f"


def get_input_files(input_dir):
    # Maybe a little overkill for a function?
    csv_files = glob.glob(os.path.join(input_dir, "*.csv"))
    return sorted(csv_files)


def get_input_files_by_days(input_dir, days):
    def get_dt(filename):
        try:
            return datetime.strptime(
                date_regex.search(filename).groups()[0], CUR_FILE_DATE_FORMAT
            )
        except:
            return datetime.strptime(
                date_regex.search(filename).groups()[0], OLD_FILE_DATE_FORMAT
            )

    files = get_input_files(input_dir)
    final = [files[0]]
    date_regex = re.compile(r"(20\d\d(?:-\d\d){2}(?:-|__)\d\d((?:-|:)\d\d){2})")
    start_dt = get_dt(files[0])
    for f in files[1:]:
        cur_dt = get_dt(f)
        if (cur_dt - start_dt).days >= days:
            return final
        else:
            final.append(f)
    return final


def finalize_data(input_files, output_file, cut_tail=0):
    for filename in input_files:
        vent_data = []
        with open(filename) as file_:
            # This ensures the script is only run with latest feed-forward TS.
            timestamp = file_.readline().rstrip("\n")
            try:
                ts = datetime.strptime(timestamp, VENT_TS_FORMAT)
            except ValueError:
                warn("Skip file {} because no timestamp is found at top of file".format(filename))
                continue
            stringio = StringIO()
            stringio.write(file_.read().replace("\x00", ""))
            stringio.seek(0)
            reader = csv.reader(stringio)
            was_be_in_breath = False
            # I need to know what monica does with breaths w/o BS and BE. For now
            # punt
            for row in reader:
                try:
                    row[0]
                except IndexError:  # XXX hackity hack
                    continue

                if "BS" in row[0] or "BE" in row[0]:
                    row[0] = " {}".format(row[0])
                    out_time = ts.strftime(FINAL_TS_FORMAT)
                    if cut_tail != 0:
                        out_time = out_time[:-cut_tail]
                    vent_data.append([out_time] + row)
                    continue
                ts = ts + TS_INCREMENT
                try:
                    out_time = ts.strftime(FINAL_TS_FORMAT)
                    if cut_tail != 0:
                         out_time = out_time[:-cut_tail]
                    vent_data.append([out_time, row[0], row[1]])
                except IndexError:  # XXX hackity hack
                    continue
        write_to_file(vent_data, output_file)


def write_to_file(vent_data, output_file):
    file = open(output_file, "a")
    writer = csv.writer(file)
    writer.writerows(vent_data)


def main():
    parser = ArgumentParser()
    parser.add_argument("input_dir", help="Path to directory for files we want to stack")
    parser.add_argument("--output-file", "-o", default="stacked_files", required=False)
    parser.add_argument("--cut_tail", "-x", default=0, type=int)
    parser.add_argument(
        "--days",
        type=int,
        help="Number of sequential days to stack for from start of PVI collection"
    )
    args = parser.parse_args()
    vent_data = []
    if args.days:
        input_files = get_input_files_by_days(args.input_dir, args.days)
    else:
        input_files = get_input_files(args.input_dir)
    output_file = "{}.csv".format(args.output_file)
    try:
        os.remove(output_file)
    except OSError:
        pass
    finalize_data(input_files, output_file, args.cut_tail)


if __name__ == "__main__":
    main()
