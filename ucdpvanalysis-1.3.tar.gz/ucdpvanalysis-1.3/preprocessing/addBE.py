"""
written 201606010??
adds BEs to a breath
"""


import os
from argparse import ArgumentParser
from algorithms.detection import detect_version_v2
from StringIO import StringIO
import csv


def printLog():
    pass
def add_relBN_and_ventBN(out_row,row,relBN,BScol):
    """adds breath number info to row"""

    relBN+=1
    out_row[0]=relBN
    try:
        ventBN = int(row[BScol+1].split(':')[1]) #extract vent BN,make an integer
        out_row[1]=ventBN

    except:
        out_row[4]='ERROR-missing ventBN'

    out_row[2]="BS"
    return out_row,relBN


#start of next function
def main(input_file,out_path,log_path=''):
    """
    Counts the number of BS and BEs in raw file
    """
    print "input_file: %s"%(input_file)
    print "====="*5
    if log_path=='':
        log_path=out_path.rstrip(".csv")
    #log_path=os.path.basename(out_path).rstrip(".csv")
    # log_path=r'201606052_BSBE/0086RPI1920151120_first6_concat'
    with open(input_file) as f:
        reader = csv.reader(f)
        row1 = next(reader)
    BScol,ncol,timestamp_1st_col,timestamp_1st_row=detect_version_v2(row1[0])

    #BScol,ncol,timestamp_1st_col,timestamp_1st_row=detect_version(input_file,log_path)

    BS_count=0
    BE_count=0
    lone_BE_before_first_whole_breath=False
    lone_BS_at_end=False
    relBN=0

    missingBS_count=0
    missingBE_count=0


    with open(input_file) as file_, open(out_path,'wb') as outC:
        csv_new_raw = csv.writer(outC, delimiter=',') #set up output csv

        #remove null bytes
        stringio = StringIO()
        stringio.write(file_.read().replace("\x00", ""))
        stringio.seek(0)
        reader = csv.reader(stringio) 
        # csv_new_raw.writerow(['relBN','ventBN','BS','BE','ERROR'])
        prev_row_BE=True
        for row_number,row in enumerate(reader):

            if row[BScol] in [' BS', 'BS']: #if BS row
                #check if missing BE (as in previous row wasn't outputted)
                if prev_row_BE==False:
                    missingBE_count+=1
                    csv_new_raw.writerow(["BE"])
                
                prev_row_BE=False
                csv_new_raw.writerow(row) #writes the BS 
            elif row[BScol] in [' BE','BE']: #if BE row
                prev_row_BE=True
                #check if first BE is before first BS
                if relBN==0:
                    lone_BE_before_first_whole_breath=True
                #after the first BE, see if BE is not followed by abs
                elif out_row[0]==[]:
                    missingBS_count+=1
                    # out_row[4]='ERROR-missing BS'
                    # out_row,relBN=add_relBN_and_ventBN(out_row,row,relBN,BScol)

                # elif out_row[0]==''    
                csv_new_raw.writerow(row)

            else: #if the values are in between
                csv_new_raw.writerow(row)

    #todo---add this to print log
        # print "number of breaths: %s"%(relBN)
        # print "missingBS_count: %s" %(missingBS_count)
        print "missingBE_count: %s"%(missingBE_count)
        # print "lone_BE_before_first_whole_breath: %s" %(lone_BE_before_first_whole_breath)
        # print "lone_BS_at_end: %s" %(lone_BS_at_end)
        # print "----"*5
    

if __name__=="__main__":
    # root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/20160516_sampling/study/20160607_2C_fullFiles_concat_FOR_TOR'
    # os.chdir(root_dir)

    # main(input_file=r'OLD_MICU_1_addBEto112/0112RPI1620160105-selected_first4_concat.csv',
    #     out_path=r'OLD_MICU_1_addBEto112/0112RPI1620160105-selected_first4_concat_addBE.csv',
    #     log_path='')
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("-waveform_csv", "-w", help="raw waveform file")
    parser.add_argument("-waveform2_csv", "-o", help="added BEs")
    args = parser.parse_args()

    main(input_file=args.waveform_csv, out_path=args.waveform2_csv)
