"""
remove_bs_be
~~~~~~~~~~~~

Does what it says: removes the bs and be from vent files only leaving the data
in the middle.
"""
import argparse
import csv
import os
import re

BS_BE_REGEX = re.compile(r" ?(BS|BE)")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("file")
    parser.add_argument("columns", type=int, choices=(2, 3))
    parser.add_argument("--outfile", help="The name (also path) of the output file")
    args = parser.parse_args()
    offset = args.columns - 2
    with open(args.file) as infile:
        outfile = args.outfile or "{}-no-bs-be.csv".format(os.path.splitext(args.file)[0])
        with open(outfile, "w") as outfile:
            infile_reader = csv.reader(infile)
            outfile_writer = csv.writer(outfile)
            for i in infile_reader:
                if not BS_BE_REGEX.search(i[offset]):
                    outfile_writer.writerow(i)


if __name__ == "__main__":
    main()
