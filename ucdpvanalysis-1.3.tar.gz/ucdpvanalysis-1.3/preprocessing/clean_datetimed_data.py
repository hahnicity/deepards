"""
preprocessing.clean_datetimed_data
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This module cleans all data we received in the era when we were attaching datetimes
to all collected files. However as a result we also ran into a bunch of race
conditions that corrupted our data. So this script is meant to fix all that, throw
out the breaths which are awful and keep the breaths which are good.
"""
from argparse import ArgumentParser
from datetime import datetime
from operator import itemgetter
import os
from StringIO import StringIO

from algorithms.detection import detect_version_v2

DT_FORMAT = "%Y-%m-%d %H:%M:%S.%f"
SECONDS_THRESHOLD = 0.1


def fix_bad_scaling(last, current):
    # Ensure -300 >= flow >= 300 and -100 >= pressure >= 100
    flow = float(current[1])
    pressure = float(current[2])
    if flow > 300 or flow < -300:
        return True
    if pressure > 100 or pressure < -100:
        return True
    return False


def fix_two_negatives(last, current):
    if float(current[1]) < 0 and float(current[2]) < 0:
        return True
    return False


def fix_moth_eaten_breaths(last, current):
    # XXX TODO
    return False


def fix_datetime_skips(last, current):
    # For some reason someone wanted to measure things in nanoseconds.
    # Check if we are doing this silliness and concatentate it if so.
    if len(current[0].split(".")[-1]) > 6:
        ms1 = current[0].split(".")[-1][:6]
        ms2 = last[0].split(".")[-1][:6]
        current_dt_str = ".".join(current[0].split(".")[:-1] + [ms1])
        last_dt_str = ".".join(last[0].split(".")[:-1] + [ms2])
    else:
        current_dt_str = current[0]
        last_dt_str = last[0]

    cur_dt = datetime.strptime(current_dt_str, DT_FORMAT)
    last_dt = datetime.strptime(last_dt_str, DT_FORMAT)
    delta = cur_dt - last_dt
    if delta.total_seconds() > SECONDS_THRESHOLD:
        return True
    return False


def fix_junk_numbers(last, current):
    try:
        float(current[1])
        float(current[2])
    except:
        return True
    return False


def fix_extra_columns(last, current):
    if len(current) > 3:
        return True
    return False


def fix_mess(funcs, text):
    def determine_to_cut(to_cut, lineno_in_breath, lineno_to_cut):
        if to_cut:
            lineno_to_cut.extend(lineno_in_breath)
        return False, []

    last = None
    bs_recorded = False
    be_recorded = True  # This is true because otherwise we would cut the first breath in file
    lines = text.split("\n")
    lineno_to_cut = []
    lineno_in_breath = []
    to_cut = False
    # See if there is a date timestamp at the top of the file.
    if len(lines[0].split(",")) > 2:
        x = 0
    else:
        x = 1

    for idx, line in enumerate(lines[x:]):
        split_data = line.split(",")

        # If we don't have 2 cols we can't do anything
        if len(split_data) < 2:
            to_cut = True
            lineno_in_breath.append(idx + x)
            continue

        if split_data[1].strip() == "BE":
            lineno_in_breath.append(idx + x)
            if not bs_recorded:
                to_cut = True
            to_cut, lineno_in_breath = determine_to_cut(to_cut, lineno_in_breath, lineno_to_cut)
            be_recorded = True
            bs_recorded = False
            last = split_data
            continue

        if split_data[1].strip() == "BS":
            if not be_recorded:
                to_cut = True
            to_cut, lineno_in_breath = determine_to_cut(to_cut, lineno_in_breath, lineno_to_cut)
            lineno_in_breath.append(idx + x)
            be_recorded = False
            bs_recorded = True
            last = split_data
            continue

        lineno_in_breath.append(idx + x)
        # Don't bother analyzing if we want to cut if we already do.
        if to_cut:
            last = split_data
            continue

        for func in funcs:
            try:
                if func(last, split_data):
                    to_cut = True
                    break
            except Exception as err:
                to_cut = True
                break
        last = split_data

    # Final determination of lineno_to_cut and clean up any remaining breath
    # lines
    if lineno_in_breath:
        to_cut = True
    determine_to_cut(to_cut, lineno_in_breath, lineno_to_cut)

    # Create new text from old.
    lineno_to_keep = sorted(
        list(set(range(len(lines))).difference(set(lineno_to_cut)))
    )
    # If the file is total garbage then don't use it.
    if not lineno_to_keep:
        return ""
    return "\n".join(list(itemgetter(*lineno_to_keep)(lines)))


def clean_datetimed_data(input_file, stringio_input):
    if input_file:
        old = open(input_file)
    elif stringio_input:
        old = stringio_input
    else:
        raise Exception("Input either a file path or a StringIO object for reading!")

    _, _, ts_1st_col, _ = detect_version_v2(old.readline())
    old.seek(0)
    if not ts_1st_col:  # Do nothing
        s = StringIO(old.read())
        old.close()
        return s

    funcs = [
        fix_datetime_skips,
        fix_moth_eaten_breaths,
        fix_extra_columns,
        fix_junk_numbers,
        fix_two_negatives,
        fix_bad_scaling,
    ]
    old_text = old.read().strip("\n")
    text = fix_mess(funcs, old_text)
    old.close()
    return StringIO(text)


def main():
    parser = ArgumentParser()
    parser.add_argument("input_file", help="rel path to input file")
    args = parser.parse_args()
    stringio = clean_datetimed_data(args.input_file, None)
    with open("{}-cleaned.csv".format(os.path.splitext(args.input_file)[0]), "w") as new:
        new.write(stringio.read())


if __name__ == "__main__":
    main()
