"""
# new aggregate files
(vs. concatenation--which just cuts and paste together)
created 201600605

similar to stack_breath_files but works with multi-file types

Only keeps the timestamp of the first file
-vs. stack_breath_files.py: puts a timestamp in front of each row
Combining 3 files (4.5mb each)---
- agg: 14.5mb
- stack: 44.5mb

original devscript=20160605_run_aggregate breaths
20161013-run from command line
"""
import os
from analysis.algorithms.TOR3 import detect_version
import glob
import csv
from StringIO import StringIO
from argparse import ArgumentParser


def remove_null_inplace(file_):
    "remove null bytes in buffer"
    # clears null bites
    stringio = StringIO()
    stringio.write(file_.read().replace("\x00", ""))
    stringio.seek(0)

    return stringio


def main(input_subdir, output_subdir='', output_name=''):
    """
    stack bunches of raw files


    Versions:
    --------
    20160505 V1.0-Written as function
    20160605 V1.2-Move remove_null_inplace to separate function

    Example:
    -------
    root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/20160516_sampling/pilot0604/'
    os.chdir(root_dir)

    #example without specific out_name
    main(input_subdir='20160604_downloaded_fullFiles/0083RPI1120151120-selected',
        output_subdir=r'20160604_fullFiles_concat_test',
        output_name='')
    """
# begin function
    if output_name == '':
        output_name = os.path.basename(input_subdir) + "_concat.csv"

    concat_path = os.path.join(output_subdir, output_name)

    print output_name

    # for root,dirs,files in os.walk(input_subdir):
    all_file_paths = glob.glob(os.path.join(input_subdir, "*.csv"))
    with open(concat_path, 'wb') as outC:
        csv_concat = csv.writer(outC, delimiter=',')

        for file_number, file_path in enumerate(all_file_paths):

            print file_path
            # logfilepath=file_path.rstrip(".csv")+".txt"
            BScol, ncol, timestamp_1st_col, timestamp_1st_row = detect_version(
                file_path, concat_path)
            if timestamp_1st_row:
                print "V3"
            if timestamp_1st_row is False and timestamp_1st_col is False:
                print "V1"
            with open(file_path) as file_:

                # remove null bytes
                stringio = remove_null_inplace(file_)
                reader = csv.reader(stringio)

                for row_number, row in enumerate(reader):
                    # if first row in file
                    if row_number == 0:
                        # copy first row if V1 or v2
                        if timestamp_1st_row is False:
                            csv_concat.writerow(row)
                        else:
                            # only copy first timestamp if v3 and first file
                            if file_number == 0:
                                csv_concat.writerow(row)
                    # all other rows besides first row==copy
                    else:
                        csv_concat.writerow(row)

            # TODO
                # combine with smart_truncate for more control over BS, BEs etc.
    # TODO for detect_version
    # include output path for the logfile
    # include change so that lines aren't generated


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("input_dir", help="Input directory")
    parser.add_argument("output_dir", help="Output directory")
    parser.add_argument("-csv_name", "-c", default="", help="output CSV Name")

    args = parser.parse_args()
    main(args.input_dir, args.output_dir, args.csv_name)
