"""
processes manual derivations etc

"""
from __future__ import division
import pandas as pd
import os
import numpy as np
from sbt.constants import ANON_ID_NAME
import math

# bm_dir = r'/Users/monica/Box Sync/UCD/sandbox2017/1_winter/20170113_sbt/20170303_vis/breath_meta/20170303_pilot5'
# manual_data = r'/Users/monica/Box Sync/UCD/sandbox2017/1_winter/20170113_sbt/20170303_for_first_draft_submission/20170303_data_manual_input.csv
#ANON_ID_NAME = 'PATIENT_RPI_ID'


def find_correct_time_stamp(df, bm_dir):
    """

    2017-03-04: originally developed in 20170304_get_correct_times_manual_dev.py
    2017-03-07: can work with folder of direct csv or patient subdirectories
    ex.
    df = pd.read_csv(manual_data, header=[0,1])
    find_correct_time_stamp(df, bm_dir)
    """

    names_df = df['name'].copy()
    starts_df = df['start'].copy()
    starts_df['file'] = starts_df['file'].str.replace('.csv', '_breath_meta.csv')
    ends_df = df['end'].copy()
    ends_df['file'] = ends_df['file'].str.replace('.csv', '_breath_meta.csv')

    starts_df['relBN'] = starts_df['bn']
    ends_df['relBN'] = ends_df['bn']

    new_starts_df = pd.DataFrame(np.nan, index=names_df.index, columns=['relBN', 'ventBN', 'rel_time_at_BS', 'abs_time_at_BS'])
    new_ends_df = pd.DataFrame(np.nan, index=names_df.index, columns=['relBN', 'ventBN', 'rel_time_at_BS', 'abs_time_at_BS'])
    for idx in names_df.index:
        name = names_df.loc[idx, 'patient']
        file_name1 = starts_df.loc[idx, 'file']
        file_name2 = ends_df.loc[idx, 'file']

        if os.path.isfile(os.path.join(bm_dir, file_name1)):
            file_path1 = os.path.join(bm_dir, file_name1)
            file_path2 = os.path.join(bm_dir, file_name1)
        else:
            file_path1 = os.path.join(bm_dir, name, file_name1)
            file_path2 = os.path.join(bm_dir, name, file_name2)


        if os.path.isfile(file_path1):
            temp_df = pd.read_csv(file_path1, index_col=0, header=0)
            written_bn = starts_df.loc[idx, 'bn']
            written_tve = starts_df.loc[idx, 'tve']
            bm_tve = temp_df.loc[temp_df['BN'] == written_bn, 'tve']
            if round(abs(bm_tve)) == round(abs(written_tve)):
                list_ = temp_df.loc[temp_df['BN'] == written_bn, ['BN', 'ventBN', 'rel_time_at_BS', 'abs_time_at_BS']].values
                new_starts_df.loc[idx, :] = list_[0]


            if file_name1 != file_name2:  # this is purely for saving load time
                temp_df = pd.read_csv(file_path2, index_col=0, header=0)

            written_bn = ends_df.loc[idx, 'bn']
            written_tve = ends_df.loc[idx, 'tve']
            bm_tve = temp_df.loc[temp_df['BN'] == written_bn, 'tve']

            if int(abs(bm_tve)) == int(abs(written_tve)):
                list_ = temp_df.loc[temp_df['BN'] == written_bn, ['BN', 'ventBN', 'rel_time_at_BS', 'abs_time_at_BS']].values
                new_ends_df.loc[idx, :] = list_[0]

            # print name, file_path1, file_path2
        else:
            print name, "didn't find: {}".format(file_path1)

    return pd.concat([names_df, new_starts_df, new_ends_df], axis=1, keys=['names', 'start', 'end'])


def get_first_sbt_interval_and_sbi_values(sbi_df, sbt_dur_bounds):
    """
    gets first sbt interval and values

    2017-03-04: originally written in 20170304_2_compare_intervals_and_sbi_dev.ipynb

    ex:
        sbt_from_sbi_data = get_first_sbt_interval_and_sbi_values(sbi_df, SBT_DUR_BOUNDS)
    """
    sbi_df2 = sbi_df.set_index(ANON_ID_NAME)
    sbi_df2['RECORDED_TIME'] = pd.to_datetime(sbi_df2['RECORDED_TIME'])

    sbi_patient_list = sbi_df[ANON_ID_NAME].unique()
    sbi_patient_list.sort()
    first_two_sbt_df = pd.DataFrame(
        np.nan,
        index=sbi_patient_list,
        columns=['start_ts', 'start_sbi', 'end_ts', 'end_sbi'])
    for patient in sbi_patient_list:
        time_stamps = sbi_df2.loc[patient, 'RECORDED_TIME']
        if type(time_stamps) == pd.tslib.Timestamp:
            first_two_sbt_df.loc[patient, 'start_ts'] = time_stamps
            first_two_sbt_df.loc[patient, 'start_sbi'] = sbi_df2.loc[patient, 'MEAS_VALUE']

        else:
            time_diff_first_two = pd.to_timedelta(time_stamps[1] - time_stamps[0])

            rule1 = time_diff_first_two > sbt_dur_bounds['likely_lower']
            rule2 = time_diff_first_two < sbt_dur_bounds['likely_upper']

            if rule1 and rule2:
                sbi_values = sbi_df2.loc[patient, 'MEAS_VALUE']
                first_two_sbt_df.loc[patient, ['start_ts', 'end_ts']] = [time_stamps[0], time_stamps[1]]
                first_two_sbt_df.loc[patient, ['start_sbi', 'end_sbi']] = [sbi_values[0], sbi_values[1]]
    return first_two_sbt_df


def calculate_durations(compared):
    """
    calculates durations from start and stop times

    2017-03-04: originally written in 20170304_2_compare_intervals_and_sbi_dev.ipynb

    ex:
        compared = pd.concat([manual_interval_df, pilot_sbt_from_sbi_data.loc[:,['start','end']]], axis=1, keys=['manual','ehr'])
        calculate_durations(compared)
    """
    for i in compared.columns:
        compared.loc[:, i] = pd.to_datetime(compared.loc[:, i])

    for version in compared.columns.get_level_values(0).unique():
        # compared.loc[(version, 'dur')] = np.nan
        duration = compared.loc[:, (version, 'end')] - compared.loc[:, (version, 'start')]
        compared.loc[:, (version, 'dur')] = duration
#         if duration >= pd.to_timedelta(0):
#             compared.loc[:, (version, 'dur')] = duration


def calculate_time_overlap(compared, v1, v2):
    """
    calculates time overlap for two methods

    2017-03-04: originally written in 20170304_2_compare_intervals_and_sbi_dev.ipynb

    ex:
        compared = pd.concat([manual_interval_df, pilot_sbt_from_sbi_data.loc[:,['start','end']]], axis=1, keys=['manual','ehr'])
        calculate_durations(compared)
        # compared = pd.concat([manual_interval_df, pilot_sbt_from_sbi_data.loc[:,['start','end']]], axis=1, keys=['manual','ehr'])
        calculate_time_overlap(compared, 'manual','ehr')
    """
    new_col = '{}_v_{}'.format(v1, v2)
    compared.loc[:, (new_col, 'time_overlap')] = np.nan

    for idx in compared.index:
        v1_start = compared.loc[idx, (v1, 'start')]
        v2_start = compared.loc[idx, (v2, 'start')]
        v1_end = compared.loc[idx, (v1, 'end')]
        v2_end = compared.loc[idx, (v2, 'end')]

        v1_starts_earlier = v1_start < v2_start
        # v1_starts_earlier = v1_start - v2_start < np.timedelta64(0, 'm')
        # if v1 starts earlier
        if v1_starts_earlier:
            if v2_start < v1_end:  # v2 starts within v1 interval
                overlap = v1_end - v2_start
            elif v2_start > v1_end:  # v2 starts later than v1 end
                overlap = pd.to_timedelta(0)
            else:
                overlap = v1_end - v2_start
            denominator = v2_end - v1_start
        # if v2 starts earlier
        else:  # if v2_starts_earlier = v1_start > v2_start:
            if v1_start < v2_end:  # v1 starts within v2 interval
                overlap = v2_end - v1_start
            elif v1_start > v2_end:  # v1 starts later than v2 end
                overlap = pd.to_timedelta(0)
            else:
                overlap = v2_end - v1_start
            denominator = v1_end - v2_start

        compared.loc[idx, (new_col, 'time_overlap')] = overlap
        avg_length = (compared.loc[idx, (v1, 'dur')] + compared.loc[idx, (v2, 'dur')]) * 0.5
        compared.loc[idx, (new_col, 'avg_length')] = avg_length
        compared.loc[idx, (new_col, 'overlap_normalized')] = overlap / avg_length
        compared.loc[idx, (new_col, 'denom2')] = denominator
        compared.loc[idx, (new_col, 'overlap_normalized2')] = overlap / denominator

    # compared.loc[:, (new_col,'avg_length')] = (compared.loc[:,(v1,'dur')] + compared.loc[:,(v2,'dur')])*0.5
    # compared.loc[:, (new_col,'overlap_normalized')] = (compared.loc[:, (new_col,'time_overlap')]) /(compared.loc[:, (new_col,'avg_length')])
    # compared.loc[:, (new_col,'overlap_normalized')] = compared

def calc_ci(o1):
    """
    2017-03-07: originally written 20170307_compare_and_extractRSBI
    """
    LB = o1['mean'] - 1.96*((o1['std'])/math.sqrt(o1['count']))
    UB = o1['mean'] + 1.96*((o1['std'])/math.sqrt(o1['count']))
    return LB, UB

def compare_three_setup_table(manual_correct_times, pilot_sbt_from_sbi_data, detected):
    """
    moved from 20170308_sbt_alg.ipynb
    2017-03-09
    """
    manual_values = manual_correct_times.loc[:,[('start','abs_time_at_BS'),('end','abs_time_at_BS')]].values
    manual_interval_df = pd.DataFrame(manual_values, columns=['start','end'], 
                                      index=manual_correct_times.loc[:,('names','patient')].values)
    pilot_sbt_from_sbi_data.columns = ['start','start_sbi', 'end', 'end_sbi']
    detected_values = detected.loc[:,[('start','abs_time'),('end','abs_time')]].values
    detected_interval_df = pd.DataFrame(detected_values, columns=['start','end'],
                                        index=detected.index.get_level_values(0))
    compared = pd.concat([manual_interval_df, pilot_sbt_from_sbi_data.loc[:,['start','end']], 
                          detected_interval_df], axis=1, keys=['manual','ehr', 'waveform'])
    calculate_durations(compared)
    calculate_time_overlap(compared, 'waveform','ehr')
    calculate_time_overlap(compared, 'waveform','manual')
    calculate_time_overlap(compared, 'manual','ehr')
    return compared 

def get_ci_and_mean(compared, name, overlap):
    """
    2017-03-09: originally written in 20170308_sbt_alg.ipynb
    """
    out = compared[(name,overlap)].describe()
    mean = out['mean']
    ci_lb, ci_ub = calc_ci(out)
    return [name, mean, ci_lb, ci_ub ]

def get_ci_and_mean_from_overlap(overlap_table, statistic):
    out = overlap_table[statistic].describe()
    mean = out['mean']
    ci_lb, ci_ub = calc_ci(out)
    return [statistic, mean, ci_lb, ci_ub]

def compare_three_calc_ci_s(compared):
    """
    2017-03-08: originallyw ritten in 20170308_sbt_alg.ipynb
    """
    o1 = compared[('waveform_v_ehr', 'overlap_normalized')].describe()
    # print o1
    # print calc_ci(o1)

    o2 = compared[('waveform_v_ehr', 'overlap_normalized2')].describe()
    print calc_ci(o2)
    # print o2
    print pd.concat([o1, o2], axis=1)
    print '\n'

    o1 = compared[('waveform_v_manual', 'overlap_normalized')].describe()
    # print o1
    # print calc_ci(o1)
    o2 = compared[('waveform_v_manual', 'overlap_normalized2')].describe()
    # print calc_ci(o2)
    # print o2
    print pd.concat([o1, o2], axis=1)
    print '\n'

    o1 = compared[('manual_v_ehr', 'overlap_normalized')].describe()
    # print o1
    print calc_ci(o1)
    o2 = compared[('manual_v_ehr', 'overlap_normalized2')].describe()
    # print calc_ci(o2)
    # print o2
    print pd.concat([o1, o2], axis=1)
    print '\n'

    list1 = get_ci_and_mean(compared, 'waveform_v_ehr', 'overlap_normalized')
    list2 = get_ci_and_mean(compared, 'waveform_v_manual', 'overlap_normalized')
    list3 = get_ci_and_mean(compared, 'manual_v_ehr', 'overlap_normalized')
    ci_df = pd.DataFrame([list1, list2, list3], columns=['name', 'mean', 'LL', 'UL'])
    print ci_df

    list1 = get_ci_and_mean(compared, 'waveform_v_ehr', 'overlap_normalized2')
    list2 = get_ci_and_mean(compared, 'waveform_v_manual', 'overlap_normalized2')
    list3 = get_ci_and_mean(compared, 'manual_v_ehr', 'overlap_normalized2')
    ci_df2 = pd.DataFrame([list1, list2, list3], columns=['name', 'mean', 'LL', 'UL'])
    print ci_df2
    return ci_df, ci_df2


def get_first_detected(detected):
    """
    ex:
        detected2 = detected.copy()
        get_first_detected(detected2) 
    """
    # detected2 = detected.copy()
    for idx, patient in enumerate(detected.index.get_level_values(0).unique()):
        # print idx, patient
        #detected2.loc[patient].drop()
        if len(detected.loc[patient]) > 1:
                for drop_file in detected.loc[patient].index[1:].unique():
                    detected.drop((patient,drop_file), inplace=True)


def prep_det_for_comparison(df):
    """
    rearranges detected df and keeps the first detected region
    """

    # detected = get_df_within_time_threshold(df, sbt_dur_bounds)
    detected = df
    detected = detected.drop([('other', 'bn_length'), ('other', 'region_number')], axis=1)
    detected[('other', 'region_number')] = detected.index.get_level_values(2)
    detected.index = detected.index.droplevel(level=2)
    # detected = detected.drop([('0282RPI1620160719', 'file3')], axis=0)

    detected[('other', 'filenumber')] = detected.index.get_level_values(1)
    detected2 = detected.copy()
    get_first_detected(detected2)
    detected2.index = detected2.index.droplevel(level=1)
    return detected2


def get_compared_table(det_df, manual_df, ehr_df):
    """
    moved to pps
    
    2017-03-09: originally written in 20170309_new_overlap_statistic.ipynb
    ex:
        det_df = prep_det_for_comparison(detected, SBT_DUR_BOUNDS)
        manual_df = manual_correct_times.copy()
        ehr_df = pilot_sbt_from_sbi_data.copy()

        compared = get_compared_table(det_df, manual_df, ehr_df)
    """
    det_times_df = det_df.loc[:, [('start','abs_time'),('end','abs_time')]]
    det_times_df.columns = det_times_df.columns.droplevel(1)

    manual_df = manual_df.set_index(('names','patient'))
    manual_df = manual_df.rename(columns={'abs_time_at_BS':'abs_time'})
    manual_times_df = manual_df.loc[:, [('start','abs_time'),('end','abs_time')]]
    manual_times_df.columns = manual_times_df.columns.droplevel(1)

    ehr_df = ehr_df.rename(columns={'start_ts':'start', 'end_ts':'end'})
    ehr_times_df = ehr_df.loc[:, ['start','end']]
    compared = pd.concat({'manual':manual_times_df, 'alg': det_times_df, 'ehr':ehr_times_df},axis=1)
    return compared



def get_overlap_fp_fn(v1_start, v1_end, v2_start, v2_end):
    """
    originally written: 20170309_new_overlap_statistic
    """

    delta0 = pd.to_timedelta(0)
    intersect_message = ''


    if v2_start < v1_start:  # v2 startst earlier
        # intersect_message = 'v2 starts earlier'

        if v2_end <= v1_start:
            intersect_message = '  v2 does not overlap'
            overlap = delta0
            fp = v2_end - v2_start
            fn = v1_end - v1_start
            intersect_message = 'r2 occurs completely before r1'

        elif v2_end < v1_end:
            intersect_message = '  v2 intersect'
            overlap = v2_end - v1_start
            fp = v1_start - v2_start
            fn = v1_end - v2_end
            assert (fn + fp + overlap) == (v1_end - v2_start)

        elif v2_end == v1_end:
            intersect_message = '  v1 and 2 end same'
            overlap = v2_end - v1_start
            fp = v1_start - v2_start
            fn = v1_end - v2_end
            assert (fn + fp + overlap) == (v1_end - v2_start)


        elif v2_end > v1_end:
            intersect_message = '  v2 encapsules v1'
            overlap = v1_end - v1_start
            fn = delta0
            fp = (v2_end - v1_end) + (v1_start - v2_start) #(v2_end - v1_end) - overlap
            assert (overlap + fn + fp) == (v2_end - v2_start)

        else:
            intersect_message = '  an end1  is empty'
            overlap = 0
            fp = v2_end - v2_start
            fn = v1_end - v1_start 
            intersect_message = '<= an end1  is empty'

    elif v2_start == v1_start:
        # intersect_message = 'v2 starts same'

        if v2_end < v1_end:
            intersect_message = '  v2 kind of within v1'
            overlap = v2_end - v2_start
            fn = v1_end - v2_end
            fp = delta0
            assert fn + overlap == (v1_end - v2_start)

        elif v2_end  == v1_end:
            intersect_message = 'v1 & v2 are same'
            overlap = v1_end - v2_start
            fn = delta0
            fp = delta0
            assert overlap == (v2_end - v2_start)

        elif v2_end > v1_end:
            intersect_message = '  v2 kind of encapsulates v1'
            overlap = v1_end - v2_start
            fp = v2_end - v1_end
            fn = delta0

            assert (fn + fp + overlap) == (v2_end - v1_start)

        else:
            intersect_message = '  an end2 is empty'
            overlap = delta0
            fp = v2_end - v2_start
            fn = v1_end - v1_start
            intersect_message = '<= an end2 is empty'

    elif v2_start > v1_start: # v2 later
        # intersect_message = 'v2 later'
        if v2_start > v1_start:
            intersect_message = '  v2 does not overlap'
            overlap = delta0
            fp = v2_end - v2_start
            fn = v1_end - v1_start
            intersect_message= 'r2 occurs completely after r1'

        elif v2_end < v1_end:
            intersect_message = '  v1 encapsulates v2'
            overlap = v2_end - v2_start
            fn = (v2_start - v1_start) + (v1_end - v2_end) #(v1_end - v1_start) - overlap
            fp = delta0
            assert (fn + fp + overlap) == (v1_end - v1_start)
        elif v2_end == v1_end:
            intersect_message = '  v2 kind of encapsulated by v1'
            overlap = v1_end - v2_start
            fn = v2_start - v1_start
            fp = delta0
            assert (fn + fp + overlap) == (v1_end - v1_start)        
        elif v2_end > v1_end:
            intersect_message = 'v1 and 2 intersect'
            overlap = v1_end - v2_start
            fn = v2_start - v1_end
            fp = v2_end - v1_end
            assert (overlap + fn + fp) == (v2_end - v1_start)
        else:
            intersect_message = '  one is empty'
            overlap = delta0
            fp = v2_end - v2_start
            fn = v1_end - v1_start   
    else:
       # intersect_message = 'one is empty'
        overlap = delta0
        fp = v2_end - v2_start
        fn = v1_end - v1_start
        intersect_message = '<= one is empty'
        
    return overlap, fp, fn, intersect_message


def calc_overlap_table(compared, gs, comparator):
    """
    moved to pps
    originally written: 20170309_new_overlap_statistic
    """
    v1 = gs
    v2 = comparator
    patient = compared.index[8]
    overlap_table = pd.DataFrame(np.nan, index=compared.index, 
                                 columns=['time_overlap', 'fn', 'fp', 'sensitivity', 'fpm_delta'])

    for patient in compared.index:
        v1_start = pd.to_datetime(compared.loc[patient, (v1, 'start')])
        v1_end = pd.to_datetime(compared.loc[patient, (v1, 'end')])
        v2_start = pd.to_datetime(compared.loc[patient, (v2, 'start')])
        v2_end = pd.to_datetime(compared.loc[patient, (v2, 'end')])

        overlap, fp, fn, intersect_message = get_overlap_fp_fn(v1_start, v1_end, v2_start, v2_end)
        overlap_table.loc[patient, 'time_overlap'] = overlap
        overlap_table.loc[patient, 'fn'] = fn
        #print patient
    #     if patient == '0135RPI1420160203':
    #         import pdb
    #         pdb.set_trace()
        overlap_table.loc[patient, 'sensitivity'] = (overlap) / (fn + overlap)
        overlap_table.loc[patient, 'fp'] = fp
        overlap_table.loc[patient, 'fpm_delta'] = fp
        overlap_table.loc[patient, 'message'] = intersect_message

        # print (v1_start, v1_end)
        # print (v2_start, v2_end)
        # print 'o : ', overlap
        # print 'fn: ', fn
        # print 'fp: ', fp
    overlap_table['fpm'] = overlap_table['fpm_delta'] / np.timedelta64(1, 'm')
    return overlap_table

def get_univar_and_mean_ci(compared, gs, comparator):
    """
    moved to pps
    
    2017-03-09: 20170309_new_overlap_statistic.ipynb
    """
    t1 = calc_overlap_table(compared, gs, comparator)
    out1a = t1['sensitivity'].describe()
    out1b = t1['fpm'].describe().round(2)


    se1 = get_ci_and_mean_from_overlap(t1, 'sensitivity')
    fpm1 = get_ci_and_mean_from_overlap(t1, 'fpm')
    results = pd.DataFrame([se1, fpm1])
    univar = pd.concat([out1a, out1b], axis=1, keys=['se', 'fpm'])
    
    return t1, univar, results

def get_df_within_time_threshold(df, sbt_dur_bounds):
    """
    subsets and returns a new data frame

    moved to pps
    2017-03-09?: 20170309_new_overlap_statistic.ipynb
    """
    mask1 = df[('other', 'dur_ts')] > sbt_dur_bounds['likely_lower']
    mask2 = df[('other', 'dur_ts')] < sbt_dur_bounds['likely_upper']

    new_df = df.loc[(mask1) & (mask2), :]
    return new_df
    
def get_df_within_time_threshold_by_time(df, lower, upper):
    """
    2017-03-09?: 20170309_new_overlap_statistic.ipynb?
    """
    mask1 = df[('other','dur_ts')] > lower
    mask2 = df[('other','dur_ts')] < upper
    
    new_df = df.loc[(mask1)&(mask2), :]
    return new_df
