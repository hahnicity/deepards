"""
Created on 2017-05-02 19:14:04
works with sbt_all_o2dev_phases_20161014.csv
"""

import numpy as np



def calc_delta_from_first_phase(df, ANON_ID_NAME):
    """
    calculate elapsed time from first phase start (2017-02-20)
    2017-05-02: moved from determine_sbt_time_from_all_o2_devices.py
    """
    pt_index = df[ANON_ID_NAME].unique()
    for i in pt_index:
        # print i
        # sub_df = df.loc[i]
        sub_df = df.loc[df[ANON_ID_NAME] == i, :].copy()
        initial_index = sub_df['PHASE_START_datetime'].index[0]
        initial_ts = sub_df['PHASE_START_datetime'][initial_index]
        # import pdb
        # pdb.set_trace()
        delta1 = sub_df['PHASE_START_datetime'].apply(lambda x: x - initial_ts)
        sub_df.loc[:, 'PHASE_START_rel_time'] = delta1
        delta2 = sub_df['PHASE_END_datetime'].apply(lambda x: x - initial_ts)
        sub_df.loc[:, 'PHASE_END_rel_time'] = delta2
        df.loc[df[ANON_ID_NAME] == i, :] = sub_df
    return df



def has_trach(row):
    """check if row has string 'trach' in it column (2017-02-20)
    2017-05-02: moved from determine_sbt_time_from_all_o2_devices.py
    """
    if row.isnull().O2_DEV_CLEANED:  # skip na values
        val = 0
    elif 'trach' in row.O2_DEV_CLEANED:
            val = 1
    else:
        val = 0
    return val

def has_corrupted_data(row):
    """if patient number is in [25,80](2017-02-21)
    2017-05-02: moved from determine_sbt_time_from_all_o2_devices.py
    """

    if row['patient_number'] >= 25 and row['patient_number'] <= 80:
        val = 1
    else:
        val = 0
    return val

def has_timestamped_data(row):
    """if patient number is in >80 (2017-02-21)
    2017-05-02: moved from determine_sbt_time_from_all_o2_devices.py
    """

    if row['patient_number'] > 80:
        val = 1
    else:
        val = 0
    return val





def simplify_O2_dev_names(row):
    """
    v1: written 2017-02-21 12:11:53
    v2: reordered based on severity (2017-02-23 18:37:07 d)

    """
    name = row.O2_DEV_CLEANED
    if row.isnull().O2_DEV_CLEANED:
        return np.nan

    # separate other categories
    elif 'trach' in name:  # put before venturi b/c "venturi;bipap"
        return 'trach'

#     elif 'bag valve' in name:
#         return 'bag valve'
    elif 'bag valve OETT' in name:
        return 'bag valve OETT'
    elif 'bag valve mask' in name:
        return 'bag valve mask'

    elif name == 'oxygen tent':
        return name
    elif name == 'oxygen hood':
        return name

    # note ---earlier ones = stronger mode of MV
    elif name == 'ventilator' or name == 'mechanical ventilator':
        return 'mechanical ventilator'
    elif 'ventilator' in name:
        return 'mechanical ventilator'
    elif 'mechanical ventilator' in name:
        return 'mechanical ventilator'

    elif name == 'CPAP':
        return 'CPAP ambiguous'
    # note, can't just do CPAP search because may get CPAP; other mode
    # which would not be confirmed CPAP
    elif 'CPAP' in name and 'nasal' in name:
        return 'CPAP confirmed'
    elif 'CPAP' in name and 'face':
        return 'CPAP confirmed'

    elif name == 'BIPAP':
        return name
    elif 'BIPAP' in name:
        return 'BIPAP'

    elif name == 'high-flow nasal cannula':
        return name
    elif 'high-flow nasal cannula' in name:
        return 'high-flow nasal cannula'

    elif name == 'nonrebreather mask':
        return name
    elif 'nonrebreather mask' in name:
        return 'nonrebreather mask'

    elif name == 'Venturi mask':
        return name
    elif 'Venturi mask'in name:
        return 'Venturi mask'

    elif name == 'partial rebreather mask':
        return name
    elif 'partial rebreather mask' in name:
        return 'partial rebreather mask'

    elif name == 'simple face mask':
        return name
    elif 'simple face mask' in name:
        return 'simple face mask'

    elif name == 'aerosol mask':
        return name
    elif 'aerosol mask' in name:
        return 'aerosol mask'

    elif name == 'face tent':
        return name
    elif name == 'mist tent':
        return name
    elif name == 'open oxygen mask':
        return name

    elif name == 'nasal cannula' or name == 'nasal cannula with humidification':
        return 'nasal cannula'
    elif name == 'nasal cannula with reservoir (i.e. oximizer)':
        return 'nasal cannula'
    elif 'nasal cannula' in name:
        return 'nasal cannula'

    elif name == 'room air':
        return name
    if 'room air' in name:
        return 'room air'

    elif name == 'T- piece':
        return 'T- piece ambiguous'
    elif 'T- piece' in name:
        return 'T-piece ambiguous'
    elif name == 'blow by':
        return 'blow by ambiguous'
    elif name == 'other (see comments)':
        return name

    else:
        return ''


def simplify_O2_dev_names_by_dict_df(row, oxygen_device_dict):
    """
    attempt at more elegant name simplification

    v1: (2017-02-24 17:24:12)
    """
    name = row.O2_DEV_CLEANED
    if row.isnull().O2_DEV_CLEANED:
        return np.nan
    elif name in oxygen_device_dict:
        return oxygen_device_dict[name]
    elif name.split(';')>1:
#         import pdb
#         pdb.set_trace()
#         this is where additional work should go
        pass
    else:
        return ''
