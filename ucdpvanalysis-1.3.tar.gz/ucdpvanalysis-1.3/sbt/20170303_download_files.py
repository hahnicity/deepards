"""
2017-03-03 13:13:06
"""

import paramiko

hostname = '152.79.84.175'
username = 'grehm'
password ='K3njimasuda'

mySSHK = r'/Users/monica/.ssh/id_rsa.pub'
sshcon   = paramiko.SSHClient()  # will create the object
sshcon.set_missing_host_key_policy(paramiko.AutoAddPolicy())# no known_hosts error
sshcon.connect(hostname, username=username, password=password, key_filename=mySSHK) # no passwd needed
#http://stackoverflow.com/questions/8382847/how-to-ssh-connect-through-python-paramiko-with-public-key
# http://jessenoller.com/2009/02/05/ssh-programming-with-paramiko-completely-different/
# https://www.blog.pythonlibrary.org/2012/10/26/python-101-how-to-move-files-between-servers/
#ftp = sshcon.open_sftp()

# class SSHConnection(object):

#     # ----------------------------------------------------------------------
#     def __init__(self, host, username, password, port=22):
#         """Initialize and setup connection"""
#         self.sftp = None
#         self.sftp_open = False
 
#         # open SSH Transport stream
#         self.transport = paramiko.Transport((host, port))

#         self.transport.connect(username=username, password=password)

#     # ----------------------------------------------------------------------
#     def _openSFTPConnection(self):
#         """
#         Opens an SFTP connection if not already open
#         """
#         if not self.sftp_open:
#             self.sftp = paramiko.SFTPClient.from_transport(self.transport)
#             self.sftp_open = True

#     # ----------------------------------------------------------------------
#     def get(self, remote_path, local_path=None):
#         """
#         Copies a file from the remote host to the local host.
#         """
#         self._openSFTPConnection()  
#         self.sftp.get(remote_path, local_path)

#     # ----------------------------------------------------------------------
#     def put(self, local_path, remote_path=None):
#         """
#         Copies a file from the local host to the remote host
#         """
#         self._openSFTPConnection()
#         self.sftp.put(local_path, remote_path)
 
#     # ----------------------------------------------------------------------
#     def close(self):
#         """
#         Close SFTP connection and ssh connection
#         """
#         if self.sftp_open:
#             self.sftp.close()
#             self.sftp_open = False
#         self.transport.close()



# if __name__ == "__main__":
#     # host = "myserver"
#     # username = "mike"
#     # pw = "dingbat!"

#     host = '152.79.84.175'
#     username = 'grehm'
#     pw ='K3njimasuda'

#     origin = '/Users/retriever/0320RPI2320160915/0320RPI2320160915-rpi23-2016-09-15-09-56-35.208468.csv'
#     dst = '/Users/monica/Downloads/test2/0320RPI2320160915-rpi23-2016-09-15-09-56-35.208468.csv'
#     #origin = '/home/mld/projects/ssh/random_file.txt'
#     #dst = '/home/mdriscoll/random_file.txt'
 
#     ssh = SSHConnection(host, username, 'publickey')
#     ssh.put(origin, dst)
#     ssh.close()