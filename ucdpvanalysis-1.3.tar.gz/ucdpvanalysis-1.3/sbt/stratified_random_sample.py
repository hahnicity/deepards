"""
Created on 2017-02-28 15:08:23
"""

from argparse import ArgumentParser
import pandas as pd
import os
import numpy as np


def main(input_meta, output_meta):
    input_df = pd.read_csv(input_meta, index_col=0)
    not_early_trach = input_df.loc[input_df['trach<12'] == 0, :].copy()
    no_sbi = not_early_trach.loc[not_early_trach['recorded_sbi'] == 0, :]
    sbi_present = not_early_trach.loc[not_early_trach['recorded_sbi'] == 1, :]

    np.random.seed(20170228)  # sets seed so that sample is pseeudo random
    # note, this method rounds the sample down if original index/popn (N) is odd
    # with replacement
    # index1 = np.random.randint(int(len(no_sbi)), size=int(0.5 * len(no_sbi)))
    # print index1
    # print no_sbi.index[index1]
    # index2 = np.random.randint(int(len(sbi_present)), size=int(0.5 * len(sbi_present)))
    # print index2
    # print sbi_present.index[index2]

    # not_early_trach['cohort'] = 'validation'
    # not_early_trach['in_derivation'] = 0

    # without replacement
    index1 = np.random.choice(int(len(no_sbi)), size=int(0.5 * len(no_sbi)), replace=False)
    print index1
    print no_sbi.index[index1]
    index2 = np.random.choice(int(len(sbi_present)), size=int(0.5 * len(sbi_present)), replace=False)
    print index2
    print sbi_present.index[index2]

    not_early_trach['cohort'] = 'validation'
    not_early_trach['in_derivation'] = 0
    not_early_trach.loc[no_sbi.index[index1], 'cohort'] = 'derivation'
    not_early_trach.loc[no_sbi.index[index1], 'in_derivation'] = 1
    not_early_trach.loc[sbi_present.index[index2], 'cohort'] = 'derivation'
    not_early_trach.loc[sbi_present.index[index2], 'in_derivation'] = 1
   
    not_early_trach.to_csv(output_meta)

if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("-input_meta", "-i", help="File with meta")
    parser.add_argument("-output_meta", "-o", help="csv to be outputted")

    args = parser.parse_args()
    main(args.input_meta, args.output_meta)
