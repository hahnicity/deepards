
"""
Created on Tue May 14 12:45 PM
@author: Keiko
Based on pool_stats.py
"""
import pandas as pd
import os
import glob
import sys

gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.solo_fused as fused; reload(fused)
import utilikilt.oz as oz

def get_patient_number(file_path):
    file_name=os.path.basename(file_path)
    name_split=file_name.split("_")
    patient_number=name_split[0]+"_"+name_split[1]+name_split[2]
    return patient_number
def stack(input_dir,index_col="BN",keep_col_list=[],drop_col_list=[]):
    """
    Stacks multiple csvs one after another

    Args:
    -----
    input_dir: input directory path
    output_dir: output directory path
    index_col: determines which column to use as index (breath identifier)
    keep_col_list: list of columns for final output
    drop_col_list: list of columns to drop from aggregated output

    Versions:
    --------
    20160524-V1.0 First implementation as a function
    20160526-V1.1 Split patient number into different function and 
                    rename for pt name

    """

    frame=pd.DataFrame()

    all_file_paths=glob.glob(os.path.join(input_dir,"*.csv"))

    list_of_dfs=[]
    file_name_list=[]
    for file_path in all_file_paths:
        df=pd.read_csv(file_path,index_col=index_col,header=0)
        list_of_dfs.append(df)

        file_name=get_patient_number(file_path)
        file_name_list.append(file_name)


    # import pdb
    # pdb.set_trace()
    aggregated = pd.concat(list_of_dfs,keys=file_name_list,axis=0)
    aggregated.index.names=['subject_ID','BN']

    file_name_list=[name.split("_")[0] for name in file_name_list]
    aggregated.index=aggregated.index.set_levels(file_name_list,level=0)
    # aggregated.index=aggregated.index.set_levels(['one','two'],level=0)
    # import pdb
    # pdb.set_trace()
    #insert error checking to make sure that keep_col_list
    #and drop list are mutually exclusive.

    # if drop_col_list!=[] and keep_col_list!=[]:
    #     "ERROR--only input drop_col_list OR keep_col_list but not both"
    #      return
    if drop_col_list!=[]:
        aggregated.drop(drop_col_list,axis=1,inplace=True)
    if keep_col_list!=[]:
        aggregated=aggregated[keep_col_list]


    return aggregated


#an example running from command line
if __name__ == "__main__":
    pass
