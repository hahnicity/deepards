# -*- coding: utf-8 -*-
"""
graphing tools based on mpld3
Created on Wed Jun 03 20:35:42 2015

@author: Keiko
"""
import mpld3
from mpld3 import plugins
import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import stats
import pandas as pd

css = """
table
{
border-collapse: collapse;
}
th
{
color: #ffffff;
background-color: #000000;
}
td
{
background-color: #cccccc;
}
table, th, td
{
font-family:Arial, Helvetica, sans-serif;
border: 1px solid black;
text-align: right;
}
"""

class pvi(object):
    def __init__(self, aligned, colorcodes, breaths):     
        ann_cols = range(1,len(aligned.aligned[0]))
#        fig, ax = plt.subplots(subplot_kw=dict(axisbg='#EEEEEE'))
        fig, ax = plt.subplots()
#        ax.grid(color = 'white', linestyle = 'solid')
        fig.suptitle('PVI comparison:\n', color = 'gray')
        ax.set_title (aligned.title)
        x = [int(i) for i in aligned.aligned[1:, 0]]
        x = stats.repl_names(x, breaths)
        length = len(aligned.aligned[1:])
        ann_total = len(ann_cols)
        i = 0
        y_labels = []
        y_loc = []
        scatter_data = []
        point_labels = []
#        to_graph = [('breath#', 'BStime', 'y', 'ann', 'color'),]
        to_graph = []   
        for ann in ann_cols:
            y_labels.append(aligned.aligned[0,ann])
            y = ann_total-i #puts in 'reverse' y order
            y_loc.append(y) # for label
            ann_col = aligned.aligned[1:,ann].tolist()            
            breath_col = aligned.aligned[1:,0]
            for breath, ann_i in zip(breath_col, ann_col):
                if ann_i in colorcodes:
                    code = colorcodes[ann_i]
                else:
                    code = 1
                BStime = breaths[eval(breath)]
                newrow = (breath, BStime, y, ann_i, code)
                new = [[breath, BStime, y, ann_i, code]]
                to_graph.append(newrow)
#            y_flat = [y]*length
#            anns = aligned.aligned[1:,ann].tolist()
#            colors = stats.repl_names(aligned.aligned[1:,ann], colorcodes)
#            colors = np.array(colors)
#            scatter = ax.scatter(x, y_flat, c=colors, s=1000,alpha = 0.5)
#            y_flat_label = [y-0.5]*length
##            for xi, yi, label in zip(x, y_flat_label, anns):        
##                ax.text (xi, yi, label, horizontalalignment = 'center', fontsize = '6')
#            scatter_data.append(scatter)
#            point_labels.append(anns)
            i +=1
        
        BN, x, y, labels, colors = zip(*to_graph)
        colors = np.array(colors)
        scatter = ax.scatter(x, y, c=colors, s=100, alpha=0.5)
        header =['breath#', 'BStime', 'ann', 'color']
        to_df = zip(BN, x, labels, colors)
        df = pd.DataFrame(to_df, columns = header, index = list(labels) )
        #testhtml = df.to_html()
        label2 = ["<h1>{title}</h1>".format(title=k) for k in labels]
#        labels = [‘<h1>{title}</h1>’.format(title=i) for i in range(10)] :
        
        labels3=[]
        for i in range(len(df)):
            lab = df.ix[[i],:].T
            lab.columns = ['{title}'.format(title =labels[i])]
            labels3.append(str(lab.to_html()))
        
        tooltip = mpld3.plugins.PointHTMLTooltip(scatter, labels=labels3, css=css)
        mpld3.plugins.connect(fig, tooltip, plugins.MousePosition())       
#        fig.plugins = []
        
        plt.sca(ax)
        plt.yticks(y_loc, y_labels)
        plt.xlabel('seconds')    
        plt.ylim((0, ann_total +1))
        plt.xlim(0,max(x)+10)

#        mpld3.show()

        self.fig = fig
        self.tooltip = tooltip
#    def showPlot(self,fig, tooltip):
#        print ('x')
#        mpld3.plugins.connect(fig, tooltip, plugins.MousePosition())  
#        mpld3.display(fig)
        
class pviStatic(object):
    def __init__(self, aligned, title, colorcodes, breaths):        
        ann_cols = range(1,len(aligned[0]))
        fig, ax = plt.subplots(subplot_kw=dict(axisbg='#EEEEEE'))
        ax.grid(color = 'white', linestyle = 'solid')
        fig.suptitle('PVI comparison:\n', color = 'gray')
        ax.set_title (title)
        x = [int(i) for i in aligned[1:, 0]]
        #x = stats.repl_names(aligned[1:,1], dicts.colors)
        x = stats.repl_names(x, breaths)
        length = len(aligned[1:])
        ann_total = len(ann_cols)
        i = 0
        y_labels = []
        y_loc = []
        scatter_data = []
        point_labels = []
        for ann in ann_cols:
            y_labels.append(aligned[0,ann])
            y = ann_total-i #puts in 'reverse' y order
            y_loc.append(y)
            y_flat = [y]*length
            anns = aligned[1:,ann].tolist()
            colors = stats.repl_names(aligned[1:,ann], colorcodes)
            colors = np.array(colors)
            scatter = ax.scatter(x, y_flat, c=colors, s=100,alpha = 0.5)
            y_flat_label = [y-0.5]*length
            for xi, yi, label in zip(x, y_flat_label, anns):        
                ax.text (xi, yi, label, horizontalalignment = 'center', fontsize = '10')
            scatter_data.append(scatter)
            point_labels.append(anns)
            i +=1
        plt.sca(ax)
        plt.yticks(y_loc, y_labels)
        plt.xlabel('seconds')    
        plt.ylim((0, ann_total +1))
        plt.show()
        
class pviZoom(object):
    def __init__(self, subset_ann, pvi, breaths, dict_colors, waveform): 
        ann = subset_ann
        matrix = ann[pvi + '_pvi'][1:]
        time = waveform.time
        pressure = waveform.pressure
        flow = waveform.flow 
        title = pvi
        
        max_time = int(round(max(time))) 
        zeros=np.zeros(len(time))
        
        y = 1
        to_graph =[]
        for row in matrix:
            #append data for graphing
            breath = eval(row[0])
            BStime = breaths[eval(row[0])]
            ann_i = row[2]
            eval_i = row[3]
            label_i = '%s -> %s' %(row[2], row[3])
            color_i = dict_colors[row[3]]
            newrow = (breath, BStime, y, ann_i, eval_i, label_i, color_i)
            to_graph.append(newrow)
            
        BN, x, y, labels1, labels2, labels3, colors = zip(*to_graph)
        colors = np.array(colors)
        snapshots =[]
        #append data for snapshots
        for i in range(len(to_graph)):
            row = to_graph[i]
            ann_i = row[2]
            breath = row[0]
            BStime = row[1]
            
            LHS = breaths[breath]
            if breath == max(breaths):
                RHS = max_time
            else:
                nextBreath = breath + 1
                RHS = breaths[nextBreath]
            time_list = [round(i,2) for i in time]
            Lindex = time_list.index(LHS)
            Rindex = time_list.index(RHS)
        
        #    snapshots.append([Lindex, Rindex])
        #print snapshots
            snapshots.append([time[Lindex:Rindex],flow[Lindex:Rindex]])
        snapshots_transposed = []
        for row in snapshots:
            snapshots_transposed.append(zip(row[0], row[1]))
                                        
        fig, ax = plt.subplots(2)
        ax[0].set_title("Hover over points(PVI instances) to see close up")
        ax[1].set_xlabel("time (s)   ->Press home icon to reset graph")
        ax[1].set_xlabel("Press home icon to reset graph")
        ax[1].get_yaxis().set_ticks([])
        ax[1].text(0, 1, title, horizontalalignment = 'center', fontsize = '12')
        
        points = ax[1].scatter(x,y, c=colors,s=200, alpha=0.5)
        for xi, yi, label1,label2 in zip(x, y, labels1,labels2):
            ax[1].text(xi, yi-0.03, label1, horizontalalignment = 'center', fontsize = '10')
            ax[1].text(xi, yi+0.03, label2, horizontalalignment = 'center', fontsize = '10')
            
#        ax[1].text(0, 0, title, horizontalalignment = 'center', fontsize = '12')    
        
        lines = ax[0].plot(time, flow, alpha=0.9, color = 'green', lw=2,)
        flow_line = ax[0].plot(time, flow, alpha=0.75, color = 'green')
        pressure_line = ax[0].plot(time, pressure, alpha=0.75, color='purple') 
        horizontal = ax[0].plot(time, zeros, alpha=0.3, color = 'gray', ls='--')
        
        linkedview = LinkedView(points, lines[0], snapshots_transposed)        
        
        self.fig = fig
        self.linkedview = linkedview

        
class LinkedView(plugins.PluginBase):
    """A simple plugin showing how multiple axes can be linked"""

    JAVASCRIPT = """
    mpld3.register_plugin("linkedview", LinkedViewPlugin);
    LinkedViewPlugin.prototype = Object.create(mpld3.Plugin.prototype);
    LinkedViewPlugin.prototype.constructor = LinkedViewPlugin;
    LinkedViewPlugin.prototype.requiredProps = ["idpts", "idline", "data"];
    LinkedViewPlugin.prototype.defaultProps = {
        hoffset:0,
        voffset:10,
        location: 'mouse'};
    function LinkedViewPlugin(fig, props){
        mpld3.Plugin.call(this, fig, props);
    };

    LinkedViewPlugin.prototype.draw = function(){
      var pts = mpld3.get_element(this.props.idpts);
      var line = mpld3.get_element(this.props.idline);
      var data = this.props.data;
      
      this.fig.canvas.append("text")
            .text("PVIs")
            .style("font-size", 12)
            .style("opacity", 0.3)
            .style("text-anchor", "right")
            .attr("x", -1)
            .attr("y", (this.fig.height / 4)*3); 

 
      function mouseover(d, i){    
        pts.elements().transition()
            .style("color", "#FF0000");
        var begin = d[0]-10;
        var end = d[0]+10;
        console.log("Show from " + begin + " to " + end);
        var truncated = Array();
        for (var row = 0; row < data[i].length ; ++row){

            var x = data[i][row][0];
            if ( begin <= x && x <= end){
                truncated.push(data[i][row]);
            }
        }

        line.data = truncated;
        line.elements().transition()
            .attr("d", line.datafunc(line.data))
            .style("color", "#FF0000");
        line.ax.set_axlim([begin,end],[-80,80]);
      }
      pts.elements().on("mouseover", mouseover);
    };
    """

    def __init__(self, points, line, linedata):
        if isinstance(points, matplotlib.lines.Line2D):
            suffix = "pts"
        else:
            suffix = None

        self.dict_ = {"type": "linkedview",
                      "idpts": mpld3.utils.get_id(points, suffix),
                      "idline": mpld3.utils.get_id(line),
                      "data": linedata,
    }

