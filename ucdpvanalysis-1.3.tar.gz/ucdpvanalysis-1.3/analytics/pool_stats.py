
"""
Created on Wed Mar 7 5:48 PM
@author: Keiko
"""
import pandas as pd
import os


def aggregate_stats(
    stats_dir, ppvi_list=['dbl.4'],
    matrix_keywords=["multi_frame2__ACCURACY", "solo__ACCURACY"],
    stat_list=['accuracy', 'sensitivity', 'specificity'],
    file_suffix=".csv",
        pt_file_subnumber=False):
    """
    Pools stats from the different output

    TODO-change from csv output to df output

    Versions
    2016-03-07 V1-Pools just accuracy
               V1.1- Hierarchical build
               V1.2- Add values to hierarchical build
               V1.3- Add multiple pva events
    2016-04-21 V1.4--Add custom number of matrix
    2016-04-26 V1.5--Output df instead of csv
    """

    # save the file suffixes for column names
    matrix_type_list = []
    for matrix_file_keyword in matrix_keywords:
        matrix_type_list.append(matrix_file_keyword.rstrip("__ACCURACY"))

    # extract names of patient files in folder
    pt_list = []
    for root, dirs, files in os.walk(stats_dir):
        for stat_file in files:
            if matrix_keywords[0] in stat_file and stat_file.endswith(file_suffix):
                if pt_file_subnumber:
                    pt_list.append(stat_file.split("_")[0] + "_" + stat_file.split("_")[1])
                else:
                    pt_list.append(stat_file.split("_")[0])
                # pt_list.append(stat_file.split("_")[0])

    # create multi-level indices for the output matrix
    # rows--statistic list (accurac, sensitivity, specificity, etc..)
    # then use patient level
    multi_row_index = pd.MultiIndex.from_product([stat_list, pt_list])
    # columns --- pvi list, before and after
    multi_column_index = pd.MultiIndex.from_product([ppvi_list, matrix_type_list])
    new_df = pd.DataFrame(0, index=multi_row_index, columns=multi_column_index)

    # before being filled

    for root, dirs, files in os.walk(stats_dir):
        for stat_file in files:

            for matrix_file_keyword, matrix_name in zip(matrix_keywords, matrix_type_list):
                # extract statistics for each  file
                if matrix_file_keyword in stat_file and stat_file.endswith(file_suffix):
                    temp_df = pd.read_csv(os.path.join(stats_dir, stat_file), index_col=0)
                    if pt_file_subnumber:
                        pt_number = stat_file.split("_")[0] + "_" + stat_file.split("_")[1]  # +"_"+stat_file.split("_")[4]
                        # pt_number=stat_file.split("_")[0]+"_"+stat_file.split("_")[4]
                    else:
                        pt_number = stat_file.split("_")[0]
                    # extract each statistic and write to output csv
                    for stat in stat_list:
                        for ppvi in ppvi_list:
                            new_value = temp_df.loc[stat, ppvi]
                            new_df.loc[(stat, pt_number), (ppvi, matrix_name)] = new_value

    # after being filled
    new_df.index.names = ['statistic', 'patient']
    new_df.columns.names = ['algorithm', 'matrix_output']
    print new_df

    return new_df
    # new_df.to_csv(output_csv)


def pool_stats(df):
    """
    Pool data from multiple patients

    Versions:
    --------
    20160426 V1

    Example:
    -------

    """
    # make a copy of current data frame
    df.fillna(0)
    df = df.convert_objects(convert_numeric=True)
    df = df.groupby(level=0).sum()
    df = df.transpose()
    df['TPandFNs'] = df['TPs'] + df['FNs']
    df['TNandFPs'] = df['TNs'] + df['FPs']
    df['all4'] = df['TPandFNs'] + df['TNandFPs']
    df['accuracy'] = (df['TPs'] + df['TNs']) / df['all4']
    df['sensitivity'] = df['TPs'] / df['TPandFNs']
    df['specificity'] = df['TNs'] / df['TNandFPs']

    df = df.transpose()

    return df


# an example running from command line
if __name__ == "__main1__":
    # from os import chdir, path
    root_dir = r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox/20160307_post_cough/'
    os.chdir(root_dir)
    stats_dir = os.path.join(root_dir + r'accuracies/')
    output_csv = os.path.join(root_dir + r'accuracies/' + "pooled_stats_TOR3_2_8.csv")
    aggregate_stats(
        stats_dir,
        ppvi_list=['dbl.4', 'bs.1', 'mt', 'co', 'co.2', 'co.3', 'co.4', 'vd.2', 'su'],
        output_csv=output_csv,
        matrix_keywords=["multi_frame2__ACCURACY", "solo__ACCURACY"],
        stat_list=['accuracy', 'sensitivity', 'specificity', 'total', 'events', 'FNs', 'FPs', 'TPs'])

        # pooled_dir=pooled_dir,matrix_keyword="ACCURACY")
        # pooled_dir=pooled_dir,matrix_keyword="solo__ACCURACY")

# if __name__=="__main__":
#     root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox'
#     os.chdir(root_dir)
#     stats_dir=r'20160421_stats_add_true_pooled'
#     det_subdir=r'20160419_TOR3_4_5_group_results_post_cough_336_mt_counter'
#     det_analysis_subdir=r'20160421_stats_add_true_pooled'

#     pooled_stats_csv="pooled_stats_"+det_subdir+"5_terminal.csv" #optional, change pooled stats_name
#     output_csv = os.path.join(root_dir,det_analysis_subdir,pooled_stats_csv)

#     aggregate_stats(det_analysis_subdir,ppvi_list=['dbl.2','dbl.4','bs.1','mt','mt.su','co.orig','co.2thresh','co.notvi','vd.2','su.2','sumt'],
#         output_csv=output_csv,
#         matrix_keywords=["multi_frame2__ACCURACY","multi_frame3__ACCURACY","solo2__ACCURACY"],
#         stat_list=['accuracy','sensitivity','specificity','total','events','FNs','FPs','TPs','TNs'])
