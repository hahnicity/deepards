"""
created June 6, 2016
"""

import os
import pandas as pd
import glob

#start of script
root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/20160516_sampling/pilot0604/'
os.chdir(root_dir)
input_dir=r'20160605pilot_detected/detected'
input_file=r'20160605pilot_detected/detected/0086RPI1920151120_first6_concat_del5762_v3_5_7__solo3.csv'
input_file=r'20160605pilot_detected/detected/0002_09_13_15_02_1to7200_v3_5_7__solo3.csv'
output_file=r'aggregated_dbl_counts.csv'

def get_dbl_count(df,pva):
    """
    versions:
    --------
    20160606 V1.0 Written

    example:
    -------
    root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/20160516_sampling/pilot0604/'
    os.chdir(root_dir)
    input_dir=r'20160605pilot_detected/detected'
    input_file=r'20160605pilot_detected/detected/0002_09_13_15_02_1to7200_v3_5_7__solo3.csv'

    df=pd.read_csv(input_file,header=0)
    print get_dbl_count(df,'dbl.4')
    """
    counts=df[pva].value_counts() #tabulates the frequency of each number
    count_double=counts[1] #get the occurrence of the number 1
    return count_double
    
#start of function2

all_file_paths=glob.glob(os.path.join(input_dir,"*solo3.csv"))

newdf=pd.DataFrame(0,index={},columns=['dbl.4']) #creates empty df

for file_path in all_file_paths:
    print os.path.basename(file_path)
    file_= os.path.basename(file_path)
    df=pd.read_csv(file_path,header=0)
    freq = get_dbl_count(df,'dbl.4')
    newdf.loc[file_,'dbl.4']=freq
    #newdf.loc['0086RPI1920151120_first6_concat_del5762_v3_5_7__solo3.csv','dbl.4']=3

newdf.to_csv(output_file)
