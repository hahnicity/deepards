# -*- coding: utf-8 -*-
"""
stats2
~~~~~~

Created on Sat Nov 14 18:31:56 2015

@author: Keiko
inspired by analysis/stats
original dev folder: Sandbox\20151114_Stats
Driver script: 20151129_Stats2_RUNME.py

original name: dev version 2.6
new name: stats2

Versions
1 - June 3rd,2015--previous comparison of single line gold standards
2.1 Clean up function
2.2 Convert into function
2.3 Add sensitivity/specificty calculation for each sub-algorithm
2.4 Add checkBinary
2.5 Add convertAllBinary
2.6 Split into driver file and library file.
2.7 Add calculations for multiple sub-files
"""
from __future__ import division
import os
import pandas as pd
import numpy as np

import pdb
__version__='2.7'

#%%functions
def countTPs(trueList,predList):
    """
    Compares two lists which use binary classification system [0,1]

    Args:
     trueList: classifications based on a gold standard (or rater1)
     predList: classification based on an algorithm (or rater2)
    both lists are in the form [0,1,...0,0] (etc.) where each individual
    can be 1=true or 0=false

    Returns:
    tp: number of true positives
    fp: number of false positives
    fn: number of false negatives
    tn: number of true negatives
    annEvals: list with results of comparison ex.['tp', 'fn', 'tp',...'tp']

    Example:
        annEval, tp, fp, fn, tn=countTPs(dfGold.dbl.tolist(),dfDet.dbl.tolist())
        sensitivity=tp/(tp+fn)
        specificity=tn/(tn+fp)

        Also used in calcROC

    Written: 2015/11/14
    """
    #initialize counters
    tp=0
    fp=0
    tn=0
    fn=0
    #initialize empty collection list
    annEval=[]

    for true, pred in zip(trueList, predList): #for each individual classification
        if true==pred:
            if true==1: #if both raters agree and both are 1,
                tp+=1  #it is a true positive, add to TP counter
                annEval.append('tp')
            else: #both raters agree and both are 0
                tn+=1 #it is a true negative, add to TN counter
                annEval.append('tn')
        if true!=pred: #if there is rater disgagreement
            if true==1: #if the gold standard is true
                fn+=1 #then the prediction/algorithm failed to detect the event
                annEval.append('fn')
            else: #if the gold standard is not true/1
                fp+=1 #then the prediction falsely detected an event
                annEval.append('fp')
    return annEval, tp, fp, fn, tn

def calcROC(trueList,predList):
    """
    Compare two lists to make calculations related to a receiver operating curve

    Args:
     trueList: classifications based on a gold standard (or rater1)
     predList: classification based on an algorithm (or rater2)
    both lists are in the form [0,1,...0,0] (etc.) where each individual
    can be 1=true or 0=false

    Returns:
     annEvals: list with results of comparison ex.['tp', 'fn', 'tp',...'tp']
     ROC: dictionary that contains calculations such as sensitivity, specificity
      and the counts of true positives, false positives etc.

    Updated: 2015/11/25 Change defaults into 'div0' (from statsv1-calcBinary)
    Written: 2015/11/14
    See:
    https://en.wikipedia.org/wiki/Receiver_operating_characteristic
    """
    annEval, tp, fp, fn, tn=countTPs(trueList,predList)
    ROC={}
    se='div0'
    spe='div0'
    ppv='div0'
    npv='div0'

    if (tp+fn)!=0:
        se=tp/(tp+fn)
    if (tn+fp)!=0:
        spe=tn/(tn+fp)
    if (tp+fp)!=0:
        ppv=tp/(tp+fp)
    if (fn+tn)!=0:
        npv=tn/(fn+tn)


    #save calculations in output (ROC) dictionary
    #also see https://en.wikipedia.org/wiki/Sensitivity_and_specificity
    ROC['sensitivity']=se
    ROC['specificity']=spe
    if spe!='div0':
        ROC['FPR']=1-spe
    ROC['accuracy']=(tp+tn)/(tp+fp+fn+tn)
    ROC['PPV']=ppv
    ROC['NPV']=npv
    if se!='div0' and spe!='div0':
        ROC['youden']=se+spe -1
    else:
        ROC['youden']=np.nan
    ROC['tp']=tp
    ROC['fp']=fp
    ROC['fn']=fn
    ROC['tn']=tn
    ROC['total']=int(tp+fp+fn+tn)
    ROC['events']=tp+fn
    return ROC,annEval


def calcStats(dfDet,dfGold, printout=False):
    """
    Calculates binary metrics for whole dataframe


    Written: 2015-11-25

    """
    dfCompared=pd.DataFrame(index=dfDet.index, columns=dfDet.columns)
    dfCompared.ventBN=dfDet.ventBN
    dfCompared.BS=dfDet.BS

    dfStats=pd.DataFrame(index=['accuracy','sensitivity', 'specificity',
                                'FPR','youden','PPV','NPV',
                                'TPs','FPs','FNs','TNs',
                                'total','events'],
                         columns=dfDet.columns[2:])
    for col in dfDet.columns.tolist():
        if col not in ['BN','ventBN','BS','pvis']:
            if printout:
                print col, '--'
            shortColName=col.split('.')[0]
            if shortColName in dfGold.columns.tolist():
                predList=dfDet[col].tolist()
                trueList=dfGold[shortColName].tolist()


                #check to make sure each list only has 0's and 1's
                isBinary=checkBinary(dfDet[col])
                if isBinary==False:
                    print "ERROR: %s is not binary" %col
                elif isBinary==True:
                    #TODO change up comparison if it isn't binary ex. bs,tvv
                    ROC, annEval = calcROC(trueList,predList)
                    if len(dfCompared[col]) != len(annEval):
                        raise Exception("columns must match in length!")
                    dfCompared[col] = annEval
                    statsCol=[ROC['accuracy'],ROC['sensitivity'],ROC['specificity'],
                              ROC['FPR'],ROC['youden'],ROC['PPV'],ROC['NPV'],
                              ROC['tp'],ROC['fp'],ROC['fn'],ROC['tn'],
                              int(ROC['total']),int(ROC['events'])]
                    dfStats[col]=statsCol
    return dfStats, dfCompared



def checkBinary(subDF):
    """
    Determine a sub dataframe only has 1's and 0's
    Args:
     subDF: row or column of a data frame
    Output:
     isBinary (boolean)
    Examples:
        checkBinary(dfDet.su)
        checkBinary(dfDet.co)

        test=pd.DataFrame([0,1,3,1,0,0,1,3])
        checkBinary(test[0])
    Written:2015/11/18
    """
    unique=subDF.unique() #grab unique values in dataframe
    unique.sort() #sort those values from smallest to largest
    #if there is only one value present
    if len(unique)==1:
        if unique[0] in [0,1]:
            isBinary=True
        elif unique[0]==' ':
            isBinary=True
        else:
            isBinary=False
    elif len(unique)==2:
        if unique[0]==0 and unique[1]==1:
            isBinary=True
        else:
            isBinary=False
    #any time there is more than 2 values present
    #there are more than 0's and 1's present
    else:
        isBinary=False
    return isBinary


def makeBinary(subDF):
    """
    Written 2015-11-25
    """
    oldList=subDF.tolist()

    newList=[]
    for row in oldList:
        if row>0:
            newList.append(1)
        else:
            newList.append(0)
    return newList

def convertAllBinary(dfDet):
    """
    Converts all rows into binary form
    Written 2015-11-25
    """
    newDF=pd.DataFrame(index=dfDet.index, columns=dfDet.columns)
    newDF.ventBN=dfDet.ventBN
    newDF.BS=dfDet.BS

    for col in dfDet.columns.tolist():
        if col=="cosumtvd":
            isBinary=checkBinary(dfDet[col])
        if col not in ['BN','ventBN','BS']:
            isBinary=checkBinary(dfDet[col])
            if isBinary==False:
               newDF[col]=makeBinary(dfDet[col])
               print col+" was converted to binary classification"
            elif isBinary==True:
               newDF[col]=dfDet[col]
    return newDF


def calcMultiStats(logfile,gold_name,det_subdir,output_subdir,gold_subdir,
                    subfiles_list=['_class_matrix_raw_multi_frame.csv',
                    '_class_matrix_solo.csv']):
    """
    Calculate the stats for multiple sub files of in an individual file


    1.1
    1.0 written 2016-02-04
    Ex.
        input_subdir=r'20160211_Derivation'
        output_subdir=r'20160211_Derivation'
        gold_subdir=r'0TestFiles/2016-02-06-gold_standard'

        sta.calcMultiStats(logfile='0002_09_14_38_2400to2700_TOR3_1_0_logfile.txt',
            gold_name='0002_09_14_38_3_2399to2701_goldstd_dbl_bs_cosumtvd.csv',
            input_subdir=input_subdir,output_subdir=output_subdir,gold_subdir=gold_subdir)

    Ex. Run on a group of TOR output
        filelist=[
        ['0002_09_14_38_2400to2700_TOR3_1_0_logfile.txt',   '0002_09_14_38_3_2399to2701_goldstd_dbl_bs_cosumtvd.csv'],
        ['0004_09_23_46_2200to2500_TOR3_1_0_logfile.txt',   '0004_09_23_46_2_2199to2501_goldstd_dbl_bs_cosumtvd.csv'],
        ]

        #process a batch of files
        for files in filelist:
            print files[0], files[1]
            print '-----------------'

            sta.calcMultiStats(logfile=files[0],
                gold_name=files[1],
                input_subdir=input_subdir,output_subdir=output_subdir,gold_subdir=gold_subdir)
    """
    filename = logfile.split('_logfile.txt')[0]
    for matrixCsv in subfiles_list:
        det_name = filename + matrixCsv
        df_det = pd.read_csv(os.path.join(det_subdir, det_name), index_col = 'BN')
        df_gold = pd.read_csv(os.path.join(gold_subdir, gold_name), index_col = 'BN')
        dfDetBinary = convertAllBinary(df_det)
        dfStats2, dfCompared2 = calcStats(dfDetBinary, df_gold)
        acc_file = filename + matrixCsv.split('.csv')[0] + "__ACCURACY.csv"
        dfStats2.to_csv(os.path.join(output_subdir, acc_file))
        compared_file = filename + matrixCsv.split('.csv')[0] + "__COMPARED.csv"
        dfCompared2.to_csv(os.path.join(output_subdir, compared_file))
