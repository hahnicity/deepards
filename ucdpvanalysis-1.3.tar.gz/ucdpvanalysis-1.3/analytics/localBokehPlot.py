# -*- coding: utf-8 -*-
"""
Created on Thu Nov 05 08:25:35 2015

@author: Keiko
based on Experiments/20150915_Breakage/p65_truncate.py
developed in Sandbox\20151105_LocalPlot

driver scripts
-raw file only--20151105_localBokehPlot_RUNME.py
-pvi + raw file--

1.0 Created for local plotting, sent to Jason/Brooks
2.0
"""

from __future__ import division
__version__="1.0"

import os
import pandas as pd
#from bokeh.charts import Scatter, Line
from bokeh.plotting import figure, show, output_file, ColumnDataSource
#from bokeh.models import LinearAxis, Range1d,Circle
#sys.path.insert(0, r'C:\allMYfiles\BOX\BedsideToCloud Pilot Project\PVI\Experiments\20150817_Tidal_Volume')
#from rawCut import rawTrunc
import algorithms.rawCut as rawCut
from argparse import ArgumentParser
#import rawCut; reload (rawCut)

#plainFile=[]
#dt = 0.02
#intSize =[]
#intervalNumber=[] #must be .csv
#plotFile=[] #must be .html
#intSize=15
#intervalNumber=2

          
def plotBokeh(inputFile, output_subdir=[], 
               plotFile=[],plainFile=[],
                dt=0.02, intSize=[], intervalNumber=[]):
                    
    """
    Plots a raw file in bokeh, no breath numbers
    
    
    Written: 2015-11-05
    """
    filename=os.path.splitext(inputFile) [0]
    if intSize==[] and intSize != intervalNumber :
        print "ERROR must input both intervalNumber and intSize"
    if plainFile==[]:
        plainFile=filename+'_plain.csv' 
    if plotFile==[]:
        output_file(os.path.join(output_subdir, filename +'_plot.html'), title=filename)
    else:
        output_file(os.path.join(output_subdir, plotFile), title=filename)
        
    
    
    inputPath = inputFile
    outputPath = os.path.join (output_subdir, plainFile)
    
    #remove NULL bytes in CSVs and overwrite previous files
    origFile = open(inputPath,'rb')
    data = origFile.read()
    origFile.close()
    if data.count('\x00')>0:
        overwrite = open(inputPath, 'wb')
        overwrite.write(data.replace('\x00', ''))
        overwrite.close()
    
    rawCut.rawTrunc(inputPath,outputPath,interval=[], printout=False, keepBS=False,
                    addRelTime=dt)

    
    wave_path = (os.path.join(output_subdir, filename+'_plain.csv'))
    df_big = pd.read_csv(wave_path, names = ['time', 'flow', 'pressure']) 
    
    minutesRecorded=(len(df_big))/((1/dt)*60)
    print "This file is %s min(s) long" %(str(minutesRecorded))
    # split columns into individual df's
    t= df_big['time'] #converting to a list is quicker for get index
    pressure = df_big['pressure']
    flow = df_big['flow']
    tlist = []
    # for row in t:
    #     tlist.append(round(row,2))    
    
    
    df_small=df_big[0:100000]
    plotData=ColumnDataSource(df_small)
    #plotData=ColumnDataSource(df_big)
    
    if intSize ==[]:
        plotData=ColumnDataSource(df_big)
        title=filename
    else:
        Lmin=intSize*(intervalNumber-1)
        Rmin=intSize*(intervalNumber)
        Lindex=Lmin*3000
        Rindex=Rmin*3000
        df_small=df_big[Lindex:Rindex]
        plotData=ColumnDataSource(df_small)
        print "Plotting %s-%s Min"%(str(Lmin), str(Rmin))
        title="%s-%s Min"%(str(Lmin), str(Rmin))

    middle = figure(webgl=True, title=title,plot_width=800,plot_height=400,
                    tools="xpan, xwheel_zoom,resize,crosshair,reset")
    middle.line(x='time', y='flow', source=plotData)
    middle.line('time', 'flow', line_width=0.5, legend = 'pressure', 
                line_color="purple", source=plotData)
    middle.xaxis.axis_label = "Time(s)"
    middle.line('time', 'pressure', line_width=0.5, legend='flow', 
                line_color="blue", 
                source=plotData)
                
    show(middle)


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("input_file", help="Input file")
    parser.add_argument("output_dir", help="output directory")
    parser.add_argument("-html_name", "-p", default="", help="output html Name")
    parser.add_argument("-csv_name", "-c", default="", help="CSV Name")
    parser.add_argument("-int_number", default=[], type=int, help="subsection to look at")
    parser.add_argument("-int_size", default=[], type=int, help="size of subsection in minutes")

    args = parser.parse_args()
    plotBokeh(args.input_file, args.output_dir, args.html_name,
              intSize=args.int_size, intervalNumber=args.int_number)
