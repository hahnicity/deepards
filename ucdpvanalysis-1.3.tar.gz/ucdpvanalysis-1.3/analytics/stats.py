# -*- coding: utf-8 -*-
"""
Created on Wed Jun 03 16:37:46 2015

@author: Keiko
"""
from __future__ import division

__version__= '1'

__dependencies__={'imported':'csv, np',
                  'custom':'none'}

import csv
import numpy as np
import sklearn.metrics
import statsmodels.stats.inter_rater
import matplotlib.pyplot as plt 
from mpl_toolkits.axes_grid1 import make_axes_locatable
import copy

def csvTOmat(INPUT_FILE):
    """
    reads CSV --> matrix via csv reader
    this is usually slower than pandas
    automatically removes blank rows
    """
    with open(INPUT_FILE, 'rU') as opened:
        N = []
        sreader = csv.reader(opened, delimiter=',')
        for row in sreader:
            if row!=[]:
                N.append(row)

    return N

class readWaveform(object):
    """
    Imports a waveform from a csv containing the colums time, flow, pressure
    Written 2015/06/3 w/vd_dev
    """
    def __init__(self, input_file, data_source):
        self.data_source = data_source
#        dt = np.dtype([('time', float), ('flow', float),('pressure', float) ])
#        dt = 'float32, float32, float32'
#        waveform = np.fromfile(input_file, dtype = dt)
#        self.data = waveform
#        self.time = waveform['time']
#        self.flow = waveform['flow']
#        self.pressure = waveform ['pressure']
        waveform = np.genfromtxt(input_file, delimiter= ',')
        self.data = waveform
        self.time = waveform[:,0].astype('float')
        self.flow = waveform[:,1].astype('float')
        self.pressure = waveform[:,2].astype('float')
#        seconds, split_seconds = divmod(30000123, 50)
        seconds, split_seconds = divmod(len(waveform), 50)
        split = split_seconds/50
#        seconds, split_seconds = len(self.time)/50
        m, s = divmod(seconds, 60)
        h, m = divmod(m, 60)
        if h/24 >0:
            d, h = divmod(h, 24)
            self.duration = '%02d days and %02d:%02d:%02d.%02d (hh:mm:ss)' % (d, h, m, s, split) 
        else: 
           self.duration = '%02d:%02d:%02d.%02d (hh:mm:ss)' %(h, m, s, split) 
#        
     
class readDetectedAnns(object):
    
    """
    DEPRECATED. see workflow in dla_dev.py
    Imports detected anns (list form-prior to matrix-form) from TOR.py
    Written 2015/06/3 w/vd_dev
    
    """
    def __init__(self, input_file, annotator, data_source):
        self.annotator = annotator
        self.data_source = data_source
        
        with open(input_file, 'rU') as opened:
            N = []
            to_array = []
            N.append(['StartTime', 'EndTime', 'Annotation', 'Parameters'])
            to_array.append(['StartTime', 'EndTime', 'Annotation', 'Parameters'])
            
            reader = csv.reader(opened, delimiter=',')
            next(reader,None)
            
            for row in reader:
                if row!=[]:
                    newrow = [round(eval(row[0]),2), eval(row[1]), row[2], eval(row[3])]
                    N.append(newrow)
                    packedRow = [round(eval(row[0]),2), eval(row[1]), row[2], row[3]]
                    to_array.append(packedRow)
        self.l = N
        self.a = np.array(to_array)
        
    def replNames(self, abbreviations):
        for l_row, a_row in zip(self.l, self.a):
            if l_row[2] in abbreviations:
                l_row[2] = abbreviations[l_row[2]]
                a_row[2] = abbreviations[a_row[2]]
        
    def addClinValues(self, clinValues):
        clinValues_list = csvTOmat(clinValues)
        self.clinValues = np.array(clinValues_list) #(~might need to optimize)
        BStimes = []
        for row in self.clinValues[1:,1]:
            BStimes.append(round(eval(row),2))
        self.breaths = dict(zip(range(len(BStimes)),BStimes))
        
#        self.breaths_t = zip(BStimes, range(len(BStimes)))
        self.BStimes = dict(zip(BStimes, range(len(BStimes))))
        self.breaths_list = BStimes
        
        byBreath = [['breath#', 'annotation', 'parameters']]
        byBreath_toarray = [['breath#', 'annotation', 'parameters']]
        for row in self.l[1:]:
            if row[0] in self.BStimes:
                byBreath.append([self.BStimes[row[0]], row[2], row[3]])
                byBreath_toarray.append([self.BStimes[row[0]], row[2], str(row[3])])
                
            else:
                print 'uh oh, matching breath # not found', row[0]
        self.byBreath = byBreath
        self.byBreath_a = np.array(byBreath_toarray)
        
class readCvizAnns(object):
    """
    Imports annotation csv's from Chronoviz
    Written 2015/06/3 w/vd_dev
    """
    def __init__(self, input_file, annotator, data_source):
        self.annotator = annotator
        self.data_source = data_source
        
        with open(input_file, 'rU') as opened:
            N= []
            N.append(['StartTime', 'EndTime', 'Annotation'])
            reader = csv.reader(opened, delimiter=',')
            next(reader,None)
            for row in reader:
                if row!=[]:
                    row[0] = row[0].split(':')
                    row[0] = eval(row[0][0])*60 + eval(row[0][1])
                    row[1] = row[1].split(':')
                    row[1] = eval(row[1][0])*60 + eval(row[1][1])
                    newrow=[row[0],row[1], row[4]]
                    N.append(newrow)
        self.l = N
        self.a = np.array(N)
        
    def replNames(self, abbreviations):
        for row in self.l:
            if row[2] in abbreviations:
                row[2] = abbreviations[row[2]]
        self.a=np.array(self.l)
    
    def removeNormals(self):
        N = []
        for row in self.l:           
            if row[2] not in ['nl', 'normal']:
                N.append(row)
        self.l = N
        self.a = np.array(N)
    
    def byBreath(self, breaths):
        byBreath = [['breath#', 'annotation']]
        for row in self.a[1:]:
            time = row[0]
            for i in range(len(breaths)):
#                print'-----', breaths[i] < eval(time)
                if i==0:
                    upper = breaths[i+1]/2
                    if breaths[i] <= eval(time) and eval(time) < upper:
#                        print time, ' between', breaths[i], breaths[i+1]
                        byBreath.append([i, row[2]])
                if i>=len(breaths)-1:
                    lower = np.mean([breaths[i-1], breaths[i]])
                    if lower <= eval(time):
#                        print time, ' more than', breaths[i]    
                        byBreath.append([i, row[2]])
                else:
                    upper = np.mean([breaths[i], breaths[i+1]])
                    lower = np.mean([breaths[i-1], breaths[i]])
                    if lower <= eval(time) and eval(time) < upper:
#                        print i, time, ' between', breaths[i], breaths[i+1]
                        byBreath.append([i, row[2]])
        self.byBreath = byBreath
        self.byBreath_a = np.array(byBreath)


class compareTwo(object):
    """
    DEPRECATED with new matrix output. See dla_dev.py or functions in next section.
    written 2015/06/03 to compare GS and detected
    """
    def __init__(self, gs, det):
        self.title = gs.annotator + ' vs. ' +det.annotator

    def align_two(self, gs, det):
        """
        
        """
        N = np.array(['breath#', 'gs', 'dt'])
        breaths = []
        
        for row in gs[1:]:
            newrow= [row[0], row[1], 'NONE']
            N=np.vstack((N,newrow))
            breaths.append(row[0])    
            
        for row in det:
            if str(row[0]) in N[:,0]:
                itemindex = np.where(N[:,0] == str(row[0]))
                N[itemindex,2] = row[1]
    #            print ('%s in %s') %(row[0], itemindex)
            else:
    #            print '%s not here' %(row[0])
                newrow = [row[0], 'NONE', row[1]]
                N = np.vstack((N, newrow))   
        self.aligned = N #(~)values are still unsorted
    def toCoded(self, codes):
        N = []
        for row in self.aligned:
            N.append(repl_names(row, codes))
        N = np.array(N)    
        self.aligned_coded = N
            
        
#        self.aligned_coded = aligned_coded
    def c_kappa(self,aligned, codes):
        true = aligned[1:,1]
        pred = aligned[1:,2]
        y_true = repl_names(true, codes)
        y_pred = repl_names(pred, codes)    
        cm = sklearn.metrics.confusion_matrix(y_true, y_pred)
        ckap_results=  statsmodels.stats.inter_rater.cohens_kappa(cm)   
        self.cm = cm
        self.ckap_results = ckap_results

    def plotCohen(self, aligned, codes, cmap = 'seismic_r'):
        title = self.title
        
        reverse_codes = {v:k for k, v in codes.items()}
        true = aligned[1:,1]
        pred = aligned[1:,2]
        
        accuracy = sklearn.metrics.accuracy_score(true,pred)
        
        y_true = repl_names(true, codes)
        y_pred = repl_names(pred, codes)    
    
        both = y_true + y_pred
        legend, axis_labels = extractLegend(both, codes)        
        cm = self.cm
        ckap_results=  self.ckap_results
    
        #plot heatmap
        fig = plt.figure(figsize=(10,5))
        
        ax1=plt.subplot(1, 3, 1, aspect=1)
        ax1.matshow(cm, cmap='seismic_r')
        ax1.set_title('Confusion Matrix: '+'\n'
            +title + '\n')
        ax1.set_ylabel('True')
#        ax1.set_xticks(range(5), labels)
        ax1.set_xlabel('Pred')
        x1, x2 = ax1.get_xlim()
        y1, y2 = ax1.get_ylim()
#        ax1.plot(ax1.get_xlim(),ax1.get_ylim(), color = 'white')
        ax1.plot([x1,x2], [y2,y1], color = 'gray')
        plt.sca(ax1)
        plt.xticks(range(1,6), axis_labels, color = 'gray')
        plt.yticks(range(1,6), axis_labels, color = 'gray')
        #overlay confusion matrix values
        for y in range(cm.shape[0]):
            for x in range(cm.shape[1]):
                plt.text(x, y, '%d' % cm[y, x],
                         horizontalalignment='center',
                         verticalalignment='center',
                         color='white'
                         )
        
        #colorbar
        divider = make_axes_locatable(plt.gca())
        cax = divider.append_axes("right", size="10%", pad=0.2)
        plt.colorbar(ax1.matshow(cm, cmap=cmap),cax=cax)
        
        #print key in box 2
        plt.subplot(1, 3, 2, aspect=1)
        plt.axis('off')
        plt.text(0, 1, 'accuracy: '+ str(accuracy*100)+ '%')
        
        plt.text(0,0.9, 'legend\n-----------', ha='left', va='top')
        i=0.7
        for row in legend:
            row_formated=str(row[0])+': '+str(row[1])
            plt.text(0,i, row_formated, fontsize=12, ha='left', va='top')
            i=i-0.1
        #plt.text(0.5,1,cm, fontsize=12)     
        
        #print cohen's kappa results in 3rd box
        
        plt.subplot(1, 3, 3, aspect=1)
        plt.text(0,0, ckap_results, fontsize=10)
        plt.axis('off')
        fig.show()        
#    def plotPVI(self, color_code):
        
class evalSubsets(object):
    """
    """
    def __init__(self, aligned, title, codes, clinValues):
        self.title = title
        self.anns_analyzed =[]
#        self.aligned = aligned #~may need to integrate with compare2
                 
                
        ann_cols = range(1,len(aligned[0])) #~may need to change depending on where annotations start
        true = repl_names(aligned[1:,1], codes)
        aligned_coded = copy.deepcopy(aligned)
#
        combined = []
        for ann in ann_cols:
            aligned_coded[1:,ann] = repl_names(aligned_coded[1:,ann],codes)
            add = aligned_coded[1:,ann].tolist()
            combined += add            
#            
#        self.aligned_coded = aligned_coded
#        self.combined = combined #~to speed up, consider unique
    
        legend, axis_labels = extractLegend(combined, codes) #replace with true if only looking at __-
        legend = np.array(legend)
        
        total_pvis = len(aligned) -1
        total_breaths = len(clinValues)-1
        
        for ann in ann_cols[1:]:
            self.anns_analyzed.append('ann'+str(ann-1))

            output_dict= {}
            for pvi in legend[1:,1]: #skips NONE
                mask_true = np.where(aligned[:,1] == pvi) #~ change if have breath intervals
                mask_pred = np.where(aligned[:,ann] == pvi)
                union = np.union1d(mask_true[0], mask_pred[0])                
                subset = np.take(aligned, union, axis=0)
                tp = 0
                fp = 0
                tn = total_breaths - total_pvis
                fn = 0
                sensitivity = 'NA'
                specificity = 'NA'
                ann_eval = [['ann_eval']]
                true_count = 0


                true_column = aligned[1:, 1]
                pred_column = aligned[1:, ann]

                for true, pred in zip(true_column, pred_column):
                    if true == pvi:
                        true_count +=1
                        if pred == pvi: 
                            tp +=1
                            ann_eval.append(['tp'])
                        if pred != pvi: 
                            fn +=1
                            ann_eval.append(['fn'])
                    if true != pvi:
                        if pred !=pvi:
                            tn +=1
                            ann_eval.append(['tn'])
                        if pred == pvi:
                            fp +=1
                            ann_eval.append(['fp'])
                
                ann_eval = np.array(ann_eval)
                aligned_eval = np.hstack((aligned, ann_eval))

                output_dict[str(pvi) + '_pvi'] = aligned_eval #subset
                
                accuracy = (tp+tn)/total_breaths
                if tp + fn != 0:
                    sensitivity = tp/(tp + fn)
                if tn + fp != 0:
                    specificity = tn/(tn + fp)
#                print 'accuracy: %s, sens: %s, spec: %s' %(accuracy, sensitivity, specificity)
#                print '-------\n'
                stats=np.array([['---','actual: %s , #ofPVIs: %s' %(true_count, total_pvis)],
                                ['accuracy', accuracy], 
                                ['sensitivity', sensitivity], 
                                ['specificity', specificity],
                                ['counts', 'tp: %s, fp: %s, tn: %s, fn: %s' % (tp, fp, tn, fn)]])
                output_dict[str(pvi) + '_stats'] = stats
                output_dict['_legend'] = legend
#                print pvi, accuracy*100, '%'
            setattr(self, 'ann'+str(ann-1), output_dict)  
    def print_stats (self):
#        for k, v in vars(self).items():
#            print k
#        return self.__getattribute__
        list_of_anns = self.anns_analyzed
        print 'annotations analyzed:  %s' % list_of_anns
        for ann_name in list_of_anns:
            print '========== %s ===========' % ann_name
            ann = getattr(self, str(ann_name))
            for key in ann:
                if key.endswith('_stats'):
                    print '------ %s ------' %key
                    print ann[key]
    def print_pvis(self):
        list_of_anns = self.anns_analyzed
        print 'annotations analyzed:  %s' % list_of_anns
        for ann_name in list_of_anns:
            print '========== %s ===========' % ann_name
            ann = getattr(self, str(ann_name))
            for key in ann:
                if key.endswith('_pvi'):
                    print '------ %s ------' %key
                    print ann[key]
    def print_ann(self, which = []):
        list_of_anns = self.anns_analyzed
        if which == []:
            print 'Which would you like to print? \n all, %s' % list_of_anns
            prompt = '  >'
            chosen_anns = raw_input (prompt)
            if chosen_anns == 'all':
                for ann_name in list_of_anns:
                    return getattr(self, str(ann_name))                    
            return getattr(self, str(chosen_anns))
        elif which == 'all':
            for ann_name in list_of_anns:
                return getattr(self, str(ann_name))
        elif which =='pass':
            pass
        else:
            print "wrong thing inputted"
            raise
            
        
def extractLegend(combined_list, codes):
    """
    extracts unique PVIs occurring in a list of codes
    must be in form [1,2,3, 6..., 8] etc.
    Written: 2015/06/03 w/vd_dev
    """
    reverse_codes = {v:k for k, v in codes.items()}
    
    bincount = np.bincount(combined_list)
    
    legend = []
    axis_labels = [''] #for some reason xticks skips the first value
    
    for i in range(len(bincount)):
        if bincount[i]!=0:
            legend.append([i, reverse_codes[i]])
            axis_labels.append(reverse_codes[i])
    return legend, axis_labels

def repl_names(inputlist, abbreviations):
    """
    Replaces names in a list and outputs a new list.
###examples
c=repl_names(b,abbreviations)
a_adams[:,2]=repl_names(a_adams[:,2], abbreviations)
    Written: 2015/06/03 w/vd_dev
    """    
    
    c=[]
    
    for row in inputlist:
        #print(row)
        if row in abbreviations:
            c.append(abbreviations[row])
        else:
            c.append(row)
    inputlist=c
    return inputlist
    
#%% herein lie functions created during DLA-DEV after converting to matrix output
def countTP(true_column, pred_column):
    """
    compares a true vs. predicted when there are multiple classifications
    
    INPUTS:
    -true_column: list of strings, usually derived from gs
    -pred_column: list of strings, usually derived from combined or breath stacking alg
    
    RETURNS:
    -tp: # of true positives
    -fp: # of false positives 
    -tn: # of true negatives
    -fn: # of false negatives
    -mc: # of misclassified events

    EX:
        true = aligned.gs.values
        pred = aligned.comb.values
        tp, fp, tn, fn, mc, annEval = stats.countTP(true,pred )
        # count misclassified algs as true positives
        annEval = stats.repl_names(annEval, {'mc':'tp'})
        tp= tp+mc

    written 2015/07/17 for dla_dev
    """
    tp = 0
    fp = 0
    tn = 0
    fn = 0
    mc = 0 #misclassified
    
    annEval = []
    for true, pred in zip(true_column, pred_column):
        if true !='n':
            if pred == true:
                tp +=1
                annEval.append('tp')
            elif pred =='n':
                fn +=1
                annEval.append('fn')
            elif pred != true:
                mc +=1
                annEval.append('mc')
        if true =='n':
            if pred == 'n':
                tn +=1
                annEval.append('tn')
            elif pred !='n':
                fp +=1
                annEval.append('fp')
    if len(true_column)==tp+fn+mc+tn+fp:
        return tp, fp, tn, fn, mc, annEval       
    else:
        return "ERROR: counts don't add up to total"
def evalAlg(true_column, pred_column, pvi):
    """
    compares a true vs. predicted when predicted only has one classification
    
    INPUTS:
    -true_column: list of strings, usually derived from gs
    -pred_column: list of strings, usually derived from one algorithm
    
    RETURNS:
    -tp: # of true positives
    -fp: # of false positives 
    -tn: # of true negatives
    -fn: # of false negatives

    written 2015/07/17 for dla_dev
    """
    tp = 0
    fp = 0
    tn = 0
    fn = 0
    
    annEval=[]
    for true, pred in zip(true_column, pred_column):
        if true == pvi:
            if pred == pvi: 
                tp +=1
                annEval.append('tp')
            if pred != pvi: 
                fn +=1
                annEval.append('fn')
        if true != pvi:
            if pred !=pvi:
                tn +=1
                annEval.append('tn')
            if pred == pvi:
                fp +=1
                annEval.append('fp')
    if len(true_column)==tp+fn+tn+fp:
        return tp, fp, tn, fn, annEval
    
    else:
        return "ERROR: counts don't add up to total. Check for additional PVI flags"
        
def binaryMetrics(tp,fp,tn,fn):
    """
    calculates 'metrics' such as sensitivity and specificity
    
    INPUTS:
    -TP, FP, TN and FN as determined by CountTP or Eval Alg
    - must be integers
    
    RETURNS:
    -ACC: accuracy
    -TPR: True Positive Rate
    
    EX:
        tp, fp, tn, fn, mc, annEval = stats.countTP(true,pred )
        annEval = stats.repl_names(annEval, {'mc':'tp'})
        tp= tp+mc
        ACC,TPR,TNR,PPV,NPV = stats.binaryMetrics(tp,fp,tn,fn)
    """
    totalBreaths = tp+fp+tn+fn
    ACC = (tp+tn)/totalBreaths #accuracy
    TPR='div0'
    TNR='div0'
    PPV='div0'
    NPV='div0'
    if tp + fn != 0:
        TPR = tp/(tp + fn) #sensitivity
    if tn + fp != 0:
        TNR = tn/(tn + fp) #specificity
    
    if tp + fp !=0:
        PPV = tp/(tp+fp)
    if fn + tn !=0:
        NPV = tn/(fn+tn)
    return ACC,TPR,TNR,PPV,NPV
    
def makeCoords(text,origCol,BSs):
    xloc=[]
    yloc=[]    
    for i in range(len(text)):
        if isinstance(text[i],str):
            xloc.append(BSs[i])
            yloc.append(origCol)
        else:
            xloc.append(np.nan)
            yloc.append(np.nan)
    return xloc, yloc