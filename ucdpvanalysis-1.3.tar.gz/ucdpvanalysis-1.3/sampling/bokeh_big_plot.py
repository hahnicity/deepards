# -*- coding: utf-8 -*-
"""
Created on Tue Jun 16 09:20:52 2015

@author: Keiko

run RR_variance before this
"""
# TODO: convert into two functions

from __future__ import division
import os
import numpy as np
import sys
import csv
sys.path.insert(0, r'C:\allMYfiles\My_Documents\GitHub\ucdpv\algorithms')
import SAM; reload(SAM)
sys.path.insert(0, r'C:\allMYfiles\My_Documents\GitHub\ucdpv\analysis')
#import dicts; 
#reload(dicts)
import stats; 
reload(stats)
#import pviplot;
#reload (pviplot)
#import matplotlib.pyplot as plt
#import mpld3
#from mpld3 import plugins
import time
import pandas as pd
import shutil

from bokeh.plotting import figure, output_notebook, show, output_file, ColumnDataSource
from bokeh.models import NumeralTickFormatter
from bokeh.models import LinearAxis, Range1d 
from bokeh.models import HoverTool
from collections import OrderedDict
root_dir=r'C:\allMYfiles\My_Documents\GitHub\sandbox4_sampling'
os.chdir(root_dir)

#%% big plot
# variables
breath_dict = breath_dict
output_subdir = 'output'
filename= 'rpi3'
output_file(os.path.join(output_subdir, filename +'plot.html'))


# read in time, flow, pressure waveforms
start_time = time.time()
wave_path = os.path.join(output_subdir,filename+'_plain.csv')
#wave = stats.readWaveform(wave_path, 'rpi3.csv') #this was much slower
df_big = pd.read_csv(wave_path, names = ['time', 'flow', 'pressure'])
run_time=(time.time() - start_time)


# split columns into individual df's
t= df_big['time'] #converting to a list is quicker for get index
pressure = df_big['pressure']
flow = df_big['flow']
tlist = []
for row in t:
    tlist.append(round(row,2))

#%%
# default values
interval = 'all'
render = False
hover = False

# new values
interval = [250,350]
#interval = 'all'
#render = 10
#good examples --100 breaths + render = 10

# slices time, pressure and flow according to interval type
x=[]; y=[]; z=[]
if interval == 'all':
    title = "All %d breaths" % (len(breath_dict))
    x = t[::render]
    y1 = pressure[::render]
    y2 = flow [::render]
    
    startBN = 0
    endBN = max(breath_dict)
    print 'plot all'
    
elif type(interval) ==list:
    startBN = interval[0]
    endBN = interval[1]
    title = "breaths %d : %d" % (startBN, endBN)
    
    #convert BNs to indices
    startBS = breath_dict[startBN][0] 
    endBS = breath_dict[endBN] [0]    
    Lindex = tlist.index(startBS)
    Rindex = tlist.index(endBS)    
    x = t[Lindex:Rindex]
    y1 = pressure[Lindex:Rindex]
    y2 = flow [Lindex:Rindex]
    
    if render >0:
        x = x[::render]
        y1 = y1[::render]
        y2 = y2 [::render]
        print 'rendering 1/%s row' %render
    print 'plot interval'
elif type(interval) == int:
    #title = "breaths %d : %d" % (subsetN, startBN, endBN)
    print 'plot subset'
    pass

#this plots only every fifth breath of based on the chosen interval
BSs=[]
BNs=[]
for k, v in breath_dict.items():
    if k%5 ==0 and k>=startBN and k<=endBN:    
        BS, IE = v
        BSs.append(round(BS,2))
        BNs.append(k)

source = ColumnDataSource(
    data = dict(
        x = x,
        y1 = y1,
        y2 = y2)
) 
# original bokeh graph developed, runs faster
if hover == False:
    p = figure(plot_width=700, plot_height=300, tools = " pan,  xwheel_zoom,reset",
                  title = title, y_range=(-100,200))
    p.line(x, y1, line_width=2, legend = 'pressure', line_color="purple",
           y_range_name = "pressure")
    p.extra_y_ranges = {"pressure": Range1d(start = -70, end =30)}
    p.add_layout(LinearAxis(y_range_name="pressure"), 'left')
    p.line(x, y2, line_width=2, legend = 'flow')
    p.text(x=BSs, y= 180, text =BNs, text_font_size="10pt") 
    show(p)    
# this bokeh plot has hover and crosshair, typically runs slower      
if hover == True:   
    p = figure(plot_width=700, plot_height=300, tools = " pan,  xwheel_zoom, crosshair, hover,reset",
                  title = title, y_range=(-100,200))
     
    p.line('x', 'y1', line_width=2, legend = 'pressure', line_color="purple",
           y_range_name = "pressure", source = source)
    p.extra_y_ranges = {"pressure": Range1d(start = -70, end =30)}
    p.add_layout(LinearAxis(y_range_name="pressure"), 'left')
    p.line('x', 'y2', line_width=2, legend = 'flow', source = source)
    p.text(x=BSs, y= 180, text =BNs, text_font_size="10pt")

    hover = p.select(dict(type = HoverTool))
    hover.tooltips = OrderedDict([
     #    ("time", "@x"),
        ("pressure", "@y1"),
        ("flow", "@y2")
    ])
                 
    show(p)  
              

 

 
