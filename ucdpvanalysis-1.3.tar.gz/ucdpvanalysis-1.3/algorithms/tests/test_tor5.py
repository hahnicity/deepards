from glob import glob
import os
from time import time

import pandas as pd

from algorithms.breath_meta import get_file_breath_meta
from algorithms.raw_utils import extract_raw
from algorithms.tests import constants
from algorithms.TOR3 import detectPVI as tor3_detectPVI

from algorithms.tor5 import __version__
from algorithms.tor5 import detectPVI as tor5_detectPVI
from algorithms.tor5 import perform_tor_with_bs_be as tor5_main

from utilikilt.custom_compare import assert_dfs_equal
from utilikilt.oz import fancy_get_file_names
from algorithms.rounding_rules import force_round_df2

class TestTOR(object):
    def setup(self):
        # what does this do?
        self.file = None
        self.temp_output_dir = os.path.join(os.path.dirname(__file__),
            r"samples/temp_output_dir")
        try:
            os.mkdir(self.temp_output_dir)
        except OSError:
            pass
        self.control_subdir = None

    def test_tor5_fast_short_jimmy_file(self):
        self.file = constants.JIMMY_TEST

        # Make sure that tor5 can even run
        self.perform_comparison(constants.JIMMY_TEST, constants.JIMMY_TEST_TOR5)

    # def test_tor5_with_timestamps(self):
    #     self.file = constants.WITH_TIMESTAMP

    def test_tor5_pt17(self):
        self.file = constants.PT0017_1to1000_CSV
        self.control_subdir = constants.PT0017_SUBDIR
        tor5_main(self.file, [301,599], self.temp_output_dir, 64, "female")
        self.run_tor5_steps_and_compare()

    def test_tor5_pt149(self):
        self.file = constants.PT0149_CSV
        self.control_subdir = constants.PT0149_SUBDIR
        tor5_main(self.file, [], self.temp_output_dir, 64, "female")
        self.run_tor5_steps_and_compare()

    def test_tor5_pt174(self):
        self.file = constants.PT0174_CSV
        self.control_subdir = constants.PT0174_SUBDIR
        tor5_main(self.file, [1388,1688], self.temp_output_dir, 64, "female")
        self.run_tor5_steps_and_compare()

    # this is a 49mb file
    def test_tor5_pt0001(self):
        self.file = constants.PT0001_CSV
        self.control_subdir = constants.PT0001_SUBDIR
        tor5_main(self.file, [6660,6699], self.temp_output_dir, 64, "female")
        self.run_tor5_steps_and_compare()

    def test_tor5_pt0001_deriv_range(self):
        # this file/breath range in particular posed problems from the derivation cohort
        # note: this was originally ran on file 0001_10_17_19_3.csv,
        # 0001_2015-02-19-10-17-19_.csv_test is the same file with a different name

        self.file = constants.PT0001_1to8000_CSV
        self.control_subdir = constants.PT0001_SUBDIR_DERIV
        tor5_main(self.file, [4280, 4578], self.temp_output_dir, 64, "female")
        self.run_tor5_steps_and_compare()

    def test_tor5_pt18(self):
        self.file = constants.PT0018_CSV
        self.control_subdir = constants.PT0018_SUBDIR
        tor5_main(self.file, [7301,7599], self.temp_output_dir, 64, "female")
        self.run_tor5_steps_and_compare()

    def test_tor5_pt23(self):
        self.file = constants.PT0023_CSV
        self.control_subdir = constants.PT0023_SUBDIR
        tor5_main(self.file, [], self.temp_output_dir, 64, "female")
        self.run_tor5_steps_and_compare()

    def test_tor5_pt282(self):
        self.file = constants.PT0282_CSV
        self.control_subdir = constants.PT0282_SUBDIR
        tor5_main(self.file, [], self.temp_output_dir, 64, "female")
        self.run_tor5_steps_and_compare()

    def test_tor5_pt311(self):
        self.file = constants.PT0311_CSV
        self.control_subdir = constants.PT0311_SUBDIR
        tor5_main(self.file, [], self.temp_output_dir, 64, "female")
        self.run_tor5_steps_and_compare()

    def test_tor5_speed_pt18(self):
        desired_time = 15
        self.file = constants.PT0018_CSV
        self.control_subdir = constants.PT0018_SUBDIR
        start = time()
        tor5_main(self.file, [7301,7599], self.temp_output_dir, 64, "female")
        elapsed = time() - start
        assert elapsed <= desired_time, \
               "Failed speed test! total elapsed time: {}. desired time: {}".\
               format(elapsed, desired_time)
        self.run_tor5_steps_and_compare()

    def test_tor5_speed_pt1(self):
        desired_time = 15
        self.file = constants.PT0001_1to8000_CSV
        self.control_subdir = constants.PT0001_SUBDIR_DERIV
        start = time()
        tor5_main(self.file, [4280, 4578], self.temp_output_dir, 64, "female")
        elapsed = time() - start
        assert elapsed <= desired_time, \
               "Failed speed test! total elapsed time: {}. desired time: {}".\
               format(elapsed, desired_time)
        self.run_tor5_steps_and_compare()

    def run_tor5_steps_and_compare(self):
        # No testing of breath meta because we are making continuous improvements
        # to algos there and they might break existing tests. As long as changes
        # do not affect TOR algo then it doesn't matter.
        self.import_and_assert_equivalent("*raw.csv")
        self.import_and_assert_equivalent("*raw_multi_frame.csv")
        self.import_and_assert_equivalent("*raw_multi_frame2.csv")
        self.import_and_assert_equivalent("*solo.csv")
        self.import_and_assert_equivalent("*solo2.csv")
        self.import_and_assert_equivalent("*solo3.csv")

    def import_and_assert_equivalent(self, output_step):
        try:
            control_output = glob(os.path.join(self.control_subdir,
                output_step+"_test"))[0]
        except:
            raise IOError('-%s- does NOT exist in %s.' % (output_step,
                self.control_subdir))
        try:
            result_output = glob(os.path.join(self.temp_output_dir,
                output_step))[0]
        except:
            raise IOError('-%s- does NOT exist in %s.' % (output_step,
                self.temp_output_dir))

        # import files
        control_df = pd.read_csv(control_output)
        result_df = pd.read_csv(result_output)

        # in case there are additional columns in new output
        result_df = result_df[control_df.columns]

        # force rounding for decreased sensitivity to small differences in numbers
        control_df = force_round_df2(control_df)
        result_df = force_round_df2(result_df)
        # result_df = result_df[control_df.columns]
        assert_dfs_equal(control_df, result_df, additional_cols=['ventBN'])

    # --------------------------------------------------------------
    def perform_comparison(self, test_file, comparator):
        self.file = test_file
        # generate tor data
        gen = extract_raw(open(self.file), False)
        tor5_detectPVI(gen, self.file)
        # compare class matrix raw
        self.assert_class_matrices_equivalent(comparator)

    def assert_class_matrices_equivalent(self, tor3_filename):
        result = pd.read_csv(self.get_class_matrix_filename())
        comparator = pd.read_csv(tor3_filename)
        # result = result[comparator.columns]
        assert_dfs_equal(comparator, result)

    def get_class_matrix_filename(self):
        splitext = os.path.splitext(self.file)[0]
        fancy_version = __version__.replace('.', '_')
        file = os.path.join(os.path.dirname(__file__), "samples",
            "{}_v{}__solo3.csv".format(splitext, fancy_version))
        return file

    # ------------------------------------------------------------------
    def teardown(self):
        # remove output files (that aren't in a temp dir)
        splitext = os.path.splitext(self.file)[0]
        fancy_version = __version__.replace('.', '_')
        files = glob(os.path.join(os.path.dirname(__file__), "samples",
            "{}_v{}*".format(splitext, fancy_version)))
        for file in files:
            os.remove(file)

        # remove output files that are in a temp dir
        files_in_temp_dir = glob(os.path.join(self.temp_output_dir,"*"))

        if files_in_temp_dir !=[]: # check if there are files
            for file_ in files_in_temp_dir:
                os.remove(file_)

        os.removedirs(self.temp_output_dir)
