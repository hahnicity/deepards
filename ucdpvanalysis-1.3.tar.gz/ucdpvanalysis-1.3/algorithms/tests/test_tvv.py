import os
from glob import glob
import pandas as pd

from algorithms.tvv import add_tvvs_to_csv
from algorithms.tests.constants import (
    PT0174_BREATH_META_FUSED,
    PT0174_SOLO3_FUSED,
    PT0174_SOLO3_FUSED_TVV,
    PT0174_CSV,
    PT0174_SUBDIR)
from utilikilt.custom_compare import assert_dfs_equal

class TestTVV(object):
    def setup(self):
        self.file = None
        self.temp_output_dir = os.path.join(os.path.dirname(__file__),
                                            r"samples/temp_output_dir")
        try:
            os.mkdir(self.temp_output_dir)
        except OSError:
            pass
        self.control_subdir = None

    def teardown(self):
        # remove output files that are in a temp dir
        files_in_temp_dir = glob(os.path.join(self.temp_output_dir, "*"))

        if files_in_temp_dir != []:  # check if there are files
            for file_ in files_in_temp_dir:
                os.remove(file_)

        os.removedirs(self.temp_output_dir)

    def test_tvv_contained(self):
        breath_meta_df = pd.read_csv(PT0174_SOLO3_FUSED_TVV)
        pbw = 61.6
        # exporting to csv makes the comparison easier
        add_tvvs_to_csv(
            PT0174_BREATH_META_FUSED,PT0174_SOLO3_FUSED, 61.6,
            output_subdir=self.temp_output_dir)

        tvv_path = glob(os.path.join(self.temp_output_dir, "*tvv.csv"))[0]

        # import the two as csvs 
        tvv_control = pd.read_csv(PT0174_SOLO3_FUSED_TVV)
        tvv_new = pd.read_csv(tvv_path)

        assert_dfs_equal(tvv_control, tvv_new)


