"""
SAM
~~~

Supportive functions for algorithms in TOR
"""
from __future__ import division
from copy import copy
import csv
import math
import sys

import numpy as np
from scipy.integrate import simps
from scipy.stats import linregress
from pandas import DataFrame

from utilikilt.integrate import fast_integrate

# XXX remove this
__version__="1.2.4"


def calc_pressure_itime(t, pressure, peep, threshold):
    if peep == 0:
        return t[-1]
    # find first point
    first_idx, last_idx = 0, -1
    # get first point where pressure goes <threshold> above peep
    for idx, val in enumerate(pressure[::-1]):
        if val >= peep + threshold:
            last_idx = len(pressure) - (idx + 1)
            break
    if last_idx == -1:
        return np.nan
    return t[last_idx] - t[first_idx]


def calc_pressure_itime_by_pip(t, pressure, pip, threshold):
    # lets just assume inspiration starts at 0
    first_idx, last_idx = 0, -1
    # get first point where pressure goes <threshold> below  pip
    for idx, val in enumerate(pressure[::-1]):
        if val >= pip - threshold:
            last_idx = len(pressure) - (idx + 1)
            break
    if last_idx == -1:
        return np.nan
    return t[last_idx] - t[first_idx]


def calc_pressure_itime_by_dyn_threshold(t, pressure, pip, peep, frac):
    """
    Calculate the pressure itime by calculating a threshold based on a
    fraction of the pip - peep difference. This algorithm is also
    improved when median peep and median pip are provided since they
    are more robust against asynchrony
    """
    threshold = (pip - peep) * frac
    return calc_pressure_itime_by_pip(t, pressure, pip, threshold)


def calc_pressure_itime_from_front(t, pressure, pip, peep, frac):
    if len(pressure) == 0:
        return np.nan
    threshold = (pip - peep) * frac
    first_idx, last_idx, passed_thresh = 0, -1, False
    # get first point where pressure goes <threshold> below  pip
    for idx, val in enumerate(pressure):
        if val >= pip - threshold and not passed_thresh:
            passed_thresh = True
        elif passed_thresh and val < pip - threshold:
            last_idx = idx + 1 if idx + 1 < len(pressure) else idx
            break
    if last_idx == -1:
        return np.nan
    return t[last_idx] - t[first_idx]


def check_if_plat_occurs(flow, pressure, dt, min_time=.2, flow_bound=.5):
    """
    Check if there is an inspiratory plateau pressure for a breath

    :param flow: array vals of flow measurements in ml/s
    :param pressure: array vals of pressure measurements from vent
    :param dt: time delta between obs
    :param min_time: the minimum amount of time a plat must be held for
    :param flow_bound: if any points go below 0 within tolerance of this value, quit
    """
    flow = np.array(flow)
    min_points = int(min_time / dt)
    found_plat = False
    skip_this_many = 10

    for idx, _ in enumerate(pressure[skip_this_many:-min_points]):
        idx = idx + skip_this_many
        is_plat = (np.logical_and(flow[idx:idx+min_points] < flow_bound, flow[idx:idx+min_points] > -flow_bound)).all()
        if is_plat:
            return True
        below_flow_tol = (flow[idx:idx+min_points] < -flow_bound).all()
        # patient is probably exhaling, and theres no insp pause
        if below_flow_tol:
            break
    return False


def calc_inspiratory_plateau(flow, pressure, dt, min_time=.4, flow_bound=0.5):
    """
    Calculate the inspiratory plateau pressure for a breath

    :param flow: array vals of flow measurements in ml/s
    :param pressure: array vals of pressure measurements from vent
    :param dt: time delta between obs
    :param min_time: the minimum amount of time a plat must be held for
    :param flow_bound: if any points go below 0 within tolerance of this value, quit
    """
    flow = np.array(flow)
    min_points = int(min_time / dt)
    min_points_on_calc = 4
    found_plat = False
    skip_this_many = 10

    for idx, _ in enumerate(pressure[skip_this_many:-min_points]):
        idx = idx + skip_this_many
        is_plat = (np.logical_and(flow[idx:idx+min_points] < flow_bound, flow[idx:idx+min_points] > -flow_bound)).all()
        if is_plat:
            found_plat = True
        # This logic may be a bit confusing. What it means is, we found a plat, but
        # we want to run until the end of the plateau, because the true plateau
        # doesn't happen until the end of the insp. pause
        if found_plat and not is_plat:
            return sum(pressure[idx-1:idx-1+min_points_on_calc]) / min_points_on_calc

        below_flow_tol = (flow[idx:idx+min_points] < -flow_bound).any()
        # patient is probably exhaling, and theres no insp pause
        if below_flow_tol:
            break
    return np.nan


def calc_expiratory_plateau(flow, pressure):
    """
    Calculate the expiratory plateau pressure for a breath

    :param flow: array vals of flow measurements in ml/s
    :param pressure: array vals of pressure measurements from vent
    """
    min_f_idx = np.argmin(flow)
    pressure = np.array(pressure[min_f_idx:])
    flow = np.array(flow[min_f_idx:])
    flow_tolerance_band = 0.3
    peep_var_thresh = .002
    min_points = int(.4 / .02)
    found_plat = False
    for idx, val in enumerate(pressure[:-min_points]):
        is_plat = (np.logical_and(flow[idx:idx+min_points] < flow_tolerance_band, flow[idx:idx+min_points] > -flow_tolerance_band)).all()
        if is_plat:
            found_plat = True
        if found_plat and not is_plat:
            return sum(pressure[idx+min_points-6:idx+min_points-1]) / 5
    if found_plat:
        return sum(pressure[-5:]) / 5
    return np.nan


def find_x0_if_plat_in_vent(t, pressure, flow, dt, x0):
    zeros = []
    p_last = 0
    p_tolerance_band = 0.02
    flow_tolerance_band = 0.5
    for idx, p in enumerate(pressure):
        if p == 0:
            continue
        if (abs(p_last - p) / p < p_tolerance_band) and (abs(flow[idx]) < flow_tolerance_band) and t[idx] <= x0:
            zeros.append(t[idx])
        if len(zeros) * dt >= 0.4:
            last_t = t[int(zeros[0] / 0.02) - 1]
            return last_t
        p_last = p
    else:
        raise Exception("something something fix your method")


def calc_plat_from_time_constant(peep, pip, tvi, tau, pif):
    """
    PEEP + ((tvi * (pip - peep)) / (tvi + (TC * PIF)))
    """
    return peep + ((tvi * (pip - peep)) / (tvi + (tau * pif)))


def calc_pif(flow, x0):
    """
    Calculate the peak inspiratory flow. This calculation is pretty unvalidated.
    It works mainly from the perspective of time constants. On square ventilator
    waveforms then this works just fine. On pressure control we fallback on the
    magic constant where we take the last 15 points and take an average of them.
    """
    x0_start_idx = int((round(x0, 2) / .02)) - 1
    # 15 is just a magic constant. Lets see how it works
    #
    # All flows are in L/min so we convert to L/sec
    res_flows = map(lambda x: round(x / 60, 2), flow[x0_start_idx - 15:x0_start_idx + 1])
    return sum(res_flows) / len(res_flows) if res_flows else np.nan


def calc_resistance(pif, pip, plat):
    """
    The resistance is calculated as (pip - plat) / pif
    """
    if pif == 0:
        return np.nan
    return (pip - plat) / pif


def brunner(tve, e_time, f_min, iters):
    """
    Perform the recursive brunner function
    """
    if f_min == 0:
        return np.nan

    if tve == 0:
        return np.nan

    def _brunner():
        return (tve / 1000) / abs(f_min / 60)

    bru_0 = _brunner()
    # XXX I think if brunner_0 > 1 then we're basically bound for
    # exponential growth and non-convergence. So we should investigate this.
    bru = bru_0 * (1 / (1 - math.exp(-1 * e_time / bru_0)))
    for i in range(iters):
        denominator = (1 - math.exp(-1 * e_time / bru))
        if denominator == 0:
            return np.nan
        bru = bru * (1 / denominator)
    return bru


def al_rawas_expiratory_const(flow, x0_index, dt, tvi, linregress_tol):
    """
    Calculate the Al Rawas time constant (tau_E)

    :param flow: array vals of flow measurements in L/s
    :param x0_index: index where flow crosses 0
    :param dt: time delta between obs
    :param tvi: TVi in L/s
    :param linregress_tol: tolerance for the residual on linear regression
    """
    if len(flow[x0_index:]) <= int(.5 / dt):
        return np.nan
    flow = flow[x0_index:]
    start_idx = int(.1 / dt)
    end_idx = int(.5 / dt)
    vols = [tvi + fast_integrate(flow[0:i], dt) for i in range(2,len(flow[:end_idx+1]))]
    x = [abs(val) for val in flow[start_idx:end_idx]]
    regress = linregress(x, vols[start_idx-1:end_idx-1])
    if regress.rvalue < linregress_tol:
        return np.nan
    return regress.slope


def al_rawas_calcs(flow, pressure, x0_index, dt, pip, peep, tvi, compliance_idx, linregress_tol=.98):
    """
    Calculate compliance using al-rawas methodology

    :param flow: array vals of flow measurements in L/s
    :param pressure: array vals of pressure measurements from vent
    :param x0_index: index where flow crosses 0
    :param dt: time delta between obs
    :param pip: peak insp pressure
    :param peep: positive end expiratory pressure
    :param tvi: TVi in L
    :param compliance_idx: After computing the compliance curve, choose which indexwe want to use
    :param linregress_tol: tolerance for the residual on linear regression

    :returns tuple: tau, plat, compliance, resistance
    """
    if len(flow[:x0_index-1]) <= compliance_idx:
        return np.nan, np.nan, np.nan, np.nan
    tau = al_rawas_expiratory_const(flow, x0_index, dt, tvi, linregress_tol)
    vols = [0] + [fast_integrate(flow[0:i], dt) for i in range(2, len(flow)+1)]
    compliance_curve = [
        (vol + tau * flow[i]) / (max(pressure[:i+1]) - peep)
        for i, vol in enumerate(vols[:x0_index-1])
    ]
    compliance = compliance_curve[compliance_idx]
    resistance = tau / compliance
    plat = tvi * (1 / compliance) + peep
    return round(tau, 4), round(plat, 2), round(compliance, 4), round(resistance, 2)


def vicario_calcs(flow, pressure, x0_index, peep, tvi, tau):
    """
    Calculate plateau pressure, compliance, and resistance via Vicario's
    method.

    :param flow: array vals of flow measurements in L/s
    :param pressure: array vals of pressure obs
    :param x0_index: index where flow crosses 0
    :param peep: positive end expiratory pressure
    :param tvi: TVi in L
    :param tau: Time constant

    :returns tuple: plateau pressure, compliance, resistance
    """
    # return null if we get a point where the patient is clearly
    # exerting themselves
    if flow[0] > 1.0:
        return np.nan
    # Eventually will need error checking to ensure patient is finished
    # exhaling @ x0
    resistance = (pressure[x0_index-1] - pressure[0]) / ((tvi/tau) + flow[x0_index-1] - flow[0])
    elastance = resistance / tau
    compliance = 1 / elastance
    plat = tvi * elastance + peep
    return plat, compliance, resistance


def least_squares_method(flow, pressure, x0_index, dt, peep, tvi):
    """
    Calculate compliance, resistance, and K via standard single chamber
    model equation:

    P_vent = V(t)E + V_dot(t)R + K

    where K is some constant that is defined by PEEP + PEEPi + P_0

    XXX incorporate residual filtering

    This method is will work in more situations than other methods will,
    but it's also going to be the least accurate, especially when a patient
    is exerting force of their muscles

    :param flow: array vals of flow measurements in L/s
    :param pressure: array vals of pressure obs
    :param x0_index: index where flow crosses 0
    :param dt: time delta between obs
    :param peep: positive end expiratory pressure
    :param tvi: TVi in L

    :returns tuple: plateau pressure, compliance, resistance, K, residual
    """
    vols = [0] + [simps(flow[:i], dx=dt) for i in range(2, x0_index if x0_index <= len(flow) else len(flow))]
    a = np.array([vols, flow[:x0_index-1], [1] * (x0_index-1)]).transpose()
    least_square_result = np.linalg.lstsq(a, np.array(pressure[:x0_index-1]))
    solution = least_square_result[0]
    elastance = solution[0]
    plat = tvi * elastance + peep
    return plat, 1 / elastance, solution[1], solution[2], least_square_result[1]


def exp_consts_by_least_squares(flow, pressure, dt, points_to_use=20, min_exp_obs=40):
    """
    Experimental method to determine expiratory constants via least squares
    regression. Follows typical formula but uses end of expiratory waveform
    to gather results. We can subtract PEEP from K to find PEEPi.

    This method may not be effective in patients who are actively
    exhaling, like patients with COPD.

    :param flow: array vals of flow measurements in L/s
    :param pressure: array vals of pressure obs
    :param dt: time delta between obs
    :param points_to_use: last number of observations in pressure waveform to use
    :param min_exp_obs: the minimum number of expiratory observations we can have

    :returns tuple: compliance, resistance, K
    """
    if min_exp_obs < points_to_use:
        raise ValueError("Cannot have more points to use than minimum expiratory obserations!")
    # if breath doesn't look normal get rid of it
    vols = [0] + [fast_integrate(flow[:i], dt) for i in range(2, len(flow)+1)]
    min_idx = np.argmin(flow)
    if flow[min_idx] > (-20 / 60.0) or len(flow[min_idx:]) < 40:
        return np.nan
    flow = flow[-1 * points_to_use:]
    if len(flow) < points_to_use:
        return np.nan
    a = np.array([vols[-1 * points_to_use:], flow, [1] * len(flow)]).transpose()
    sol = np.linalg.lstsq(a, np.array(pressure[-points_to_use:]))[0]
    return 1 / sol[0], sol[1], sol[2]


def lourens_time_const(flow, x0_index, dt):
    """
    Calculate Lourens time constant for patients. Lourens performed her
    calculations on paralyzed COPD patients. So it might be helpful in
    this case.

    :param flow: array vals of flow measurements in L/s
    :param x0_index: index where flow crosses 0
    :param dt: time delta between obs

    :returns tuple: tau_.75, tau_.5, tau_.25
    """
    min_idx = flow.index(min(flow))
    flow = [abs(v) for v in flow[min_idx:]]
    vols = [0] + [fast_integrate(flow[0:i], dt) for i in range(2, len(flow)+1)]
    tve = vols[-1]
    one_quarter, half, three_quarter = tve / 4.0, tve / 2.0, tve * (3/4.0)
    quarter_idx, half_idx, three_quarter_idx = None, None, None
    for idx, v in enumerate(vols[1:]):
        if v > one_quarter and vols[idx-1] <= one_quarter:
            quarter_idx = idx
        elif v > half and vols[idx-1] <= half:
            half_idx = idx
        elif v > three_quarter and vols[idx-1] <= three_quarter:
            three_quarter_idx = idx
    tau_1 = (tve * .75) / (flow[quarter_idx] - flow[-1])
    tau_2 = (tve * .5) / (flow[half_idx] - flow[-1])
    tau_3 = (tve * .25) / (flow[three_quarter_idx] - flow[-1])
    return tau_1, tau_2, tau_3



def find_mean_flow_from_pef(flow, pef, t_offset):
    """
    Find the mean flow from our pef to end of expiration
    """
    idx = flow.index(pef) + int(t_offset / .02)
    remaining_flow = flow[idx:]
    if len(remaining_flow) == 0:
        return np.nan
    return sum(remaining_flow) / len(remaining_flow)


def find_slope_from_minf_to_zero(t, flow, pef, t_offset=0):
    """
    In lieu of a compliance measurement now we will calculate the slope from min
    flow to 0.
    """
    t_off_idx = int(t_offset / 0.02)
    min_idx = flow.index(pef) + t_off_idx
    try:
        flow_min = (t[min_idx], min_idx, flow[min_idx])
    except IndexError:
        return np.nan
    flow_zero = (0, 0, -1 * sys.maxsize)  # (time, idx, flow)

    for offset_idx, time in enumerate(t[flow_min[1]:]):
        idx = offset_idx + flow_min[1]
        if flow[idx] > flow_zero[2] and flow[idx] < 0:
            flow_zero = (time, idx, flow[idx])

    # this means there werent any new points in the flow after pef.
    if flow_zero == (0, 0, -1 * sys.maxsize):
        return np.nan

    # This means the pef and the flow min are the same point
    if (float(flow_zero[0]) - flow_min[0]) == 0:
        return np.nan

    slope = (float(flow_zero[2]) - flow_min[2]) / (float(flow_zero[0]) - flow_min[0])
    # means that we have a negative slope
    if slope < 0:
        return np.nan
    else:
        return slope


# 2015_06_22
def findx0(t, waveform, time_threshold):
    """
    Finds where waveform crosses 0 (changes from + to -)

    Args:
    t: time
    waveform: line to be analyzed
    time-threshold: upper limit (max value) for absolute value of time
    forward_dt: future point in waveform that must be negative

    Updated 2015/09/24 (SAM1.1.9) Stop evaluating if next value is nan
        (as in, non-data rows filled with 'nan' stop being considered as
         waveform[i+1])

    Updated 2015/09/11 and renamed SAM1_1_7; neg flow thresholds changed from
    <= -8 to <= -5 (note that 1st elif clause was found to be < -8 and was
    changed to be <= -5)

    Updated 2015/09/11 and renamed SAM1_1_6; included change in all clauses to
    replace <= to < signs. This dealt with run failures presumably due to
    trailing zeros at the end of the array. Also updated to include 0 in the
    definition of i to account for failures where the value just before the 1st
    neg value was 0 instead of positive.

    Updated 2015/09/09 and renamed SAM1_1_5 to signify SAM v1.1.5; included
    fourth elif clause to x0 logic to allow for cases in which flow 'dribbles'
    along at low values (e.g. -3) for a sustained period, never reaching -8
    threshold, but representing true exhalation event

    Updated 2015/09/04 2.2.6 Improve x0 function sensitivity with 3rd OR clause
        and smaller neg threshold
    Updated: 2015/09/03 2.2.4 Additional OR clause
    Updated: 2015/06/11
    Written: ?
    """
    t.extend([np.nan] * 6)
    waveform.extend([np.nan] * 6)
    cross0_time = []
    for i in range(len(waveform)-2): #if change to append scheme, will have to worry about -1 error
        if waveform[i]>=0 and waveform[i+1] is not np.nan:
            if waveform[i + 1] <= -5 and waveform[i + 2] < 0:
                    cross0_time.append(t[i + 1])
            elif waveform[i + 1]<0 and waveform[i + 4] <= -5:
                    cross0_time.append(t[i + 1])
            elif waveform[i+1]<0 and waveform[i+2]<=-5:
                    cross0_time.append(t[i + 1])
            elif waveform[i+1]<0 and waveform[i+2]<0 and waveform[i+3]<0 and \
                waveform[i+4]<0 and waveform[i+5]<0:
                    cross0_time.append(t[i + 1])

    i = 0
    while i <= len(cross0_time) - 2:
        if abs(cross0_time[i] - cross0_time[i + 1]) < time_threshold:
            del cross0_time[i + 1]
        else:
            i += 1

    for i in range(6):
        t.pop(-1)
        waveform.pop(-1)
    return cross0_time


def findx02(wave,dt):
    """
    Finds where waveform crosses 0 after largest portion contiguous positive AUC

    Args:
    wave: line to be analyzed (ex. flow)

    V1.0 2015-09-23 (2.0) SAM 1.1.8
    Find x02 separates the the wave into positive portions and negative portions.
    The largest positive portion will be considered the inspiratory portion.

    V1.1 2015-10-27 (2.1) SAM 1.2.0
    Utilizes AUC instead of just duration/length of portion

    20150615-V1.1 SAM 1.2.3 default for x0_index is []
    """
    posPortions=[] #holds all positive portion arrays
    negPortions=[] #holds all negative portion arrays
    hold=[] #holding array that is being built
    largestPos=0 #eventually becomes the largest pos AUC (tvi)
    largestNeg=0 #eventually becomes the largest neg AUC (tve)
    x0_index=[] #index where x0 occurs

    for i in range(len(wave)-1): #for each value in the wave
        if wave[i]>0: # if the value is greater than 0, it is considered positive
            hold.append(wave[i]) # and will be added to the holding array
            sign = 'pos'
        else: # if the value isn't greater than 0, it is considered negative
            hold.append(wave[i]) # and will be added to the holding array
            sign = 'neg'

        if wave[i+1]>0: #determine the sign of the next value in the wave
            nextSign = 'pos'
        else:
            nextSign = 'neg'

        if sign != nextSign: #if the sign is different than the sign of next value
            # save the holding array
            if sign=='pos':
                posPortions.append(hold)
                #calculate areas under the curve (tvi)
                holdAUC = simps(hold, dx=dt)*1000/60 #1000ml/L, 60 sec/min
                if holdAUC>largestPos: #if holding array has largest AUC
                    largestPos=holdAUC #it is now considered the largest AUC array
                    x0_index=i+1 #x0 will be considered time + 1
            if sign =='neg': # similar to positive
                negPortions.append(hold)
                holdAUC = simps(hold, dx=dt)*1000/60 #1000ml/L, 60 sec/min
                if holdAUC<largestNeg:
                    largestNeg=holdAUC
            hold=[]
            #possibly add some additional thing here?
    return posPortions, negPortions, largestPos, largestNeg, x0_index
#    return posPortions, negPortions, longestPos,longestNeg, x0_index

def calcTV3(wave,dt,x02index):
    """
    Written 2015/10/27
    """
    tvi=0
    tve=0
    hold=[] #holding array
    for i in range(len(wave)-1):#for each value in the wave
        if wave[i]>0: # if the value is greater than 0, it is considered positive
            hold.append(wave[i]) # and will be added to the holding array
            sign = 'pos'
        else: # if the value isn't greater than 0, it is considered negative
            hold.append(wave[i]) # and will be added to the holding array
            sign = 'neg'

        if wave[i+1]>0: #determine the sign of the next value in the wave
            nextSign = 'pos'
        else:
            nextSign = 'neg'

        if sign != nextSign: #if the sign is different than the sign of next value
            if i<x02index and sign=='pos':
                holdAUC = simps(hold, dx=dt)*1000/60 #1000ml/L, 60 sec/min
                tvi+=holdAUC
            elif i>=x02index and sign =='neg':
                holdAUC = simps(hold, dx=dt)*1000/60 #1000ml/L, 60 sec/min
                tve+=holdAUC
            else:
                pass

    return tvi, tve
def writecsv(outputM, OUTPUT_FILE):
    """writes csv using CSV reader, requires python 2.7"""
    with open(OUTPUT_FILE, 'wb') as outputopen:
        outputwriter = csv.writer(outputopen, delimiter=',', quoting=csv.QUOTE_NONNUMERIC)
        for row in outputM:
            outputwriter.writerow(row)

    #print "'" + OUTPUT_FILE + "' written in" + '\n\t' + os.getcwd()

def isFlat(data, epsilon = 1, y=0):
    """
    Determines if a region is flat around the horizontal line y.

    This function is used in the delayed trigger algorithms

    ARGS:
    data: 1D list or array (ex. e_pressure)
    epsilon: upper/lower bound
    y: value that the data approaches

    RETURNS:
    flatLengths: list containing lengths of regions that meet criteria
    maxFlat: longest length (units: index numbers, NOT time)
    sumFlat: sum of flatLenghts, another way of measuring time spent near y

    written: 2015/05/23
    """
    flatLengths = []
    k = 0
    for row in data:
        if abs(row-y)<epsilon:
            k+=1
        else:
            if k>0:
                flatLengths.append(k)
                k = 0
    if flatLengths !=[]:
        maxFlat = max(flatLengths)
        sumFlat = sum(flatLengths)
    else:
        maxFlat = 0
        sumFlat = 0

    return flatLengths, maxFlat, sumFlat


def find_x0s_multi_algorithms(flow, t, last_t, dt):
    """
    Calculate x0s based on multiple algorithms

    versions
    20160503 V1 Original, from TOR 3.5.1
    20160613 V1.1 Disregard ts (time stamp)
    20160721 V1.2 Change output to dictionary
    20160722 V2 Make only output indices
    """
    x0_indices_dict = {}

    #index #1
    x01s = findx0(t, flow, 0.5)

    if x01s!=[]: #if x01 has multiple values, use the first value to mark end of breath
        x01index=t.index(x01s[0])
    else:# if breath doesn't cross 0 (eg. double trigger, nubbin)
        x01index = t.index(last_t) #???perhaps we should set to beginning of breath?

    #index #2
    pos,neg,FlowLargePos,FlowLargeNeg,x02index = findx02(flow,dt)
    if x02index==[]:
        x02index = len(flow) - 1

    #save output
    x0_indices_dict['x01index'] = x01index
    x0_indices_dict['x02index'] = x02index

    return x0_indices_dict


def x0_heuristic(x0_indices_dict,BN,t):
    """
    Determine which x0 to use
    20160503 V1 Original, from TOR 3.5.1
    20160716 V2 Remove ts dependency
    """

    x01index=int(x0_indices_dict['x01index'])
    x02index=int(x0_indices_dict['x02index'])

    # THIS IS ESPECIALLY IMPORTANT IN NUBBIN BREATHS
    if x02index>x01index:
        x0_index=x02index
        iTime=t[x02index]
    else:
        iTime=t[x01index]
        x0_index=x01index

    return iTime,x0_index

def is_cosumtvd(input_df, whichCosumtvd):
    """
    Adds 1 if COSUMTVD has been detected
    """
    #create empty data frame
    out_df = DataFrame(0,index=input_df.index,columns=input_df.columns)
    for BN in input_df.index:
        if whichCosumtvd=='any':
            if artifacts.any()>0:
                out_df.loc[BN,"cosumtvd"]=1

            else:
                out_df.loc[BN,"cosumtvd"]=0
        else:
            artifact_counter=0
            for artifact in whichCosumtvd:
                if input_df.loc[BN,artifact]!=0:
                    artifact_counter+=1

            if artifact_counter>0:
                out_df.loc[BN,"cosumtvd"]=1

            else:
                out_df.loc[BN,"cosumtvd"]=0
            artifact_counter=0

    return out_df



#-----
# DEPRECATED STUFF?
#-------
def find_plateau_length(data,maxHeight,percentThreshold=0,absThreshold=0):
    if percentThreshold!=0 and absThreshold!=0:
        pass
    elif percentThreshold!=0:
        threshold=percentThreshold*maxHeight
    elif absThreshold!=0:
        threshold=maxHeight-absThreshold
    else: #no threshold given
        pass


def calc_slopes(wave,dt=0.02):
    slopes=[]
    for i in range(len(wave)-1):
        slope=(wave[i+1]-wave[i])/dt

        slopes.append(slope)

    return slopes

def simple_rolling_average(wave, width):
    filtered_wave=[]

    for i in range(len(wave)-(width-1)):
        subset=wave[i:i+width]
        new_datapoint=np.mean(subset)
        filtered_wave.append(new_datapoint)

    return filtered_wave


def detect_pos_spike(wave):#,time_threshold,sd_threshold):
    mean=np.mean(wave)
    sd=np.std(wave)

    pos_spike=0
    longest_outlier_region=0
    outlier_counter=0
    regions=[]
    for i in range(len(wave)-1):
        if wave[i]>1*sd:
            outlier_counter+=1
        else:
            if outlier_counter>0:
                regions.append(outlier_counter)
                if outlier_counter>longest_outlier_region:
                    longest_outlier_region=outlier_counter

            outlier_counter=0

    if longest_outlier_region>2:
        pos_spike=1

    return pos_spike, regions



def detect_pos_spike_by_slope(slopes, delta_threshold):
    big_changes=[]
    isSpike=0
    for i in range(len(slopes)-1):
        if slopes[i]>0 and slopes[i+1]<0:
            big_changes.append(slopes[i]-slopes[i+1])
            delta=slopes[i]-slopes[i+1]
            if delta>delta_threshold:
                isSpike=1
    return isSpike


def where_spike(slopes, look_pos_spike=True, time_threshold=0.2,dt=0.02):
    """
    2016-06-06
    """
    i_threshold=time_threshold/0.02

    largest_pos_slope=max(slopes)
    largest_neg_slope=min(slopes)

    pos_index = slopes.index(largest_pos_slope)
    neg_index = slopes.index(largest_neg_slope)

    distance = neg_index-pos_index
    if look_pos_spike:
        if pos_index < neg_index and distance<=i_threshold:
            return pos_index
        else:
            return []
    else:
        if pos_index > neg_index and distance>= -i_threshold:
            return pos_index
        else:
            return []
