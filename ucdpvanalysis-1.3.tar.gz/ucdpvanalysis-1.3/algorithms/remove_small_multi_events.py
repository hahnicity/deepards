"""
20160416--DEPRECATED---moved to solo.py

Created on Mon Mar 1 4:41PM
@author: Keiko
"""


from pandas import DataFrame, read_csv

def remove(input_csv,artifact,output_csv=[],min_frame_threshold=3):
    """
    Removes multi-events that are less than/equal to a threshold-frames long
    For removal of false positive suctions and multiple triggers

    This function assumes that multi-events are not missing any numbers
    So it might not work as expected with "1,2,3,0,5"


    Args:
    ----
    input_csv:
     CSV to be processed
    output_csv:
     CSV to be written, default=overwrites input_csv
    artifact:
     PVA that will be processed
    frame_threshold:
     max number of frames an event can be and still be removed

    Versions:
    --------
    1 Written: 03/01/2016
    2 Updated 03/30/2016- 
    """

    if output_csv==[]:
        output_csv=input_csv

    #import CSV
    raw_df = read_csv(input_csv,index_col="BN")
    #create empty data frame
    output_df = DataFrame(0,index=raw_df.index,columns=raw_df.columns)

    for BN in raw_df.index:

        #copy values (in current BN) from original data frame to new data frame
        output_df.loc[BN]=raw_df.loc[BN].values.tolist()

        #save current frame annotation
        PVA_event_counter = raw_df.loc[BN,artifact] 

        #set the counter for the next BN
        if BN<max(raw_df.index):
            future_PVA_event_counter = raw_df.loc[BN+1, artifact]
        else:
            future_PVA_event_counter=0 #takes care of the last BN in frame
        
        #if current frame is the last of a multi-event
        if PVA_event_counter>future_PVA_event_counter:
            #and there are less frames than the threshold
            if PVA_event_counter < min_frame_threshold:
                for i in range(min_frame_threshold-1):
                    output_df.loc[BN-i,artifact]=0

    output_df.to_csv(output_csv)

#an example from command line
if __name__ == "__main__":
    from os import chdir, path
    root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox/20160301_stack_multi/'
    chdir(root_dir)
    input_csv=path.join(root_dir+'0007_file_1of1_2804to3202_3_2_1_removeMulti_class_matrix_raw_multi_frame.csv')
    output_csv=path.join(root_dir+'0007_file_1of1_2804to3202_3_2_1_removeMulti_class_matrix_raw_multi_frame2.csv')
    remove(input_csv,"mt",output_csv,min_frame_threshold=2)