"""
Created on Thu Jan 14 22:34:12 2016
From TOR2.py
Overall Versions
3.5.8 Make TOR3 functional again
3.5.7 Fusion debug diagnostic
3.5.6 Fix x02 fails to be at the end of the breath
3.5.5 Rounded values for breath meta
3.5.4 Add cosumtvd designation to multi_frame2
3.5.3 ALG Add BS 4.1-4.3
3.5.2.1 ALG Removed TVi close for dbl.3 for v_ctrl
3.5.2 ALG Rounded ratios for dbl,bs, & multi
3.5.1 Move findx0 into SAM
3.5.0 General code clean up
3.4.9 Fixing merge with Develop to make sure both codes work
3.4.8 Merge Greg's edits
3.4.7 MULTI select cosumtvd (artifact) exclusion
3.4.6 ALG Revert to old mt/su counter from ~3.3.4
3.4.5 ALG Revert to old mt/su counter from 3.3.6
3.4.4 Read 3 types of input raw files
3.4.3 Without cough in middles
3.4.2 ALG Remove cough during mt or su (multi-event)
3.4.1 ALG Cough 8.1-8.3 new itime and TVi thresholds
3.4.0 ALG Remove 3 frame mt, if cough is 2nd
3.3.9 Count cough in middle of mt or st
3.3.8 Move remove_small_multi_events to solo.py make for RAM df
3.3.7 ALG Add sumt and cosumtvd columns
3.3.6 ALG Make multi same alg as suction (mt.su)
3.3.5 Auto add version number to suffix
3.3.4 ALG Extend 1 frame and remove residual frame for all dbl algs
3.3.3 ALG Suction similar to mt
3.3.2 ALG Double check intervals for dbl/bs
3.3.1 ALG Remove residual dbl single frames
3.3.0 Update pseudocode
3.2.9 ALG Turn off all coughs except 7.2
3.2.8 ALG Add cough 7.1-7.7 and cough.sudo
3.2.7 ALG Add cough 6.6 and 6.7
3.2.6 Add optional output of flow and pressure values
3.2.5 Move solo_fused
3.2.4 ALG Breath stack2
3.2.3 ALG Move make-solo after multi-frame post process.
3.2.2 ALG Remove any multi frame artifact
3.2.1 ALG Remove mt<3 post processing
3.2.0 ALG Change mt counter to not be inclusive of nl breaths
3.1.9 ALG Change dbl to output 1 and 2 for each frame.
3.1.8 ALG Conditional x01 x02 logic for nubbin breaths
3.1.7 Half-move make_solo after buffer (non-multi lines)
3.1.6 Move make_solo into a separate function
3.1.5.1 TV fusion
3.1.5 ALG buffer remove mt from a regular dbl
3.1.4 Add preliminary buffer for dbl-mt type events
3.1.3 ALG Include last dbl frame in mt counter
3.1.2 ALG Change cosumtvd location
3.1.1 ALG Add double trigger 4
3.1.0 Add second frame annotation for double trigger
3.0.9 Add matrix_raw_multi_frame output
3.0.8 Add matrix_solo_output based on specified cosumtvd
3.0.7 Add matrix_solo_output based on any cosumtvd
3.0.6 Add rename of output files
3.0.5 Add auto truncation naming suffix
3.0.4 ALG Add double trigger 2.3
3.0.3 Remove extraneous pvi variables
3.0.2 Add dataframe for pvi variable storage
3.0.1 Add output for truncation start-BN and relative time
3.0.0 Made into function
Alg versions
============
Tidal Volume
Double Trigger
--------------
2.1 Tve < 0.25*Tvi
2.2 Tve < 0.25*Tvi & eTime<0.25sec
2.2.1 Tve <0.25*TVi & eTime<=0.3sec
2.3 Tve in [0.25,0.5)*TVi & eTime<=0.3sec & TVi<250 & Tve <100
2.4 If meets 2.2.1 or 2.3
3.1 N/A (will be from literature)
3.2 (same as 2.2.1) Tve <0.25*TVi & eTime<=0.3sec
3.3 (same as 2.3) Tve in [0.25,0.5)*TVi & eTime<=0.3sec & TVi<250 & Tve <100
3.4 If meets 3.2 or 3.3
4.1
4.2 rounded_TVratio<0.25 and eTime<=0.3
4.3 rounded_TVratio in [0.25,05) & eTime<=0.3 & TVe<100
4.3.1 rounded_TVratio in [0.25,05) & eTime<=0.3 & TVe<=100
4.4 If 4.2 or 4.3
(remove_artifacts_from_BS_DBL)
Breath Stacking
---------------
1 BSL TVe in [25,50)*Tvi, BSM TVe in [50,75)*TVi, BSS Tve in [75,95)
2 BS eTime>0.3
  BSL TVe in [0,33)*Tvi, BSM TVe in [33,66)*TVi, BSS Tve in [66,95)
3.1 BS eTime>0.3
  BSL TVe in [0,33)*Tvi, BSM TVe in [33,66)*TVi, BSS Tve in [66,90)
    Added "wasDBL21=0" on line 113 to deal with error message saying that this was not defined
    Changed breath stacking logic to require that TVe is <90% of TVi (was < 95%) to
    account for lack of specificity due to tail end of expiration bouncing from + to -
3.2 TVi<250 & iTime<=0.3 & abs(TVe) >=0.25*TVi
3.1or2 if meets 3.1 or 3.2
(same with rounded rules)
4.1 if rounded_TVratio=<0.9 and eTime>0.3:
  BSL TVratio in [0,33), BSM TVratio in [33,66), BSS TVratio in [66,90)
4.2 TVi<250 & iTime<=0.3 & ratio >=0.25
4.3 If 4.1 or 4.2
5.1 eTime>0.3 and rounded_TVratio<0.90:
  BSL TVratio in [0,33), BSM TVratio in [33,66), BSS TVratio in [66,90)
5.2 TVe>100 and eTime<=0.3 and rounded_TVratio>=0.25 and rounded_TVratio<0.9
   BSL TVratio in [0.25,33), BSM TVratio in [33,66), BSS TVratio in [66,90)
5.3 If 5.1 or 5.2
---rounded_TVratio<=0.90 and eTime>=0.3: &
4.1 BSL ratio in [0,33)*Tvi, BSM ratio in [33,66)*TVi, ratio Tve in [66,90)
4.2 TVi<250 & iTime<=0.3 & rounded_TVratio>=0.25
4.3 If 4.1 or 4.2
Multi Trigger
-------------
1 Reflect the same as consecutive doubles
2 Include last normal frame as part of multi-trigger
2.1 Make the counter non continuous
3 (2 round process)
  1st round of processing
    if current = dbl.4, then mt counter = +1
    if current = dbl.4 & past1 = dbl.4, then mt counter= +1
    if current NOT dbl.4 & past1 = dbl.4, then add to mt counter or dbl=2
    if current NOT dbl.4 & past1 NOT dbl.4, then not MT and mt counter = 0
  2nd round of processing
    #if mt =1 or 2 then change mt1 and mt2 into 0 (remove_small_multi_events)
    if mt =1 or 2 then change mt1 and mt2 into 0 (solo.remove_small_multi_events)

Suction
-------
1 frame_dur (breath length)<0.5 & TVi<250
2 etime </= 0.2 &
   includes trailing last frame
   & is >/= 3 in a row
Cough
-----
2.1 p at max iFlow<0.5*PIP, p at max eFlow>0.5*PIP, iTime<0.5, TVi<500
2.2 p at max iFlow<0.5*Maw, p at max eFlow>0.5*Maw, iTime<0.5, TVi<500
3.1-3.3: iTime<0.5 & TVi<500
3.1 p at max iFlow <75% max pressure & p at min eFlow > 50% max pressure
3.2 p 0.04 after BS <75% max pressure & p 0.04 after XO >50% max pressure
3.3 AUC pressure- insp<40 & exp<40 & TVe<300
4.1-4.3: iTime<0.5 & TVi<500
4.1 same as 3.1
4.2 AUC pressure- insp<1 & TVe<300
4.3 AUC pressure (Edward)- insp<40 & TVe<300
4.4 AUC pressure (Edward)- insp<40 & exp<40 & TVe<300
5.1 same as 3.1
5.2 iTime<0.5 & TVi<150 d& insp pressure AUC<5
5.3 iTime<0.5 & TVi<500 & max(iFlow)>100
6.1 (same as 3.1) p at max iFlow <75% max pressure & p at min eFlow > 50% max pressure
6.2 (same as 5.2)  iTime<0.5 & TVi<150 & insp pressure AUC<5
6.3 (same as 5.3) iTime<0.5 & TVi<500 & max(iFlow)>100
6.5 ipAUC < 25% ideal ipauc (based on ideal itime=1.2)
6.6 detect near simultaneous positive spike in both pressure and flow
6.7 same as 6.6 but only in inspiratory time period
7.1 iTime<0.5 & TVi <500 & coP1 <0.75*maxP & coP2>0.5*maxP and PIF>20:
7.2 iTime<0.5 & TVi <150 & ipAUC<5 & PIF>20
7.3 iTime<0.5 & TVi <150 & ipAUC<5 & PIF>20:
7.4 ipAUC<0.25*ideal_ipAUC & PIF>20
7.5 positive spike by slope
7.6 spike using SAM.spike
7.7
8.1 (same as 7.2) if iTime<0.5 and TVi <150 and ipAUC<5 and PIF>20:
8.2 iTime<=0.2 and TVi <150 and ipAUC<5 and PIF>20
8.3 iTime<=0.2 and ipAUC<5 and PIF>20
Vent Disconnect
---------------
1.1 TVi>1000 & ipAUC>5 & pressure @BE<gPEEP
1.2 TVi>2000 & ipAUC>5
multi-event heuristics
----------------------
"""

# the one ring to rule them all
from __future__ import division
import argparse
import datetime
from collections import Counter
import copy
import csv
from operator import xor
import os
import sys
import time

import numpy as np
import pandas as pd
from scipy.integrate import simps

##??? how are these working? are
from preprocessing.clear_null_bytes import clear_null_bytes
from preprocessing.clean_datetimed_data import clean_datetimed_data
from algorithms.constants import ROW_PREFIX_NAMES
from algorithms.constants import META_HEADER_TOR_3 as META_HEADER
# import algorithms.solo as solo
# import algorithms.solo_fused as solo_fused
# import algorithms.SAM as SAM
# import algorithms.remove_small_multi_events as remove_small_multi_events

#local/same directory, will keep this way until I change the tutorial for brooks
import remove_small_multi_events
import solo
import SAM_for_TOR3 as SAM
import solo_fused

__version__='3.5.8'


#initialize custom classes
class flushArray():
    """
    Ensure that the header and row has the same number of elements.
    This is a custom class that checks the length of a CSV output row
    matches the length of a header. (As in, outputs warnings when the
    columns do not align).
    Each instance of flushArray would be a different output csv file.
    Args:
    ----
     name:
      (string)
     csvWriter:
      the open file that is being written by csv.writer
     header:
      1d array (list) with names in header
     row:
      1d array (list) of values to be appended to the output array
    """
    def __init__(self, csvWriter, header): #creates an instance
        csvWriter.writerow(header) #writes the header row
        #attach attributes to the instance
        self.headerLength=len(header)
        self.name = str(csvWriter)
        self.rowN=0 #counter: row number of output (usually BN)
        self.csvWriter=csvWriter
        self.row_buffer = []
        # XXX make this configurable
        self.buffer_flush_size = 500

    def addRow(self, row, inBNinterval):
        BN = int(row[0]) #breath number is the first element in the added row
        if inBNinterval:
            self.row_buffer.append(row)

        if inBNinterval and len(self.row_buffer) >= self.buffer_flush_size:
            self.csvWriter.writerows(self.row_buffer) #writes the output row
            self.row_buffer = []

        #TODO: change with the match in compareCSV
        #if the first row doesn't align with the header, then raise the error
        #it's unncessary to do for all rows,
        #since we use a loop function to add each row
        if len(row)!=self.headerLength and BN==1:
            print"WARNING: %s Header:%d, New Row: %d" %(self.name+'.csv'
                '-Header length does not match row length. \n Check output variables?',
                int(self.headerLength), int(len(row)))

    def flush(self):
        self.csvWriter.writerows(self.row_buffer)


class FlushArrayMock(object):
    def addRow(self, a, b):
        pass

    def flush(self):
        pass


def printLog(outputPath, string):
    """
    print and write to designated .txt file
    """
    printFile = open(outputPath + '_logfile.txt', 'a')
    printFile.write(string+'\n')
    print string


def detect_version(inputPath, outputPath):
    # detect timestamp
    # needs to open up a separate file or else the big algorithm skips first line
    with open(inputPath,'rU') as rawFirstLine:
        first = rawFirstLine.readline()

        #having 2 versions just in case the first line is partial

        #detect 2nd type, with first column as time column
        #2015-06-09 02:35:07.685091508, BS, S:114,

        if len(first.split(', '))==3 or len(first.split('-'))==3:
            timestamp_1st_col = True
            timestamp_1st_row = False
            printLog(outputPath, 'Date timestamp as 3rd col (v2)')
            printLog(outputPath, '-------------------------------')

            BScol = 1
            ncol = 3

        #detect 3rd type, with date time in first row
        elif len(first.split('-'))==6:
            timestamp_1st_col = False
            timestamp_1st_row = True
            printLog(outputPath, 'Date timestamp in first row (v3)')
            printLog(outputPath, '-------------------------------')
            BScol = 0
            ncol = 2

        #detect 1st type, 2 col  #BS, S:52335,\n (by default)
        else: #if len(first.split(', ')) == 2:  #BS, S:52335,\n, #BS, #100
            timestamp_1st_col = False
            timestamp_1st_row = False
            printLog(outputPath, 'No timestamp (v1)')
            printLog(outputPath, '----------------')
            BScol = 0
            ncol = 2
        return  BScol, ncol, timestamp_1st_col, timestamp_1st_row

def detectPVI(input_file, outName='',outSuffix='',
              input_subdir='',output_subdir='',
              BNinterval=[],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              writePlain=False,keepBS=True,addRelTime=False,
              outSubsets=False,
              outAbsTime=True,outAbsSep=False,
              anyCosumtvd=False, only_meta=False):
    """
    Detects PVI in a file
    Args:
    ----
     input_file:
      .csv file for Processing
     outName:
       custom output name prefix (override). By default, it is the same as the
       input_file
     input_subdir:
      path to subdirectory with input_file (Mac or Windows format)
     output_subdir:
      path to subdirectory where files will be written
     BNinterval:
      breath region to analyze ex. [3,12].
     altBNstart:
      for analyzing pre-truncated files--changes initial BN count #
     altRelTimeStart:
      for analyzing pre-truncated files--changes initial relative time counter
     tvePos:
      changes any negative TVe values into positive
     dt:
      sampling rate (default 0.02sec/sample)
     gender:
      for calculation of PBW
     ptHeight:
      height in inches, for calculation of PBW
     writePlain:
      writes an additional csv file of the pressure/flow
     keepBS:
      writes 'BS' and 'BE' lines in the plain file
     addRelTime:
     anyCosumtvd:
      changes heuristic to consider all cosumtvd algorithms
    only_meta:
      Only outputs the breath matrix nothing else
    """
    #==============================================================================
    # log-file intro stuff/file set up
    #==============================================================================
    start_time = time.time()
    inputPath=os.path.join(input_subdir,input_file)
    filename=os.path.splitext(input_file) [0]

    outSuffix="_v"+__version__.replace('.','_')+'_'+outSuffix

    print outSuffix

    if BNinterval!=[]:
        truncated_suffix='_%dto%d'%(BNinterval[0],BNinterval[1])
        outSuffix= truncated_suffix+outSuffix
    if outName=='':
        outputPath=os.path.join(output_subdir,filename)+outSuffix
    else:
        outputPath=os.path.join(output_subdir,outName)+outSuffix

    printLog(outputPath,"*"*30)
    printLog(outputPath,"Root Dir: %s"%(str(os.getcwd())))
    printLog(outputPath,"Input: %s"%(inputPath))
    printLog(outputPath,"Output: %s"%(outputPath))
    printLog(outputPath,"dt: %s"%(str(dt)))
    printLog(outputPath,"gender: %s"%(gender))
    printLog(outputPath,"pt Height: %s"%(str(ptHeight)))
    printLog(outputPath,"Output interval:%s" %BNinterval)
    printLog(outputPath,"Alt BN start:%s" %altBNstart)
    printLog(outputPath,"Alt relative time start: %s"%altRelTimeStart)
    printLog(outputPath,"TOR version: %s, SAM version: %s \n"
                                    %(str(__version__), str(SAM.__version__)))

    #==============================================================================
    # initialize variables
    #==============================================================================



    PBW = SAM.calcPBW(gender, ptHeight)
    printLog(outputPath,"PBW: %s" %(str(PBW)))

    # interbreath
    # -----------
    #[]-signifies array, 0 signifies counter
    PEEPs      = []
    RRs        = []
    i          = 0 #i_th row (non BS,nonBE)
    gPEEP      = 0
    if altBNstart!=0:
        BN=altBNstart-1
    else:
        BN=0
    ventBN = 0
    countBS = 0
    countBE = 0
    missingBE=0

    # new variables
    # convention: lowercase = counter, isUPPER = binary or coded flag

    # PVI variables
    wasDBL21=0
    mt = 0 #dbl trigger counter --> RENAME AS counter_mt
    counter_mt_multi_frame=0
    counter_su_multi_frame=0
    bs1 = 0 #severity of bs
    bs2 = 0
    isTVV = 0
    isTVV2 = 0

    TEST_COUNTER=0
    # artifact variables
    su = 0 #sscounter
    isSU = 0
    wasSU = 0
    coP1 =0
    coP2 = 0

    #frame buffer variables
    # counter_multi_event=0
    # was_multi_event=0
    # write_buffer=0
    # combine_dbl_TVs=0
    # buffer_counter_mt=0

    # only in one frame
    # -----------------
    # previous reading frame (-1)
    prevBStime = 0
    # oldTVi, oldTVe
    # current breath (reading frame) only
    N                    = 2000 # length of temp arrays
    flow                 = [np.nan]*N
    pressure             = [np.nan]*N
    t                    = [np.nan]*N #time(relative)
    ts                   = [np.nan]*N #timestamps(absolute)
    last_t               = 0 # orig: lastb
    BStime         = 0 # absolute BS timestamp (not relative)
    frame_dur            = 0     # length of current breath/frame #orig: timecount
    peep                 = 0
    look                 = 0 # used to exclude values before first breath start
    clipboard=[]
    # next reading frame
    nextBStime = 0.02 if altRelTimeStart == 0 else altRelTimeStart

    # We can just preprocess all of our files here for convenience if we want
    raw = clear_null_bytes(inputPath)
    raw = clean_datetimed_data(None, raw)

    BScol, ncol, timestamp_1st_col,timestamp_1st_row = detect_version(
                                        inputPath, outputPath)
    printLog(outputPath, '------------------------------')

    # opens ventilator CSV output and creates four files
    # - plain.csv ()
    with open(outputPath + '_breath_meta.csv', 'wb') as outB,\
         open(outputPath + '_class_matrix_raw.csv', 'wb') as outR,\
         open(outputPath + '_class_matrix_raw_multi_frame.csv','wb') as outRMF,\
         open(outputPath + '_compareTV.csv','wb') as outTV:

        #TODO: combine the reader step with flush array
        rawCSV = csv.reader(raw, delimiter=',')
        csv_matrix_raw = csv.writer(outR, delimiter = ',')
        csv_matrix_raw_multi_frame = csv.writer(outRMF,delimiter=',')
        csv_breath_meta = csv.writer(outB, delimiter=',')
        csvTV = csv.writer(outTV,delimiter=',')

        if writePlain:
            outP = open(outputPath +'_plain.csv', 'wb')
            csvPlain = csv.writer(outP, delimiter=',', quoting=csv.QUOTE_NONE)
        if outSubsets:
            outP = open(outputPath +'_subsets.csv', 'wb')
            csv_subsets = csv.writer(outP, delimiter=',', quoting=csv.QUOTE_NONE)

        #breath_meta
        breath_meta = flushArray(csv_breath_meta, META_HEADER)

        #pvi_list
        pvi_list=['pvis','dbl.2','dbl.3','dbl.4','bs.1','bs.2','bs.1or2','bs.sudo','co.sudo','dtpi', 'dtpa.1','dtpa.2','dtpa.3',
                     'cosumtvd','sumt', 'mt','mt.su','co.orig','co.2thresh','co.noTVi','vd','vd.2', 'su','su.2','tvv']
        matrixHeader=ROW_PREFIX_NAMES+pvi_list

        #THIS ISN'T RIGHT!!!
        #initialize data frame for previous frame
        #by default, make the BN=0
        first_index = 0 if not BNinterval else BNinterval[0] - 1
        prev_pvi_raw = pd.DataFrame(0, index={first_index}, columns=pvi_list)

        matrixHeader2 = ROW_PREFIX_NAMES+[ ' ','dbl','bs', 'tvv']
        full_xO_tv_list=['whichx0','x01index','x01time', 'tvi1', 'tve1',
                  'x02index','x02time', 'tvi2', 'tve2',
                  'x03index','x03time', 'tvi3', 'tve3']

        tv_list = ['x01','TVi1','TVe1',
                    'x02','TVi2','TVe2','TVi3','TVe3']
        TVheader = ROW_PREFIX_NAMES+[' ']+ tv_list+[' ','diffx0','diffTVi','diffTVe']

        if only_meta:
            matrix_raw_output = FlushArrayMock()
            matrix_raw_multi_frame = FlushArrayMock()
            TVoutput = FlushArrayMock()
        else:
            matrix_raw_output=flushArray(csv_matrix_raw, matrixHeader)
            matrix_raw_multi_frame=flushArray(csv_matrix_raw_multi_frame,matrixHeader)
            TVoutput=flushArray(csvTV,TVheader)

        subset_header = ROW_PREFIX_NAMES + ['IEnd','I:E ratio',
                        'iTime','eTime','inst_RR',
                      'TVi', 'TVe', 'TVe:TVi ratio',
                      'maxF', 'minF','maxP',
                      'PIP', 'Maw', 'PEEP',
                      'ipAUC', 'epAUC',' ','flow','pressure']


        if outSubsets:
            subset_output = flushArray(csv_subsets,subset_header)


        for row_number, row in enumerate(rawCSV):
            # print row_number,row
            # If empty just continue iterating
            if row[0] == []:
                continue
            #in v2 file types, the first line is sometimes just a timestamp, so skip
            if timestamp_1st_col:
                if len(row)==1:
                  continue

            #determine if row is BS, BE or in between
            # if row is demarcated as breath start --> starts copying next row
            if row[BScol] in [' BS', 'BS']:
                #TODO fix BS counter
                if countBS>countBE:
                    printLog(outputPath,
                        'Missing BE @ ventBN %s(BN %s)/row %s/time %s'
                            %(ventBN,BN,row_number, last_t))
                    countBE=countBS
                    missingBE+=1

                # line value of beginning breath
                BN      += 1       #adds 1 to breath counter, initial=1

                BStime = nextBStime #moves BStime to current frame, initial=0.02
                try:
                    ventBN = int(row[BScol+1].split(':')[1]) #extract vent BN,make an integer
                except:
                    printLog(outputPath,'Missing ventBN'+str(row))


                countBS+=1
                look=1

                #print interval truncation information
                if BNinterval==[]:
                    inBNinterval=True
                else:
                    if BN==BNinterval[0]:
                        printLog(outputPath, 'TRUNCATION START')
                        printLog(outputPath, 'BN: %s' %BN)
                        truncation_start_BN=BN
                        printLog(outputPath, 'ventBN: %s' %ventBN)
                        printLog(outputPath, 'time: %s' %str(round(BStime,2)))
                        truncation_start_rel_time=BStime
                    if BN==BNinterval[1]:
                        printLog(outputPath, 'BN: %s' %BN)
                        printLog(outputPath, 'ventBN: %s' %ventBN)
                        printLog(outputPath, 'time: %s' %str(round(BStime,2)))
                    if BN>=BNinterval[0] and BN<=BNinterval[1]:
                        inBNinterval=True
                    else:
                        inBNinterval=False

                #csv output
                if keepBS==True:
                    BSrow=row
            # if row is demarcated as a breath end --> stops copying and processes
            # look==1 ensures that alg won't evaluate a breath w/o a BS (e.g. 1st half breath)
            elif row[BScol] in [' BE', 'BE'] and look==0:
                countBE+=1

            elif row[BScol] in [' BE', 'BE'] and inBNinterval==0:
                countBE+=1
                # timestamping
                # -------------
                frame_dur = last_t+0.02  # duration of current frame in seconds
                nextBStime +=frame_dur #BS absolute time stamp of next frame
                # reset frame (breath) variables
                # --------------------
                flow       = [np.nan]*N
                pressure   = [np.nan]*N
                t          = [np.nan]*N
                ts         = [np.nan]*N
                i          = 0
            elif row[BScol] in [' BE', 'BE'] and inBNinterval:
                look = 0
                countBE+=1
                # extract abs times if they exist
                # ------------------------------

                # plain csv output
                # ----------------
                if writePlain and inBNinterval:
                    if keepBS:
                        csvPlain.writerow(BSrow)
                    for fpRow in clipboard: #outputs +/-time, flow,pressure
                        csvPlain.writerow(fpRow)
                    if keepBS:
                        BErow=row
                        csvPlain.writerow(BErow)
                    clipboard=[]
                # timestamping
                # -------------
                frame_dur = last_t+0.02  # duration of current frame in seconds
                nextBStime +=frame_dur #BS absolute time stamp of next frame

                # extraction inhalation and exhalation
                # -----------------------------------
                BEindex = t.index(last_t)

                df_x0_row,TV_partial_output=SAM.find_x0s_multi_algorithms(flow=flow,t=t,last_t=last_t,BN=BN,
                    full_xO_tv_list=full_xO_tv_list,timestamp_1st_col=timestamp_1st_col,
                    BStime=BStime,dt=dt,tvePos=tvePos,ts=ts)

                breath_meta_row_prefix=[BN,ventBN,round(BStime,2)]
                TVoutputRow=breath_meta_row_prefix+TV_partial_output
                TVoutput.addRow(TVoutputRow,inBNinterval)

                iTime,IEindex,x0index=SAM.x0_heuristic(df_x0_row=df_x0_row,BN=BN,t=t)



                # TODO: NOTE!!!!! make sure to  ROUND TIMESTAMPS

                # calculations based on x0
                # ----------------------
                frame_dur = round(frame_dur,2)
                iTime=round(iTime,2)

                eTime = round(frame_dur-iTime,2)

                # if ventBN >46225 and ventBN <46229:
                #     print BN
                IEratio = round((iTime)/(eTime),2)


                RR= round(60/(frame_dur),2)
                RRs.append(RR)

                iTimestamp = BStime + iTime
                xoTimestamp = ts[IEindex]

                iPressure = pressure[0:IEindex]
                ePressure = pressure[IEindex:BEindex+1]
                iFlow     = flow[0:IEindex]
                eFlow     = flow[IEindex:BEindex+1]

                wPressure = pressure[0:BEindex+1]
                wFlow     = flow[0:BEindex+1]

                PIP = round(max(iPressure),2)
                Maw= round(sum(iPressure)/len(iPressure),2)


                # calculate PEEP (pos end exp pressure)
                # -------------------------------------
                # if ePressure and not dbl trigger or suction
                # the peep is the average of the end pressure

                if ePressure != []:
                    peep  = round(sum(ePressure[-5:])/5,2)
                    PEEPs.append(peep)

                # 08/14/2016--- TOADD
                # else:
                #     peep = 0

                # calculate the AUCS/integral of the last breath
                #------------------------------------------
                # calculate inspiratory TV
                TVi = simps(iFlow, dx=dt)*1000/60 #1000ml/L, 60 sec/min
                 #if expiratory flow DNE, don't calculate expiratory TV (e.g. )
                if eFlow == []:
                    TVe = 0
                else:
                    TVe = simps(eFlow, dx=dt)*1000/60

                TVratio=(abs(TVe))/TVi
                rounded_TVratio=round(TVratio,2) #abs(TVe)/tvi

                TVi = round(TVi,1)
                TVe = round(TVe,1)


                ipAUC = simps(iPressure, dx=dt)
                ipAUC = round(ipAUC,2)

                if ePressure==[]:
                    epAUC=0
                else:
                    epAUC = float(simps(ePressure, dx=dt))
                    epAUC = round(epAUC,2)

                maxP = round(max(pressure),2) #max pressure for whole breath
                maxF = round(max(wFlow),2)
                minF = round(min(wFlow),2)



                # calc gPEEP
                # ---------
                if PEEPs!=[]:
                    gPEEP = sum(PEEPs)/len(PEEPs)


               # writing output
               # -------------

                TV_partial_output2=TV_partial_output[1:7]
                if tvePos==True:
                    TVe = abs(TVe)
                    TV_partial_output2[2]=abs(TV_partial_output2[2])
                    TV_partial_output2[5]=abs(TV_partial_output2[5])
                otherClin = [iTime,eTime,RR, TVi, TVe, TVratio,
                             maxF, minF, maxP,
                             PIP, Maw, peep,
                             ipAUC, epAUC,
                             ' ',round(BStime,2)]+TV_partial_output2
                breath_meta_row_prefix=[BN,ventBN,round(BStime,2)]
                breath_metaRow = breath_meta_row_prefix+[round(iTimestamp,2),float(IEratio)] \
                                    + otherClin
                breath_meta.addRow(breath_metaRow,inBNinterval)

                if outSubsets:
                    subset_row = breath_meta_row_prefix + [round(iTimestamp,2), float(IEratio)]\
                                    +[iTime,eTime,RR, TVi, TVe, TVratio,
                                 maxF, minF, maxP,
                                 PIP, Maw, peep,
                                 ipAUC, epAUC, ' '] + [wFlow]+[wPressure]
                    subset_output.addRow(subset_row,inBNinterval)

#==============================================================================
#       algorithm detection
#==============================================================================

                # instantiate pvi dataframe variables
                is_pvi = pd.DataFrame(0, index={BN}, columns=pvi_list)
                is_pvi['pvis']=' '

                #double trigger
                #4.1
                  # TODO add double trigger 1 from literature

                #4.2
                #if abs(TVe) <0.25*TVi and eTime<=0.3: #and TVi>100
                if rounded_TVratio<0.25 and eTime<=0.3: #and TVi>100
                    wasDBL21 = 1
                    is_pvi['dbl.2']=1

                #4.3
                #if abs(TVe)>0.25*TVi and abs(TVe)<0.5*TVi and eTime<=0.3\
                #TODO!!! needs to be changed to match >=0.25
                if rounded_TVratio>=0.25 and rounded_TVratio<0.5 and eTime<=0.3\
                  and TVe<=100:
                    is_pvi['dbl.3']=1

                #4.4
                if is_pvi.loc[BN,'dbl.2']==1 or is_pvi.loc[BN,'dbl.3']==1:
                    is_pvi['dbl.4']=1
                    #mt+=1 #original MT counter that is based off dbl.4
                    #is_pvi['mt']=mt


                # # mult trigger
                # if is_pvi.loc[BN,'dbl.4'] == 0 and mt >0:
                #     isMT = 1
                #     wasMT = 1
                #     mt = 0

               # delayed termination-pissed
                p_incr=[]
                slope_t=5
                forward_t=2
                pressure_t = PIP
                for f in range(len(ePressure)-forward_t):
                    slope = (ePressure[f+forward_t] - ePressure[f])/0.02
                    rule1 = slope>=slope_t
                    rule2a = ePressure[f+forward_t]> pressure_t
                    rule2b = ePressure[f]> pressure_t
                    if rule1 and rule2a and rule2b:
                        p_incr.append(BStime+iTime+t[f])
                if p_incr !=[]:
                    is_pvi['dtpi']=1

                # delayed termination-passive
                DTPA = 0
                AUC_eFlow =0
                AUC_begin_eFlow =0
                flowMinIndex = 0
                dx =0
                epsilon = 2
                inspHoldDur = 0
                beginP = []
                flatFlowDur = 0
                timeThreshold = 0.04
                maxFlat2 = 0; sumFlat2=0
                if eFlow !=[]: #only evaluates frames with exp. phase
                    flowMin = min(eFlow)
                    flowMinIndex = eFlow.index(flowMin)
                    minTime = BStime + iTime + t[flowMinIndex]
                    beginE = eFlow[:flowMinIndex]
                    if flowMinIndex!=0:
                        for f in range(len(beginE)):
                            if abs(eFlow[f])<epsilon:
                                inspHoldDur = t[f]
                    if inspHoldDur>timeThreshold:
                        is_pvi['dtpa.1']=1

                    flatFlowDur, maxFlat, sumFlat = SAM.isFlat(beginE, epsilon=1)
                    if maxFlat*dt>timeThreshold:
                        is_pvi['dtpa.2']=1
                    beginP = ePressure[:flowMinIndex]
                    flatPresDur, maxFlat2, sumFlat2 = SAM.isFlat(beginP, epsilon=1, y=peep)
                    if maxFlat2*dt>timeThreshold:
                        is_pvi['dtpa.3']=1

                # breath stacking

                # v5.1
                if eTime>0.3 and rounded_TVratio<0.90: #technically the rounded_ratio is redundant
                    if rounded_TVratio >= 0.66 and rounded_TVratio< .90:
                        bs1 = 1;
                    elif rounded_TVratio>=0.33 and rounded_TVratio<0.66:
                        bs1 = 2;
                    elif rounded_TVratio>= 0 and rounded_TVratio< 0.33:
                        bs1 = 3;
                    is_pvi['bs.1'] = bs1
                # v5.2
                if TVe>100 and eTime<=0.3 and rounded_TVratio>=0.25 and rounded_TVratio<0.9: #technically the rounded ratio is redundant
                    if rounded_TVratio >= 0.66 and rounded_TVratio< .90:
                        bs2 = 1;
                    elif rounded_TVratio>=0.33 and rounded_TVratio<0.66:
                        bs2 = 2;
                    elif rounded_TVratio>= 0.25 and rounded_TVratio< 0.33:
                        bs2 = 3;


                    is_pvi['bs.2']=bs2
                #v5.3
                if is_pvi.loc[BN,'bs.1']>0 or is_pvi.loc[BN,'bs.2']>0:
                    is_pvi['bs.1or2']=1

                # cough
                if eFlow !=[]: #expiratory flow must exist
                    PIF = round(max(iFlow),2) #peak inspiratory flow
                    # coP1 = iPressure[iFlow.index(PIF)] # corresponding pressure val
                    MEF = min(eFlow) #peak expiratory flow
                    # coP2 = ePressure[eFlow.index(MEF)] #corresponding pressure val

                    #8.1
                    if iTime<0.5 and TVi <150 and ipAUC<5 and PIF>20:
                        is_pvi['co.orig']=1

                    #8.2
                    if iTime<=0.2 and TVi <150 and ipAUC<5 and PIF>20:
                        is_pvi['co.2thresh']=1

                    #8.3
                    if iTime<=0.2 and ipAUC<5 and PIF>20:
                        is_pvi['co.noTVi']=1

                    ideal_itime=0.8
                    ideal_ipAUC=maxP*ideal_itime

                #sudo bs/cough
                    if ipAUC<0.25*ideal_ipAUC and PIF<20:
                        is_pvi['co.sudo']=1

                # vent disconnect
                if TVi>1000 and ipAUC>5 and pressure[i]<gPEEP:
                    is_pvi['vd']=1
                if TVi>2000 and ipAUC>5:
                    is_pvi['vd.2']=1

                # suction
                if frame_dur<0.5 and TVi<250: #frame_dur=breath length,#500?

                    isSU = 1

                    is_pvi['su']
                    su += 1
                    if su==1:
                        suStart = BStime
                        suBN = BN
                    is_pvi['su']=su

                if isSU==0:    #as soon as suction ends, write output
                    if su>3:
                        wasSU = 1
                        suEnd = BStime
    #                    outSuction = [float(BN), float(suEnd), str("sEND")]
    #                   this is where you would put in output for SU end in a list
                    su=0 #reset su counter
                #v2
                if eTime<=0.3:
                  is_pvi['su.2']=1
                  is_pvi['mt.su']=1
                  is_pvi['sumt']=1
                #cosumtvd
                is_pvi['cosumtvd']=' '
#==============================================================================
#       matrix output
#==============================================================================
                #output raw row
                det_row=is_pvi.values.tolist()[0] #converts values to lis
                matrixRow = breath_meta_row_prefix + det_row#see matrixHeader
                matrix_raw_output.addRow(matrixRow,inBNinterval)
#==============================================================================
#       multi frame output
#==============================================================================
                #initialize new df to store multiframe data
                pvi_raw_mult_frame=pd.DataFrame(is_pvi.values.tolist(),index={BN},
                    columns=pvi_list)

                #if previous frame was dbl, temporarily change this frame
                #to double (to capture the second peak of dbl)
                #
                # XXX TODO If this is clinically wrong we can change it I just need my scripts
                # to work
                prev_pvi_idx = BN - 1
                if prev_pvi_idx not in prev_pvi_raw.index:
                    prev_pvi_idx = prev_pvi_raw.index[-1]

                #if the breath was a double, it's mt
                if is_pvi.loc[BN,'dbl.2']==1:
                    pass
                #if previous frame was a double trigger (capture second peak of double)
                if prev_pvi_raw.loc[BN-1,'dbl.2']==1 and is_pvi.loc[BN,'dbl.2']==0:
                    pvi_raw_mult_frame['dbl.2']=2
                #if previous frame wasn't the second peak and current frame isn't a double
                if prev_pvi_raw.loc[BN-1,'dbl.2']==0 and is_pvi.loc[BN,'dbl.2']==0:
                        pass

                #if the breath was a double, it's mt
                if is_pvi.loc[BN,'dbl.3']==1:
                    pass
                #if previous frame was a double trigger (capture second peak of double)
                if prev_pvi_raw.loc[BN-1,'dbl.3']==1 and is_pvi.loc[BN,'dbl.3']==0:
                    pvi_raw_mult_frame['dbl.3']=2
                #if previous frame wasn't the second peak and current frame isn't a double
                if prev_pvi_raw.loc[BN-1,'dbl.3']==0 and is_pvi.loc[BN,'dbl.3']==0:
                        pass


                #mt counter
                #if the breath is a double, it's mt
                if is_pvi.loc[BN,'dbl.4']==1:
                    counter_mt_multi_frame+=1
                    pvi_raw_mult_frame['mt']=counter_mt_multi_frame
                #if previous frame was a double trigger (capture second peak of double)
                # wasDBL_or_isCO=is_pvi.loc[BN,'dbl.4']==0 or is_pvi.loc[BN,'co.orig']==1

                if prev_pvi_raw.loc[BN-1,'dbl.4']==1 and is_pvi.loc[BN,'dbl.4']==0: #wasDBL_or_isCO:
                    counter_mt_multi_frame+=1
                    pvi_raw_mult_frame['mt']=counter_mt_multi_frame
                    pvi_raw_mult_frame['dbl.4']=2
                    counter_mt_multi_frame=0
                if prev_pvi_raw.loc[BN-1,'dbl.4']==0 and is_pvi.loc[BN,'dbl.4']==0:
                    counter_mt_multi_frame=0

                #suction
                if is_pvi.loc[BN,'su.2']==1:
                    counter_su_multi_frame+=1
                    pvi_raw_mult_frame['su.2']=counter_su_multi_frame
                    pvi_raw_mult_frame['mt.su']=counter_su_multi_frame
                    pvi_raw_mult_frame['sumt']=counter_su_multi_frame

                #wasSU_or_isCO=is_pvi.loc[BN,'su.2']==0 or is_pvi.loc[BN,'co.orig']==1
                if prev_pvi_raw.loc[BN-1,'su.2']==1 and is_pvi.loc[BN,'su.2']==0:  #wasSU_or_isCO:
                    counter_su_multi_frame+=1
                    pvi_raw_mult_frame['su.2']=counter_su_multi_frame
                    pvi_raw_mult_frame['mt.su']=counter_su_multi_frame
                    pvi_raw_mult_frame['sumt']=counter_su_multi_frame
                    counter_su_multi_frame=0
                if prev_pvi_raw.loc[BN-1,'su.2']==0 and is_pvi.loc[BN,'su.2']==0:
                    counter_su_multi_frame=0

                #output row
                det_row=pvi_raw_mult_frame.values.tolist()[0] #converts values to lis
                matrix_rawMF_row = breath_meta_row_prefix + det_row#see matrixHeader
                matrix_raw_multi_frame.addRow(matrix_rawMF_row,inBNinterval)

                # reset variables
                bs = 0
                isSU =0

                # reset frame (breath) variables
                # --------------------
                flow       = [np.nan]*N
                pressure   = [np.nan]*N
                t          = [np.nan]*N
                ts         = [np.nan]*N
                i          = 0

                # save frame variables
                prev_pvi_raw=pd.DataFrame(is_pvi.values.tolist(), index={BN},
                    columns=pvi_list)

                prev_breath_meta_row_prefix=copy.deepcopy(breath_meta_row_prefix)

            # if it's BE, calculate the t volume for that time period???
            elif look: #elif look==1
                # grabbing values for row in rawCSV
                fullrow=len(row)==ncol
                if timestamp_1st_col:
                    if fullrow:
                        try:
                            flow[i]     = float(row[1])
                            pressure[i] = float(row[2])
                            t[i]        = float(i)*dt
                            ts[i]       = row[0]
                        except:
                            printLog(outputPath,'Weird Row: '+str(row))
                        if writePlain and inBNinterval:
                            csvPlain.writerow([ts[i], flow[i], pressure[i]])

                        last_ts=ts[i]
                        last_t = t[i]
                        i     += 1 # progress i counter for non BS/BE rows

                else:
                    if fullrow:
                        try:
                            flow[i]     = float(row[0])
                            pressure[i] = float(row[1])
                            t[i]        = float(i)*dt
                        except:
                            printLog(outputPath,'Weird Row: '+str(row))

                        #outputs a plain CSV with three columns/removes BS/BEs for
                        #used to create small CSVs for graphing
                        if writePlain and inBNinterval:
                            if addRelTime==True:
                                clipboard.append([float(BStime+t[i]), flow[i], pressure[i]])
                            else:
                                clipboard.append([flow[i], pressure[i]])

    #                     record last time value
                        last_t = t[i]
                        i     += 1 # progress i counter for non BS/BE rows

        breath_meta.flush()
        matrix_raw_output.flush()
        matrix_raw_multi_frame.flush()
        TVoutput.flush()

    #close files that were opened as part of a conditional statement

    if writePlain:
        outP.close()

#==============================================================================
#   post-processing multi-frame
#==============================================================================
    if not only_meta:
        # Remove "multi triggers"<=2 and suctions <3.
        raw_multi_frame_df=pd.read_csv(outputPath+'_class_matrix_raw_multi_frame.csv',
                                index_col="BN")

        for pva in ["mt","su","su.2","mt.su","sumt"]:
            if pva =="mt":
                raw_multi_frame_df2 = solo.remove_small_multi_events(
                            raw_multi_frame_df,pva,
                )
            else:
                raw_multi_frame_df2 = solo.remove_small_multi_events(
                            raw_multi_frame_df2,pva,
                )

        raw_multi_frame_df2.to_csv(outputPath+'_class_matrix_raw_multi_frame2.csv',
                                index=True)
#==============================================================================
#   multi-algorithm heuristics
#==============================================================================

        solo_df=solo.remove_cough_during_mt_or_su(raw_multi_frame_df2)

        solo_df.to_csv(outputPath+'_solo.csv',index=True)

        solo2_df = solo.remove_artifacts_from_BS_DBL(solo_df)
        solo2_df.to_csv(outputPath+'_solo2.csv')

        solo3_df = solo.remove_residual_dbl_single_frames(
          solo2_df, pva='dbl.4')
        solo3_df = solo.remove_residual_dbl_single_frames(
          solo3_df, pva='dbl.2')
        solo3_df = solo.remove_residual_dbl_single_frames(
          solo3_df, pva='dbl.3')

        solo3_df.to_csv(outputPath+'_solo3.csv',index=True)

#==============================================================================
#   post-processing multi-frame
#==============================================================================

    run_time=(time.time() - start_time)
    printLog(outputPath,("-------------------"))
    printLog(outputPath,("--- File Processing Complete!---"))
    printLog(outputPath,("--- %s seconds elapsed, %s rows processed---" % (run_time, row_number)))
    printLog(outputPath, (time.strftime("Finished at %d/%m/%Y  %H:%M:%S")))
    printLog(outputPath,("-------------------\n"))

    if altBNstart!=0:
        printLog(outputPath,"Breaths:%s"%(int(BN)-altBNstart+1))
    else:
        printLog(outputPath,"BNs:%s"%(int(BN)))

    actualBEs=countBE-(missingBE)
    printLog(outputPath,"BSs:%s"%(int(countBS)))
    printLog(outputPath,"BEs:%s"%(int(actualBEs)))

    printLog(outputPath,"*"*30)

    print BNinterval!=[]
    if BNinterval!=[]:
        return truncation_start_BN, truncation_start_rel_time
    else:
        return 0,0 #if not, there will be an error when running detectPVI without an interval

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_file")
    parser.add_argument("--only-meta", action="store_true", default=False)
    parser.add_argument("--bn-start", type=int)
    parser.add_argument("--bn-end", type=int)
    # This differs from default in detectPVI but it seems to be taking the majority
    # of our time in processing
    parser.add_argument("--write-plain", action="store_true", default=False)
    args = parser.parse_args()
    if xor(bool(args.bn_start), bool(args.bn_end)):
        raise Exception('If you set a breath interval you must set a start and an end!')
    bn_interval = [] if not args.bn_start else [args.bn_start, args.bn_end]
    detectPVI(args.input_file, BNinterval=bn_interval, only_meta=args.only_meta, writePlain=args.write_plain)


if __name__ == "__main__":
    main()
