from io import SEEK_END, SEEK_SET
from StringIO import StringIO

from algorithms.raw_utils import real_time_extractor
from algorithms.tor5 import detectPVI


class RealTimeTor(object):
    def __init__(self, window_size, height, gender, tor_subdir, tor_file_prefix='real_time'):
        """
        :param window_size: Size of the rolling breath window.
        :param height: patient height
        :param gender: patient gender
        :param tor_subdir: subdirectory for tor file output
        :param tor_file_prefix: file prefix for all tor files
        """
        self.last_frame = None
        self.window_size = window_size
        self.height = height
        self.gender = gender
        self.tor_subdir = tor_subdir
        self.descriptor = StringIO()
        self.newline_flag = False
        self.size_additions = []
        self.tor_file_prefix = tor_file_prefix

    def add_new_data(self, data):
        """
        Add new breath data to the TOR analysis. Data should be in string format,
        and should be a single breath long. The first breath added should also
        have a timestamp at the top. Subsequent breaths must have timestamps
        associated with themselves.

        :param data: String of data of each breath, with timestamp attached
                     to first line as a BS time indicator
        """
        self.descriptor.seek(0, SEEK_END)
        # +1 because the following breath will have a newline
        self.size_additions.append(len(data.strip()) + 1)
        if not self.newline_flag:
            newline = ""
            self.newline_flag = True
        else:
            newline = "\n"
        self.descriptor.write(newline + data.strip())
        self.descriptor.seek(0)

    def analyze_new_breath(self, data):
        """
        Convenience method that just adds new data and analyzes it in succession

        :param data: String of data of each breath, with timestamp attached
                     to first line as a BS time indicator
        """
        self.add_new_data(data)
        return self.analyze_raw()

    def analyze_raw(self):
        """
        Analyze current data given to real-time TOR
        """
        processed_csv = real_time_extractor(self.descriptor, False)
        if len(processed_csv) > self.window_size:
            # Here we resize the TOR data that we have and truncate it the number
            # of breaths we have is above the sliding window length.
            # This works while its just one breath at a time, however more
            # breaths at a time will break this algorithm
            self._truncate_head()
            processed_csv.pop(0)

        # If we have discontiguous BNs then the analysis will have a problem
        # within TOR because it assumes contiguous BNs. So ensure we can spot
        # when discontiguous regions occur and split them up.
        split_positions = [0]
        for idx, breath in enumerate(processed_csv):
            try:
                diff = breath['vent_bn'] - prev_breath
            except NameError:
                prev_breath = breath['vent_bn']
                diff = 1
            if diff != 1:
                split_positions.append(idx)
            prev_breath = breath['vent_bn']
        split_positions.append(len(processed_csv))

        # This section just takes all the solo slices, runs them through TOR,
        # and then throws them all into an array
        solo_slices = []
        for i, idx0 in enumerate(split_positions[:-1]):
            raw_slice = processed_csv[idx0:split_positions[i+1]]
            solo3_tvv, fused_tvv = detectPVI(
                raw_slice, self.tor_file_prefix, output_subdir=self.tor_subdir,
                ptHeight=self.height, gender=self.gender
            )
            solo_slices.append(solo3_tvv)

        if isinstance(self.last_frame, type(None)):
            self.last_frame = solo_slices[-1]
            return (solo_slices[0].append(solo_slices[1:], ignore_index=True) if len(solo_slices) > 1 else solo_slices[0], processed_csv)

        solo_slices[0] = self._reconcile(solo_slices[0])
        self.last_frame = solo_slices[-1]
        # As a note, currently there are a few columns that are not working
        # within the context of real time tor, and probably aren't going to work:
        # BS, and BN are the ones I can see right now. Currently I just remove
        # them
        return (solo_slices[0].append(solo_slices[1:], ignore_index=True) if len(solo_slices) > 1 else solo_slices[0], processed_csv)

    def update_height_gender(self, height, gender):
        self.height = height
        self.gender = gender

    def _reconcile(self, frame):
        """
        Reconciles the BN classifications of a given frame with the last frame
        seen.
        """
        if len(self.last_frame) != len(frame):
            return frame
        # make sure frame indexing will align
        self.last_frame.index = range(len(self.last_frame))
        self.frame = range(len(frame))
        if not (frame.ventBN != self.last_frame.ventBN).any():
            return frame
        # The tail of the current frame does not need reconciliation, the head
        # does.
        mod_cols = frame.columns.difference(['BN', 'BS'])
        frame_fr = frame.iloc[0]
        last_frame_fr = self.last_frame.iloc[0]
        # continue the stretch of sumt
        if (last_frame_fr.sumt > 0):
            to_modify = []
            for offset, row in self.last_frame.iloc[1:].iterrows():
                if row.sumt == 0:
                    break
                to_modify.append((offset - 1, row))
            for offset, row in to_modify:
                frame.loc[offset, mod_cols] = row[mod_cols]
        # In this case the first breath of frame would just be normal so switch it
        # to last breath of dta
        elif (last_frame_fr['dbl.4'] == 1):
            frame.loc[frame_fr.name, mod_cols] = self.last_frame.iloc[1][mod_cols]
        return frame

    def _truncate_head(self):
        bytes_to_truncate = self.size_additions.pop(0)
        tmp_descriptor = StringIO()
        self.descriptor.seek(bytes_to_truncate, SEEK_SET)
        tmp_descriptor.write(self.descriptor.read())
        self.descriptor = tmp_descriptor
