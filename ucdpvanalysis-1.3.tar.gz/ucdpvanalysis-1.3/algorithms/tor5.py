"""
Created on Thu Jan 14 22:34:12 2016
From TOR3.py and tor4.py

================
Overall Versions
================
5.0.0 Copy of tor3
5.0.1 Copy of tor4
5.0.1.1 Copy change output name
5.0.2 Different names
5.0.3 Add fusion
5.0.4 Add tvv
5.1.0 True BEindex

Alg versions
============
Tidal Volume

Double Trigger
--------------
2.1 tve < 0.25*tvi
2.2 tve < 0.25*tvi & eTime<0.25sec
2.2.1 tve <0.25*tvi & eTime<=0.3sec
2.3 tve in [0.25,0.5)*tvi & eTime<=0.3sec & tvi<250 & tve <100
2.4 If meets 2.2.1 or 2.3
3.1 N/A (will be from literature)
3.2 (same as 2.2.1) tve <0.25*tvi & eTime<=0.3sec
3.3 (same as 2.3) tve in [0.25,0.5)*tvi & eTime<=0.3sec & tvi<250 & tve <100
3.4 If meets 3.2 or 3.3
4.1
4.2 rounded_TVratio<0.25 and eTime<=0.3
4.3 rounded_TVratio in [0.25,05) & eTime<=0.3 & tve<100
4.3.1 rounded_TVratio in [0.25,05) & eTime<=0.3 & tve<=100
4.4 If 4.2 or 4.3
(remove_artifacts_from_BS_DBL)
Breath Stacking
---------------
1 BSL tve in [25,50)*tvi, BSM tve in [50,75)*tvi, BSS tve in [75,95)
2 BS eTime>0.3
  BSL tve in [0,33)*tvi, BSM tve in [33,66)*tvi, BSS tve in [66,95)
3.1 BS eTime>0.3
  BSL tve in [0,33)*tvi, BSM tve in [33,66)*tvi, BSS tve in [66,90)
    Added "wasDBL21=0" on line 113 to deal with error message saying that this was not defined
    Changed breath stacking logic to require that tve is <90% of tvi (was < 95%) to
    account for lack of specificity due to tail end of expiration bouncing from + to -
3.2 tvi<250 & iTime<=0.3 & abs(tve) >=0.25*tvi
3.1or2 if meets 3.1 or 3.2
(same with rounded rules)
4.1 if rounded_TVratio=<0.9 and eTime>0.3:
  BSL TVratio in [0,33), BSM TVratio in [33,66), BSS TVratio in [66,90)
4.2 tvi<250 & iTime<=0.3 & ratio >=0.25
4.3 If 4.1 or 4.2
5.1 eTime>0.3 and rounded_TVratio<0.90:
  BSL TVratio in [0,33), BSM TVratio in [33,66), BSS TVratio in [66,90)
5.2 tve>100 and eTime<=0.3 and rounded_TVratio>=0.25 and rounded_TVratio<0.9
   BSL TVratio in [0.25,33), BSM TVratio in [33,66), BSS TVratio in [66,90)
5.3 If 5.1 or 5.2
---rounded_TVratio<=0.90 and eTime>=0.3: &
4.1 BSL ratio in [0,33)*tvi, BSM ratio in [33,66)*tvi, ratio tve in [66,90)
4.2 tvi<250 & iTime<=0.3 & rounded_TVratio>=0.25
4.3 If 4.1 or 4.2
M
if .9 <= tve_tvi < .66:ulti Trigger
-------------
1 Reflect the same as consecutive doubles
2 Include last normal frame as part of multi-trigger
2.1 Make the counter non continuous
3 (2 round process)
  1st round of processing
    if current = dbl.4, then mt counter = +1
    if current = dbl.4 & past1 = dbl.4, then mt counter= +1
    if current NOT dbl.4 & past1 = dbl.4, then add to mt counter or dbl=2
    if current NOT dbl.4 & past1 NOT dbl.4, then not MT and mt counter = 0
  2nd round of processing
    #if mt =1 or 2 then change mt1 and mt2 into 0 (remove_small_multi_events)
    if mt =1 or 2 then change mt1 and mt2 into 0 (solo.remove_small_multi_events)

Suction
-------
1 frame_dur (breath length)<0.5 & tvi<250
2 etime </= 0.2 &
   includes trailing last frame
   & is >/= 3 in a row
Cough
-----
2.1 p at max iFlow<0.5*PIP, p at max eFlow>0.5*PIP, iTime<0.5, tvi<500
2.2 p at max iFlow<0.5*Maw, p at max eFlow>0.5*Maw, iTime<0.5, tvi<500
3.1-3.3: iTime<0.5 & tvi<500
3.1 p at max iFlow <75% max pressure & p at min eFlow > 50% max pressure
3.2 p 0.04 after BS <75% max pressure & p 0.04 after XO >50% max pressure
3.3 AUC pressure- insp<40 & exp<40 & tve<300
4.1-4.3: iTime<0.5 & tvi<500
4.1 same as 3.1
4.2 AUC pressure- insp<1 & tve<300
4.3 AUC pressure (Edward)- insp<40 & tve<300
4.4 AUC pressure (Edward)- insp<40 & exp<40 & tve<300
5.1 same as 3.1
5.2 iTime<0.5 & tvi<150 d& insp pressure AUC<5
5.3 iTime<0.5 & tvi<500 & max(iFlow)>100
6.1 (same as 3.1) p at max iFlow <75% max pressure & p at min eFlow > 50% max pressure
6.2 (same as 5.2)  iTime<0.5 & tvi<150 & insp pressure AUC<5
6.3 (same as 5.3) iTime<0.5 & tvi<500 & max(iFlow)>100
6.5 ipAUC < 25% ideal ipauc (based on ideal itime=1.2)
6.6 detect near simultaneous positive spike in both pressure and flow
6.7 same as 6.6 but only in inspiratory time period
7.1 iTime<0.5 & tvi <500 & coP1 <0.75*maxP & coP2>0.5*maxP and PIF>20:
7.2 iTime<0.5 & tvi <150 & ipAUC<5 & PIF>20
7.3 iTime<0.5 & tvi <150 & ipAUC<5 & PIF>20:
7.4 ipAUC<0.25*ideal_ipAUC & PIF>20
7.5 positive spike by slope
7.6 spike using SAM.spike
7.7
8.1 (same as 7.2) if iTime<0.5 and tvi <150 and ipAUC<5 and PIF>20:
8.2 iTime<=0.2 and tvi <150 and ipAUC<5 and PIF>20
8.3 iTime<=0.2 and ipAUC<5 and PIF>20
Vent Disconnect
---------------
1.1 tvi>1000 & ipAUC>5 & pressure @BE<gPEEP
1.2 tvi>2000 & ipAUC>5
multi-event heuristics
----------------------
"""

# the one ring to rule them all
from __future__ import division
from argparse import ArgumentParser
from collections import OrderedDict
import copy
import csv
import logging
import os
import time

import numpy as np
import pandas as pd

from algorithms.breath_meta import get_production_breath_meta
from algorithms.constants import (
    META_HEADER, META_HEADER_TOR_3, ROW_PREFIX_NAMES, PVI_LIST,
    GENDER, PT_HEIGHT
)
from algorithms.raw_utils import pb840_bs_be_denoting_extractor, extract_raw
import solo
import SAM
import solo_fused
import tvv
from utilikilt.oz import create_output_path
from detection import detect_version_v3

__version__ = '5.1.0'
logger  = logging.getLogger(__name__)


# Why did I over-engineer this??
class flushArray():
    """
    Ensure that the header and row has the same number of elements.

    This is a custom class that checks the length of a CSV output row
    matches the length of a header. (As in, outputs warnings when the
    columns do not align).
    Each instance of flushArray would be a different output csv file.

    Args:
    ----
     name:
      (string)
     csvWriter:
      the open file that is being written by csv.writer
     header:
      1d array (list) with names in header
     row:
      1d array (list) of values to be appended to the output array
    """
    def __init__(self, csvWriter, header):  # creates an instance
        csvWriter.writerow(header)  # writes the header row
        # attach attributes to the instance
        self.headerLength = len(header)
        self.name = str(csvWriter)
        self.rowN = 0  # counter: row number of output (usually BN)
        self.csvWriter = csvWriter
        self.row_buffer = []
        self.buffer_flush_size = 500

    def addRow(self, row):
        BN = int(row[0])  # breath number is the first element in the added row
        self.row_buffer.append(row)

        if len(self.row_buffer) >= self.buffer_flush_size:
            self.csvWriter.writerows(self.row_buffer)  # writes the output row
            self.row_buffer = []

        # if the first row doesn't align with the header, then raise the error
        # it's unncessary to do for all rows,
        # since we use a loop function to add each row
        if len(row) != self.headerLength and BN == 1:
            print"WARNING: %s Header:%d, New Row: %d" %(self.name+'.csv'
                '-Header length does not match row length. \n Check output variables?',
                int(self.headerLength), int(len(row)))

    def flush(self):
        self.csvWriter.writerows(self.row_buffer)


def detectPVI(vwd_array,
              input_file="",
              output_name_override="",
              output_suffix="",
              output_subdir="",
              gender=GENDER,
              ptHeight=PT_HEIGHT,
              rel_bn_interval=[],
              write_results=True):
    """
    Legacy method for to detect PVI in a file

    Args:
    ----
     vwd_array:
       raw statistics from the ventilator for our breaths
     input_file:
        Original csv file, used for naming purposes only.
     output_name_override:
       custom output name prefix (override). By default, it is the same as the
       input_file
     output_suffix:
       suffix for files written with TOR
     output_subdir:
      path to subdirectory where files will be written
     gender:
      for calculation of PBW
     ptHeight:
      height in inches, for calculation of PBW
    write_results:
      write all results (multi-frame2 and solo only for now) to file

    Returns:
    -------
    Tuple with (solo3 with tvv, solo3 fused with tvv)
    """
    # ------------------------------------------------------------------
    # log-file intro stuff/file set up
    # ------------------------------------------------------------------

    outputPath = create_output_path(
        input_file, output_subdir, output_name_override,
        output_suffix, __version__, rel_bn_interval)

    logger.debug("\n" + "*" * 30)
    logger.debug("Root Dir: %s" % (str(os.getcwd())))
    logger.debug("Input: %s" % str(input_file))
    logger.debug("Output: %s" % (outputPath))
    logger.debug("gender: %s" % (gender))
    logger.debug("pt height: %s" % (str(ptHeight)))
    logger.debug("rel bn interval: %s" % rel_bn_interval)
    # ------------------------------------------------------------------
    # initialize variables
    # ------------------------------------------------------------------

    vwd_array = list(vwd_array)
    breath_meta = []
    for breath_data in vwd_array:
        bm_data = get_production_breath_meta(breath_data)
        breath_meta.append(bm_data)

    results = detect_pvis(vwd_array, breath_meta, outputPath, gender, ptHeight, rel_bn_interval, write_results)
    logger.debug("\n" + "-" * 30)
    logger.debug((time.strftime("Finished at %d/%m/%Y  %H:%M:%S")))
    return results


def detect_pvis(vwd_array, breath_meta, output_path, gender, height, rel_bn_interval=[], write_results=False):
    """
    New interface for detecting PVI in a file. Essentially operates same as
    the old interface except you can call it programatically after precomputing
    breath metadata.

    :param vwd_array: list of breaths, each of which has raw breath data
    :param breath_meta: list of breath metadata information for each raw breath
    :param output_path: Directory and file prefix for output files eg: /tmp/foo
    :param gender: Gender of patient
    :param height: Height of patient (inches)
    :param rel_bn_interval: list of relative breath numbers to use
    :param write_results: Whether/not to write results to file
    """
    # PVI variables
    counter_mt_multi_frame = 0
    counter_su_multi_frame = 0
    bs1 = 0  # severity of bs
    bs2 = 0

    # artifact variables
    su = 0  # sscounter
    isSU = 0
    wasSU = 0

    # data storage
    is_pvi = OrderedDict({})
    for pvi in PVI_LIST:
        is_pvi[pvi] = 0
    is_pvi['pvis'] = ' '

    breath_meta_data = OrderedDict({})
    for row in META_HEADER:
        breath_meta_data[row] = 0
    prev_breath_meta_row = copy.copy(breath_meta_data)

    # opens ventilator CSV output and creates four files
    with open(output_path + '_class_matrix_raw.csv', 'wb') as outR,\
         open(output_path + '_class_matrix_raw_multi_frame.csv', 'wb') as outRMF,\
         open(output_path + '_breath_meta.csv', 'wb') as out_bm:

        # TODO: combine the reader step with flush array
        csv_matrix_raw = csv.writer(outR, delimiter=',')
        csv_matrix_raw_multi_frame = csv.writer(outRMF, delimiter=',')
        csv_breath_meta = csv.writer(out_bm, delimiter=',')

        # PVI_LIST
        matrixHeader = ROW_PREFIX_NAMES + PVI_LIST + ['abs_bs']

        matrix_raw_output = flushArray(csv_matrix_raw, matrixHeader)
        matrix_raw_multi_frame = flushArray(csv_matrix_raw_multi_frame,
                                            matrixHeader)

        matrix_breath_meta = flushArray(csv_breath_meta, META_HEADER)

        # initialize for previous frame
        prev_pvi_raw = copy.copy(is_pvi)
        # --------------------------------------------------------------
        #       import previous data
        # --------------------------------------------------------------
        for vwd_idx, breath_data in enumerate(vwd_array):
            # import raw csv breath metadata

            BN = breath_data['rel_bn']  # rel bn
            vent_bn = breath_data['vent_bn']
            BStime = round(breath_data['bs_time'], 2)
            t = breath_data['t']
            dt = breath_data['dt']
            pressure = breath_data['pressure']
            frame_dur = breath_data['frame_dur']
            if ('ts' in breath_data and breath_data['ts']) or ('abs_bs' in breath_data and breath_data['abs_bs']):
                date_time_stamping_exists = True
                if 'abs_bs' in breath_data:
                    abs_bs = breath_data['abs_bs']
                else:
                    abs_bs = breath_data['ts'][0]
            else:
                date_time_stamping_exists = False
                abs_bs = np.nan

            bm_data = breath_meta[vwd_idx]
            for idx, row in enumerate(META_HEADER):
                breath_meta_data[row] = bm_data[idx]

            breath_meta_data['IEnd'] = round(breath_meta_data['IEnd'], 2)
            breath_meta_data['iTime'] = round(breath_meta_data['iTime'], 2)
            breath_meta_data['eTime'] = round(breath_meta_data['eTime'], 2)
            iTime = breath_meta_data['iTime']
            eTime = breath_meta_data['eTime']
            breath_meta_data['I:E ratio'] = round((iTime)/(eTime), 2)
            breath_meta_data['inst_RR'] = round(breath_meta_data['inst_RR'], 2)
            breath_meta_data['tvi'] = round(breath_meta_data['tvi'], 1)
            breath_meta_data['tve'] = round(breath_meta_data['tve'], 1)
            tvi = breath_meta_data['tvi']
            tve = breath_meta_data['tve']
            breath_meta_data['tve:tvi ratio'] = round(breath_meta_data['tve:tvi ratio'], 2)
            rounded_TVratio = breath_meta_data['tve:tvi ratio']
            breath_meta_data['maxF'] = round(breath_meta_data['maxF'], 2)
            max_f = breath_meta_data['maxF']
            breath_meta_data['minF'] = round(breath_meta_data['minF'], 2)
            breath_meta_data['maxP'] = round(breath_meta_data['maxP'], 2)
            maxP = breath_meta_data['maxP']
            breath_meta_data['PIP'] = breath_meta_data['PIP']
            PIP = breath_meta_data['PIP']
            breath_meta_data['Maw'] = round(breath_meta_data['Maw'], 2)
            breath_meta_data['PEEP'] = round(breath_meta_data['PEEP'], 2)
            peep = breath_meta_data['PEEP']
            breath_meta_data['ipAUC'] = round(breath_meta_data['ipAUC'], 2)
            ipAUC = breath_meta_data['ipAUC']
            breath_meta_data['epAUC'] = round(breath_meta_data['epAUC'], 2)

            if date_time_stamping_exists is False:
                breath_meta_data['x01'] = round(breath_meta_data['x01'], 2)
                breath_meta_data['x02'] = round(breath_meta_data['x02'], 2)

            breath_meta_row_prefix = [BN, vent_bn, BStime]

            # breath array division by x0_index
            x0_index = int(breath_meta_data['x0_index'])
            be_index = t.index(t[-1])

            iFlow = breath_data['flow'][:x0_index]
            eFlow = breath_data['flow'][x0_index:]
            ePressure = breath_data['pressure'][x0_index:]

            if ePressure == []:
                peep = round(prev_breath_meta_row['PEEP'], 2)

            # output breath meta for comparison to tor3
            matrix_breath_meta.addRow(breath_meta_data.values())
            prev_breath_meta_row = copy.copy(breath_meta_data)
            # --------------------------------------------------------------
            #       raw detections
            # --------------------------------------------------------------
            # could change this into an object instead of a mini df
            # instantiate new data frame for storage
            for pvi in PVI_LIST:
                is_pvi[pvi] = 0
            is_pvi['pvis'] = ' '

            # double trigger

            # 4.2
            # if abs(tve) <0.25*tvi and eTime<=0.3: #and tvi>100
            if rounded_TVratio < 0.25 and eTime <= 0.3:  # and tvi>100
                is_pvi['dbl.2'] = 1

            # 4.3
            # if abs(tve)>0.25*tvi and abs(tve)<0.5*tvi and eTime<=0.3\
            if rounded_TVratio >= 0.25 and rounded_TVratio < 0.5 and eTime <= 0.3\
                and tve <= 100:
                is_pvi['dbl.3'] = 1

            # 4.4
            if is_pvi['dbl.2'] == 1 or is_pvi['dbl.3'] == 1:
                is_pvi['dbl.4'] = 1

            # delayed termination-pissed
            p_incr = []
            slope_t = 5
            forward_t = 2

            # This algo just takes up a ton of time based on all the calls it
            # must make throughout the code
            for idx, obs in enumerate(ePressure[:-forward_t]):
                forward_obs = ePressure[idx + forward_t]
                slope = (forward_obs - obs) / 0.02
                # rule1 and rule2a and rule2b
                if (slope >= slope_t) and (forward_obs > PIP) and (obs > PIP):
                    is_pvi['dtpi'] = 1
                    break

            # delayed termination-passive
            flowMinIndex = 0
            epsilon = 2
            inspHoldDur = 0
            beginP = []
            flatFlowDur = 0
            timeThreshold = 0.04
            maxFlat2 = 0
            sumFlat2 = 0
            if eFlow != []:  # only evaluates frames with exp. phase
                flowMin = min(eFlow)
                flowMinIndex = eFlow.index(flowMin)
                minTime = BStime + iTime + t[flowMinIndex]
                beginE = eFlow[:flowMinIndex]
                if flowMinIndex != 0:
                    for f in range(len(beginE)):
                        if abs(eFlow[f]) < epsilon:
                            inspHoldDur = t[f]
                if inspHoldDur > timeThreshold:
                    is_pvi['dtpa.1'] = 1

                flatFlowDur, maxFlat, sumFlat = SAM.isFlat(beginE, epsilon=1)
                if maxFlat * dt > timeThreshold:
                    is_pvi['dtpa.2'] = 1
                beginP = ePressure[:flowMinIndex]
                flatPresDur, maxFlat2, sumFlat2 = SAM.isFlat(beginP, epsilon=1, y=peep)
                if maxFlat2 * dt > timeThreshold:
                    is_pvi['dtpa.3'] = 1

            # breath stacking

            # v5.1
            if eTime > 0.3 and 0 <= rounded_TVratio < 0.90:  # technically the rounded_ratio is redundant
                if rounded_TVratio >= 0.66 and rounded_TVratio < .90:
                    bs1 = 1
                elif rounded_TVratio >= 0.33 and rounded_TVratio < 0.66:
                    bs1 = 2
                elif rounded_TVratio >= 0 and rounded_TVratio < 0.33:
                    bs1 = 3
                is_pvi['bs.1'] = bs1
            # v5.2
            if tve > 100 and eTime <= 0.3 and rounded_TVratio >= 0.25 and rounded_TVratio < 0.9:  # technically the rounded ratio is redundant
                if rounded_TVratio >= 0.66 and rounded_TVratio < .90:
                    bs2 = 1
                elif rounded_TVratio >= 0.33 and rounded_TVratio < 0.66:
                    bs2 = 2
                elif rounded_TVratio >= 0.25 and rounded_TVratio < 0.33:
                    bs2 = 3

                is_pvi['bs.2'] = bs2
            # v5.3
            if is_pvi['bs.1'] > 0 or is_pvi['bs.2'] > 0:
                is_pvi['bs.1or2'] = 1

            # cough
            if eFlow != []:  # expiratory flow must exist
                if iFlow:
                    PIF = round(max(iFlow), 2)  # peak inspiratory flow

                    # 8.1
                    if iTime < 0.5 and tvi < 150 and ipAUC < 5 and PIF > 20:
                        is_pvi['co.orig'] = 1

                    # 8.2
                    if iTime <= 0.2 and tvi < 150 and ipAUC < 5 and PIF > 20:
                        is_pvi['co.2thresh'] = 1

                    # 8.3
                    if iTime <= 0.2 and ipAUC < 5 and PIF > 20:
                        is_pvi['co.noTVi'] = 1

                    ideal_itime = 0.8
                    ideal_ipAUC = maxP * ideal_itime

                    # sudo bs/cough
                    if ipAUC < 0.25 * ideal_ipAUC and PIF < 20:
                        is_pvi['co.sudo'] = 1

            # vent disconnect
            if tvi > 2000 and ipAUC > 5:
                is_pvi['vd.2'] = 1

            # suction
            if frame_dur < 0.5 and tvi < 250:  # frame_dur=breath length,#500?
                isSU = 1
                su += 1
                is_pvi['su'] = su

            if isSU == 0:  # as soon as suction ends, write output
                su = 0  # reset su counter

            # v2
            if eTime <= 0.3:
                is_pvi['su.2'] = 1
                is_pvi['mt.su'] = 1
                is_pvi['sumt'] = 1
            # cosumtvd
            is_pvi['cosumtvd'] = ' '
        # --------------------------------------------------------------
        #       matrix output
        # --------------------------------------------------------------
            # output raw row
            det_row = is_pvi.values()  # converts values to lis
            matrixRow = breath_meta_row_prefix + det_row + [abs_bs] # see matrixHeader
            matrix_raw_output.addRow(matrixRow)
        # --------------------------------------------------------------
        #       multi frame output
        # --------------------------------------------------------------
            # initialize new df to store multiframe data
            pvi_raw_mult_frame = copy.copy(is_pvi)

            # if previous frame was dbl, temporarily change this frame
            # to double (to capture the second peak of dbl)

            # if the breath was a double, it's mt
            if is_pvi['dbl.2'] == 1:
                pass
            # if previous frame was a double trigger (capture second peak of double)
            if prev_pvi_raw['dbl.2'] == 1 and is_pvi['dbl.2'] == 0:
                pvi_raw_mult_frame['dbl.2'] = 2
            # if previous frame wasn't the second peak and current frame isn't a double
            if prev_pvi_raw['dbl.2'] == 0 and is_pvi['dbl.2'] == 0:
                    pass

            # if the breath was a double, it's mt
            if is_pvi['dbl.3'] == 1:
                pass
            # if previous frame was a double trigger (capture second peak of double)
            if prev_pvi_raw['dbl.3'] == 1 and is_pvi['dbl.3'] == 0:
                pvi_raw_mult_frame['dbl.3'] = 2
            # if previous frame wasn't the second peak and current frame isn't a double
            if prev_pvi_raw['dbl.3'] == 0 and is_pvi['dbl.3'] == 0:
                    pass

            # mt counter
            # if the breath is a double, it's mt
            if is_pvi['dbl.4'] == 1:
                counter_mt_multi_frame += 1
                pvi_raw_mult_frame['mt'] = counter_mt_multi_frame
            # if previous frame was a double trigger (capture second peak of double)

            if prev_pvi_raw['dbl.4'] == 1 and is_pvi['dbl.4'] == 0:  # wasDBL_or_isCO:
                counter_mt_multi_frame += 1
                pvi_raw_mult_frame['mt'] = counter_mt_multi_frame
                pvi_raw_mult_frame['dbl.4'] = 2
                counter_mt_multi_frame = 0
            if prev_pvi_raw['dbl.4'] == 0 and is_pvi['dbl.4'] == 0:
                counter_mt_multi_frame = 0

            # suction
            if is_pvi['su.2'] == 1:
                counter_su_multi_frame += 1
                pvi_raw_mult_frame['su.2'] = counter_su_multi_frame
                pvi_raw_mult_frame['mt.su'] = counter_su_multi_frame
                pvi_raw_mult_frame['sumt'] = counter_su_multi_frame

            # this counts the last breath of a suction as a suction
            if prev_pvi_raw['su.2'] == 1 and is_pvi['su.2'] == 0:
                counter_su_multi_frame += 1
                pvi_raw_mult_frame['su.2'] = counter_su_multi_frame
                pvi_raw_mult_frame['mt.su'] = counter_su_multi_frame
                pvi_raw_mult_frame['sumt'] = counter_su_multi_frame
                counter_su_multi_frame = 0
            if prev_pvi_raw['su.2'] == 0 and is_pvi['su.2'] == 0:
                counter_su_multi_frame = 0

            # reset variables
            isSU = 0

            # output row
            det_row = pvi_raw_mult_frame.values()  # converts values to lis
            matrix_rawMF_row = breath_meta_row_prefix + det_row + [abs_bs]  # see matrixHeader
            matrix_raw_multi_frame.addRow(matrix_rawMF_row)
            prev_pvi_raw = copy.copy(is_pvi)

    # ------------------------------------------------------------------
    #   flush out buffer
    # ------------------------------------------------------------------
        matrix_raw_output.flush()
        matrix_raw_multi_frame.flush()
        matrix_breath_meta.flush()

    # ----------------------------------------------------------------------
    #   post-processing multi-frame
    # ----------------------------------------------------------------------


    # Remove "multi triggers"<=2 and suctions <3.
    raw_multi_frame_df = pd.read_csv(output_path + '_class_matrix_raw_multi_frame.csv')

    for pva in ["mt", "su", "su.2", "mt.su", "sumt"]:
        raw_multi_frame_df2 = solo.remove_small_multi_events(raw_multi_frame_df, pva)

    if write_results:
        raw_multi_frame_df2.to_csv(
            output_path + '_class_matrix_raw_multi_frame2.csv', index=False
        )

    # ----------------------------------------------------------------------
    #   multi-algorithm heuristics
    # ----------------------------------------------------------------------
    solo_df = solo.remove_cough_during_mt_or_su(raw_multi_frame_df2)

    if write_results:
        solo_df.to_csv(output_path + '_solo.csv', index=False)

    solo2_df = solo.remove_artifacts_from_BS_DBL(solo_df)
    if write_results:
        solo2_df.to_csv(output_path + '_solo2.csv', index=False)

    # remove single frames of a double trigger
    solo3_df = solo.remove_residual_dbl_single_frames(solo2_df, pva='dbl.4')
    solo3_df = solo.remove_residual_dbl_single_frames(solo3_df, pva='dbl.2')
    solo3_df = solo.remove_residual_dbl_single_frames(solo3_df, pva='dbl.3')
    if write_results:
        solo3_df.to_csv(output_path + '_solo3.csv', index=False)
    # ----------------------------------------------------------------------
    #   fusion
    # ----------------------------------------------------------------------
    breath_meta_df = pd.read_csv(output_path + '_breath_meta.csv')
    fused_bm, fused_det = solo_fused.fuse_dta(breath_meta_df.copy(), solo3_df.copy())
    fused_bm, fused_det = solo_fused.fuse_bsa(fused_bm, fused_det)
    if write_results:
        fused_bm.to_csv(output_path + '_breath_meta_FUSED.csv', index=False)
        fused_det.to_csv(output_path + '_solo3_FUSED.csv', index=False)
    # ----------------------------------------------------------------------
    #   tvv calculations
    # ----------------------------------------------------------------------
    pbw = tvv.calcPBW(gender, height)
    fused_with_tvv = tvv.add_tvvs_to_df(fused_bm, fused_det, pbw)
    if write_results:
        fused_with_tvv.to_csv(output_path + '_solo3_FUSED_tvv.csv', index=False)
    # surprisingly tvv is not a time hog
    solo3_with_tvv = tvv.add_tvvs_to_df(breath_meta_df, solo3_df, pbw)
    if write_results:
        solo3_with_tvv.to_csv(output_path + "_solo3_tvv.csv", index=False)
    # final printing
    return solo3_with_tvv, fused_with_tvv


def perform_tor_with_bs_be(waveform_csv, rel_bn_interval, output_subdir, height, gender):
    raw_generator = extract_raw(
        open(waveform_csv, "rU"), False, rel_bn_interval=rel_bn_interval
    )
    return detectPVI(
        raw_generator, waveform_csv,
        output_subdir=output_subdir, rel_bn_interval=rel_bn_interval,
        ptHeight=height, gender=gender
    )


def perform_tor_no_bs_be(waveform_csv, rel_bn_interval, output_subdir, height, gender):
    raw_generator = pb840_bs_be_denoting_extractor(open(waveform_csv, 'rU'), rel_bn_interval)
    return detectPVI(
        raw_generator, waveform_csv,
        output_subdir=output_subdir, rel_bn_interval=rel_bn_interval,
        height=height, gender=gender
    )


def main():
    parser = ArgumentParser()
    parser.add_argument("file")
    parser.add_argument("-o", "--output_subdir", default="")
    parser.add_argument(
        "-ht", "--height", default=PT_HEIGHT, type=int, help="patient height in inches"
    )
    parser.add_argument("-g", "--gender", choices=["female", "male"], default=GENDER)
    parser.add_argument("-e", "--bn-end", type=int)
    parser.add_argument("-s", "--bn-start", type=int)
    subparsers = parser.add_subparsers()
    with_bs_be = subparsers.add_parser("with_bs_be")
    with_bs_be.set_defaults(bs_be=True)
    no_bs_be = subparsers.add_parser("no_bs_be")
    no_bs_be.set_defaults(bs_be=False)
    args = parser.parse_args()
    if args.bn_start and args.bn_start:
        interval = [args.bn_start, args.bn_end]
    elif args.bn_start or args.bn_end:
        raise Exception("You must supply a start and an end if you want to specify an interval!")
    else:
        interval = []

    start_time = time.time()
    if args.bs_be:
        perform_tor_with_bs_be(args.file, interval, args.output_subdir, args.height, args.gender)
    else:
        perform_tor_no_bs_be(args.file, interval, args.output_subdir, args.height, args.gender)

    run_time = (time.time() - start_time)
    print "-------%s seconds elapsed" % run_time
    m, s = divmod(run_time, 60)
    h, m = divmod(m, 60)
    print "%d:%02d:%02d elapsed" % (h, m, s)


if __name__ == "__main__":
    main()
