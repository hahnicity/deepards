# function that detects breath stacks based on Beitler's 'BREATHE criteria' (code currently excludes criterion 4)
# function utilizes raw_utils.py, breath_meta.py

# current_breath_stacks: list of consecutive 'rel_bn' that passed criterion 1-3
# all_breath_stacks: list storing all 'current_breath_stacks'
# metadata: list of metadata for each breath in file (lists within a list), needed for criterion 5

import pandas as pd

def breathe_criteria(patient_file, sex, height):
    from algorithms.raw_utils import extract_raw
    from algorithms.breath_meta import get_production_breath_meta
    current_breath_stacks = []
    all_breath_stacks = []
    metadata = []
    PBW_F = 45.5 + 2.3 * (height - 60)  # Female PBW
    PBW_M = 50 + 2.3 * (height - 60)  # Male PBW
    if sex == "F":
        PBW = PBW_F
    elif sex == "M":
        PBW = PBW_M
    generator = extract_raw(open(patient_file), False)
    for breath in generator:
        meta = get_production_breath_meta(breath)
        metadata.append(meta)
        if meta[7] < 1 and (meta[9] - meta[10]) >= 2 * PBW:  # criterion 2 and 3
            current_breath_stacks.append(breath['rel_bn'])
        else:
            # empty current_breath_stacks should not be attached to all_breath_stacks
            if len(current_breath_stacks) != 0:
                all_breath_stacks.append(current_breath_stacks)
                current_breath_stacks = []
            else:
                current_breath_stacks = []

    # We now have a list ('all_breath_stacks') containing lists of consecutive rel_bn's that passed criterion 1-3
    # Now, for each individual list inside 'all_breath_stacks', we calc cum. tvi, tve, and then subtract
    # the cum. tve from the cum. tvi to test criterion 5
    # If individual list passed criterion 5, add list and total tvi of list to 'current_dict' and append 'current_dict'
    # to list 'breath_stacks'

    # current_dict: dictionary with keys: "breaths_nums", "tvi_total"
    # breath_stacks: list storing all 'current_dict'
    # all_final_bs: list storing all 'rel_bn' that passed criterion 1-5 (excluding 4). created for testing purposes

    current_dict = {}
    breath_stacks = []
    all_final_bs = []
    for cons_bs in all_breath_stacks:
        cum_tvi = 0  # cumulative tvi
        cum_tve = 0  # cumulative tve
        for n in cons_bs:
            cum_tvi += metadata[n - 1][9]
        for m in cons_bs:
            cum_tve += metadata[m - 1][10]
        # We now have cum. tvi of breaths in cons_bs list
        # but need to add tvi of breath following last breath in cons_bs before applying criterion 5
        x = cons_bs[-1] # stores last element (rel_bn) of cons_bs
        cum_tvi_2 = cum_tvi + metadata[x][9]  # cum. tvi which includes tvi of one breath ahead
        # Note: using 6.5mL/kg PBW as intended tv
        if (cum_tvi_2 - cum_tve) >= (2 + 6.5) * PBW: # criterion 5
            current_dict["breath_nums"] = cons_bs
            current_dict["tvi_total"] = cum_tvi_2 - cum_tve
            all_final_bs.extend(cons_bs) # storing 'rel_bn' that passed criterion 1-5 (excluding 4)
            breath_stacks.append(current_dict)
            current_dict = {}
        else:
            current_dict = {}
    return breath_stacks, all_final_bs
bs, bs_nums = breathe_criteria('/Users/anna-marianau/Downloads/0008_10_17_20_2692to3030_raw.csv', "F", 64)
print 'Total breath stacks detected:', len(bs_nums)
print bs
