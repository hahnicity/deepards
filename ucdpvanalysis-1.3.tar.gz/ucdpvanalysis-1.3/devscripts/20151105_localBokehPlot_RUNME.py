#
"""
1.save this file and the two other scripts in the same folder
2.create subfolders  "input" and "output" (if you like)
3.install Bokeh by either.
    a. in command line type "conda install bokeh"
    b. in the anaconda command line type "conda install bokeh"
    
    * note, you may need to update anaconda first with
        "conda update -f conda"
        
4. put the file of interest in input or local file
5. change out the variables within the function 

NOTE: this is your own local runme file, no versioning needed for this
"""



import os
# change the root directory
root_dir=r'C:\allMYfiles\BOX\BedsideToCloud Pilot Project\PVI\Sandbox\20151105_LocalPlot'
os.chdir(root_dir )

import localBokehPlot

#%%
#ex 1.
#intSize--breaks up the file into chunks with the length (intSize) minutes 
    #so intSize=30 means it would look at a chunk of 30 minutes
# intervalNumber refers to which chunk you want to lookat, so intNumber=2 is
    #the second chunk (30-60seconds)
localBokehPlot.plotBokeh(inputFile='RPi07_gwf5_get_serial4_file1_2015_10_31_12_20_25.122301.csv',
          input_subdir=r'input',output_subdir=r'output',
          intSize=15, intervalNumber=1,
          plainFile=[], plotFile='file1_1.html')
#%%
#ex 2. whole file       (omits the arguments for intSize and interval Number)   

localBokehPlot.plotBokeh(inputFile='RPi07_gwf5_get_serial4_file1_2015_10_31_12_20_25.122301.csv',
          input_subdir=r'input',output_subdir=r'output',
          plainFile=[], plotFile=[])
          
localBokehPlot.plotBokeh(inputFile='RPi07_gwf5_get_serial4_file1_2015_10_31_12_20_25.122301.csv',
          input_subdir=r'input',output_subdir=r'output',
          intSize=[], intervalNumber=[],
          plainFile=[], plotFile=[])

#%%
#ex3 no subdirectories
localBokehPlot.plotBokeh(inputFile='RPi07_gwf5_get_serial4_file2_2015_10_31_14_20_29.207528.csv',
          input_subdir='',output_subdir='',
          intSize=[], intervalNumber=[],
          plainFile=[], plotFile=[])                   
          
#%%
localBokehPlot.plotBokeh(inputFile='RPi07_gwf5_get_serial4_file2_2015_10_31_14_20_29.207528.csv',
          input_subdir='',output_subdir='',
          intSize=15, intervalNumber=1,
          plainFile=[], plotFile='file1_2.html')