"""
Created on Mon Apr 11 
@author: Keiko
"""

import os
import pandas as pd
import numpy as np
# import sys

# gitPath=r'/Users/monica/github/ucdpv/analysis/'
# if gitPath not in sys.path:
#      sys.path.append(gitPath)
# import annotations.add_vent_bn_and_ts as add_vent_bn_and_ts;reload(add_vent_bn_and_ts)
# #TODO eventually add timestamp adding


def fancy_get_file_names(input_subdir,onlyCSV=True,stripCSV=True):
    """
    Versions 2016-04-14
    """
    file_list=[]
    copy_file_name = False
    for root,dirs,files in os.walk(input_subdir):
        for file_name in files:
            if file_name.endswith('.csv'):
                if stripCSV:
                    file_name=file_name.rstrip('.csv')
                file_list.append(file_name)
                # copy_file_name=True
            elif onlyCSV==False:
                file_list.append(file_name)
                # copy_file_name=True

    if copy_file_name:
        file_list.append(file_name)
    return file_list
def get_file_names(input_subdir):
    file_list=[]
    for root,dirs,files in os.walk(input_subdir):
        for file_name in files:
            file_list.append(file_name.rstrip('.csv'))
    return file_list
def get_csv_files(input_subdir):
    file_list=[]
    for root,dirs,files in os.walk(input_subdir):
        for full_file_name in files:
            if full_file_name.endswith('.csv'):
                file_list.append(full_file_name)
    return file_list    
    #print file_list
    #http://stackoverflow.com/questions/21702342/creating-a-new-column-based-on-if-elif-else-condition
def is_sumt(row):
    if row['su']>0 or row['mt']>0:
        val = 1
    else:
        val = 0
    return val

def is_cosumtvd(row):
    if row['co']>0 or row['su']>0 or row['mt'] or row['vd']>0:
        val = 1
    else:
        val = 0
    return val
#an example 1 running from command line
if __name__ == "__notmain__": #change this to main
    root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox'
    os.chdir(root_dir)
    

    output_subdir=r'20160419_gold_combine_cosumtvd'
    gold_subdir=r'0TestFiles/2016-04-12-gold_standard_combine_cosumtvd'

    try:
      os.mkdir(output_subdir)
    except OSError:
      print "/--'%s' subdirectory already exists-- \n" %output_subdir

    input_csv=os.path.join(gold_subdir,'0011_14_17_21_1_474to774_goldstd_dbl_bs_cosumtvd.csv')
    temp_df = pd.read_csv(input_csv)
    temp_df['sumt']=temp_df.apply(is_sumt,axis=1)
    temp_df['cosumtvd']=temp_df.apply(is_cosumtvd,axis=1)

    output_path=os.path.join(output_subdir,'test.csv')
    temp_df.to_csv(output_path)
    print temp_df
    print temp_df.columns
    #get_file_names(input_subdir=gold_subdir)

# #example 2, multiple files
if __name__=="__main__":
    root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox'
    os.chdir(root_dir)
    

    output_subdir=r'20160419_gold_combine_cosumtvd'
    gold_subdir=r'0TestFiles/2016-02-06-gold_standard'

    try:
        os.mkdir(output_subdir)
    except OSError:
        print "--/'%s' subdirectory already exists \n" %output_subdir

    files=fancy_get_file_names(input_subdir=gold_subdir,onlyCSV=True)
    
    for gold_file in files:
        input_csv = os.path.join(gold_subdir,gold_file+".csv")
        output_csv = os.path.join(output_subdir,gold_file+"_comb_cosumtvd.csv")
        
        temp_df = pd.read_csv(input_csv,index_col="BN")
        temp_df['sumt']=temp_df.apply(is_sumt,axis=1)
        temp_df['cosumtvd']=temp_df.apply(is_cosumtvd,axis=1)  
        temp_df.to_csv(output_csv)
        print "%s --processed" %(gold_file+"_comb_cosumtvd.csv")
        # print temp_df.head()
