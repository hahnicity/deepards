"""
Created to run tkinter/gold files
20160502--changes from script into function
"""

import os
import sys

gitPath=r'Users/monica/github/ucdpv/' #change this!


#ADDS GIT PATH
if gitPath not in sys.path:
     sys.path.append(gitPath)
import analysis.annotations.compareCSV_tkinter as compare

root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox' #change this!
os.chdir(root_dir) #changes the working directory/don't edit this
gold_dir=r'20160427_tkinter2/input' #change this or leave blank, gold_dir=''
output_dir=r'20160427_tkinter2/output' #change this or leave blank, output_dir=''

# remember you can comment anything that you don't want to run





#comparing two normal files
compare.main(csv1='WF_B2CRPi01__2015-02-19__10_17_19.590102799_5_7579to7781_adams_20150901.csv',
                csv2='WF_B2CRPi01__2015-02-19__10_17_19.590102799_5_7579to7781_kuhn.csv',
                combined="combined_test1.csv",
                gold_dir=gold_dir,
                output_dir=output_dir)

#comparing two abnormal files
#bad breath
compare.main(csv1='WF_B2CRPi01__2015-02-19__10_17_19.590102799_5_7579to7781_adams_20150901.csv',
                csv2='WF_B2CRPi01__2015-02-19__10_17_19.590102799_5_7579to7781_kuhn_bad_breath.csv',
                combined="combined_test2.csv",
                gold_dir=gold_dir,
                output_dir=output_dir)

#different column names
compare.main(csv1='WF_B2CRPi01__2015-02-19__10_17_19.590102799_5_7579to7781_adams_20150901.csv',
                csv2='WF_B2CRPi01__2015-02-19__10_17_19.590102799_5_7579to7781_kuhn_wrong_col_name2.csv',
                combined="combined_test3.csv",
                gold_dir=gold_dir,
                output_dir=output_dir)


#new file type
compare.main(csv1='WF_B2CRPi01__2015-02-19__10_17_19.590102799_5_7579to7781_adams_20150901.csv',
                csv2='WF_B2CRPi01__2015-02-19__10_17_19.590102799_5_7579to7781_kuhn.csv',
                combined="combined_test4.csv",
                gold_dir=gold_dir,
                output_dir=output_dir)


#comparing two files, in one folder, and output in same folder

compare.main(csv1='0010_00_17_20_11_20800to20841_vd_new_type.csv',
                csv2='0010_00_17_20_11_20800to20841_vd_new_type_extras.csv',
                combined='combined_test5.csv',
                gold_dir='',
                output_dir='',
                root_dir='/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox/20160427_tkinter2/input')
os.chdir(root_dir)

# can also just fill in CSV1 and CSV2, combined, and leave the rest blank
#this is the same as above
os.chdir('/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox/20160427_tkinter2/input')
compare.main(csv1='0010_00_17_20_11_20800to20841_vd_new_type.csv',
                csv2='0010_00_17_20_11_20800to20841_vd_new_type_extras.csv',
                combined='combined_test5.csv',
                gold_dir='',
                output_dir='',
                root_dir='')

#this is also the same
compare.main(csv1='0010_00_17_20_11_20800to20841_vd_new_type.csv',
                csv2='0010_00_17_20_11_20800to20841_vd_new_type_extras.csv',
                combined='combined_test5.csv')