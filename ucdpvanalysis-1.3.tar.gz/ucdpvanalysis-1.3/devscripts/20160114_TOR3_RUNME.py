# -*- coding: utf-8 -*-
"""
Created on Thu Jan 14 23:14:55 2016

@author: Keiko
"""
import sys
import os
gitPath=r'C:\allMYfiles\My_Documents\GitHub\ucdpv\analysis'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.TOR3 as TOR


root_dir=r'C:\allMYfiles\BOX\BedsideToCloud Pilot Project\PVI\Sandbox'
os.chdir(root_dir)


#test_shortfile
TOR.detectPVI(input_file='0008_10_17_20__3033to3076_plain.csv', 
              outName='',outSuffix='_TOR3',
              input_subdir=r'0TestFiles\cough',output_subdir=r'20160114_TOR3',
              BNinterval=[],altBNstart=2,altRelTimeStart=5.1,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=False,addRelTime=True,
              outAbsTime=True,outAbsSep=False)
              


#%%pt8
#%%truncating validation files
TOR.detectPVI(input_file='0008_10_17_20.csv', 
              outName='',outSuffix='_TOR3_truncation_test',
              input_subdir=r'0TestFiles\fullFiles',output_subdir=r'20160114_TOR3',
              BNinterval=[3033,3076],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)


#%%truncation
TOR.detectPVI(input_file='0001_10_17_19.csv', 
              outName='',outSuffix='_4280to4578',
              input_subdir=r'0TestFiles\fullFiles',
              output_subdir=r'0TestFiles\derivation_truncation',
              BNinterval=[4280,4578],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)

#%%pt1
#%%detectPVI
TOR.detectPVI(input_file='0001_10_17_19_4280to4578_plain.csv', 
              outName='',outSuffix='_TOR3_0_0',
              input_subdir=r'0TestFiles\derivation_truncation',
              output_subdir=r'20160114_Derivation1',
              BNinterval=[],altBNstart=4280,altRelTimeStart=13189.48,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=False,addRelTime=True,
              outAbsTime=True,outAbsSep=False)               

#%%pt4
#%%truncation
TOR.detectPVI(input_file='0004_09_23_46.csv', 
              outName='',outSuffix='_2200to2500',
              input_subdir=r'0TestFiles\fullFiles',
              output_subdir=r'0TestFiles\derivation_truncation',
              BNinterval=[2200,2500],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)

#%%detectPVI
TOR.detectPVI(input_file='0004_09_23_46_2200to2500_plain.csv', 
              outName='',outSuffix='_TOR3_0_0',
              input_subdir=r'0TestFiles\derivation_truncation',
              output_subdir=r'20160114_Derivation1',
              BNinterval=[],altBNstart=2200,altRelTimeStart=9235.28,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=False,addRelTime=True,
              outAbsTime=True,outAbsSep=False)  
              

#%%truncation
TOR.detectPVI(input_file='0008_10_17_20.csv', 
              outName='',outSuffix='_2692to3030',
              input_subdir=r'0TestFiles\fullFiles',
              output_subdir=r'0TestFiles\derivation_truncation',
              BNinterval=[2692,3030],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)    
              
#%%detectPVI
TOR.detectPVI(input_file='0008_10_17_20_2692to3030_plain.csv', 
              outName='',outSuffix='_TOR3_0_0',
              input_subdir=r'0TestFiles\derivation_truncation',
              output_subdir=r'20160114_Derivation1',
              BNinterval=[],altBNstart=2692,altRelTimeStart=7155.72,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=False,addRelTime=True,
              outAbsTime=True,outAbsSep=False) 


#%%testing feed forward truncation information
#%%truncation
reload(TOR)
altBN_pt8,altRelTime_pt8=TOR.detectPVI(input_file='0008_10_17_20.csv', 
              outName='',outSuffix='_2692to3030_test_feed_forward',
              input_subdir=r'0TestFiles\fullFiles',
              output_subdir=r'20160114_TOR3',
              BNinterval=[2692,3030],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)    
              
TOR.detectPVI(input_file='0008_10_17_20_2692to3030_plain.csv', 
              outName='',outSuffix='_TOR3_0_0',
              input_subdir=r'0TestFiles\derivation_truncation',
              output_subdir=r'20160114_TOR3',
              BNinterval=[],
              altBNstart=altBN_pt8,altRelTimeStart=round(altRelTime_pt8,2),
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=False,addRelTime=True,
              outAbsTime=True,outAbsSep=False) 
              