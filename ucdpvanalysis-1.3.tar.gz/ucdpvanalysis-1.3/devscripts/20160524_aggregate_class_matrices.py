
"""
Created on Tue May 24 12:45 PM
@author: Keiko
Based on pool_stats.py
development file.
target file  analytics/aggregate_class_matrices.py
"""
import pandas as pd
import os
import sys

gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.solo_fused as fused; reload(fused)
import utilikilt.oz as oz
import glob

import analytics.aggregate_class_matrices as AGG

root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/20160524_aggregate_for_Sandy'
os.chdir(root_dir)

input_dir=r'test_build/test_build_inputs'
output_dir=r'test_build_outputs'
output_path=r"2.7_drop cols.csv"

aggregated = AGG.stack(input_dir,
                        index_col="BN",
                        add_col_list=['dbl','bs','co','sumt','vd','cosumtvd'])


# aggregated = AGG.stack(input_dir,output_dir,
#                         index_col="BN",
#                         drop_col_list=['dbl','bs','co','sumt','vd','cosumtvd'])


# aggregated = AGG.stack(input_dir,output_dir,
#                         index_col="BN",
#                         keep_col_list=['dbl'],
#                         drop_col_list=['dbl'])
aggregated.to_csv(output_path)

#an example running from command line
if __name__ == "__main1__":
    # from os import chdir, path
    root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/20160524_aggregate_for_Sandy'
    os.chdir(root_dir)

    input_dir=r'test_build/test_build_inputs'
    output_dir=r'test_build_outputs'


    # import pdb
    # pdb.set_trace()
    # aggregated = pd.concat((pd.read_csv(f) for f in input_dir))

    
    # pdb.set_trace()
    
    frame=pd.DataFrame()

    all_file_paths=glob.glob(os.path.join(input_dir,"*.csv"))

    list_of_dfs=[]
    patient_name_list=[]
    for file_path in all_file_paths:
        df=pd.read_csv(file_path,index_col="BN",header=0)
        list_of_dfs.append(df)

        file_name=os.path.basename(file_path)
        patient_number=file_name.split("_")[0]
        patient_name_list.append(patient_number)

    aggregated = pd.concat(list_of_dfs,keys=patient_name_list,axis=0)

    #drop extraneous columns
    # drop_list=['vent BN','rel time','abs time','TVi','e-time','TVe','TVe/TVi ratio',
    #             'mt','su','dtpi','dtpa','fa','aNOS','wNOS']
    # aggregated.drop(drop_list,axis=1,inplace=True)

    #delete columns
    agg_dif_column_order=aggregated[['dbl','bs','co','sumt','vd','cosumtvd']]
    
    agg_dif_column_order.index.names=['subject_ID','BN']
    agg_dif_column_order.to_csv("test_build/test2.1_rename.csv")
    import pdb
    pdb.set_trace()
    #           qstart function
    #ONE LINE---, BUT TO THE RIGHT
    # aggregated = pd.concat((pd.read_csv(f) for f in all_file_paths))



