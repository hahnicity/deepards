#run 20160516 TOR first
#change wd in terminal first
import sys
import os

gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.solo_fused as fused; reload(fused)
import utilikilt.oz as oz

root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/'
os.chdir(root_dir)
det_root=r'20160516_fix_fusion'

os.chdir(det_root)



# fused.create_solo_fused("0021_00_43_00_4100to4399_v3_5_7__2_original_solo3_copy.csv","0021_00_43_00_4100to4399_v3_5_7__2_original_breath_meta_copy.csv",61.6)
fused.create_solo_fused("0021_00_43_00_4100to4399_v3_5_7__2_original_breath_meta_copy.csv","0021_00_43_00_4100to4399_v3_5_7__2_original_solo3_copy.csv",61.6)
