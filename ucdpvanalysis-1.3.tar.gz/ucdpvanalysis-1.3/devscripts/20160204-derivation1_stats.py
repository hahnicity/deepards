# -*- coding: utf-8 -*-
"""
Created on Thu Feb  4 13:39:59 2016

@author: monica
based on 
20160106_Stats2_LocalBokehPlot
"""

from __future__ import division
import os
import pandas as pd
import sys
import numpy as np
#%% import stats

gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
    sys.path.append(gitPath)
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)

#%%
root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox'
os.chdir(root_dir )

input_subdir=r'20160202_Derivation1'
output_subdir=r'20160202_Derivation1'
det_name='0002_09_14_38_2400to2700_plain_TOR3_1_0_detected.csv'
det_path=os.path.join(output_subdir,det_name)
df_det=pd.read_csv(det_path,index_col='BN')

gold_subdir=r'0TestFiles/2016-02-02-gold_standard'
gold_name='0002_09_14_38_3_2399to2701_goldstd_dbl_bs_cosumtvd.csv'
gold_path=os.path.join(gold_subdir,gold_name)
df_gold=pd.read_csv(gold_path,index_col='BN')

filename=det_name.split('_detected.csv')[0]
acc_file=filename+"_accuracy2.csv"
#%%
dfStats,dfCompared=sta.calcStats(df_det,df_gold)
dfStatsShort=dfStats[0:3]
dfCounts=dfStats[5:]    
dfStats.to_csv(os.path.join(output_subdir,acc_file))

#converting to binary first
dfDetBinary=sta.convertAllBinary(df_det)
dfStats2,dfCompared2=sta.calcStats(dfDetBinary,df_gold)
dfStats2.to_csv(os.path.join(output_subdir,acc_file))

print(dfStats2)
