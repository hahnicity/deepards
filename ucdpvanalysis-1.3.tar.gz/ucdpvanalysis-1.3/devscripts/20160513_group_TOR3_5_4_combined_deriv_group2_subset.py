# -*- coding: utf-8 -*-
"""
Created on Thu Jan 14 23:14:55 2016

@author: Keiko

1.1 Add pooled stats as function and df piping
1.2 Add actual poole dstats
1.2.1 det_subdir=r'20160503_TOR3_5_0_group_results_post_merge'
1.2.4 det_subdir=r'20160510_TOR3_5_2_1_new_derivation'
1.2.5 det_subdir=r'20160510_TOR3_5_3_combined_deriv_DBL_BSv5'
1.2.5.1 accuracies2
1.2.6 "TOR 3_5_3" add TOR 1.2.6
1.2.7 Change file output directory structure


based on 20160421_stats_add_true_pooled.py
based on 20160418_TOR3_4_2_group_post_cough
added dynamic list update
based on 20160301_TOR3_group2.py
based on 20160224_TOR3_group.py
based on 20160216_TOR3_derivation_RUNME.py
based on 20160211_TOR3_derivation_RUNME.py
based on 20160202_TOR3_trunc_run_RUNME.py
run in mac
"""
from __future__ import division
__version__="1.2.7"

import sys
import os
import time
import pandas as pd
gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.TOR3 as TOR
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)
import analytics.pool_stats as pool; reload(pool)
import pdb
import utilikilt.oz as oz


start_time = time.time() 
#%%change these!!
root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/'
input_subdir=r'0TestFiles/20160510_combined_derivation_full_files'
gold_subdir=r'0TestFiles/20160513_combined_derivation_gold'
det_root=r'20160513_TOR3_5_4_126_only'
aggregated_name = ''
real_pooled_name = ''
out_suffix=''


runTOR = True

#%%remember to use new input directory!!!!

#make subfolder for accuracies
accuracies_subdir=os.path.join(det_root,'accuracies3')
det_subdir=os.path.join(det_root,'detected3')
if aggregated_name=='':
    aggregated_stats_csv="aggregated_stats_"+det_root+"3.csv" #optional, change pooled stats_name
if real_pooled_name=='':
    real_pooled_stats_csv="pooled_stats_"+det_root+"3.csv" #optional, change pooled stats_name

#change root_dir
os.chdir(root_dir)

filelist=[
# '0001_10_17_19_3.csv',
# '0002_09_14_38_3.csv',
# '0004_09_23_46_2.csv',
# '0007_21_17_20_3.csv',
# '0008_10_17_20_2.csv',
# '0009_03_19_47_1.csv',
'0010_00_17_20_11.csv',
# '0010_03_17_19_1_deleted_first_line.csv',
# '0011_14_17_21_1.csv',
# '0012_19_53_45_17_first_and_last_line_deleted.csv',
# '0013_15_49_102_10.csv',
# '20151008_gwf2_q2hr_whileloop_1_expt_17_15_31.csv',
# '0086-2015-11-22-10-52-12.csv',
'0099_10_26_59.csv',
# '0122_2016-01-28-15-29-25.csv',
'0126_2016-01-27-07-04-47.csv',
# '0140-2016-02-08-16-13-46.csv',
'0149_rpi18-2016-02-17-08-38-13.566218.csv',
'0149_rpi18-2016-02-17-08-43-02.524207.csv'
]

interval_list=[
# [4280,   4578],
# [2400,   2700],
# [2200,   2500],
# [2804,   3202],
# [2692,   3030],
# [1825,   2125],
[20800,  20840],
# [1401,   1699],
# [475,    773],
# [35129,  35427],
# [27671,  27969],
# [950,    1248],
# [1850,  2149],
[300, 599],
# [1, 299],
[1020,  1319],
# [1900,  2199],
[20, 69],
[50, 99]
]

oz.mkdir(det_root)
oz.mkdir(det_subdir)
oz.mkdir(accuracies_subdir)
 
if runTOR:
    for input_file,interval in zip(filelist,interval_list):
           print input_file, interval[0],interval[1]
           altBN_pt2,altRelTime_pt2=TOR.detectPVI(
                         input_file=input_file, 
                         outName='',outSuffix=out_suffix,
                         input_subdir=input_subdir,
                         output_subdir=det_subdir,
                         BNinterval=[interval[0],interval[1]],
                         altBNstart=0,altRelTimeStart=0,
                         tvePos=True, dt=0.02,gender="female",ptHeight=67,
                         keepBS=False,addRelTime=True,
                         outSubsets=False)       

gold_file_list = oz.fancy_get_file_names(input_subdir=gold_subdir,
                    ends_with=".csv",strip_suffix=False)
# for gold in gold_file_list:
#     print gold

gold_file_list=[
'0010_00_17_20_11_20800to20841_goldstd_dbl_bs_cosumtvd_comb_cosumtvd.csv',
'0126_2016-01-27-07-04-47_datetime_removed_1_1020to1320_goldstd_dbl_bs_cosumtvd_comb_cosumtvd.csv',
'0099_10_26_59_datetime_removed_1_300to600_goldstd_dbl_bs_cosumtvd_comb_cosumtvd.csv',
'0149_2016-02-17-08-38-13_1_20to70_goldstd_dbl_bs_cosumtvd_comb_cosumtvd.csv',
'0149_2016-02-17-08-43-02_1_50to100_goldstd_dbl_bs_cosumtvd_comb_cosumtvd.csv'

]

log_file_list = oz.fancy_get_file_names(input_subdir=det_subdir,
                    ends_with="logfile.txt",strip_suffix=False)
# for logfile in log_file_list:
#     print logfile

#ensure there are the same number of files in each folder
error_message =  "Different number of gold files(%s) vs. logfiles(%s)"%(len(gold_file_list),len(log_file_list))
assert len(gold_file_list)==len(log_file_list),error_message

log_file_list.sort()
gold_file_list.sort()

# assert len(gold_file_list)==5, "Files do not match up"


for gold_file,log_file in zip(gold_file_list,log_file_list):
    assert gold_file[0:4]==log_file[0:4], "File mismatch: %s, %s" %(gold_file,logfile)
    print '\n',log_file, gold_file
    print '-----------------'

    sta.calcMultiStats(logfile=log_file,
        gold_name=gold_file,
        det_subdir=det_subdir,output_subdir=accuracies_subdir,gold_subdir=gold_subdir,
        subfiles_list=[
                    '_class_matrix_raw.csv',
                    '_class_matrix_raw_multi_frame2.csv',                 
                    '_solo.csv',
                    '_solo2.csv',
                    '_solo3.csv'])

#aggregate results together
# from analytics.pool_stats import aggregate_stats
agg_df=pool.aggregate_stats(accuracies_subdir,ppvi_list=['dbl.2','dbl.3','dbl.4','bs.1','bs.2','bs.1or2','mt','mt.su','co.noTVi','vd.2','su.2','sumt','cosumtvd'],

# agg_df=pool.aggregate_stats(accuracies_subdir,ppvi_list=['dbl.2','dbl.4','bs.1','mt','mt.su','co.orig','co.2thresh','co.noTVi','vd.2','su.2','sumt'],
        # output_csv=output_csv,
        matrix_keywords=["raw__ACCURACY","multi_frame2__ACCURACY","solo3__ACCURACY"],
        stat_list=['accuracy','sensitivity','specificity','total','events','FNs','FPs','TPs','TNs'],
        pt_file_subnumber=True)
#write csv

agg_df.to_csv(os.path.join(det_root,aggregated_stats_csv))

#pool results together
new = pool.pool_stats(agg_df)
new.to_csv(os.path.join(det_root,real_pooled_stats_csv))


run_time=(time.time() - start_time)
print "-------%s seconds elapsed" %run_time
quit()
