"""
Created Jun 3 2016

originally "sample_patient.py"
"""

import pandas as pd


#file_path=r'0517_clinical_meta.csv'
file_path=r'0517_clinical_meta_add_data_status.csv'

def get_id_number(row):
    "extracts id number from unique patient identifier"
    id_number=row['Patient Unique Identifier'][0:4] #first 4 digits of the identifier
    return int(id_number)

def is_obstr_and_ARDS(row):
    "new value for obstr and ards "
    if row['Obstruction?']>0 or row['ARDS?']>0:
        both_dx=1

        if row['Obstruction?']>0 and row['ARDS?']>0:
            both_dx=0
    else:
        both_dx=0
    return both_dx


def not_corrupted(row):
    "if not in corrupted range"
    if row['ID']<=25 or row['ID']>=80:
        not_corrupted=1
    else:
        not_corrupted=0
    return not_corrupted

def started_in_ED(row):
    "determine if enrollment unit included emergency department"
    unit=row['Enrollment Unit']
    if isinstance(unit,basestring) and "ED" in unit: #to handle non-string values
        started_in_ED=1
    else:
        started_in_ED=0
    return started_in_ED

imported=pd.read_csv(file_path,header=0)


#select columns that we want
columns_to_keep=['Patient Unique Identifier','Obstruction?','ARDS?','Enrollment Unit','Data on Box']
df=imported[columns_to_keep]

#add additional covariates
df['ID']=df.apply(get_id_number,axis=1)  
df['not_corrupted']=df.apply(not_corrupted,axis=1) #binomal var for non-corrupted data
df['either?']=df.apply(is_obstr_and_ARDS,axis=1) #binomial var-if OBSTR or ARDS but not both
df['started_in_ED']=df.apply(started_in_ED,axis=1) #binomial var for start in ED

#get rows that are not corrupted and data on box
df2=df[(df['not_corrupted']==1)&(df['Data on Box']=="Y")]

# df['corrupted']=df.apply(is_corrupted,axis=1)
# df=df[df['corrupted']!=1]
#subset obstruction or ARDS
#replaces numbers that equal 1 with 3
#df['Obstruction?']=df['Obstruction?'].where(df['Obstruction?']!=1,3)
# df['Obstruction?'].apply(lambda x: 'true' if x > 0 else "false")

df3=df2[df2['either?']==1]

#subset non-corrupted data
# df2=df2.loc[df['ID']<=25]+df.loc[df['ID']>=80]

df3.to_csv("20160604_processed_clinical_data.csv")

import pdb 
pdb.set_trace()
