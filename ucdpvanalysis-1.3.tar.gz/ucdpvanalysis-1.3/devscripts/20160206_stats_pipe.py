# -*- coding: utf-8 -*-
"""
Created on Thu Feb  4 13:39:59 2016

@author: monica
based on 
20160204-derivation1_stats.py
which is based on 
20160106_Stats2_LocalBokehPlot
"""

from __future__ import division
import os
import pandas as pd
import sys
import numpy as np
#%% import stats

gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
    sys.path.append(gitPath)
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)

#%%
root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox'
os.chdir(root_dir )
input_subdir=r'20160206_Derivation'
output_subdir=r'20160206_Derivation'
gold_subdir=r'0TestFiles/2016-02-06-gold_standard'

logfile='0002_09_14_38_2200to2500_TOR3_1_0_logfile.txt'
gold_name='0002_09_14_38_3_2399to2701_goldstd_dbl_bs_cosumtvd.csv'


def calcMultiStats(logfile,gold_name,input_subdir,output_subdir,gold_subdir):
	filename=logfile.split('_logfile.txt')[0]
	for matrixCsv in ['_class_matrix_raw_multi_frame.csv',
					'_class_matrix_solo.csv']:
		det_name=filename+matrixCsv

		df_det=pd.read_csv(os.path.join(output_subdir,det_name),index_col='BN')
		df_gold=pd.read_csv(os.path.join(gold_subdir,gold_name),index_col='BN')
		dfDetBinary=sta.convertAllBinary(df_det)
		dfStats2,dfCompared2=sta.calcStats(dfDetBinary,df_gold)
		acc_file=filename+matrixCsv+"_accuracy.csv"
		dfStats2.to_csv(os.path.join(output_subdir,acc_file))
		compared_file=filename+matrixCsv+"_compared.csv"
		dfCompared2.to_csv(os.path.join(output_subdir,compared_file))



calcMultiStats(logfile='0002_09_14_38_2400to2700_TOR3_1_0_logfile.txt',
	gold_name='0002_09_14_38_3_2399to2701_goldstd_dbl_bs_cosumtvd.csv',
	input_subdir=input_subdir,output_subdir=output_subdir,gold_subdir=gold_subdir)

filelist=[
['0002_09_14_38_2400to2700_TOR3_1_0_logfile.txt',	'0002_09_14_38_3_2399to2701_goldstd_dbl_bs_cosumtvd.csv'],
['0004_09_23_46_2200to2500_TOR3_1_0_logfile.txt',	'0004_09_23_46_2_2199to2501_goldstd_dbl_bs_cosumtvd.csv'],
['0007_file_1of1_2804to3202_TOR3_1_0_logfile.txt',	'0007_21_17_20_3_2803to3203_goldstd_dbl_bs_cosumtvd.csv'],
['0008_10_17_20_2692to3030_TOR3_1_0_logfile.txt',	'0008_10_17_20_2_2691to3031_goldstd_dbl_bs_cosumtvd.csv'],
['0009_03_19_47_1825to2125_TOR3_1_0_logfile.txt',	'0009_03_19_47_1_1824to2126_goldstd_dbl_bs_cosumtvd.csv'],
['0010_03_17_19_deleted_first_line_1401to1699_TOR3_1_0_logfile.txt',	'0010_03_17_19_1_1400to1700_goldstd_dbl_bs_cosumtvd.csv'],
['0011_14_17_21_1401to1699_TOR3_1_0_logfile.txt',	'0011_14_17_21_1_474to774_goldstd_dbl_bs_cosumtvd.csv'],
['0012_19_53_45_first_and_last_line_deleted_1401to1699_TOR3_1_0_logfile.txt',	'0012_19_53_45_17_35128to35428_goldstd_dbl_bs_cosumtvd.csv'],
['0013_15_49_102_1401to1699_TOR3_1_0_logfile.txt',	'0013_15_49_102_10_27670to27970_goldstd_dbl_bs_consumtvd.csv'],
['20151008_gwf2_q2hr_whileloop_expt_17_15_31_1401to1699_TOR3_1_0_logfile.txt',	'20151008_gwf2_q2hr_whileloop_expt_17_15_31_1_949to1249_goldstd_dbl_bs_cosumtvd.csv']
]

for files in filelist:
	print files[0], files[1]
	print '-----------------'

	calcMultiStats(logfile=files[0],
		gold_name=files[1],
		input_subdir=input_subdir,output_subdir=output_subdir,gold_subdir=gold_subdir)

