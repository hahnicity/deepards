# -*- coding: utf-8 -*-
"""
Created on Thu Jan 14 23:14:55 2016

@author: Keiko

based on 20160224_TOR3_group.py
based on 20160216_TOR3_derivation_RUNME.py
based on 20160211_TOR3_derivation_RUNME.py
based on 20160202_TOR3_trunc_run_RUNME.py
run in mac
"""
import sys
import os
import time
import pandas as pd
gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.TOR3 as TOR
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)


start_time = time.time() 
#%%change these!!
root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox'
os.chdir(root_dir)
input_subdir=r'0TestFiles/fullFiles'
# output_subdir=r'20160225_post_nubbin'
output_subdir=r'20160307_post_cough2'
out_suffix='_TOR3_2_9'

filelist=[
'0001_10_17_19.csv',
'0002_09_14_38.csv',
'0004_09_23_46.csv',
'0007_file_1of1.csv',
'0008_10_17_20.csv',
'0009_03_19_47.csv',
'0010_03_17_19_deleted_first_line.csv',
'0011_14_17_21.csv',
'0012_19_53_45_first_and_last_line_deleted.csv',
'0013_15_49_102.csv',
'20151008_gwf2_q2hr_whileloop_expt_17_15_31.csv'
# '20151008_gwf2_q2hr_whileloop_expt_17_15_31_first_line_deleted.csv'
]

interval_list=[
[4280,   4578],
[2400,   2700],
[2200,   2500],
[2804,   3202],
[2692,   3030],
[1825,   2125],
[1401,   1699],
[475,    773],
[35129,  35427],
[27671,  27969],
[950,    1248]
]
for input_file,interval in zip(filelist,interval_list):
       print input_file, interval[0],interval[1]
       altBN_pt2,altRelTime_pt2=TOR.detectPVI(
                     input_file=input_file, 
                     outName='',outSuffix=out_suffix,
                     input_subdir=input_subdir,
                     output_subdir=output_subdir,
                     BNinterval=[interval[0],interval[1]],
                     altBNstart=0,altRelTimeStart=0,
                     tvePos=True, dt=0.02,gender="female",ptHeight=67,
                     printout=True,
                     writePlain=True,keepBS=False,addRelTime=True)       


run_time=(time.time() - start_time)
print "-------%s seconds elapsed" %run_time