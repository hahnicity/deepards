# -*- coding: utf-8 -*-
"""
Created on Thu Jan 14 23:14:55 2016

@author: Keiko

based on 20160114_TOR3_RUNME.py
"""
import sys
import os
gitPath=r'C:\allMYfiles\My_Documents\GitHub\ucdpv\analysis'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.TOR3 as TOR
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)
import pandas as pd

root_dir=r'C:\allMYfiles\BOX\BedsideToCloud Pilot Project\PVI\Sandbox'
os.chdir(root_dir)

#%%


#%%pt8
#%%truncating validation files
TOR.detectPVI(input_file='0008_10_17_20.csv', 
              outName='',outSuffix='_TOR3_truncation_test',
              input_subdir=r'0TestFiles\fullFiles',output_subdir=r'20160114_TOR3',
              BNinterval=[3033,3076],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)


#%%truncation
TOR.detectPVI(input_file='0001_10_17_19.csv', 
              outName='',outSuffix='_4280to4578',
              input_subdir=r'0TestFiles\fullFiles',
              output_subdir=r'0TestFiles\derivation_truncation',
              BNinterval=[4280,4578],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)

#%%pt1
#%%detectPVI
TOR.detectPVI(input_file='0001_10_17_19_4280to4578_plain.csv', 
              outName='',outSuffix='_TOR3_0_0',
              input_subdir=r'0TestFiles\derivation_truncation',
              output_subdir=r'20160114_Derivation1',
              BNinterval=[],altBNstart=4280,altRelTimeStart=13189.48,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=False,addRelTime=True,
              outAbsTime=True,outAbsSep=False)               

#%%pt4
#%%truncation
TOR.detectPVI(input_file='0004_09_23_46.csv', 
              outName='',outSuffix='_2200to2500',
              input_subdir=r'0TestFiles\fullFiles',
              output_subdir=r'0TestFiles\derivation_truncation',
              BNinterval=[2200,2500],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)

#%%detectPVI
TOR.detectPVI(input_file='0004_09_23_46_2200to2500_plain.csv', 
              outName='',outSuffix='_TOR3_0_0',
              input_subdir=r'0TestFiles\derivation_truncation',
              output_subdir=r'20160114_Derivation1',
              BNinterval=[],altBNstart=2200,altRelTimeStart=9235.28,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=False,addRelTime=True,
              outAbsTime=True,outAbsSep=False)  
              

#%%truncation
TOR.detectPVI(input_file='0008_10_17_20.csv', 
              outName='',outSuffix='_2692to3030',
              input_subdir=r'0TestFiles\fullFiles',
              output_subdir=r'0TestFiles\derivation_truncation',
              BNinterval=[2692,3030],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)    
              
#%%detectPVI
TOR.detectPVI(input_file='0008_10_17_20_2692to3030_plain.csv', 
              outName='',outSuffix='_TOR3_0_0',
              input_subdir=r'0TestFiles\derivation_truncation',
              output_subdir=r'20160114_Derivation1',
              BNinterval=[],altBNstart=2692,altRelTimeStart=7155.72,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=False,addRelTime=True,
              outAbsTime=True,outAbsSep=False) 


#%%testing feed forward truncation information
#%%truncation
reload(TOR)
altBN_pt8,altRelTime_pt8=TOR.detectPVI(input_file='0008_10_17_20.csv', 
              outName='',outSuffix='_2692to3030_test_feed_forward',
              input_subdir=r'0TestFiles\fullFiles',
              output_subdir=r'20160114_TOR3',
              BNinterval=[2692,3030],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)    
              
TOR.detectPVI(input_file='0008_10_17_20_2692to3030_plain.csv', 
              outName='',outSuffix='_TOR3_0_0',
              input_subdir=r'0TestFiles\derivation_truncation',
              output_subdir=r'20160114_TOR3',
              BNinterval=[],
              altBNstart=altBN_pt8,altRelTimeStart=round(altRelTime_pt8,2),
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=False,addRelTime=True,
              outAbsTime=True,outAbsSep=False) 

#%%test 
inputSubdir='0TestFiles\derivation_truncation'
detect_subdir='20160114_TOR3'
sta_subdir=detect_subdir
waveFile='0008_10_17_20_2692to3030_plain.csv'
goldFile='0009_03_19_47_1_1824to2126_goldstd_dbl_bs_cosumtvd.csv'

filename= waveFile.strip('_plain.csv')

detPath =os.path.join(detect_subdir, filename+'_detected.csv')
dfDet=pd.read_csv(detPath,  index_col='BN')
dfPath =os.path.join(inputSubdir, goldFile)
dfGold=pd.read_csv(dfPath,  index_col='BN')