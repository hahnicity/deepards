# -*- coding: utf-8 -*-
"""
Created on Sun Nov 29 18:22:42 2015

@author: Keiko

Runme/driver file for algorithms/stats2

2015/12/08 Linked plotting <copy of 20151129_Stats2_LocalBokehPlot_RUNME.py>
2015/12/23 
    Heatmap boxes are the same width as inspiratory time.
    Fitted for output jason-vent-session4_cough_PS-nodotdot
"""

from __future__ import division
import os
import pandas as pd
import sys
import numpy as np
#%% import files
root_dir=r'C:\allMYfiles\BOX\BedsideToCloud Pilot Project\PVI\Sandbox'
os.chdir(root_dir )

gitPath=r'C:\allMYfiles\My_Documents\GitHub\ucdpv\analysis'
if gitPath not in sys.path:
    sys.path.append(gitPath)
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)
#%%import
#inputSubdir='input'
#outputSubdir=r'output'
#outputSubdir=r'output1208_twoDouble'
#
#waveFile='0007_file_1of1__588to794_plain_v5_reltime_plain.csv'
#goldFile='0007_file_1of1_1_587to795_gold_std_dbl_bs_cosumtvd.csv'
#detFile = '0007_file_1of1__588to794_plain_v5_reltime_detected.csv'
#filename='0007_file_1of1__588to794_plain_v5_reltime'

inputSubdir=r'0TestFiles\cough'
outputSubdir=r'20151211_CoughAlgv7'
#waveFile='jason-vent-session4_cough_PS_no_dotdot__2to43_plain.csv'
goldFile='jason-vent-session4_cough_PS_no_dotdot_1_1to44_adams_dbl_bs_cosumtvd.csv'
filename='jason-vent-session4_cough_PS_no_dotdot__2to43_plain_2.4.5'


accFile=filename+"_accuracy.csv"

#detPath =os.path.join(inputSubdir, filename+'_detected.csv')
detPath =os.path.join(outputSubdir, filename+'_detected.csv')
dfDet=pd.read_csv(detPath,  index_col='BN')
dfPath =os.path.join(inputSubdir, goldFile)
dfGold=pd.read_csv(dfPath,  index_col='BN')
#jason-vent-session4_cough_PS_no_dotdot__2to43_plain_2.4.4_detected.csv
#jason-vent-session4_cough_PS_no_dotdot__2to43_plain_2.4.4_detected
#%%call functions    
dfStats,dfCompared=sta.calcStats(dfDet,dfGold)
dfStatsShort=dfStats[0:3]
dfCounts=dfStats[5:]    
dfStats.to_csv(os.path.join(outputSubdir,accFile))

#converting to binary first
dfDetBinary=sta.convertAllBinary(dfDet)
dfStats2,dfCompared2=sta.calcStats(dfDetBinary,dfGold)
dfStats2.to_csv(os.path.join(outputSubdir,accFile))

print(dfStats2)

#%%
#%%
#%%new functions
def replace1swithName(dfDet,colPrefix='',printout=False):
    """
    
    Written:2015-11-29
    Updated:2015-12-08 Added ability to change name  
    """
    newDF=pd.DataFrame(index=dfDet.index, columns=dfDet.columns)
    newDF.ventBN=dfDet.ventBN
    newDF.BS=dfDet.BS

    for col in dfDet.columns.tolist():
        if colPrefix!='':
            newName=colPrefix+col
        else:
            newName=col
        if col not in ['BN','ventBN','BS']:
            if printout:
                print col, '--'
            newDF[col]=dfDet[col].replace(1,newName)
            newDF[col]=newDF[col].replace(0,np.NaN)
            if printout:
                list=newDF[col].tolist()
                print list
                
    return newDF

dfDetNames=replace1swithName(dfDetBinary)
#dfNewGold=replace1swithName(dfGold,colPrefix='GOLD-',printout=True)

#%%plot
from bokeh.plotting import figure, show, output_file, ColumnDataSource, gridplot

wavePath = (os.path.join(inputSubdir, filename+'_plain.csv'))
wavePath=(os.path.join(outputSubdir, filename+'_plain.csv'))
df_big = pd.read_csv(wavePath, names = ['time', 'flow', 'pressure']) 
clin_path=os.path.join(outputSubdir,filename+'_clinValues.csv')
df_clin=pd.read_csv(clin_path,index_col='BN')


title=filename
#%%
plotData=ColumnDataSource(df_big)

output_file(os.path.join(outputSubdir, filename +'_plot2.html'), title=filename)
wavePlot = figure(webgl=True, title=title,plot_width=800,plot_height=400,
                tools="xpan, xwheel_zoom,resize,crosshair,reset")
wavePlot.line(x='time', y='flow', source=plotData)
wavePlot.line('time', 'flow', line_width=0.5, legend = 'pressure', 
            line_color="purple", source=plotData)
wavePlot.xaxis.axis_label = "Time(s)"
wavePlot.line('time', 'pressure', line_width=0.5, legend='flow', 
            line_color="blue", 
            source=plotData)
            
#show(wavePlot)

#%% heatmap
#future variables
add_BN=True
PVItoGraph=[]
PVItoGraph=['GOLD-dbl','dbl','GOLD-mt','mt',
            'dbl.2','GOLD-bs','bs','GOLD-co','co','co.2','co.3','co.4','co.5',
            'vd']
if add_BN:
    PVItoGraph.insert(0,'BN')

reload(dicts)
hmData=ColumnDataSource(dfDetNames)



#xlocation based on index
BNs=dfDetNames.index.tolist()
xloc=BNs
#xlocation based on time
xloc=dfDetNames.BS.tolist()
# add breath numbers
wavePlot.text(x='BS',y=50,text=BNs,source=hmData)

#default things to graph
if PVItoGraph==[]:
    ylabel=dfDetNames.columns.tolist()
    ylabel.remove('ventBN')
    ylabel.remove('BS')
#    ylabel.append('gold')
else:
    ylabel=PVItoGraph

hm = figure(webgl=True, title=title,plot_width=800,plot_height=400,
                tools="xpan, xwheel_zoom,resize,crosshair,reset",
                y_range=ylabel, x_range=wavePlot.x_range)

i_widths=df_clin.iTime.tolist()
for pvi in ylabel:
    notGold=pvi.split('-')[0]!='GOLD'
    if pvi not in ['BN','ventBN','BS'] and notGold:
#        print pvi
        shortPVI=pvi.split('.')[0]
        color= dicts.colors[shortPVI]
#        hm.circle(x=xloc,y=pvi,source=hmData,alpha=0.5,color=color) 
        hm.rect(x=xloc,y=pvi,width=i_widths,height=1,source=hmData,alpha=0.5,color=color) 

newGold=dfGold.replace(0,np.nan)
newGold.dbl=newGold.dbl.replace(1,'GOLD-dbl')
newGold.mt=newGold.mt.replace(1,'GOLD-mt')
newGold.co=newGold.co.replace(1,'GOLD-co')
newGold.bs=newGold.bs.replace(1,'GOLD-bs')

hm.rect(x=xloc, y=newGold.dbl.tolist(), width=i_widths,height=1,color='black')
hm.rect(x=xloc, y=newGold.mt.tolist(), width=i_widths,height=1,color='black')
hm.rect(x=xloc, y=newGold.co.tolist(), width=i_widths,height=1,color='black')
hm.rect(x=xloc, y=newGold.bs.tolist(), width=i_widths,height=1,color='black')

if add_BN:
    BN_row=len(BNs)*['BN']
    hm.text(x=xloc,y=BN_row,text=BNs)
#hm.rect(x=xloc, y=newGold.co.tolist(), width=1,height=1,color='black')
#hm.rect(x=xloc, y=newGold.bs.tolist(), width=1,height=1,color='black')


both=gridplot([[hm],[wavePlot]]) 
show(both)
