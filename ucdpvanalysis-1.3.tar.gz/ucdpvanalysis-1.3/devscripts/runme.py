# -*- coding: utf-8 -*-
"""
Created on Wed Jun 03 16:39:34 2015

@author: Keiko

Use this script for output related to algorithm development
"""
from __future__ import division
#run TOR.py first
import os
import numpy as np
import sys
import csv
#sys.path.insert(0, r'C:\allMYfiles\My_Documents\GitHub\ucdpv\analysis')
import dicts; 
reload(dicts)
import stats; 
reload(stats)
import pviplot;
reload (pviplot)

root_dir=r'C:\allMYfiles\My_Documents\GitHub\sandbox3_stats'
os.chdir(root_dir )
input_subdir='input'
output_subdir='output'


input_file='2014_06_11_PB840_DBL_TRIG.csv'
filename=os.path.splitext(input_file) [0]
input_path=os.path.join (output_subdir, input_file) 

#%% import detected


det_path = os.path.join(output_subdir,filename+'_anno.csv')
det = stats.readDetectedAnns(det_path, 'detected', input_file)
det.replNames(dicts.abbrev)
clinValues_path = os.path.join(output_subdir,filename+'_clin.csv')
det.addClinValues(clinValues_path)

#%%import cviz anns
gs_path = os.path.join (input_subdir, 'a_lung_P_CTRL_PB840_DBL_TRIG_GOLD.csv')

gs = stats.readCvizAnns(gs_path, 'gold standard', input_file)
gs.replNames(dicts.abbrev)
gs.removeNormals()

gs.byBreath(det.breaths_list)

#%%
test = stats.compareTwo(gs,det)
test.align_two(gs.byBreath, det.byBreath)
test.c_kappa(test.aligned, dicts.codes)
test.toCoded(dicts.codes)
test.plotCohen(test.aligned, dicts.codes)

subsets = stats.evalSubsets(test.aligned, test.title, dicts.codes, det.clinValues)
subsets.print_stats()


#%%import waveform
#waveform=gbp.csvTOmat(os.path.join(output_subdir,filename+'_plain.csv'))
wave_path = os.path.join(output_subdir,filename+'_plain.csv')
wave = stats.readWaveform(wave_path, 'a_lung_P_CTRL_PB840_DBL_TRIG_GOLD.csv')

#%% plot waveform
import matplotlib.pyplot as plt
import mpld3
from mpld3 import plugins

time = wave.time
pressure = wave.pressure
flow = wave.flow


#%% regular plot of waveform
fig = plt.figure(figsize=(12,5))
fig.suptitle(input_file +"\n\n", fontsize=14)
axes1 = fig.add_subplot(2,1,1)
axes1.plot(time, pressure, color='purple')
axes1.axhspan(0, 0, color='gray', alpha=0.5)
axes1.plot(time,flow, color='blue')
print 'static or dynamic plot?'
plotType = raw_input ('  >')
if plotType == 'dynamic':
    mpld3.show()
else: 
    pass

pviplot.pviStatic(test, dicts.colors, det.breaths)



#%% scatter tooltip
#import matplotlib.pyplot as plt-
#import numpy as np
#import mpld3
#
#fig, ax = plt.subplots(subplot_kw=dict(axisbg='#EEEEEE'))
#N = 100
#heatmap = ax.matshow(cm, cmap='seismic_r')r
#ax.set_title('Confusion matrix \n'+'True vs. pred')
#ax.set_ylabel('True')
#ax.set_xlabel('Pred')
#
#        #overlay confusion matrix values
#for y in range(cm.shape[0]):
#    for x in range(cm.shape[1]):
#        plt.text(x, y, '%d' % cm[y, x],
#                 horizontalalignment='center',
#                 verticalalignment='center',
#                 color='white'
#                 )
#
#divider = make_axes_locatable(plt.gca())
#cax = divider.append_axes("right", size="10%", pad=0.2)
#plt.colorbar(ax.matshow(cm, cmap='seismic_r'),cax=cax)
##scatter = ax.scatter(np.random.normal(size=N),
##                     np.random.normal(size=N),
##                     c=np.random.random(size=N),
##                     s=1000 * np.random.random(size=N),
##                     alpha=0.3,
##                     cmap=plt.cm.jet)
##ax.grid(color='white', linestyle='solid')
#
#ax.set_title("PVI", size=20)
#
##labels = ['point {0}'.format(i + 1) for i in range(N)]
##tooltip = mpld3.plugins.PointLabelTooltip(scatter, labels=labels)
#mpld3.plugins.connect(fig, tooltip)
#
#mpld3.show()