"""
Created on April 14
"""
import os

def fancy_get_file_names(input_subdir,ends_with="",strip_suffix=False,
                        contains=""):
    """
    Gets file names from a directory and returns a list
    Versions 2016-04-14

    Args:
    -----
     input_subdir: path to input subdirectory
     ends_with: suffix that the file should have
     strip_suffix: removes the suffix in the output (ex. print names without ".csv")
     contains: keyword that file should contains

    examples:
    ---------
        #get csv files only and remove ".csv" at the end
        files=fancy_get_file_names(input_subdir=gold_subdir,
                                    ends_with=".csv",strip_suffix=True,
                                    contains="")
        #get log files but keep ".txt" at the end
        files=fancy_get_file_names(input_subdir=gold_subdir,
                                    ends_with=".txt",strip_suffix=False,
                                    contains="logfile")

        #get a list of any file in the directory
        files=fancy_get_file_names(input_subdir=gold_subdir,
                                    ends_with="",strip_suffix=False,
                                    contains="")  
        # or
        files=fancy_get_file_names(gold_subdir)      

    """
    file_list=[]
    suffix = ends_with
    keyword = contains
    copy_file_name = False
    for root,dirs,files in os.walk(input_subdir):
        for file_name in files:
            if file_name.endswith(suffix) and keyword in file_name:
                if strip_suffix:
                    file_name=file_name.rstrip(suffix)
                file_list.append(file_name)

    return file_list

#try extracting file names.
if __name__=="__main__":
    root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox' 
    output_subdir=r'20160411_gold_combine_cosumtvd'
    gold_subdir=r'0TestFiles/2016-04-12-gold_standard_combine_cosumtvd'

    os.chdir(root_dir) 

    #get csv files only and remove ".csv" at the end
    files=fancy_get_file_names(input_subdir=gold_subdir,
                                ends_with=".csv",strip_suffix=True,
                                contains="")
    #get log files but keep ".txt" at the end
    files=fancy_get_file_names(input_subdir=gold_subdir,
                                ends_with=".txt",strip_suffix=False,
                                contains="logfile")

    #get a list of any file in the directory
    files=fancy_get_file_names(input_subdir=gold_subdir,
                                ends_with="",strip_suffix=False,
                                contains="")  
    # or
    files=fancy_get_file_names(gold_subdir)      

    
    for gold_file in files:
        print gold_file
