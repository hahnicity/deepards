"""
created to develop reading in new file types
"""

import sys
import os
import pandas as pd

#import custom package
gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.TOR3 as TOR; reload(TOR)
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)


root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox'
os.chdir(root_dir)
output_subdir=r'20160418_read_file_dev'
try:
  os.mkdir(output_subdir)
except:
  print "'%s' subdirectory already exists" %output_subdir

altBN,altRelTime=TOR.detectPVI(input_file='0175-2016-03-07-11-14-19.832687.csv', 
              outName='',outSuffix='1_test_new_read',
              input_subdir=r'0TestFiles/fullFiles',
              output_subdir=output_subdir,
              BNinterval=[],
              # BNinterval=[4280,4578],
              altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=False,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False,
              anyCosumtvd=True) 





altBN,altRelTime=TOR.detectPVI(input_file='0024_RPi04_2015-06-09__02-35-04.csv', 
              outName='',outSuffix='1_test_new_read',
              input_subdir=r'0TestFiles/fullFiles',
              output_subdir=output_subdir,
              BNinterval=[],
              # BNinterval=[4280,4578],
              altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=False,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False,
              anyCosumtvd=True) 


altBN,altRelTime=TOR.detectPVI(input_file='0015__2015-04-06__13_51_38.027640436.csv', 
              outName='',outSuffix='1_test_new_read',
              input_subdir=r'0TestFiles/fullFiles',
              output_subdir=output_subdir,
              BNinterval=[],
              # BNinterval=[4280,4578],
              altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=False,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False,
              anyCosumtvd=True) 



# quit()

# from os import chdir, path
# root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox/'
# chdir(root_dir)
# input_dir=r'0TestFiles/fullFiles'
# output_dir=r'20160418_read_file_dev'

# input_csv=path.join(root_dir,input_dir,"0175-2016-03-07-11-14-19.832687.csv")
# output_csv=path.join(root_dir,output_dir,'0175-2016-03-07-11-14-19.832687_post.csv')

# with open(input_csv,'rU') as rawFirstLine:
#     first = rawFirstLine.readline()
#     print first
#     print first.split(' ')
#     print first.split('-')
#     print len(first.split('-'))



# altBN,altRelTime=TOR.detectPVI(input_file='0001_10_17_19.csv', 
#               outName='',outSuffix='4_no_co_during_sumt',
#               #'3_cough_in_middle_frame_threshold',
#               #'2_cough_new_thresholds'
#               #'1_pre',

#               input_subdir=r'0TestFiles/fullFiles',
#               output_subdir=output_subdir,
#               BNinterval=[4280,4578],
#               altBNstart=0,altRelTimeStart=0,
#               tvePos=True, dt=0.02,gender="female",ptHeight=67,
#               printout=True,
#               writePlain=False,keepBS=True,addRelTime=False,
#               outAbsTime=True,outAbsSep=False,
#               anyCosumtvd=True) 
#test multiple files


# VERSION 1
#     with open(inputPath,'rU') as rawFirstLine:
#         first = rawFirstLine.readline()
#         #detect 1st type, 2 col 
#         if len(first.split(', ')) == 2:  #BS, S:52335,\n
#             timestamp_1st_col = False
#             timestamp_1st_row = False
#             printLog(outputPath, 'Timestamp = False (v1)')
#             printLog(outputPath, '----------------')
#             BScol = 0
#             ncol = 2

#         #detect 2nd type, with first column as time column
#         elif len(first.split(', ')) == 3:
#             timestamp_1st_col = True
#             timestamp_1st_row = False
#             printLog(outputPath, 'Timestamp as 3rd col (v2)')
#             printLog(outputPath, '--------------------')
#             BScol = 1
#             ncol = 3

#         #detect 3rd type, with date time in first row
#         elif len(first.split('-'))==6:
#             timestamp_1st_col = False
#             timestamp_1st_row = True
#             printLog(outputPath, 'Timestamp in first row (V3)')
#             printLog(outputPath, '-----------------------')
#             BScol = 0
#             ncol = 2
        
#         else:
#             print "ERROR, what file version?"