"""
Created on Thu Feb 4 21:00:00 2016

@author: Keiko

based on 20160202_TOR3_trunc_run_RUNME.py
run in mac
"""

import sys
import os
import pandas as pd

#import custom package
gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.TOR3 as TOR; reload(TOR)
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)


root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox'
os.chdir(root_dir)

#%%truncation pt 2
reload(TOR)

#graph this file 
# file is "/static/output/WF_B2CRPi03__2015-02-15__21_17_20.798541945_3.csv" 
#pt 7 0007_21_17_20_3_2803to3203_goldstd_dbl_bs_cosumtvd
altBN,altRelTime=TOR.detectPVI(input_file='0007_file_1of1.csv', 
              outName='',outSuffix='_3_1_8_nubbin3',
              input_subdir=r'0TestFiles/fullFiles',
              output_subdir=r'20160224_TOR3_nubbin',
              BNinterval=[2804,3202],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False,
              anyCosumtvd=True) 


#stats 
gold_subdir=r'0TestFiles/2016-02-06-gold_standard'
sta.calcMultiStats(logfile='0007_file_1of1_2804to3202_3_1_5_smartbuffer_logfile.txt',
            gold_name='0007_21_17_20_3_2803to3203_goldstd_dbl_bs_cosumtvd.csv',
            det_subdir=r'20160224_TOR3_nubbin',
            output_subdir=r'20160224_TOR3_nubbin',
            gold_subdir=gold_subdir)