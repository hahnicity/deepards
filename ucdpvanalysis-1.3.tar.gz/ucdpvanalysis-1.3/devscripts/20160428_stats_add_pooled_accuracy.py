# -*- coding: utf-8 -*-
"""
Created on Thu Jan 14 23:14:55 2016

@author: Keiko

1.1 Add pooled stats as function and df piping
based on 20160421_stats_add_true_pooled.py
based on 20160418_TOR3_4_2_group_post_cough
added dynamic list update
based on 
based on 20160301_TOR3_group2.py
based on 20160224_TOR3_group.py
based on 20160216_TOR3_derivation_RUNME.py
based on 20160211_TOR3_derivation_RUNME.py
based on 20160202_TOR3_trunc_run_RUNME.py
run in mac
"""
from __future__ import division
__version__="1.1"

import sys
import os
import time
import pandas as pd
gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.TOR3 as TOR
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)
import analytics.pool_stats as pool; reload(pool)
import pdb

start_time = time.time() 
#%%change these!!
root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox'
input_subdir=r'0TestFiles/fullFiles'
# input_subdir=r'0TestFiles/2016-04-26-fullFiles_renamed'
gold_subdir=r'0TestFiles/2016-04-19-gold_standard_combine_cosumtvd_and_vd'
det_subdir=r'20160428_TOR3_4_9_group_results_post_merge'

runTOR = True

#%%remember to use new input directory!!!!


aggregated_stats_csv="aggregated_stats7_PIPE_"+det_subdir+".csv" #optional, change pooled stats_name
real_pooled_stats_csv="pooled_stats7_PIPE_"+det_subdir+".csv" #optional, change pooled stats_name

out_suffix=''

#change root_dir
os.chdir(root_dir)
#make subfolder for accuracies
det_analysis_subdir=os.path.join(det_subdir,'accuracies')

#move to an outside function
def fancy_get_file_names(input_subdir,ends_with="",strip_suffix=False,
                        contains=""):
    """
    Gets file names from a directory and returns a list
    Versions 2016-04-14

    Args:
    -----
     input_subdir: path to input subdirectory
     ends_with: suffix that the file should have
     strip_suffix: removes the suffix in the output (ex. print names without ".csv")
     contains: keyword that file should contains

    examples:
    ---------
        #get csv files only and remove ".csv" at the end
        files=fancy_get_file_names(input_subdir=gold_subdir,
                                    ends_with=".csv",strip_suffix=True,
                                    contains="")
        #get log files but keep ".txt" at the end
        files=fancy_get_file_names(input_subdir=gold_subdir,
                                    ends_with=".txt",strip_suffix=False,
                                    contains="logfile")

        #get a list of any file in the directory
        files=fancy_get_file_names(input_subdir=gold_subdir,
                                    ends_with="",strip_suffix=False,
                                    contains="")  
        # or
        files=fancy_get_file_names(gold_subdir)      

    """
    file_list=[]
    suffix = ends_with
    keyword = contains
    copy_file_name = False
    for root,dirs,files in os.walk(input_subdir):
        for file_name in files:
            if file_name.endswith(suffix) and keyword in file_name:
                if strip_suffix:
                    file_name=file_name.rstrip(suffix)
                file_list.append(file_name)

    return file_list

filelist=[
'0001_10_17_19.csv',
'0002_09_14_38.csv',
'0004_09_23_46.csv',
'0007_21_17_20.csv',
'0008_10_17_20.csv',
'0009_03_19_47.csv',
'0010_00_17_20_11.csv',
'0010_03_17_19_deleted_first_line.csv',
'0011_14_17_21.csv',
'0012_19_53_45_first_and_last_line_deleted.csv',
'0013_15_49_102.csv',
'20151008_gwf2_q2hr_whileloop_expt_17_15_31.csv'
]

interval_list=[
[4280,   4578],
[2400,   2700],
[2200,   2500],
[2804,   3202],
[2692,   3030],
[1825,   2125],
[20800,  20840],
[1401,   1699],
[475,    773],
[35129,  35427],
[27671,  27969],
[950,    1248]

]

try:
    os.mkdir(det_subdir)
except:
    print "'%s' subdirectory already exists" %det_subdir
try:
    os.mkdir(det_analysis_subdir)
except:
  print "'%s' subdirectory already exists" %det_analysis_subdir
if runTOR:
    for input_file,interval in zip(filelist,interval_list):
           print input_file, interval[0],interval[1]
           altBN_pt2,altRelTime_pt2=TOR.detectPVI(
                         input_file=input_file, 
                         outName='',outSuffix=out_suffix,
                         input_subdir=input_subdir,
                         output_subdir=det_subdir,
                         BNinterval=[interval[0],interval[1]],
                         altBNstart=0,altRelTimeStart=0,
                         tvePos=True, dt=0.02,gender="female",ptHeight=67,
                         printout=True,
                         writePlain=False,keepBS=False,addRelTime=True)       

gold_file_list = fancy_get_file_names(input_subdir=gold_subdir,
                    ends_with=".csv",strip_suffix=False)


# for gold in gold_file_list:
#     print gold

log_file_list = fancy_get_file_names(input_subdir=det_subdir,
                    ends_with="logfile.txt",strip_suffix=False)
# for logfile in log_file_list:
#     print logfile

#ensure there are the same number of files in each folder
error_message =  "Different number of gold files(%s) vs. logfiles(%s)"%(len(gold_file_list),len(log_file_list))
assert len(gold_file_list)==len(log_file_list),error_message

log_file_list.sort()
gold_file_list.sort()

# assert len(gold_file_list)==5, "Files do not match up"


for gold_file,log_file in zip(gold_file_list,log_file_list):
    assert gold_file[0:4]==log_file[0:4], "File mismatch: %s, %s" %(gold_file,logfile)
    print '\n',log_file, gold_file
    print '-----------------'


    # try:
    sta.calcMultiStats(logfile=log_file,
        gold_name=gold_file,
        det_subdir=det_subdir,output_subdir=det_analysis_subdir,gold_subdir=gold_subdir,
        subfiles_list=[
                    '_class_matrix_raw.csv',
                    '_class_matrix_raw_multi_frame2.csv',                 
                    '_solo.csv',
                    '_solo2.csv',
                    '_solo3.csv'])

    # except IOError:
    #     print IOError
    #     print log_file
    #     pdb.set_trace()
    # except:
    #     print "other error"
    #     print log_file

#aggregate results together
# from analytics.pool_stats import aggregate_stats

agg_df=pool.aggregate_stats(det_analysis_subdir,ppvi_list=['dbl.2','dbl.4','bs.1','mt','mt.su','co.orig','co.2thresh','co.noTVi','vd.2','su.2','sumt'],
        # output_csv=output_csv,
        matrix_keywords=["raw__ACCURACY","multi_frame2__ACCURACY","solo3__ACCURACY"],
        stat_list=['accuracy','sensitivity','specificity','total','events','FNs','FPs','TPs','TNs'])


agg_df.to_csv(os.path.join(det_analysis_subdir,aggregated_stats_csv))
#pool results together
new = pool.pool_stats(agg_df)
new.to_csv(os.path.join(det_analysis_subdir,real_pooled_stats_csv))


# #pool results together
# imported_df = pd.read_csv(os.path.join(det_analysis_subdir,aggregated_stats_csv),index_col=[0,1],header=[0,1])
# new = pool.pool_stats(imported_df)
# new.to_csv(os.path.join(det_analysis_subdir,real_pooled_stats_csv))


# #pool results together
# new = pd.read_csv(os.path.join(det_analysis_subdir,aggregated_stats_csv),index_col=[0,1],header=[0,1])

# new.fillna(0)
# new = new.convert_objects(convert_numeric=True)
# new= new.groupby(level=0).sum()
# new=new.transpose()
# new['TPandFNs']=new['TPs']+new['FNs']
# new['TNandFPs']=new['TNs']+new['FPs']
# new['all4']=new['TPandFNs']+new['TNandFPs']
# new['accuracy']=(new['TPs']+new['TNs'])/new['all4']
# new['sensitivity']=new['TPs']/new['TPandFNs']
# new['specificity']=new['TNs']/new['TNandFPs']

# new=new.transpose()
# new.to_csv(os.path.join(det_analysis_subdir,real_pooled_stats_csv))




run_time=(time.time() - start_time)
print "-------%s seconds elapsed" %run_time
quit()
