# -*- coding: utf-8 -*-
"""
Created on Sun Nov 29 18:22:42 2015

@author: Keiko

Runme/driver file for algorithms/stats2
"""

from __future__ import division
import os
import pandas as pd
import sys

#%% import files
root_dir=r'C:\allMYfiles\BOX\BedsideToCloud Pilot Project\PVI\Sandbox\20151114_Stats'
os.chdir(root_dir )

analyticsPath=r'C:\allMYfiles\My_Documents\GitHub\ucdpv\analysis'
if analyticsPath not in sys.path:
    sys.path.append(analyticsPath)
import stats2 as sta; reload(sta)

#%%import
inputSubdir='input'
outputSubdir=r'output'
inputFile='RPi07_gwf5_get_serial4_file1_2015_10_31_12_20_25.122301.csv'

waveFile='0007_file_1of1__588to794_plain_v5_reltime_plain.csv'
goldFile='0007_file_1of1_1_587to795_gold_std_dbl_bs_cosumtvd.csv'
detFile = '0007_file_1of1__588to794_plain_v5_reltime_detected.csv'

filename='0007_file_1of1__588to794_plain_v5_reltime'
accFile=filename+"_accuracy.csv"

detPath =os.path.join(inputSubdir, filename+'_detected.csv')
dfDet=pd.read_csv(detPath,  index_col='BN')
dfPath =os.path.join(inputSubdir, goldFile)
dfGold=pd.read_csv(dfPath,  index_col='BN')


#%%call functions    
dfStats,dfCompared=sta.calcStats(dfDet,dfGold)
dfStatsShort=dfStats[0:3]
dfCounts=dfStats[5:]    
dfStats.to_csv(os.path.join(outputSubdir,accFile))

#converting to binary first
dfDetBinary=sta.convertAllBinary(dfDet)
dfStats2,dfCompared2=sta.calcStats(dfDetBinary,dfGold)

print(dfStats2)

