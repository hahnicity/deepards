# -*- coding: utf-8 -*-
"""
Created on Thu Jan 14 23:14:55 2016

@author: Keiko

based on 20160202_TOR3_stats_RUNME.py
run in mac
"""
import sys
import os
gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.TOR3 as TOR
import analytics.stats2 as sta; reload(sta)
import analytics.dicts as dicts; reload(dicts)
import pandas as pd

root_dir=r'/Users/monica/Box Sync/BedsideToCloud Pilot Project/PVI/Sandbox'
os.chdir(root_dir)

#%%truncation pt 2
reload(TOR)
altBN_pt2,altRelTime_pt2=TOR.detectPVI(input_file='0002_09_14_38.csv', 
              outName='',outSuffix='_2400to2700',
              input_subdir=r'0TestFiles/fullFiles',
              output_subdir=r'0TestFiles/2016-02-02_derivation_truncation2',
              BNinterval=[2200,2500],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)    
 #%% detectPVI            
TOR.detectPVI(input_file='0002_09_14_38_2400to2700_plain.csv', 
              outName='',outSuffix='_TOR3_1_0',
              input_subdir=r'0TestFiles/2016-02-02_derivation_truncation2',
              output_subdir=r'20160202_Derivation1',
              BNinterval=[],
              altBNstart=altBN_pt2,altRelTimeStart=round(altRelTime_pt2,2),
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=False,addRelTime=True,
              outAbsTime=True,outAbsSep=False) 
#%%truncation pt 4
reload(TOR)
altBN_pt4,altRelTime_pt4=TOR.detectPVI(input_file='0004_09_23_46.csv', 
              outName='',outSuffix='_2200to2500',
              input_subdir=r'0TestFiles/fullFiles',
              output_subdir=r'0TestFiles/2016-02-02_derivation_truncation2',
              BNinterval=[2200,2500],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)    
 #%% detectPVI pt             
TOR.detectPVI(input_file='0004_09_23_46_2200to2500_plain.csv', 
              outName='',outSuffix='_TOR3_1_0',
              input_subdir=r'0TestFiles/2016-02-02_derivation_truncation2',
              output_subdir=r'20160202_Derivation1',
              BNinterval=[],
              altBNstart=altBN_pt4,altRelTimeStart=round(altRelTime_pt4,2),
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=False,addRelTime=True,
              outAbsTime=True,outAbsSep=False) 

#%%truncation pt 7
reload(TOR)
altBN_pt7,altRelTime_pt7=TOR.detectPVI(input_file='0007_file_1of1.csv', 
              outName='',outSuffix='_2804to3202',
              input_subdir=r'0TestFiles/fullFiles',
              output_subdir=r'0TestFiles/2016-02-02_derivation_truncation2',
              BNinterval=[2200,2500],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)    
 #%% detectPVI pt             
TOR.detectPVI(input_file='0007_file_1of1_2804to3202_plain.csv', 
              outName='',outSuffix='_TOR3_1_0',
              input_subdir=r'0TestFiles/2016-02-02_derivation_truncation2',
              output_subdir=r'20160202_Derivation1',
              BNinterval=[],
              altBNstart=altBN_pt7,altRelTimeStart=round(altRelTime_pt7,2),
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=False,addRelTime=True,
              outAbsTime=True,outAbsSep=False) 

#%%truncation pt 8
reload(TOR)
altBN_pt8,altRelTime_pt8=TOR.detectPVI(input_file='0008_10_17_20.csv', 
              outName='',outSuffix='_2692to3030',
              input_subdir=r'0TestFiles/fullFiles',
              output_subdir=r'0TestFiles/2016-02-02_derivation_truncation2',
              BNinterval=[2692,3030],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)    
 #%% detectPVI pt             
TOR.detectPVI(input_file='0008_10_17_20_2692to3030_plain.csv', 
              outName='',outSuffix='_TOR3_1_0',
              input_subdir=r'0TestFiles/2016-02-02_derivation_truncation2',
              output_subdir=r'20160202_Derivation1',
              BNinterval=[],
              altBNstart=altBN_pt8,altRelTimeStart=round(altRelTime_pt8,2),
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=False,addRelTime=True,
              outAbsTime=True,outAbsSep=False) 


#%%truncation pt 9
reload(TOR)
altBN_pt9,altRelTime_pt9=TOR.detectPVI(input_file='0009_03_19_47.csv', 
              outName='',outSuffix='_1825to2125',
              input_subdir=r'0TestFiles/fullFiles',
              output_subdir=r'0TestFiles/2016-02-02_derivation_truncation2',
              BNinterval=[1825,2125],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)    
 #%% detectPVI pt             
TOR.detectPVI(input_file='0009_03_19_47_1825to2125_plain.csv', 
              outName='',outSuffix='_TOR3_1_0',
              input_subdir=r'0TestFiles/2016-02-02_derivation_truncation2',
              output_subdir=r'20160202_Derivation1',
              BNinterval=[],
              altBNstart=altBN_pt9,altRelTimeStart=round(altRelTime_pt9,2),
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=False,addRelTime=True,
              outAbsTime=True,outAbsSep=False) 


#%%truncation pt 10
reload(TOR)
altBN_pt10,altRelTime_pt10=TOR.detectPVI(input_file='0010_03_17_19_deleted_first_line.csv', 
              outName='',outSuffix='_1401to1699',
              input_subdir=r'0TestFiles/fullFiles',
              output_subdir=r'0TestFiles/2016-02-02_derivation_truncation2',
              BNinterval=[1401,1699],altBNstart=0,altRelTimeStart=0,
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=True,addRelTime=False,
              outAbsTime=True,outAbsSep=False)    
 #%% detectPVI pt             
TOR.detectPVI(input_file='0010_03_17_19_deleted_first_line_1401to1699_plain.csv', 
              outName='',outSuffix='_TOR3_1_0',
              input_subdir=r'0TestFiles/2016-02-02_derivation_truncation2',
              output_subdir=r'20160202_Derivation1',
              BNinterval=[],
              altBNstart=altBN_pt10,altRelTimeStart=round(altRelTime_pt10,2),
              tvePos=True, dt=0.02,gender="female",ptHeight=67,
              printout=True,
              writePlain=True,keepBS=False,addRelTime=True,
              outAbsTime=True,outAbsSep=False) 
