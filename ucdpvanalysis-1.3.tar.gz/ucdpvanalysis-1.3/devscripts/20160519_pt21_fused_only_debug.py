#run 20160516 TOR first
#change wd in terminal first
import sys
import os
import pdb

gitPath=r'/Users/monica/github/ucdpv/analysis/'
if gitPath not in sys.path:
     sys.path.append(gitPath)

import algorithms.solo_fused as fused; reload(fused)
import utilikilt.oz as oz

root_dir=r'/Users/monica/Box Sync/UCD/sandbox2016/'
os.chdir(root_dir)
det_root=r'20160516_fix_fusion'


os.chdir(det_root)

# oz.mkdir("new")

# fused.create_solo_fused("0021_00_43_00_4100to4399_v3_5_7__2_original_solo3_copy.csv","0021_00_43_00_4100to4399_v3_5_7__2_original_breath_meta_copy.csv",61.6)
fused.create_solo_fused("0021_00_43_00_4100to4399_v3_5_7__2_original_breath_meta_copy.csv","0021_00_43_00_4100to4399_v3_5_7__2_original_solo3_copy.csv",
    61.6, dbl_alg="dbl.4",
    meta_fused_path=r"new/0021_00_43_00_4100to4399_v3_5_7__2_original_breath_meta_copy_FUSED11_newTVV.csv",
    detected_fused_path=r"new/0021_00_43_00_4100to4399_v3_5_7__2_original_solo3_copy_FUSED11_newTVV.csv",
    breath_meta_row_prefix=["BN","ventBN","BS"])


                        # meta_fused_path=r"new/0021_00_43_00_4100to4399_v3_5_7__2_original_breath_meta_copy_FUSED5_add_blank.csv",
                        # detected_fused_path=r"new/0021_00_43_00_4100to4399_v3_5_7__2_original_solo3_copy_FUSED5_add_blank.csv")


# fused.create_solo_fused("0021_00_43_00_4100to4399_v3_5_7__2_original_breath_meta_copy.csv","0021_00_43_00_4100to4399_v3_5_7__2_original_solo3_copy.csv",61.6)