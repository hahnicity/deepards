from fastdtw import fastdtw
import numpy as np
from scipy.spatial.distance import euclidean
from numpy import linalg as LA
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib.cm as cm
import pylab as p
from time import time
import os
import sys;
sys.path.append("/ucdpvanalytics/")
from algorithms.raw_utils import extract_raw_speedup
from algorithms.breath_meta import get_production_breath_meta
from algorithms.tor5 import detectPVI


pd.set_option('display.max_columns', 50)
pd.set_option('display.width', 1000)
pd.set_option('display.max_rows', 200)
pd.set_option('display.height', 1000)


patientname = '0147RPI1220160213-rpi12-2016-02-17-15-06-15.106260'  #manually input patient's file name
print "Patient's Name: {}".format(patientname)


df = pd.DataFrame(columns=['BN','DTWs', 'DTWi', 'DTWe'])

#Get the pressure waveform of Inspiration part in Golden Breath in VC mode
out_min = G_out.min()




g = open("/Users/nella/Desktop/AIM_2/DTW-test/data/ventmode-datafiles/raw_vwd/%s.csv" %patientname)  #manually set the path for raw vwd file

print 'Abnormal Breaths Detection Start'
generator2 = extract_raw_speedup(g,False)
detectdata = detectPVI(generator2)
solo = detectdata[0]

BS = pd.DataFrame(solo[solo['bs.1or2']>0]['BN']) #if BS exist
BS['BS'] = 1


DT = pd.DataFrame(solo[solo['dbl.4']>0]['BN']) #if DT exist
DT['DT'] = 1
dg = pd.concat([BS,DT],axis=1)


CO = pd.DataFrame(solo[solo['co.noTVi'] > 0]['BN']) # if CO exist
CO['CO'] = 1
dg = pd.concat([dg,CO],axis=1)

SU = pd.DataFrame(solo[solo['su.2']>0]['BN']) # if SU exist
SU['SU'] = 1
dg = pd.concat([dg,SU],axis=1)

MT = pd.DataFrame(solo[solo['mt']>0]['BN']) # if MT exist
MT['MT'] = 1
dg = pd.concat([dg,MT],axis=1)

VD = pd.DataFrame(solo[solo['vd.2']>0]['BN']) # if VD exist
VD['VD'] = 1
dg = pd.concat([dg,VD],axis=1)

dg = dg.drop('BN',1)

print 'Abnormal Breaths Detection Completed'

f = open("/Users/nella/Desktop/AIM_2/DTW-test/data/ventmode-datafiles/raw_vwd/%s.csv" %patientname)
print 'DTW Distance Calculation Start'

generator = extract_raw_speedup(f,False)

for breath in generator:
	metadata = get_production_breath_meta(breath)

	cut = metadata[28] #find the cut point for inspiration & expiration
	NoB = metadata[0] #get the Breath Number

	length = len(breath['flow'])
	#print "The cut is:{}, from {} to {}".format(cut,breath['flow'][cut-1],breath['flow'][cut])

	B_in = np.array(breath['pressure'][0:cut]) # get the pressure waveform in inspiration part
	B_out = np.array(breath['flow'][cut:length]) # get the flow waveform in expiration part
	B_in_max = B_in.max()
	B_out_min = B_out.min()

	B_in = B_in/B_in_max*in_max # scale the current breath to the same peak as golden breath
	B_out = B_out/B_out_min*out_min
	#print "Breath IN :{}".format(B_in)
	#print "Breath OUT :{}".format(B_out)
	#print np.array(B_out).empty

	dist_in,path_in = fastdtw(B_in,G_in,dist= euclidean) # calculate the DTWi
	dist_out,path_out = fastdtw(B_out,G_out,dist=euclidean) # calculate the DTWe

	df2 = pd.DataFrame([[NoB,dist_in + dist_out,dist_in,dist_out]], columns=['BN','DTWs', 'DTWi', 'DTWe']) # DTWs

	df = df.append(df2)


print 'DTW Distance Calculation Completed'
df = df.reset_index()
df = df.drop('index',1)

result = pd.concat([df,dg],axis=1)
result = result.fillna(0)
result['ABNOR'] = result['BS']+result['DT']+result['CO']+result['SU']+result['MT']+result['VD']  #if any BS,DT,CO,SU,MT,VD exist, then this is an abnoraml breath
result = result[['BN','DTWs','DTWi','DTWe','ABNOR','BS','DT','CO','SU','MT','VD']]
result.to_csv('/Users/nella/Desktop/AIM_2/DTW-test/data/RESULTS/VC/%s_result.csv' %patientname,index=False)
print "------------------------------------------- Patient: {} Completed -------------------------------------------".format(patientname)
