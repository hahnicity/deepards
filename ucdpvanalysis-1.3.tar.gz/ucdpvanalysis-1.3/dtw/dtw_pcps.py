from fastdtw import fastdtw
import numpy as np
from scipy.spatial.distance import euclidean
from numpy import linalg as LA
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib.cm as cm
import pylab as p
from time import time
import os
import sys;
sys.path.append("/ucdpvanalytics/")
from algorithms.raw_utils import extract_raw_speedup
from algorithms.breath_meta import get_production_breath_meta
from algorithms.tor5 import detectPVI


pd.set_option('display.max_columns', 50)
pd.set_option('display.width', 1000)
pd.set_option('display.max_rows', 200000)
pd.set_option('display.height', 1000)


patientname = '0110RPI0920160102-rpi14-2016-01-23-16-53-48.262030-pc' #manually input patient's file name
print "Patient's Name: {}".format(patientname)


df = pd.DataFrame(columns=['BN','DTWs', 'DTWi', 'DTWe'])

#Get the flow waveform of Inspiration part in Golden Breath in PC/PS mode
G_in = np.array([0.87,3.44,13.66,25.95,39.75,52.74,59.12,61.86,56.23,54.25,51.78,51.31,48.8,47.02,44.39,43.56,41.6,39.98,38.79,37.18,35.62,33.84,33.25,32,30.39,28.96,27.38,26.56,25.1,23.76,22.75,21.22,20.35,18.56,17.17,16.92,15.19,14.71,12.78,13.14,12.21,11.17,10.52,9.68,9.21,8.77]).reshape(-1,1)
in_max = G_in.max() #find the peak for scale

#Get the flow waveform of Expiration part in Golden Breath in PC/PS mode
G_out = np.array([-34.56,-58.86,-62.94,-54.36,-48.66,-45.19,-42.23,-41.15,-38.89,-38.92,-35.99,-34.27,-33.13,-31.63,-31.57,-29.34,-28.12,-27.99,-26.76,-25.95,-24.96,-23.04,-22.19,-21.1,-20.39,-19.24,-19.27,-18.28,-17.07,-17.39,-15.78,-14.57,-13.05,-12.3,-12.52,-11.88,-11.85,-10.98,-10.61,-10.48,-10.15,-10.74,-9.71,-9.98,-9.77,-9.63,-9.71,-9.43,-9.63,-9.14,-8.38,-8.11,-7.84,-7.65,-6.82,-6.03,-5.48,-4.94,-4.84,-4.5,-4.08,-3.86,-3.57,-3.6,-3.19,-2.92,-2.88,-2.91,-3.24,-3.75,-4.18,-4.42,-4.43,-4.6,-4.57,-4.75,-4.67,-4.42,-4.31,-3.76,-3.26,-2.64,-2.02,-1.59,-1.21,-1.25,-1.19,-1.03,-0.74,-0.43,-0.19,-0.06,-0.11,-0.13,-0.18,-0.32,-0.62,-1.26,-1.77,-2.16,-2.45,-2.64,-2.79,-2.83,-2.92,-2.83,-2.7,-2.49,-2.19,-1.98,-1.57,-1.02,-0.68,-0.35,-0.23,-0.01,0.15,0.37,0.52,0.48,0.46,0.33,0.19,0.18,0.04,-0.37,-0.89,-1.28,-1.52,-1.73,-1.75,-1.89,-1.75,-1.49,-1.34,-0.95,-0.48,-0.09,-0.07,0.02,0.05,0.06,0.12,0.2,0.18,0.11,0.03,0.01,-0.17,-0.56,-1.06,-1.6,-1.95,-2.37,-2.58,-2.73,-2.86,-2.87,-2.82,-2.53,-2.36,-1.99,-1.52,-0.81,-0.09,0.06,0.17,0.22,0.34]).reshape(-1,1)
out_min = G_out.min() 




g = open("/Users/nella/Desktop/AIM_2/DTW-test/data/raw_vwd/%s.csv" %patientname) #manually set the path for raw vwd file

print 'Abnormal Breaths Detection Start'
generator2 = extract_raw_speedup(g,False)
detectdata = detectPVI(generator2)
solo = detectdata[0]
#print solo

BS = pd.DataFrame(solo[solo['bs.1or2']>0]['BN'])
BS['BS'] = 1


DT = pd.DataFrame(solo[solo['dbl.4']>0]['BN'])
DT['DT'] = 1
dg = pd.concat([BS,DT],axis=1)


CO = pd.DataFrame(solo[solo['co.noTVi'] > 0]['BN'])
CO['CO'] = 1
dg = pd.concat([dg,CO],axis=1)

SU = pd.DataFrame(solo[solo['su.2']>0]['BN'])
SU['SU'] = 1
dg = pd.concat([dg,SU],axis=1)

MT = pd.DataFrame(solo[solo['mt']>0]['BN'])
MT['MT'] = 1
dg = pd.concat([dg,MT],axis=1)

VD = pd.DataFrame(solo[solo['vd.2']>0]['BN'])
VD['VD'] = 1
dg = pd.concat([dg,VD],axis=1)

dg = dg.drop('BN',1)

print 'Abnormal Breaths Detection Completed'

f = open("/Users/nella/Desktop/AIM_2/DTW-test/data/raw_vwd/%s.csv" %patientname)
print 'DTW Distance Calculation Start'

generator = extract_raw_speedup(f,False)

for breath in generator:
	metadata = get_production_breath_meta(breath)
	
	#print metadata
	cut = metadata[28] #find the cut point for inspiration & expiration
	NoB = metadata[0] #get the Breath Number
	#print NoB
	length = len(breath['flow'])
	#print "The cut is:{}, from {} to {}".format(cut,breath['flow'][cut-1],breath['flow'][cut])

	B_in = np.array(breath['flow'][0:cut]) # get the flow waveform in inspiration part
	B_out = np.array(breath['flow'][cut:length]) # get the flow waveform in expiration part
	B_in_max = B_in.max()
	B_out_min = B_out.min()


	B_in = B_in/B_in_max*in_max
	B_out = B_out/B_out_min*out_min
	#print "Breath IN :{}".format(B_in)
	#print "Breath OUT :{}".format(B_out)
	#print np.array(B_out).empty

	dist_in,path_in = fastdtw(B_in,G_in,dist= euclidean) # calculate the DTWi
	dist_out,path_out = fastdtw(B_out,G_out,dist= euclidean) # calculate the DTWe
	
	df2 = pd.DataFrame([[NoB,dist_in + dist_out,dist_in,dist_out]], columns=['BN','DTWs', 'DTWi', 'DTWe']) # calculate the DTWs
    

	df = df.append(df2)
	

print 'DTW Distance Calculation Completed'
df = df.reset_index()
df = df.drop('index',1)


result = pd.concat([df,dg],axis=1)
result = result.fillna(0)
result['ABNOR'] = result['BS']+result['DT']+result['CO']+result['SU']+result['MT']+result['VD'] #if any BS,DT,CO,SU,MT,VD exist, then this is an abnoraml breath
result = result[['BN','DTWs','DTWi','DTWe','ABNOR','BS','DT','CO','SU','MT','VD']]
result.to_csv('/Users/nella/Desktop/AIM_2/DTW-test/data/RESULTS/PC/%s_result_correct.csv' %patientname,index=False)
#print result

print "------------------------------------------- Patient: {} Completed -------------------------------------------".format(patientname)

