from glob import glob
import os
import re

import numpy as np
import pandas as pd

GT_DIR = os.path.join(os.path.dirname(__file__), 'ventmode_ground_truth/')
RAW_DIR = os.path.join(os.path.dirname(__file__), 'ventmode_raw/')
VENTMAP_DIR = os.path.join(os.path.dirname(__file__), 'ventmap_output/')


def get_ventmode_ground_truth():
    raw_files = glob(RAW_DIR + "*.csv")

    def _analyze_file(filename):
        filename_regex = r'(?P<patient>\d{4}RPI\d{10})(?:-rpi\d{1,2})?-(?P<year>\d{4})[-_](?P<month>\d{2})[-_](?P<day>\d{2})[-_](?P<hour>\d{2})[-_](?P<minute>\d{2})'
        out = pd.read_csv(filename)
        pat_match = re.search(filename_regex, filename)
        if not pat_match:
            raise Exception('Could not find regex match in file {}'.format(filename))
        patient = pat_match.group('patient')
        out['patient'] = patient
        out['y_filename'] = filename
        for f in raw_files:
            x_pat_match = re.search(filename_regex, f)
            if not x_pat_match:
                raise Exception('pattern match not found for raw filename: {}'.format(f))
            if pat_match.groups() == x_pat_match.groups():
                out['x_filename'] = f
                break
        else:
            raise Exception('matching x filename not found for {}'.format(filename))
        out = out.rename(columns={'vent BN': 'vent_bn', 'ventBN': 'vent_bn'})
        return out

    files = glob(os.path.join(GT_DIR, "*.csv"))
    gt = _analyze_file(files[0])
    for f in files[1:]:
        gt = gt.append(_analyze_file(f))

    return gt


def get_and_link_tor_data(linking_df):
    def _analyze_file(filename):
        tmp = pd.read_csv(filename)
        base_filename = os.path.basename(filename.split('_v5_1_0')[0] + '.csv')
        tmp['base_filename'] = base_filename
        return tmp

    solo3_files = glob(VENTMAP_DIR + "*solo3.csv")
    df = _analyze_file(solo3_files[0])
    for f in solo3_files[1:]:
        df = df.append(_analyze_file(f))

    linking_df['filename'] = linking_df.filename.apply(os.path.basename)
    linking_df.bn = linking_df.bn.astype(np.int64)
    merged = linking_df.merge(df, how='left', left_on=['bn', 'filename'], right_on=['BN', 'base_filename'])
    return merged.drop(['base_filename', 'BN', 'dbl.2', 'dbl.3', 'dtpi', 'dtpa.1', 'dtpa.2', 'dtpa.3', 'pvis'], axis=1)
