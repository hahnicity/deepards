from argparse import ArgumentParser
from glob import glob
import os

from algorithms import tor5


def main():
    parser = ArgumentParser()
    parser.add_argument('dir', help='path to raw data')
    parser.add_argument('--output-dir', default='ventmap_output')
    args = parser.parse_args()

    csv_files = glob(os.path.join(args.dir, "*.csv"))
    # XXX we may be interested in tvv, but for now let's focus on just generic
    # analytics like dta and bsa
    gender = 'female'
    height = 67

    for file_ in csv_files:
        tor5.perform_tor_with_bs_be(file_, [], args.output_dir, height, gender)


if __name__ == "__main__":
    main()
