import argparse
import subprocess

import numpy as np
import pandas as pd
from wfdb.io import rdann, rdsamp

from analytics import ProximalPressureAnalysis
from visualize_lstm_results import perform_prediction_post_processing, time_series_iou


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('file')
    parser.add_argument('-i', '--bp-idx', type=int, default=1, help='index of bp observations in wfdb file')
    parser.add_argument('--no-viz', action='store_true')
    parser.add_argument('--no-gt', action='store_true')
    args = parser.parse_args()

    signal, info = rdsamp(args.file)
    pressure = signal[:, args.bp_idx]
    analysis = ProximalPressureAnalysis(pressure, 3)

    proc = subprocess.Popen(['./wabp', '-r', args.file], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = proc.communicate()
    beat_idx = rdann(args.file, 'wabp').sample
    min_maxes = analysis._find_min_maxes()
    for j, idx in enumerate(beat_idx):
        for min, max in min_maxes:
            if min <= idx <= max:
                beat_idx[j] = min
                break

    if not args.no_gt:
        gt = np.zeros(len(analysis.pp))
        all_gt_idx = pd.read_pickle(args.file + '-diastolic.pkl')
        gt[all_gt_idx] = 1
        gt, gt_clusters = perform_prediction_post_processing(gt, 1, 1)
        gt_idx = [sorted(clust)[0] for clust in gt_clusters]
        gt = np.zeros(len(gt))
        gt[gt_idx] = 1

        time_series_iou(beat_idx, gt_idx)

    if not args.no_viz:
        analysis.diastolic_idx = beat_idx
        for i in range(0, len(analysis.pp), 3000):
            analysis.validate(i, i+3000, dot_size=5)



if __name__ == "__main__":
    main()
