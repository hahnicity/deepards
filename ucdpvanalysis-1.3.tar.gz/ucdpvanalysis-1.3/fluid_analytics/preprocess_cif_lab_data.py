"""
preprocess_cif_lab_data
~~~~~~~~~~~~~~~~~~~~~~~

Process raw txt data taken from CIF experiments into CSV and WFDB format
"""
import argparse
import os
try:
    from StringIO import StringIO
except:
    from io import StringIO

import numpy as np
import pandas as pd
from wfdb.io import wrsamp


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('input_file')
    parser.add_argument('-c', '--data-consistency-cutoff', type=int, default=9, help="cutoff checking line for data consistency after N data points")
    parser.add_argument('-o', '--output-dir', default='data/')
    parser.add_argument('--freq', type=int, default=100, help='sampling frequency in Hz')
    args = parser.parse_args()

    data_chunks = []
    with open(args.input_file, 'r') as f:
        for line in f.readlines():
            if line.startswith('ChannelTitle='):
                header = ['time'] + line.strip().split('\t')[1:]
                # Rename to be in accordance with WFDB. Also we may not be
                # able to tell BP signals well from the distal pressure during
                # occlusion
                if 'prox Pr' in header:
                    idx = header.index('prox Pr')
                    header[idx] = 'BP'
                for idx, col in enumerate(header):
                    header[idx] = col.replace(' ', '_')
                expected_cols = len(header)

            if line.startswith('UnitName='):
                units = ['sec'] + line.strip().split('\t')[1:]
                if '\xb0C' in units:
                    idx = units.index('\xb0C')
                    units[idx] = 'deg_Celsius'
                for idx, unit in enumerate(units):
                    if unit == '*':
                        units[idx] = 'unknown'
                    elif unit == 'L/min':
                        units[idx] = 'liters_per_min'
                    elif unit == 'mL':
                        units[idx] = 'milliliters'
            try:
                header
                units
            except NameError:
                continue
            else:
                break

    with open(args.input_file, 'r') as f:
        chunk = []
        # XXX This logic probably needs to be improved for chunk segmentation
        # versus just filtering for bad lines. Currently I've leaned in the
        # direction of just filtering bad lines, but some conciliation will
        # need to be found
        for line in f.readlines()[args.data_consistency_cutoff:]:
            split_line = line.split('\t')
            if len(split_line) == expected_cols:
                try:
                    [float(i) for i in split_line]
                except:
                    if chunk:
                        data_chunks.append(chunk)
                        chunk = []
                else:
                    chunk.append(line)
        else:
            if chunk:
                data_chunks.append(chunk)

        file_base = os.path.splitext(os.path.basename(args.input_file))[0]
        for idx, chunk in enumerate(data_chunks):
            df = pd.read_csv(
                StringIO("".join(chunk)),
                header=None,
                error_bad_lines=False,
                sep='\t',
                dtype={name: np.float32 for name in header},
            )
            filename = os.path.join(args.output_dir, '{}-{}.csv'.format(file_base, idx))
            df.columns = header
            df.to_csv(filename, index=None)
            wrsamp(os.path.splitext(filename)[0], fs=args.freq, units=units, sig_name=header, p_signal=df.values, fmt=['16'] * len(header))


if __name__ == "__main__":
    main()
