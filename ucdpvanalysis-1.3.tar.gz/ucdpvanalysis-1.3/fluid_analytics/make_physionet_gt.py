"""
make_physionet_gt
~~~~~~~~~~~~~~~~~

Make ground truth dataset for arterial pressure min detection using
physionet dataset
"""
import argparse
import os

import numpy as np
import pandas as pd
from wfdb.io import rdann, rdsamp

from analytics import ProximalPressureAnalysis


def main():
    parser = argparse.ArgumentParser()
    # just analyze single file for now
    parser.add_argument('file')
    parser.add_argument('-dsl', '--diastolic-search-len', type=int, default=50)
    parser.add_argument('-s', '--validate-step-size', default=4000, type=int)
    parser.add_argument('-n', '--necessary-diff', type=int, default=10)
    parser.add_argument('-ds', '--dot-size', type=int, default=3)
    parser.add_argument('-m', '--max-idxs', type=int, default=200)
    args = parser.parse_args()
    filename = os.path.splitext(args.file)[0]

    annos = rdann(filename, 'atr').sample
    signal, info = rdsamp(filename)
    # pressure is always signal idx 1
    pressure = signal[:, 1]
    analysis = ProximalPressureAnalysis(pressure, 3)
    diastolic_idx = [analysis._find_diastolic_idx(idx, args.diastolic_search_len, args.necessary_diff) for idx in annos]
    diastolic_idx = np.array([i for i in diastolic_idx if i])

    additional_points = []
    for di in diastolic_idx:
        di_val = analysis.pp[di]
        highest_max = 0
        highest_max_idx = None
        for offset, val in enumerate(analysis.pp[di:]):
            cur_idx = offset + di
            additional_points.append(cur_idx)
            if cur_idx == len(analysis.pp) - 1:
                break
            if val > highest_max:
                highest_max = val
                highest_max_idx = cur_idx
            if analysis.pp[cur_idx-1] <= val > analysis.pp[cur_idx+1] and val - di_val > args.necessary_diff:
                break

            # Act as a guard for going too far. Hopefully we can backtrack to the correct point
            if offset > args.max_idxs:
                additional_points = additional_points[:additional_points.index(highest_max_idx)]
                break
    diastolic_idx = np.append(diastolic_idx, additional_points)
    diastolic_idx.sort()

    analysis.diastolic_idx = diastolic_idx
    for i in range(0, len(analysis.pp), args.validate_step_size):
        analysis.validate(i, i+args.validate_step_size, dot_size=args.dot_size)
    answer = raw_input("Are you satisfied with the ground truth output? [y/n]")
    file_dir = os.path.dirname(args.file)
    if answer == 'y':
        pd.to_pickle(diastolic_idx, os.path.join(file_dir, "{}-diastolic.pkl".format(os.path.basename(filename))))


if __name__ == "__main__":
    main()
