"""
dataset
~~~~~~~

Utilities for loading ABP datasets
"""
from glob import glob
import os

import numpy as np
import pandas as pd
from scipy.ndimage.filters import gaussian_filter1d
import torch
from torch.utils.data import Dataset
from wfdb.io import rdsamp

ABP_MEAN = 100.40961215707934
ABP_STD = 25.46104366590512


def read_file(filename):
    with open(filename) as f:
        return [i.strip() for i in f.readlines()]


class PhysioNetABPData(Dataset):
    def __init__(self, dirpath, files_to_use, chunksize, smoothing_factor=3, save_to_file=None, load_from_file=None):
        """
        Load PhysioNet dataset from a desired directory. All files should have integer
        values as names in accordance with the PhysioNet 2014 challenge

        :param dirpath: Dir to load data from
        :param files_to_use: List of files to load for the current dataset. Can also be a string if you point it to a txt file with list of all files to load
        :param chunksize: Size of each sequence
        :param smoothing_factor: Int val by which degree to smooth data via gaussian 1d filter
        :param save_to_file: Absolute filepath of where to save dataset
        :param load_from_file: Absolute filepath of where to load dataset
        """
        if load_from_file:
            self.chunks = torch.load(load_from_file)
            return

        if isinstance(files_to_use, str):
            files_to_use = read_file(files_to_use)
        else:
            files_to_use = [str(i) for i in files_to_use]

        data_files = [os.path.join(dirpath, i) for i in files_to_use]
        gt_files = [os.path.join(dirpath, "{}-diastolic.pkl".format(i)) for i in files_to_use]

        # loading all the files and data here does not take too much time
        abps = []
        for file_ in data_files:
            signal, info = rdsamp(file_)
            # ABP is always signal idx 1
            abps.append(gaussian_filter1d(signal[:, 1], smoothing_factor))

        labels = []
        for idx, sig in enumerate(abps):
            gt = np.zeros(len(sig))
            diastolic_file = data_files[idx] + '-diastolic.pkl'
            diast_idxs = pd.read_pickle(diastolic_file)
            gt[diast_idxs] = 1
            labels.append(gt)

        # segment into chunks
        #
        # for now just do non-overlapping chunks, but in the future
        # can add option for data augmentation and overlapping chunks
        self.chunks = []
        for idx, sig in enumerate(abps):
            gt = labels[idx]
            for j in range(0, len(sig), chunksize):
                chunk = sig[j:j+chunksize]
                if len(chunk) < chunksize:
                    continue
                chunk_gt = np.append(chunk.reshape((chunksize, 1)), gt[j:j+chunksize].reshape((chunksize, 1)), axis=1)
                self.chunks.append(chunk_gt)

        if save_to_file:
            torch.save(self.chunks, save_to_file)

    def __len__(self):
        return len(self.chunks)

    def __getitem__(self, idx):
        input = (self.chunks[idx][:, 0] - ABP_MEAN) / ABP_STD
        labels = self.chunks[idx][:, 1]
        chunksize = len(input)
        # Add data transforms here
        return torch.FloatTensor(input.reshape((chunksize, 1))), torch.FloatTensor(labels.reshape((chunksize, 1)))


class ABPTestData(Dataset):
    def __init__(self, dirpath, files_to_use, chunksize, smoothing_factor=3):
        """
        Load PhysioNet dataset from a desired directory. All files should have integer
        values as names in accordance with the PhysioNet 2014 challenge

        :param dirpath: Dir to load data from
        :param files_to_use: List of files to load for the current dataset. Can also be a string if you point it to a txt file with list of all files to load
        :param chunksize: Size of each sequence
        :param smoothing_factor: Int val by which degree to smooth data via gaussian 1d filter
        """
        if isinstance(files_to_use, str):
            files_to_use = read_file(files_to_use)
        else:
            files_to_use = [str(i) for i in files_to_use]

        data_files = [os.path.join(dirpath, i) for i in files_to_use]
        # loading all the files and data here does not take too much time
        abps = []
        for file_ in data_files:
            signal, info = rdsamp(file_)
            colnames = info['sig_name']
            if 'BP' in colnames:
                idx = colnames.index('BP')
            elif 'ABP' in colnames:
                idx = colnames.index('ABP')
            # ABP is always signal idx 1
            abps.append(gaussian_filter1d(signal[:, idx], smoothing_factor))

        self.chunks = []
        for idx, sig in enumerate(abps):
            for j in range(0, len(sig), chunksize):
                chunk = sig[j:j+chunksize]
                if len(chunk) < chunksize:
                    continue
                chunk = chunk.reshape((chunksize, 1))
                self.chunks.append(chunk)

    def __len__(self):
        return len(self.chunks)

    def __getitem__(self, idx):
        input = (self.chunks[idx][:, 0] - ABP_MEAN) / ABP_STD
        chunksize = len(input)
        # Add data transforms here
        return torch.FloatTensor(input.reshape((chunksize, 1)))
