"""
add_vent_bn_and_ts
~~~~~~~~~~~~~~~~~~

Add vent numbers and (blank) absolute timestamps to post processed files

The usage of this script is as follows: Take a standard post processed file
that doesn't have vent numbers or absolute timestamps attached. Then pass this
script the relative path to this file, and the raw vent file

python add_vent_bn_and_ts.py post_processed.csv raw_file.csv

This script will then create a file called `post_processed-final.csv` that
has the vent bn's and timestamps attached.

If you want to have a custom named output file you can do that too

python add_vent_bn_and_ts.py post_processed.csv raw_file.csv --out-file foo.csv

And this will create the output file foo.csv
"""
from argparse import ArgumentParser
import csv
import re

VENT_BN_PATTERN = "S:(\d+)"


def parse_args():
    parser = ArgumentParser()
    parser.add_argument(
        "post_processed_input_file", help="Relative path to the post processed input file"
    )
    parser.add_argument("raw_input_file", help="Relative path to the raw input file")
    parser.add_argument("--out-file", help="Relative path to the output file")
    return parser.parse_args()


def add_cols(post_processed_input_file, raw_input_file, out_file):
    data = []
    vent_bns = []
    compiled = re.compile(VENT_BN_PATTERN)
    with open(raw_input_file, "rU") as raw_infile:
        inreader = csv.reader(raw_infile)
        for line in inreader:
            try:
                match = compiled.search(line[1])
            except IndexError:
                continue
            if match:
                vent_bns.append(match.groups()[0])

    with open(post_processed_input_file, "rU") as post_infile:
            inreader = csv.reader(post_infile)
            first_row = inreader.next()
            first_row.insert(1, "ventBN")
            first_row.insert(3, "absTimestamp")
            data.append(first_row)
            for row in inreader:
                bn = int(row[0])
                row.insert(1, vent_bns[bn - 1])
                row.insert(3, "")
                data.append(row)

    with open(out_file, "wb") as out:
        writer = csv.writer(out)
        for row in data:
            writer.writerow(row)


def main():
    args = parse_args()
    if not args.out_file:
        out_file = "{}-final.csv".format(args.post_processed_input_file.split(".")[0])
    else:
        out_file = args.out_file
    add_cols(args.post_processed_input_file, args.raw_input_file, out_file)


if __name__ == "__main__":
    main()
