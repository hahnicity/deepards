"""
Created May 26 2016, 19:21 PM
@author: Keiko
"""

import os
import pandas as pandas
import numpy as np
import pandas as pd
import utilikilt.oz as oz


#from 20160513_gold_processed_valid_files.py
   #http://stackoverflow.com/questions/21702342/creating-a-new-column-based-on-if-elif-else-condition
def is_sumt(row):
    "new value for sumt column"
    if row['su']>0 or row['mt']>0:
        val = 1
    else:
        val = 0
    return val

def is_cosumtvd(row):
    "new value for cosumtvd column"
    if row['co']>0 or row['su']>0 or row['mt'] or row['vd']>0:
        val = 1
    else:
        val = 0
    return val

def change_dbl_to_bs(temp_df):
    """
    change DBL -> BS if e-time is 0.3
    for files coming off the new pipeline
    """
    if 'e-time' in temp_df.columns and 'abs time' in temp_df.columns:
        for idx in temp_df.index:
            notLast = idx<temp_df.index[-1] # PROBABLY should change the index values to make this unneccessary

            if temp_df.loc[idx,'e-time']==0.3 and temp_df.loc[idx,'dbl']==1 and notLast:
                temp_df.loc[idx,'dbl']=0
                temp_df.loc[idx+1,'dbl']=0
                temp_df.loc[idx,'bs']=1

    return temp_df


def process_file (input_csv,output_csv):
    """
    process_file
    Versions
    20160512 V1.0 Make SUMT and COSUMT into a function
    """
    #read the csv
    temp_df = pd.read_csv(input_csv,index_col="BN")
    #determine if sumt is present
    temp_df['sumt']=temp_df.apply(is_sumt,axis=1)
    #determine if cosumtvd is present
    temp_df['cosumtvd']=temp_df.apply(is_cosumtvd,axis=1)  
    #change DBL -> BS if e-time is 0.3
    temp_df=change_dbl_to_bs(temp_df=temp_df)
    #output to csv
    temp_df.to_csv(output_csv)


def process_multi_files(input_subdir,output_subdir,output_suffix="_processed_comb_cosumtvd.csv"):
    """
    Versions
    20160526 V1.0 Make into function
    """

    oz.mkdir(output_subdir)
    
    files=oz.fancy_get_file_names(input_subdir=input_subdir,ends_with=".csv")

    print files
    for gold_file in files:
        #create paths for the input and output csv
        input_csv = os.path.join(input_subdir,gold_file)
        print input_csv
        output_csv = os.path.join(output_subdir,gold_file+output_suffix)      
        process_file(input_csv,output_csv)

        print "%s --processed" %(gold_file+output_suffix)


