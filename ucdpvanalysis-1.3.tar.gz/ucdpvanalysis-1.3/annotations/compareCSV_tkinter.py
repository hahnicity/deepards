# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 20:58:03 2015

@author: Keiko

Command line usage
http://home.wlu.edu/~lambertk/breezypythongui/

Versions
?????????? V0.3
2016-04-27 V1.0 Revamp as a remote function
2016-05-02 V1.1 Add main function
"""
__version__='1.0'

import os
import pandas as pd
import csv
from breezypythongui import EasyFrame
import argparse
import sys
import pdb


import time

#import tkinter based on version of python
if sys.version_info[0] < 3:
    import Tkinter as Tk
else:
    import tkinter as Tk

#future !!!
parser = argparse.ArgumentParser()
#add arguments that command line can take
parser.add_argument("gold_file1",help="directory_path/filename1.csv")
parser.add_argument("gold_file2",help="directory_path/filename2.csv")
# parser.add_argument("output",help="")

def compareSubDF(subDF1,subDF2, purpose=[]):
    """
    Makes sure two linear data frames are the same.
    
    Args:
     subDF1: first pandas data frame
     subDF2: second pandas data frame
     purpose: reason for testing a match, customizes the print message
     
    Returns:
     matched: Boolean, where True=no match
    
    Usage:
     matchedBN =compareSubDF(df1.BN, df2.BN, 'BN')
     matchedColumns =compareSubDF(df1.columns, df2.columns, 'columns')  
    
    Written: 10/20/2015 for compareCSV_tkinter.py
    2016-04-27 V1.2 Remove custom error messages
    """
    compared = subDF1!=subDF2
    mismatchCount=compared.tolist().count(True)
    if mismatchCount>0:       
        # print "------\n WARNING: %s mismatch(es) present"%(str(mismatchCount))
        # if purpose=='BN':
        #     print "-->Double check CSVs analyze same breath regions"
        # elif purpose=='columns':
        #     print "-->Double check CSVS are from same annotation batch "
        # if purpose=='anns':
        #     print pd.concat([subDF1,subDF2], axis=1, keys=['csv1','csv2']).transpose()
        # else:
        #     print "\n CSV1"    
        #     print subDF1[compared]
        #     print "\n CSV2"
        #     print subDF2[compared]
        matched = False
    elif mismatchCount==0:
        matched=True
    return matched


class csvTkinter(EasyFrame):
    """Application window for comparing CSVs."""
    def __init__(self,df1, df2,csvGS,first_ann):
        """Sets up the window and the widgets."""
        EasyFrame.__init__(self, title = "This is a title!")
        #display row
        for colNumber in range(len(df1.columns)):
#            print colNumber, df1.columns[colNumber]
            self.addLabel(text=df1.columns[colNumber], row=0, column=colNumber)

#        self.addLabel(text = "A",row = 0, column = 0, background='yellow')
#        self.field1 = self.addIntegerField(value = 0,row = 1,column = 0)

        # adds panel to place buttons
        buttonPanel = self.addPanel(row=5,column=0, columnspan=len(df1.columns))  
        buttonPanel.addButton(text="Find the next mismatch!", row=0, column=0,
                              command = self.findNext)
        buttonPanel.addButton(text="Find all mismatches!", row=0, column=1,
                              command=self.findAll)
#        self.textButton = self.addButton(text = "Next Row!", 
#                                         row = 5, column = 0,
#                                     command = self.findNext)
                                     
        #adds text rectangle for message output
        self.outputArea = self.addTextArea("", row = 8, column = 0,
                                    columnspan = len(df1.columns),
                                    width = 50, height = 15)
        #initialize interframe variables                 
        self.i=0
        self.log=""
        self.columns=df1.columns
        #save other variables
        self.csvGS=csvGS #saves location of csv
        firstAnnCol=df1.columns.get_loc(first_ann) #obtains column number of dbl
        lastAnnCol = len(df1.columns) #obtains last column number
        ann1 = df1.iloc[:, firstAnnCol:lastAnnCol]
        ann2 = df2.iloc[:, firstAnnCol:lastAnnCol]
        self.breathInfo = df1.iloc[:,0:firstAnnCol]
        self.firstAnnCol =  firstAnnCol
        self.lastAnnCol = lastAnnCol
        #replace Nan (empty values) with 0 so that the compare will work
        self.ann1=ann1.fillna(0)
        self.ann2=ann2.fillna(0)
        
#        self.df1=df1
        self.newAnn=[]
        
    def findNext(self):
        """

        """

        ann1=self.ann1; ann2=self.ann2; breathInfo=self.breathInfo
        
        matchedRow=True
#        newAnnArray=[]
        if self.i>0 and self.i<len(ann2):
            mismatchedBreathInfo=self.breathInfo.iloc[self.i-1]
            newAnnArray=mismatchedBreathInfo.tolist()
            for item in self.newAnn:
                newAnnArray.append(item.getNumber())
            self.log+= "New Row:"+str(newAnnArray)+"\n"
            print "New Row:"+str(newAnnArray)+"\n"
            self.csvGS.writerow(newAnnArray)
            self.newAnn=[]

        
        if self.i>=len(ann2): 
                    self.addLabel(text='---FINISHED COMPARING ALL ROWS--', row=6, column=0)
                    print '---FINISHED COMPARING ALL ROWS, PLEASE CLOSE--'
        
        while matchedRow==True and self.i<len(ann2):
            matchedRow=compareSubDF(ann1.iloc[self.i], ann2.iloc[self.i],purpose='anns')
            BN = breathInfo.iloc[self.i][0]           
            if matchedRow:
                outRow = breathInfo.iloc[self.i].tolist() + ann1.iloc[self.i].tolist()
                logRow = "BN %s: matches" %str(int(BN))
                self.csvGS.writerow(outRow)
#                print self.i, BN
            else:
                # pdb.set_trace()
                print "index:%s, BN:%s, MISMATCH"%(str(self.i), str(BN))
                outRow = breathInfo.iloc[self.i].tolist()
                logRow = "Mismatch in %s"%str(int(BN))
#                self.csvGS.writerow(outRow)
                #make things appear at the top to gather information
                columnIndices=range(len(self.columns))
                ann1Row = breathInfo.iloc[self.i].tolist() + ann1.iloc[self.i].tolist()
                ann2Row = breathInfo.iloc[self.i].tolist() + ann2.iloc[self.i].tolist()
                
                # print '----'
                # print ann1Row
                # print ann2Row

                #display row number along top                
                for colNumber, ann1_i, ann2_i in zip(columnIndices,ann1Row,ann2Row) :
                    # print ann1_i, ann2_i
                    color1="white"
                    color2="white"
                    if colNumber>=self.firstAnnCol:
                        
                        if ann1_i ==0:
                            ann1_i = ''
                        else:
                            color1="yellow"
                        if ann2_i ==0:
                            ann2_i = ''
                        else:
                            color2="yellow"

                    #it's as if the ghost remnant isn't completely removed (and it's usually 4 characters long)
                    # option 1, replace with blanks
                    # option 2, everything is base =...., '' is a blank overlay
                    # if ann1_i ==0:
                    #     ann1_i = '   '
                    # if ann2_i ==0:
                    #     ann2_i = '    '
                    self.addLabel(text='....', row=2, column=colNumber) #to remove ghost lettering
                    self.addLabel(text=ann1_i, row=2, column=colNumber,background=color1)
                    self.addLabel(text='....', row=3, column=colNumber)
                    self.addLabel(text=ann2_i, row=3, column=colNumber,background=color2)
                for colnumber in columnIndices:
                    if colnumber>=self.firstAnnCol:
                       self.newAnn.append(self.addIntegerField(value=0,row=4,column=colnumber))
#                    print self.newAnn
            self.log+=logRow+"\n"
            self.outputArea.setText(self.log)
            self.i+=1

            #clear rows
            ann1Row=[]
            ann2Row=[]
            
    def findAll(self):
        """
        Finds all the mismatches and prints them in the text area
        """
#        rowN=self.i
        ann1=self.ann1; ann2=self.ann2; breathInfo=self.breathInfo
#        BN = breathInfo.iloc[rowN][0]
        for rowN in range(len(ann1)):    
            BN = breathInfo.iloc[rowN][0]
            matchedRow=compareSubDF(ann1.iloc[rowN], ann2.iloc[rowN], purpose='anns')
           
            if matchedRow: 
                outRow = breathInfo.iloc[rowN].tolist() + ann1.iloc[rowN].tolist()
                logRow = "BN %s: matches" %str(int(BN))
            else:
                outRow = breathInfo.iloc[rowN].tolist()
                logRow = "Mismatch in %s"%str(int(BN))
                print "index:%s, BN:%s, MISMATCH"%(str(self.i), str(BN))

            self.csvGS.writerow(outRow)
            
            self.log+=logRow+"\n"
    #        self.log+="%1d \n" %self.i
            self.outputArea.setText(self.log)
            self.i+=1

#######################################################
#   script --> function
########################################################


def printLog(outputPath, string):
    """
    print and write to designated .txt file
    """
    printFile = open(outputPath, 'a')
    printFile.write(string+'\n')
    print string


def main(csv1, csv2,combined,gold_dir='',output_dir='',root_dir=''):
    """
    Compare two csv files

    20160502 V1- Created function
    """
    if root_dir!='':
        os.chdir(root_dir)

    #set up log file header
    log_file_path=os.path.join(output_dir,combined+'_logfile.txt')
    printLog(log_file_path, "=="*10)
    printLog(log_file_path, (time.strftime("Started at %d/%m/%Y  %H:%M:%S")))
    printLog(log_file_path,"Root Dir: %s"%(str(os.getcwd())))
    printLog(log_file_path,"Gold subdirectory: %s" %gold_dir)

    printLog(log_file_path,"--CSV1: %s"%csv1)
    printLog(log_file_path,"--CSV2: %s"%csv2)

    printLog(log_file_path,"Output subdirectory: %s" %output_dir)
    printLog(log_file_path,"--combined: %s" %combined)

    #import csv files as dataframes
    df1 = pd.read_csv(os.path.join(gold_dir,csv1))
    df2 = pd.read_csv(os.path.join(gold_dir,csv2))

    printLog(log_file_path,"Files imported successfully.")

    #make custom error
    class FileError(Exception):
        pass

    #error checking
    matchedBN = compareSubDF(df1.BN, df2.BN, 'BN')
    if matchedBN==False:
        raise FileError("\n\t-->Breath numbers don't match"+
                        "\n\t-->Double check CSVs analyze same breath regions")
    matchedColumns = compareSubDF(df1.columns, df2.columns, 'columns')
    if matchedColumns==False:
        raise FileError("\n\t-->Columns don't match"+
                        "\n-->Double check CSVS are from same annotation batch")

    ## instantiate and pop up window
    with open(os.path.join(output_dir,combined), 'wb') as outGS:
        csvGS = csv.writer(outGS, delimiter=',', quoting=csv.QUOTE_NONE)
        csvGS.writerow(df1.columns)
        csvTkinter(df1,df2,csvGS,"dbl").mainloop()

    printLog(log_file_path,'woohoo!! all done')

    printLog(log_file_path, (time.strftime("Finished at %d/%m/%Y  %H:%M:%S")))
    printLog(log_file_path, "=="*10)


