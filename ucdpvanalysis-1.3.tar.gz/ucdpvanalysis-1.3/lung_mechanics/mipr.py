"""
mipr
~~~~~

From Chiew's paper "Assessing mechanical ventilation asynchrony through iterative airway pressure reconstruction."
"""
import numpy as np

from lung_mechanics.iipr import (
    get_least_squares_preds,
    IMPLAUSIBLE_PRESSURE,
    preprocess_flow_pressure
)


def get_predicted_pressure_waveform(flow, pressure, vols):
    """
    Get the pressure waveform as predicted by the least squares model

    :param flow: array vals of flow measurements in L/s
    :param pressure: array vals of pressure obs
    :param vols: calculated volumes inspired over time

    :returns tuple: the modeled pressure, elastance, resistance, and the residual
    """
    elastance, resist, K, residual = get_least_squares_preds(flow, pressure, vols)
    modeled_pressure = elastance * vols + resist * flow + K
    return modeled_pressure, elastance, resist, residual


def perform_mipr(flow, pressure, x0, peep, convert_to_ls=True):
    """
    :param flow: array vals of flow measurements in L/s
    :param pressure: array vals of pressure obs
    :param x0: index where flow crosses 0
    :param peep: positive end expiratory pressure
    :param convert_to_ls: Convert flow/TVi to L/s from ml/s

    :returns tuple: compliance, resistance, residual, response code

    Response codes:
        0: Used algorithm and was successful
    """
    max_iter = 20
    flow, pressure, vols = preprocess_flow_pressure(flow, pressure, convert_to_ls)
    elastance, resist, K, residual = get_least_squares_preds(flow, pressure, vols)

    for i in range(max_iter):
        # XXX implement pressure filling algo for late asynchronies.
        # There's a bit of subjectivity to this because the group never really defined
        # beginning of the breating cycle. So for now I'm just going to do a 1/3 split
        # for beginning,middle,end
        modeled_pressure, elastance, resistance, residual = get_predicted_pressure_waveform(flow[:x0], pressure[:x0], vols[:x0])
        recon_line = np.concatenate([
            modeled_pressure, [IMPLAUSIBLE_PRESSURE] * (len(pressure) - x0)
        ])
        pressure = np.array([pressure, recon_line]).max(axis=0)

    # Option to quantify asynchrony using Chiew's AUC calcs.
    # MAsyn = (AUCrec − AUCori) / AUCrec × 100%
    return 1/elastance, resistance, residual, 0
