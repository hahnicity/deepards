"""
iipr
~~~~

From Newberry's paper "Iterative Interpolative Pressure Reconstruction for Improved
Respiratory Mechanics Estimation During Asynchronous Volume Controlled Ventilation"
"""
from copy import copy

import numpy as np
from scipy.integrate import simps

from algorithms.SAM import least_squares_method

IMPLAUSIBLE_PRESSURE = -1000


def shear_transform(waveform, dt=0.02, time_offset=0):
    """
    Return shear transform function to do with what you want
    """
    m = (waveform[0] - waveform[-1]) / (dt * (len(waveform)-1))
    c = -m * (time_offset * dt)
    t = np.arange(len(waveform)) * dt
    return waveform + m * t + c


def find_shoulders(flow, pressure, dt=0.02):
    """
    Follows shear transform discussed in Stevenson et al. 2012.

    The goal here is to find the left and right shear locations for the pressure curve
    """
    # flow min idx is included in the shear calculation
    max_p_idx = np.argmax(pressure)
    min_f_idx = np.argmin(flow)
    # A first approximation of the shear transform is found by the maximum of
    # the shear transform between the first data point and the point of maximum
    # pressure
    shear_left = np.argmax(shear_transform(pressure[:max_p_idx+1], dt=dt))
    # The second shoulder is found by taking the maximum of the shear transform
    # between the point of maximum pressure and the point of minimum flow
    try:
        shear_right_func = shear_transform(pressure[max_p_idx:min_f_idx+1], dt=dt, time_offset=max_p_idx)
    except ValueError:
        return None, None
    # just use first max val instead of the global max. It should be good enough
    for idx, val in enumerate(shear_right_func[::-1][1:]):
        if shear_right_func[idx-1] <= val >= shear_right_func[idx+1]:
            # -2 is because we are advancing index by 1 above, and that the len gives
            # a length that is 1 greater than the final index. So its -1 - 1 = -2
            shear_right = (len(shear_right_func) - 2 - idx) + max_p_idx
            break
    else:  # shear max unable to be found
        return None, None

    return shear_left, shear_right


def get_least_squares_preds(flow, pressure, vols):
    """
    Get elastance, resistance, K, and residual as defined by least squares eq.

        Paw = E*V + R*V^dot + P0
    """
    a = np.array([vols, flow, [1] * len(pressure)]).transpose()
    least_square_result = np.linalg.lstsq(a, pressure)
    elastance, resist, K = least_square_result[0]
    try:
        residual = least_square_result[1][0]
    except IndexError:
        residual = None
    return elastance, resist, K, residual


def get_predicted_pressure_waveform(flow, pressure, vols):
    """
    Get the pressure waveform as predicted by the least squares model

    :param flow: array vals of flow measurements in L/s
    :param pressure: array vals of pressure obs
    :param vols: calculated volumes inspired over time

    :returns tuple: the modeled pressure and the residual
    """
    elastance, resist, K, residual = get_least_squares_preds(flow, pressure, vols)
    modeled_pressure = elastance * vols + resist * flow + K
    return modeled_pressure, residual


def get_predicted_pressure_waveform_with_shears(flow, pressure, vols, shear_left, shear_right):
    """
    Get the pressure waveform as predicted by the least squares model

    :param flow: array vals of flow measurements in L/s
    :param pressure: array vals of pressure obs
    :param vols: calculated volumes inspired over time
    :param shear_left: Left shear point
    :param shear_right: Right shear point

    :returns tuple: the modeled pressure and the residual
    """
    orig_len = len(flow)
    flow = flow[shear_left:shear_right+1]
    vols = vols[shear_left:shear_right+1]
    pressure = pressure[shear_left:shear_right+1]
    modeled_pressure, residual = get_predicted_pressure_waveform(flow, pressure, vols)
    modeled_pressure = np.append([np.nan] * shear_left, modeled_pressure)
    return np.append(modeled_pressure, [np.nan] * (orig_len - shear_right - 1)), residual


def find_intercept_via_points(a1, a2, b1, b2):
    """
    Determine if intersection between two lines (a and b) is found.

    :param a1: first point on line a
    :param a2: second point on line a
    :param b1: first point on line b
    :param b2: second point on line b

    :returns tuple: bool on whether intercept found,
                    and offset of closest point to intercept
    """
    intercept_found = ((a1 >= b1 and a2 < b2) or (a1 <= b1 and a2 > b2) or (a1 == b1))
    if intercept_found and abs(a1-b1) < abs(a2-b2):
        return True, 0
    elif intercept_found:
        return True, 1
    else:
        return False, None


def find_first_intercept(a, b):
    """
    Find first intersection between two lines (a and b).
    """
    for i in range(1, len(a)):
        intercept_found, offset = find_intercept_via_points(a[i], a[i-1], b[i], b[i-1])
        if intercept_found:
            return True, i - offset
    return False, None


def is_fit(flow, pressure, vols):
    """
    Evaluate newly reconstructed pressure if it needs to be fit again (step 8).

    If it is not fit, return False. If it is fit return True
    """
    # perform steps 1-2 again
    shear_left, shear_right = find_shoulders(flow, pressure)
    modeled_pressure, residual = get_predicted_pressure_waveform_with_shears(flow, pressure, vols, shear_left, shear_right)
    diff = abs(pressure[shear_left:shear_right+1] - modeled_pressure[shear_left:shear_right+1])

    peep = np.mean(pressure[-5:])
    auc = simps(pressure[shear_left:shear_right+1] - peep)

    # If the pressure is above an auc threshold then return False
    if simps(diff) > .045 * auc:
        return False

    return True


def perform_single_iter_reconstruction(flow, pressure, vols):
    """
    :returns tuple: reconstructed pressure, compliance, resistance, residual, response code
    """
    # step 1
    shear_left, shear_right = find_shoulders(flow, pressure)
    # no shear transform found
    if not shear_left:
        return None, None, None, None, 2

    # step 2
    #
    # One idea that I have is to just stop analysis on breaths where the residual is
    # sufficiently low, but this is not discussed in paper at all.
    modeled_pressure, residual = get_predicted_pressure_waveform_with_shears(flow, pressure, vols, shear_left, shear_right)

    # Step 3. Paper says intersections are identified based on gradient of pressure
    # curve at the crossings. If grad_pressure<0 or grad_pressure<grad_fit_pressure
    # these are two circumstances that an intersection could be considered valid.
    #
    # First figure out how many intercepts we actually have.
    intercepts = []
    crossings = []
    cur_crossing = []
    for idx, val in enumerate(modeled_pressure):
        if val is np.nan or modeled_pressure[idx-1] is np.nan:
            continue
        pressure_grad = pressure[idx] - pressure[idx-1]
        modeled_pressure_grad = modeled_pressure[idx] - modeled_pressure[idx-1]
        intercept_found, offset = find_intercept_via_points(pressure[idx], pressure[idx-1], modeled_pressure[idx], modeled_pressure[idx-1])

        # found intercept
        if intercept_found and (pressure_grad < 0 or pressure_grad < modeled_pressure_grad):
            intercepts.append(idx-offset)
            if len(cur_crossing) == 0:
                cur_crossing.append(idx-offset)
            else:
                cur_crossing.append(idx-offset)
                crossings.append(cur_crossing)
                cur_crossing = []

    shear_mins = []
    for crossing in crossings:
        min_idx, max_idx = crossing
        shear_min = np.argmin(shear_transform(pressure[min_idx:max_idx+1], time_offset=min_idx)) + min_idx
        shear_mins.append([shear_min, min_idx, max_idx])

    # step 4
    for idx, crossing in enumerate(shear_mins):
        shear_min, min_idx, max_idx = crossing
        # create intercept line from min to first crossing
        m = (pressure[min_idx] - pressure[shear_min-1]) / (min_idx - (shear_min-1))
        b = pressure[shear_min-1]
        n_points = -29 if shear_min - 1 - 29 >= 0 else -(shear_min - 1)
        arr_left = m * np.arange(n_points, 1) + b
        left_intercept_found, left_intercept = find_first_intercept(arr_left[::-1], pressure[:shear_min][::-1])

        # create intercept line from min to second crossing
        m = (pressure[max_idx] - pressure[shear_min+1]) / (max_idx - (shear_min+1))
        b = pressure[shear_min+1]
        arr_right = m * np.arange(0, 30) + b
        right_intercept_found, right_intercept = find_first_intercept(arr_right, pressure[shear_min+1:])

        # If we didn't find intercepts then fallback to uing least squares.
        if not left_intercept_found or not right_intercept_found:
            elas, res, K, resid = get_least_squares_preds(flow, pressure, vols)
            return None, 1/elas, res, resid, 3
        right_intercept = right_intercept + shear_min + 1
        left_intercept = shear_min - 1 - left_intercept

        shear_mins[idx].extend([left_intercept, right_intercept])

    # XXX must do additional work for cases where there are no
    # crossings or there are lonely intercepts without partners
    #
    # How to commence on these?? There are a few that happen in my example file:
    # rel bns: 27

    # step 5
    for min_idx, min_idx, max_idx, left_intercept, right_intercept in shear_mins:
        m = (pressure[right_intercept] - pressure[left_intercept]) / (right_intercept - left_intercept)
        b = pressure[left_intercept]
        recon_line = np.arange(0, right_intercept-left_intercept+1) * m + b
        recon_line = np.concatenate([
            [IMPLAUSIBLE_PRESSURE] * (left_intercept),
            recon_line,
            [IMPLAUSIBLE_PRESSURE] * (len(pressure)-1-right_intercept)
        ])
        recon = np.array([pressure, recon_line]).max(axis=0)

    # step 6
    #
    for idx, (min_idx, min_idx, max_idx, left_intercept, right_intercept) in enumerate(shear_mins):
        # XXX Do this for left hand side
        #
        # It says this only happens if the first identified async crossing is lower (less than)
        # than half way between left pressure shoulder and point immediately previous. What does
        # this mean? If I think I understand this... it means the left pressure shoulder
        # and the point previous to the left shoulder. But how does this make any sense?

        # Do this for right hand side, but don't evaluate prior to final asynchrony.
        if idx != len(shear_mins) - 1:
            continue
        m = (pressure[right_intercept] - pressure[left_intercept]) / (right_intercept - left_intercept)
        # This doesn't make sense to perform if the slope is going up, only if it's going down
        if m > 0:
            continue

        exp_grad = (pressure[shear_right + 2] - pressure[shear_right]) / 2
        b = pressure[shear_right+2]
        line = []
        # First we just construct the vertical part of the line
        for i in range(10):
            i = -i
            y = exp_grad * i + b
            if y < pressure[min_idx]:
                line.append(y)
            else:
                line.append(pressure[min_idx])
        # now attach to the horizonal part
        n_points = shear_right - len(line) + 3 - min_idx
        line = np.append([pressure[min_idx]] * n_points, line[::-1])
        line = np.concatenate([
            [IMPLAUSIBLE_PRESSURE] * min_idx,
            line,
            [IMPLAUSIBLE_PRESSURE] * (len(pressure) - 1 - (shear_right + 2))
        ])
        recon = np.array([recon, line]).max(axis=0)

    # We do step 7 throughout the code here, so there is no need to do additional work
    # on it
    return recon, None, None, None, 0


def preprocess_flow_pressure(flow, pressure, convert_to_ls):
    flow = np.array(flow)
    if convert_to_ls:
        flow = flow / 60.0
    vols = np.array([0] + [simps(flow[:i+1], dx=0.02) for i in range(1, len(flow))])
    pressure = np.array(pressure)
    return flow, pressure, vols


def perform_iipr_algo(flow, pressure, x0, peep, convert_to_ls=True):
    """
    :param flow: array vals of flow measurements in L/s
    :param pressure: array vals of pressure obs
    :param x0: index where flow crosses 0
    :param peep: positive end expiratory pressure
    :param convert_to_ls: Convert flow/TVi to L/s from ml/s

    :returns tuple: compliance, resistance, residual, response code

    Response codes:
        0: Used algorithm and was successful
        2: No shear points found
        3: Used least squares as fallback because no pressure intercepts found
           when performing step 4 of algorithm.
        4: Failed on step 9, so fallback to least squares for last found reconstruction
    """
    max_iter = 10
    pressure, flow, vols = preprocess_flow_pressure(flow, pressure, convert_to_ls)

    # perform first iter (steps 1-7)
    recon, comp, res, residual, code = perform_single_iter_reconstruction(flow, pressure, vols)
    if code != 0:
        return comp, res, residual, code

    # step 8-9
    iters = 1
    while not is_fit(flow, recon, vols) and iters < max_iter:
        recon_copy = copy(recon)
        recon, comp, res, residual, code = perform_single_iter_reconstruction(flow, recon, vols)
        if code != 0:
            elas, res, K, residual = get_least_squares_preds(flow, recon_copy, vols)
            return 1/elas, res, residual, 4
        iters += 1
    elas, res, _, residual = get_least_squares_preds(flow, recon, vols)
    return 1/elas, res, residual, 0
