"""
lung_mechanics.cvc_analyze
~~~~~~~~~~~~~~~~~~~~~~~~~~

Analyze CVC data, and compare methods for analyzing different lung physiologic variables
"""
import argparse
from glob import glob
import os

import numpy as np
import pandas as pd

from algorithms.breath_meta import get_production_breath_meta
from algorithms.raw_utils import extract_raw
from algorithms.SAM import al_rawas_calcs, brunner, calc_expiratory_plateau, calc_inspiratory_plateau, least_squares_method, vicario_calcs
from lung_mechanics.pressure_ctrl_correction import perform_algo as kannangara


class FileCalculations(object):
    def __init__(self, filename, algorithms_to_use, peeps_to_use, recorded_compliance=None):
        """
        :param filename: filename to analyze
        :param algorithms_to_use: Algorithms you want to include in your analysis. Should
        be a list and consist of choices: 'vicario_co', 'kannangara', 'least_squares',
        'brunner', 'vicario_2_point', ' al_rawas'
        :param peeps_to_use: Number of PEEPs to use when we calculate a median
        :param recorded_compliance: Compliance pre-recorded for the file.
        """
        self.dt = .02
        self.algorithms_to_use = algorithms_to_use
        self.peeps = []
        self.peeps_to_use = peeps_to_use
        self.results = {}
        self.last_gold = np.nan if not recorded_compliance else recorded_compliance
        # Al-Rawas finds the expiratory time const via a regression on the
        # expiratory flow. If the residual is less than this value then
        # declare the exp const as unachievable.
        self.al_rawas_tol = .95
        # Al-Rawas has another weird constant in his equation. This probably
        # varies from patient to patient in different circumstances and theres
        # probably no really good way of finding it.
        self.al_rawas_idx = 15
        self.filename = filename

    def _find_insp_plat(self):
        pass

    def _al_rawas(self):
        flow_l_s = [v/60.0 for v in self.flow]
        return al_rawas_calcs(
            flow_l_s,
            self.pressure,
            self.x0, self.dt,
            self.pip,
            self.peep,
            self.tvi/1000.0,
            self.al_rawas_idx,
            self.al_rawas_tol
        )

    def _vicario_constrained(self):
        pass

    def _vicario_two_point(self, tc):
        """
        :param tc: time constant
        """
        if tc is not np.nan:
            flow_l_s = [v/60.0 for v in self.flow]
            return vicario_calcs(flow_l_s, pressure, self.x0, self.peep, self.tvi/1000.0, tc)
        else:
            return np.nan

    def _kannangara(self):
        sols = kannangara(self.flow, self.pressure, self.x0, self.peep, 0.05)
        # Only desire compliance currently
        if sols[0]:
            return sols[0]
        else:
            return np.nan

    def _least_squares(self):
        flow_l_s = [v/60.0 for v in self.flow]
        return least_squares_method(flow_l_s, self.pressure, self.x0, self.dt, self.peep, self.tvi/1000.0)[1]

    def _brunner(self):
        pass

    def analyze_breath(self, breath):
        rel_bn = breath['rel_bn']
        self.results[rel_bn] = {val: np.nan for val in self.algorithms_to_use + ['gold_stnd_compliance']}
        bm = get_production_breath_meta(breath)
        self.e_time = bm[7]
        self.tvi = bm[9]
        self.tve = bm[10]
        self.pip = bm[15]
        self.peeps.append(bm[17])
        self.peep = np.median(self.peeps[-self.peeps_to_use:])
        self.x0 = bm[28]
        self.flow = breath['flow']
        self.pressure = breath['pressure']

        plat = calc_inspiratory_plateau(self.flow, self.pressure, self.dt)
        if plat is not np.nan:
            gold = (self.tvi / 1000.0) / (plat - self.peep)
            self.results[rel_bn]['gold_stnd_compliance'] = gold
            self.last_gold = gold
        else:
            self.results[rel_bn]['gold_stnd_compliance'] = self.last_gold

        if 'kannangara' in self.algorithms_to_use:
            self.results[rel_bn]['kannangara'] = self._kannangara()
        if 'least_squares' in self.algorithms_to_use:
            self.results[rel_bn]['least_squares'] = self._least_squares()
        if 'al_rawas' in self.algorithms_to_use:
            al_rawas = self._al_rawas()
            tc = al_rawas[0]
            self.results[rel_bn]['al_rawas'] = al_rawas[2]
        if 'vicario_co' in self.algorithms_to_use:
            # XXX not implemented
            pass
        if 'vicario_2_point' in self.algorithms_to_use:
            self.results[rel_bn]['vicario_2_point'] = self._vicario_two_point(tc)
        if 'brunner' in self.algorithms_to_use:
            # XXX not implemented
            pass

    def analyze_file(self):
        gen = extract_raw(open(self.filename), False)
        for breath in gen:
            self.analyze_breath(breath)
        return self.results_analysis()

    def results_analysis(self):
        """
        Calculate Median Average Deviation (MAD) between gold standard and a calculation
        and the MAD within a calculation
        """
        # should be {algo: [mad gld stnd, mad inter, breaths, mean_gld, [val1, val2, ...], [gld1, gld2, ...]], ...}
        analysis = {val: [0, 0, 0, 0, [], []] for val in self.algorithms_to_use}
        for bn in self.results:
            gld = self.results[bn]['gold_stnd_compliance']
            if gld is np.nan:
                continue
            for algo in self.algorithms_to_use:
                val = self.results[bn][algo]
                if val is np.nan:
                    continue
                analysis[algo][2] += 1
                analysis[algo][-2].append(val)
                analysis[algo][-1].append(gld)

        for algo in self.algorithms_to_use:
            vals = np.array(analysis[algo][-2])
            glds = np.array(analysis[algo][-1])
            median_val = np.median(vals)
            inter_mad = np.median(np.abs(vals - median_val))
            gld_mad = np.median(np.abs(vals - glds))
            analysis[algo][0] = gld_mad
            analysis[algo][1] = inter_mad
            analysis[algo][3] = np.mean(glds)
            # delete intermediate data for algo values and gold calcs
            del analysis[algo][-1]
            del analysis[algo][-1]
        return analysis


def build_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument('cvc_dir', help='path to dirname with cvc data files')
    parser.add_argument('cvc_experiments_file', help='path to file which holds cvc experiments')
    parser.add_argument('--use-recorded-compliance', help='Use compliance recorded on the experiment spreadsheet', action='store_true')
    parser.add_argument('--compliance-units', choices=['L', 'ml'], help="Units compliance should be recorded in (liters or milliliters)")
    return parser


def main():
    args = build_parser().parse_args()
    cvc_experiments = pd.read_csv(args.cvc_experiments_file)
    cvc_experiments = cvc_experiments[~cvc_experiments.type.isna()]
    if args.compliance_units == 'ml':
        conversion_factor = 1000
    else:
        conversion_factor = 1

    for idx, experiment in cvc_experiments.iterrows():
        if args.use_recorded_compliance:
            recorded_compliance = experiment['analytics-compliance']
        else:
            recorded_compliance = None
        time_start = experiment['Time Start'][0:2] + "-" + experiment['Time Start'][2:4]
        file = glob(os.path.join(args.cvc_dir, '*{}*.csv'.format(time_start)))
        if len(file) > 1 or len(file) == 0:
            raise Exception('Unable to find a singular file for experiment at start time: {}'.format(time_start))
        # XXX just use LS for now.
        calcs = FileCalculations(file[0], ['least_squares'], 30, recorded_compliance=recorded_compliance)
        results = calcs.analyze_file()
        for algo in results:
            cvc_experiments.loc[idx, '{}-gold-mad'.format(algo)] = results[algo][0] * conversion_factor
            cvc_experiments.loc[idx, '{}-inter-mad'.format(algo)] = results[algo][1] * conversion_factor
            cvc_experiments.loc[idx, '{}-breaths-analyzed'.format(algo)] = results[algo][2]
            cvc_experiments.loc[idx, '{}-mean-gold'.format(algo)] = results[algo][3] * conversion_factor

    import IPython; IPython.embed()


if __name__ == "__main__":
    main()
