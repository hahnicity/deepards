import numpy as np
from scipy.optimize import fmin_slsqp


def construct_h(flow, vols):
    """
    :param flow: numpy array
    :param vols: numpy array
    """
    h = np.zeros([len(flow)+2, len(flow)+2])
    h[0][0] = np.sum(flow ** 2)
    h[0][1] = np.sum(flow * vols)
    h[1][0] = np.sum(flow * vols)
    h[1][1] = np.sum(vols ** 2)
    for i in range(2, len(flow)+2):
        h[0][i] = flow[i-2]
        h[i][0] = flow[i-2]
        h[1][i] = vols[i-2]
        h[i][1] = vols[i-2]
        h[i][i] = 1

    return 2 * h


def construct_a(n_obs, m_idx):
    """
    """
    # there may have been a bug here with the number of rows. I think
    # I was seeing it too, with the early dropoff
    #
    # I was also creating matrices with too many rows
    a = np.zeros([n_obs-1, n_obs+2])
    for i in range(0, m_idx):
        a[i][i+2] = -1
        a[i][i+3] = 1

    for i in range(m_idx, n_obs-1):
        a[i][i+2] = 1
        a[i][i+3] = -1

    return a


def objective(h, f, g, x):
    return .5 * x.transpose().dot(h).dot(x) + f.transpose().dot(x) + g


def optimize(flow, vols, pressure, x0, m_idx, r_max=100, r_min=0, e_max=100, e_min=0, p_min=-15, p_max=20, initial_guess=None):
    """
    :param flow: numpy array
    :param vols: numpy array
    :param pressure: numpy array
    :param x0: x0 index
    :param m_idx: index to use for t_m
    """
    # XXX tmp
    flow, pressure, vols = flow[:x0], pressure[:x0], vols[:x0]
    if isinstance(initial_guess, type(None)):
        initial_guess=np.ones(len(flow)+2)
    g = np.sum(pressure ** 2)
    h = construct_h(flow, vols)
    a = construct_a(len(flow), m_idx)
    f = -2 * np.append([np.sum(flow * pressure), np.sum(vols * pressure)], pressure)
    bounds = [(r_min, r_max), (e_min, e_max)] + [(p_min, p_max) for i in range(len(flow))]
    obj = lambda x: objective(h, f, g, x)
    ieq_con = lambda x: a.dot(x)
    # least squares is vulnerable to local minima, so you should really consider
    # doing iterations to and making your initial guesses random.
    result = fmin_slsqp(obj, initial_guess, ieqcons=[ieq_con], bounds=bounds)
    R = result[0]
    E = result[1]
    P_mus = result[2:]
    predicted = R * flow + E * vols + P_mus
    residual = (1.0 / len(flow)) * np.sum((predicted - pressure) ** 2)
    return result, residual
