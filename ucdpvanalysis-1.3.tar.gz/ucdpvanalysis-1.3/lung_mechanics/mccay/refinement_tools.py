'''
Tools for comparing and refining models
'''

from importlib import reload
from matplotlib import pyplot as plt
import numpy as np

from circuit_analysis import RC_functions
pressure_control_RC = RC_functions.pressure_control_RC
pc_Rext_Cext = RC_functions.pc_Rext_Cext
pressure_control_LRC = RC_functions.pressure_control_LRC
pc_extLRC = RC_functions.pc_extLRC
pc_iterative_LRC = RC_functions.pc_iterative_LRC

def plot_mbvd_list(mbvd_list, dataset_descriptions):

    """Plots all the breaths in a list of mbvd's.
    Useful for choosing points for LRC comparison.
    """

    for i in range(len(mbvd_list)):

        plt.plot(mbvd_list[i].vdot, 'bo-')
        plt.plot(mbvd_list[i].pcirc, 'go-')
        plt.title(dataset_descriptions[i])
        plt.grid()
        plt.show()

def LRC_iterative_compare(mbvd_list, \
                          dataset_descriptions, \
                          breath_descriptions, \
                          breath_indices, \
                          data_of_interest, \
                          FR_ranges, \
                          recon_tolerances, \
                          plot_type,
                          plot_title,
                          plot_display):

    """Function for evaluating the effectiveness of the LRC algorithm
    and for making improvements to it.
    """

    doi = data_of_interest

    breath_index_list = []

    interp_dict_list = []

    vdot_R_list = []
    R_list = []

    pcirc_recon_list = []

    vdot_R_interest = []
    R_interest = []

    for i in range(len(mbvd_list)):

        # breath_index = mbvd_list[i].which_breath(breath_points[i])
        breath_index = breath_indices[i]

        breath_index_list.append(breath_index)

        # Iterate to find appropriate fraction FLR
        FLR = pc_iterative_LRC(FR_ranges[i], recon_tolerances[i], \
                                 mbvd_list[i].vdot_list[breath_index], \
                                 mbvd_list[i].pcirc_list[breath_index], \
                                 mbvd_list[i].pcirc_list[breath_index][0], \
                                 0.0, 'none')

        # Do an LRC reconstruction based on found FLR
        (pcirc_recon, component_dict, interp_dict) = \
                                pressure_control_LRC(FLR, \
                                mbvd_list[i].vdot_list[breath_index], \
                                mbvd_list[i].pcirc_list[breath_index], \
                                mbvd_list[i].pcirc_list[breath_index][0], \
                                0.0, 'none')

        pcirc_recon_list.append(pcirc_recon)

        # Store data about resistance and other quantities
        interp_dict_list.append(interp_dict)
        vdot_R_list.append(interp_dict['vdot_R'])
        R_list.append(interp_dict['R'])

        if i == doi:
            vdot_R_interest = interp_dict['vdot_R']
            R_interest = interp_dict['R']

        # Add fluid dynamics calc?

    # Plot R(vdot)

    fig = plt.figure()
    ax = plt.subplot(111)
    plt.title(plot_title)

    for i in range(len(vdot_R_list)):

        ax.plot(np.array(vdot_R_list[i])*60.0*1000.0, \
                np.array(R_list[i])/(98.07*60.0*1000.0), 'o-', \
                label = dataset_descriptions[i] + ', ' \
                + breath_descriptions[i])

    ax.grid()
    ax.legend(loc='best')
    plt.ylabel('R [cmH2O*min/L]')
    plt.xlabel('vdot [L/min]')


    if plot_display == 'show':
        plt.show()
    else:
        temporary_plot_name = 'temporary_plots/' \
                              + plot_display + '/' \
                              + str(breath_indices[doi]) \
                              + '_temp_plot'
        fig.savefig(temporary_plot_name)
        plt.close()

    # Plot recon of waveform of interest

    pcirc = mbvd_list[doi].pcirc_list[breath_indices[doi]]
    vdot = mbvd_list[doi].vdot_list[breath_indices[doi]]

    pcirc_recon = pcirc_recon_list[doi]

    fig, axarr = plt.subplots(2, sharex=True)

    axarr[0].plot(np.array(vdot), \
                 'bo-')
    axarr[0].set_title('Flow Rate')
    axarr[0].set_ylabel('vdot [L/min]')
    axarr[0].set_xlabel('points at 50 Hz')
    axarr[0].grid()

    axarr[1].plot(np.array(pcirc), \
                  'go-')
    axarr[1].plot(np.array(pcirc_recon)/98.07, 'ro-')
    axarr[1].set_title('Circulation Pressure')
    axarr[1].set_ylabel('pcirc [cmH2O]')
    axarr[1].set_xlabel('points at 50 Hz')
    axarr[1].grid()

    if plot_display == 'show':
        plt.show()
    else:
        temporary_plot_name = 'temporary_plots/' \
                              + plot_display + '/' \
                              + str(breath_indices[doi]) + '_temp_plot_wf'
        fig.savefig(temporary_plot_name)
        plt.close()


    return (vdot_R_interest, R_interest)
