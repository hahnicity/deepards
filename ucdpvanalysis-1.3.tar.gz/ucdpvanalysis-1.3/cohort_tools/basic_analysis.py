from argparse import ArgumentParser
from datetime import timedelta

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


class Analysis(object):
    def __init__(self, args):
        self.args = args

    def _convert_abs_bs_to_regular_time(self, bs_col):
        return pd.to_datetime(bs_col.dt.strftime("%H:%M"), format="%H:%M")

    def _get_tvi_tve_diff(self, copd_obs):
        diff = (copd_obs.tvi - copd_obs.tve)
        diff.loc[diff[diff > 2000].index] = np.nan
        # These obs all have negative tvi
        diff.loc[diff[diff < 0].index] = np.nan
        return diff.dropna()

    def cross_patient_by_volume(self):
        copd_obs = pd.read_pickle(self.args.bs_file)
        diff = self._get_tvi_tve_diff(copd_obs)
        diff.hist(bins=24)
        plt.title("Distribution of $TVi-TVe$")
        plt.xlabel("$TVi-TVe$")
        plt.ylabel("count")
        plt.show()

    def cross_patient_time_by_severity(self):
        copd_obs = pd.read_pickle(self.args.bs_file)
        copd_obs = copd_obs.dropna()
        copd_obs.abs_bs = self._convert_abs_bs_to_regular_time(copd_obs.abs_bs)
        plt.figure()
        copd_obs[copd_obs.bs_1 == 1].abs_bs.hist(bins=24)
        copd_obs[copd_obs.bs_1 == 2].abs_bs.hist(bins=24)
        copd_obs[copd_obs.bs_1 == 3].abs_bs.hist(bins=24)
        plt.title("Breath Stacking Severity over Day")
        plt.xlabel("time")
        plt.ylabel("count")
        plt.legend([1, 2, 3], loc=2)
        plt.show()

    def cross_patient_time_analysis(self):
        copd_obs = pd.read_pickle(self.args.bs_file)
        copd_obs = copd_obs.dropna()
        copd_obs.abs_bs = self._convert_abs_bs_to_regular_time(copd_obs.abs_bs)
        copd_obs.abs_bs.hist(bins=24)
        plt.title("All BS' over time of day")
        plt.xlabel("time")
        plt.ylabel("count")
        plt.show()

    def cross_patient_by_volume_pbw(self):
        copd_obs = pd.read_pickle(self.args.bs_file)
        copd_obs = copd_obs.dropna()
        key_file = pd.read_csv(self.args.code_key)
        copd_obs['tvi_diff'] = self._get_tvi_tve_diff(copd_obs)
        pbw_series = pd.Series([])
        for patient in copd_obs.patient.unique():
            pbw = float(key_file[key_file['Patient Unique Identifier'] == patient].iloc[0]['Weight (kg)'])
            result = copd_obs[copd_obs.patient == patient].tvi_diff > .25 * 6 * pbw
            pbw_series = pbw_series.append(result)
        copd_obs['pbw_metric'] = pbw_series
        copd_obs[copd_obs['pbw_metric']].tvi_diff.hist(bins=50)
        plt.title("Distribution of events where $TVi-TVe > .25 * 6 * pbw$")
        plt.xlabel("$TVi-TVe$")
        plt.ylabel("count")
        plt.show()

    def analyze_patient(self):
        copd_obs = pd.read_pickle(self.args.bs_file)
        pt_obs = copd_obs[copd_obs.patient == self.args.patient]
        pt_obs.abs_bs.hist(bins=24)
        plt.title("Patient: {} BS over time".format(self.args.patient))
        plt.xlabel("time")
        plt.ylabel("count")
        plt.show()

    def first_24(self):
        copd_obs = pd.read_pickle(self.args.bs_file)
        copd_obs = copd_obs.dropna()
        first_day_obs = pd.DataFrame([], columns=copd_obs.columns)
        for patient in copd_obs.patient.unique():
            pt_obs = copd_obs[copd_obs.patient == patient].sort(columns=["abs_bs"])
            first_day_end = pt_obs.iloc[0].abs_bs + timedelta(days=1)
            first_day_obs = first_day_obs.append(pt_obs[pt_obs.abs_bs <= first_day_end])
        first_day_obs.abs_bs = self._convert_abs_bs_to_regular_time(copd_obs.abs_bs)
        first_day_obs.abs_bs.hist(bins=24)
        plt.title("First 24 hours of BS'")
        plt.xlabel("time")
        plt.ylabel("count")
        plt.show()

    def last_24(self):
        copd_obs = pd.read_pickle(self.args.bs_file)
        copd_obs = copd_obs.dropna()
        last_day_obs = pd.DataFrame([], columns=copd_obs.columns)
        for patient in copd_obs.patient.unique():
            pt_obs = copd_obs[copd_obs.patient == patient].sort(columns=["abs_bs"])
            last_day_start = pt_obs.iloc[-1].abs_bs - timedelta(days=1)
            last_day_obs = last_day_obs.append(pt_obs[pt_obs.abs_bs >= last_day_start])
        last_day_obs.abs_bs = self._convert_abs_bs_to_regular_time(copd_obs.abs_bs)
        last_day_obs.abs_bs.hist(bins=24)
        plt.title("Last 24 hours of BS'")
        plt.xlabel("time")
        plt.ylabel("count")
        plt.show()


def main():
    parser = ArgumentParser()
    parser.add_argument("bs_file")
    subparsers = parser.add_subparsers()

    patient_parser = subparsers.add_parser("per_patient")
    patient_parser.add_argument("patient")
    patient_parser.set_defaults(func='analyze_patient')

    all_patient_parser = subparsers.add_parser("cross_time")
    all_patient_parser.set_defaults(func='cross_patient_time_analysis')

    time_by_severity = subparsers.add_parser("cross_time_by_severity")
    time_by_severity.set_defaults(func='cross_patient_time_by_severity')

    volume_hist = subparsers.add_parser("cross_volume_hist")
    volume_hist.set_defaults(func='cross_patient_by_volume')

    volume_by_pbw_hist = subparsers.add_parser("cross_volume_by_pbw_hist")
    volume_by_pbw_hist.add_argument("code_key")
    volume_by_pbw_hist.set_defaults(func='cross_patient_by_volume_pbw')

    first_24 = subparsers.add_parser("first_24")
    first_24.set_defaults(func='first_24')

    last_24 = subparsers.add_parser('last_24')
    last_24.set_defaults(func='last_24')

    args = parser.parse_args()
    analyzer = Analysis(args)
    getattr(analyzer, args.func)()


if __name__ == "__main__":
    main()
