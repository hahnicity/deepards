"""
run_full_cohort_breath_meta
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Run a selection of dirs but only their breath metadata. This currently has default
support for running experimental breath metadata. Also in contrast to the
run_full_cohort.py script this currently only specifies a single patient. If
necessary in the future we can change behavior.
"""
from argparse import ArgumentParser
from glob import glob
import os

from algorithms.breath_meta import get_file_experimental_breath_meta, write_breath_meta


def run_bulk_breath_meta(in_dir, out_dir):
    files = glob(os.path.join(in_dir, "*.csv"))
    for file in files:
        bm = get_file_experimental_breath_meta(file)
        newfile = "{}_breath_meta_experimental.csv".format(os.path.splitext(os.path.basename(file))[0])
        outfile = os.path.join(out_dir, newfile)
        write_breath_meta(bm, outfile)


def main():
    parser = ArgumentParser()
    parser.add_argument("--pt-dir", required=True)
    parser.add_argument("--out-dir", required=True)
    args = parser.parse_args()
    run_bulk_breath_meta(args.pt_dir, args.out_dir)


if __name__ == "__main__":
    main()
