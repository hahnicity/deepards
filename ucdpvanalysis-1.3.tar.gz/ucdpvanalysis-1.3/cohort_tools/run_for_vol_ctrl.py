import argparse
import pandas as pd

from devscripts.run_full_cohort_breath_meta import run_bulk_breath_meta

parser = argparse.ArgumentParser()
parser.add_argument("key")
parser.add_argument("-s", type=int, required=True)
parser.add_argument("-e", type=int, required=True)
args = parser.parse_args()

key = pd.read_csv(args.key)
completed = "breath_meta_completed.list"
copd_patients = key[key.COPD == "1"]["Patient Unique Identifier"]

for pt in copd_patients[args.s:args.e].values:
	with open(completed, "r+a") as com:
		pt_completed = com.readlines()
		if pt in pt_completed:
			continue
		out_dir = "/x1/data/results/{}".format(pt)
		in_dir = "/home/pi/{}".format(pt)
		run_bulk_breath_meta(in_dir, out_dir)
		com.write(pt + "\n")
		com.flush()
