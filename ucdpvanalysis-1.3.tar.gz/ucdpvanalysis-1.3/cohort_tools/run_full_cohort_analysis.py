"""
run_full_cohort_analysis
~~~~~~~~~~~~~~~~~~~~~~~~
"""
from argparse import ArgumentParser

import pandas as pd

import create_cohort
import first_24_48
import lib
import quality_check


def main():
    parser = ArgumentParser()
    parser.add_argument("pvi_file", help="The breath datadump file in CSV format. If you are using the --only-analyze option then this argument should be the processed patient breath file")
    parser.add_argument("mapfile", help="File that maps patient pseudo-id to csn")
    parser.add_argument("cohort", choices=lib.COHORT_CHOICES)
    parser.add_argument("o2_dev_file", help="File linking o2 devices to patients")
    parser.add_argument("--only-analyze", action="store_true", help="if you have already run the cohort post processing then you can skip those steps and just run the analysis.")
    parser.add_argument("--only-qc", action="store_true", help="if you have already run the cohort analysis  then you can skip those steps and just run the quality check.")
    parser.add_argument("--no-eval", action="store_true", help="Do not evaluate the processed data. Useful if you just want to process a data set")
    parser.add_argument("-p", "--output-processed", help="filename you want to store the processed breath file in")
    parser.add_argument('--patient', help='Only analyze a single patient. Good for debugging')
    parser.add_argument('--no-hourly-bins', action='store_false')
    args = parser.parse_args()

    mapping = lib.clean_mapping(pd.read_csv(args.mapfile))
    if (not args.only_analyze and not args.only_qc):
        print("read_raw: {} cohort".format(args.cohort))
        raw = lib.read_raw_fused_file(args.pvi_file)
        if args.cohort == "ards":
            df = create_cohort.ards_func(mapping, raw)
        elif args.cohort == "exa":
            df = create_cohort.exa_func(mapping, raw)
        elif args.cohort == "copd":
            df = create_cohort.copd_func(mapping, raw)
        elif args.cohort == "non_ards":
            df = create_cohort.non_ards_func(mapping, raw)
        print("perform post processing: {} cohort".format(args.cohort))
        df = lib.perform_all_post_processing(df)
        if args.output_processed:
            df.to_csv(args.output_processed, index=False)
    else:
        df = lib.read_processed_file(args.pvi_file)

    if args.patient:
        df = df[df.patient == args.patient]
    sbt = pd.read_csv(args.o2_dev_file)

    if not args.no_eval:
        if not args.only_qc:
            print("perform analysis: {} cohort".format(args.cohort))
            first_24_48.perform_binning_calculations(mapping, df, sbt, args.cohort, args.no_hourly_bins)


if __name__ == "__main__":
    main()
