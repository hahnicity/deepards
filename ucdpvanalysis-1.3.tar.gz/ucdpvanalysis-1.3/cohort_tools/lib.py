"""
lib
~~~

DEPRECATED.

legacy tools for performing cohort analysis tasks. Much of the work in here is
being split into different sub-modules that are more appropriate.
"""
from collections import OrderedDict
import math

import numpy as np
import pandas as pd

COHORT_CHOICES = ["copd", "exa", "other", "ards", "non_ards", "testing"]
SKIP_HOUR = "skip"

PROCESSED_MAPPING = OrderedDict()
PROCESSED_MAPPING["patient"] = "object"
PROCESSED_MAPPING["abs_bs"] = "float16"
PROCESSED_MAPPING["tve"] = "float16"
PROCESSED_MAPPING["tvi"] = "float16"
PROCESSED_MAPPING["tve_tvi_ratio"] = "float16"
PROCESSED_MAPPING["bs_1"] = "int8"
PROCESSED_MAPPING["dbl_2"] = "int8"
PROCESSED_MAPPING["dbl_3"] = "int8"
PROCESSED_MAPPING["dbl_4"] = "int8"
PROCESSED_MAPPING["tvv"] = "int8"
PROCESSED_MAPPING["bs_2"] = "int8"
PROCESSED_MAPPING["bs_1or2"] = "int8"
PROCESSED_MAPPING["last_hour_all"] = "int16"
PROCESSED_MAPPING["bsf_ms"] = "int16"
PROCESSED_MAPPING["bsf_mms"] = "int16"
PROCESSED_MAPPING["dblf"] = "int16"
PROCESSED_MAPPING["bsi_ms"] = "float16"
PROCESSED_MAPPING["bsi_mms"] = "float16"
PROCESSED_MAPPING["asyncf_ms"] = "int16"
PROCESSED_MAPPING["asyncf_mms"] = "int16"
PROCESSED_MAPPING["asynci_ms"] = "float16"
PROCESSED_MAPPING["asynci_mms"] = "float16"
PROCESSED_MAPPING["tvvf_mms"] = "int16"
PROCESSED_MAPPING["tvvf_ms"] = "int16"
PROCESSED_MAPPING["tvvf_s"] = "int16"
PROCESSED_MAPPING["tvvi_mms"] = "float16"
PROCESSED_MAPPING["tvvi_ms"] = "float16"
PROCESSED_MAPPING["tvvi_s"] = "float16"
PROCESSED_MAPPING["breath_time"] = "float16"
PROCESSED_MAPPING["peep"] = "float16"
PROCESSED_MAPPING["maw"] = "float16"
PROCESSED_MAPPING["pip"] = "float16"
PROCESSED_MAPPING["ip_auc"] = "float16"
PROCESSED_MAPPING['n_past_10'] = 'int16'
PROCESSED_MAPPING['bsf_ms_past_10'] = 'int16'
PROCESSED_MAPPING['bsf_mms_past_10'] = 'int16'
PROCESSED_MAPPING['dblf_past_10'] = 'int16'
PROCESSED_MAPPING['tvvf_s_past_10'] = 'int16'
PROCESSED_MAPPING['tvvf_ms_past_10'] = 'int16'
PROCESSED_MAPPING['tvvf_mms_past_10'] = 'int16'
PROCESSED_MAPPING["asyncf_ms_past_10"] = "int16"
PROCESSED_MAPPING["asyncf_mms_past_10"] = "int16"
PROCESSED_COLS = PROCESSED_MAPPING.keys()


def clean_mapping(mapping):
    mapping = mapping.rename(columns={
        "Patient Unique Identifier": "patient",
        "ARDS?": "ards",
        "COPD": "copd",
        "COPD Exacerbation?": "exacerbation",
    })
    mapping.patient = mapping.patient.str[:4]
    mapping = mapping[~mapping['Inpatient CSN'].isnull()]
    return mapping


def clean_o2dev_data(o2dev):
    """
    Post-process TDAP data.
    """
    o2dev.PHASE_START = pd.to_datetime(o2dev.PHASE_START)
    o2dev.PHASE_END = pd.to_datetime(o2dev.PHASE_END)
    # special birds
    birds = ["other (see comments);mechanical ventilator", "CPAP"]
    for bird in birds:
        mv = o2dev[o2dev.O2_DEV_CLEANED == bird]
        o2dev.loc[mv.index, "O2_DEV_CLEANED"] = "ventilator"
    # Handle the other common cases
    o2dev.O2_DEV_CLEANED = o2dev.O2_DEV_CLEANED.str.extract("(?P<pat>[\w \-]+);?")
    inputs_to_consolidate = [
        "mechanical ventilator",
        "trach mist",
        "T- piece",
        "tracheostomy collar",
        "bag valve OETT",
        "bag valve mask",
        "CPAP",
    ]
    for input_ in inputs_to_consolidate:
        mv = o2dev[o2dev.O2_DEV_CLEANED == input_]
        # For now stick to plain ventilator
        o2dev.loc[mv.index, "O2_DEV_CLEANED"] = "ventilator"

    for encounter_id in o2dev.PAT_ENC_CSN_ID.unique():
        o2dev_patient = o2dev[o2dev.PAT_ENC_CSN_ID == encounter_id]
        ventilator = o2dev_patient[o2dev_patient.O2_DEV_CLEANED == "ventilator"]
        if len(ventilator) < 1:
            print("Patient {} has no record of ventilator aparatus".format(encounter_id))
            continue

        to_drop = []
        try:
            keep_iloc = 0
            for i, row in enumerate(ventilator.iterrows()):
                diff = ventilator.iloc[i+1].PHASE_START - row[1].PHASE_END
                if diff <= pd.Timedelta(hours=1):
                    time_end = ventilator.iloc[i+1].PHASE_END
                    to_drop.append(ventilator.iloc[i+1].name)
                    o2dev.loc[ventilator.iloc[keep_iloc].name, "PHASE_END"] = time_end
                else:
                    keep_iloc = i + 1
        except IndexError:
            o2dev = o2dev.drop(to_drop)

    o2dev = o2dev[o2dev.O2_DEV_CLEANED == "ventilator"]
    return o2dev


def cohort_analyses(copd, exa, other):
    def to_percentages(cohort):
        cohort.bsi_ms = cohort.bsi_ms * 100
        cohort.bsi_mms = cohort.bsi_mms * 100
        cohort.asynci_ms = cohort.asynci_ms * 100
        cohort.asynci_mms = cohort.asynci_mms * 100

    def get_cohort_row(cohort, name):
        return [
            name,
            cohort.bsf_ms.mean(),
            cohort.bsf_mms.mean(),
            cohort.bsi_ms.mean(),
            cohort.bsi_mms.mean(),
            cohort.asyncf_ms.mean(),
            cohort.asyncf_mms.mean(),
            cohort.asynci_ms.mean(),
            cohort.asynci_mms.mean(),
        ]

    to_percentages(copd)
    to_percentages(exa)
    to_percentages(other)
    return pd.DataFrame([
        get_cohort_row(exa, "exacerbation"),
        get_cohort_row(copd, "copd only"),
        get_cohort_row(other, "other")
    ], columns=[
        "cohort",
        "bsf_ms",
        "bsf_mms",
        "bsi_ms",
        "bsi_mms",
        "asyncf_ms",
        "asyncf_mms",
        "asynci_ms",
        "asynci_mms",
    ])


def per_patient_analysis(df):
    frame = None
    for patient in df.patient.unique():
        patient_df = df[df.patient == patient]
        if isinstance(frame, type(None)):
            frame = pd.DataFrame([[
                patient,
                len(patient_df),
                patient_df.bsf_ms.mean(),
                patient_df.bsf_mms.mean(),
                patient_df.bsi_ms.mean(),
                patient_df.bsi_mms.mean(),
                patient_df.asyncf_ms.mean(),
                patient_df.asyncf_mms.mean(),
                patient_df.asynci_ms.mean(),
                patient_df.asynci_mms.mean(),
            ]])
        else:
            frame = frame.append([[
                patient,
                len(patient_df),
                patient_df.bsf_ms.mean(),
                patient_df.bsf_mms.mean(),
                patient_df.bsi_ms.mean(),
                patient_df.bsi_mms.mean(),
                patient_df.asyncf_ms.mean(),
                patient_df.asyncf_mms.mean(),
                patient_df.asynci_ms.mean(),
                patient_df.asynci_mms.mean(),
            ]])
    frame.columns = [
        "patient", "n_obs",
        "bsf_ms", "bsf_mms",
        "bsi_ms", "bsi_mms",
        "asyncf_ms", "asyncf_mms",
        "asynci_ms", "asynci_mms"
    ]
    frame.index = range(0, len(frame))
    return frame


def read_raw_fused_file(filename):
    mapping = {
        0: ("object", "patient"),
        1: ("float16", "abs_bs"),
        2: ("float16", "tve"),
        3: ("float16", "tvi"),
        4: ("float16", "tve_tvi_ratio"),
        5: ("float16", "e_time"),
        6: ("float16", "i_time"),
        7: ("float16", "peep"),
        8: ("float16", "maw"),
        9: ("float16", "pip"),
        10: ("float16", "ip_auc"),
        11: ("int8", "bs_1"),
        12: ("int8", "dbl_2"),
        13: ("int8", "dbl_3"),
        14: ("int8", "dbl_4"),
        15: ("int8", "tvv"),
    }
    df = pd.read_csv(
        filename,
        dtype={k: v[0] for k, v in mapping.items()},
        header=None,
        parse_dates=[1]
    )
    return df.rename(columns={k: v[1] for k, v in mapping.items()})


def read_processed_file(filename):
    processed = pd.read_csv(filename, dtype=PROCESSED_MAPPING, parse_dates=[1])
    processed.patient = processed.patient.str[:4]
    processed.sort_values(by=["patient", "abs_bs"], inplace=True)
    processed.index = pd.MultiIndex.from_tuples(zip(processed.patient, processed.index))
    return processed


def compute_patient_hour_idxs(patient_df, vent_phases):
    """
    Precompute idx's for specific hour locations on a patient so
    we can do quick slicing on a patient

    For the DF we have hours we may have no data for. So we denote them
    as 'skip'

    Returns a dictionary of data in the form

    {
        "vent_phase_hours": [
            (0, 1, 2, 3, 4, 5, 6),
            (6, 7, 8, 9, ...),
            ...
        ],
        "vent_phase_idxs": [
            (0, 10000),
            (10001, 20000),
            ...
        ],
        "hour_start_end": {
            0: (<time start>, <time end>),
            1: (<time start>, <time end>),
            ...
        },
        "hour_idxs": {
            0: (0, 1000)
            1: (1001, 2000),
            ...
        }
    }

    :param patient_df: The df of specific patient data we wish to analyze
    :param vent_phases: The df of vent phases for the specific patient
    """
    def get_slice_indexes(slice):
        low_idx = slice.iloc[0].name
        high_idx = slice.iloc[-1].name
        if isinstance(low_idx, tuple):
            low_idx = low_idx[-1]
        if isinstance(high_idx, tuple):
            high_idx = high_idx[-1]
        return low_idx, high_idx

    vent_phases = vent_phases[vent_phases.O2_DEV_CLEANED == 'ventilator']
    patient_hour_locs = {
        "vent_phase_hours": [],
        "vent_phase_idxs": [],
        "hour_start_end": {},
        "hour_idxs": {}
    }
    if len(vent_phases) == 0:
        return patient_hour_locs

    abs_hour = 0
    for _, phase in vent_phases.iterrows():
        vent_start = phase.PHASE_START
        vent_end = phase.PHASE_END
        phase_range = patient_df[(patient_df.abs_bs >= vent_start) & (patient_df.abs_bs <= vent_end)]
        if len(phase_range) == 0:
            patient_hour_locs["vent_phase_idxs"].append((SKIP_HOUR, SKIP_HOUR))
            continue
        patient_hour_locs['vent_phase_idxs'].append(get_slice_indexes(phase_range))

    # Now compute hour idxs. The deal about this is that we want our hour idxs to
    # be agnostic to vent phases. But we also want to be aware if the patient
    # is disconnected from the vent for some period of time. So if a new vent
    # phase overlaps with an hour then we don't want to cut off the hour
    # prematurely
    phase_idx = 0
    hour_offset = 0
    first_phase = vent_phases.iloc[phase_idx]
    vent_start = first_phase.PHASE_START
    vent_end = first_phase.PHASE_END
    phase_hours = [[] for _ in range(len(vent_phases))]

    # XXX you'd like something a little more intelligent than 60 * 24
    for hour in range(60 * 24):
        bin_start = vent_start + pd.Timedelta(hours=hour-hour_offset)
        bin_end = vent_start + pd.Timedelta(hours=hour+1-hour_offset)

        if bin_start >= vent_end:
            try:  # look out for corner case that we hit end vent phase exactly
                phase_idx += 1
                hour_offset = hour + 1
                next_phase = vent_phases.iloc[phase_idx]
                vent_start = next_phase.PHASE_START
                vent_end = next_phase.PHASE_END
                if not next_phase.PHASE_START <= bin_start <= next_phase.PHASE_END:
                    continue
            except IndexError:  # there is no next phase
                break

        phase_hours[phase_idx].append(hour)

        if bin_end > vent_end:
            try:
                phase_idx += 1
                hour_offset = hour + 1
                next_phase = vent_phases.iloc[phase_idx]
                vent_start = next_phase.PHASE_START
                vent_end = next_phase.PHASE_END
                if not next_phase.PHASE_START <= bin_end <= next_phase.PHASE_END:
                    bin_end = vent_end
                else:  # the new phase shares an hour with the old one
                    phase_hours[phase_idx].append(hour)
            except IndexError:  # if there is no next phase
                bin_end = vent_end

        patient_hour_locs['hour_start_end'][hour] = (bin_start, bin_end)
        slice = patient_df[
            (patient_df.abs_bs < bin_end) &
            (patient_df.abs_bs >= bin_start)
        ]
        if len(slice) == 0:
            patient_hour_locs["hour_idxs"][hour] = (SKIP_HOUR, SKIP_HOUR)
        else:
            patient_hour_locs["hour_idxs"][hour] = get_slice_indexes(slice)

    patient_hour_locs['vent_phase_hours'] = phase_hours
    return patient_hour_locs


def get_patient_vent_phases(mapping, patient, vent_phases):
    """
    Returns the vent phases for a specific patient. Returns None if there
    were no vent phases for whatever reason.
    """
    mapped = mapping[mapping.patient == patient]
    if len(mapped) > 0 and len(mapped['Inpatient CSN'].unique()) == 1:
        encounter_id = mapping[mapping.patient == patient].iloc[0]['Inpatient CSN']
        pt_phases = vent_phases[vent_phases.PAT_ENC_CSN_ID == int(encounter_id)]
        if len(pt_phases) > 0:
            return pt_phases


def perform_patient_hour_mapping(processed, mapping, vent_phases):
    patients = processed.patient.unique()
    patient_hour_locs = {}
    for patient in patients:
        pt_phases = get_patient_vent_phases(mapping, patient, vent_phases)
        if len(pt_phases) == 0:
            continue
        patient_df = processed.loc[patient]
        patient_hour_locs[patient] = compute_patient_hour_idxs(patient_df, pt_phases)
    return patient_hour_locs


def create_bs2(df):
    bs_2 = pd.Series([0] * len(df), index=df.index, dtype=np.int8)
    is_2 = df[df["bs_1"] == 0]
    severity_3 = is_2[is_2.tve_tvi_ratio < .33]
    severity_2 = is_2[(is_2.tve_tvi_ratio < .66) & (is_2.tve_tvi_ratio >= .33)]
    severity_1 = is_2[(is_2.tve_tvi_ratio >= .66) & (is_2.tve_tvi_ratio < .9)]
    bs_2.loc[severity_3.index] = 3
    bs_2.loc[severity_2.index] = 2
    bs_2.loc[severity_1.index] = 1
    df['bs_2'] = bs_2
    df['bs_1or2'] = (df.bs_1 | df.bs_2).astype(np.int8)
    return df


# This function is testament to the fact that pandas is slowww when using apply.
# Better to go with cython or just iterate manually.
def find_number_breaths_in_delta(df, td):
    if not isinstance(td, pd.Timedelta):
        raise ValueError("td must be an instance of pandas.Timedelta!")
    result = []
    for patient in df.patient.unique():
        patient_frame = df[df.patient == patient].values
        idx_last = 0
        cur_count = 0
        for idx_cur, row in enumerate(patient_frame):
            cur_count += 1
            for i in range(idx_last, idx_cur):
                if row[1] - td <= patient_frame[i][1] <= row[1]:
                    result.append(cur_count)
                    break
                cur_count -= 1
                idx_last += 1
            else:
                result.append(cur_count)
    return np.array(result).astype(np.int16)


def timedelta_pva_func(df, type_, severity_condition, timedelta_col):
    """
    Determine number of pva events within the past time window

    :param df: DataFrame with breath information
    :param type_: The type of pva we wish to analyze
    :param severity_condition: severity of the pva
    :param timedelta_col: name of the column that records number of breaths in past <timedelta>
    """
    result = []
    td = pd.Timedelta(hours=1)
    cols = list(df.columns)
    type_idx = {
        "dbl": cols.index("dbl_4"),
        "bs": cols.index("bs_1or2"),
        "tvv": cols.index("tvv")
    }[type_]
    # last_hour_all_index = lhai
    lhai = cols.index(timedelta_col)
    condition = {"dbl": 0, "bs": severity_condition, "tvv": severity_condition}[type_]
    for patient in df.patient.unique():
        patient_frame = df[df.patient == patient].values
        cur_count = 0
        for idx_cur, row in enumerate(patient_frame):
            if row[type_idx] > condition:
                cur_count += 1
            # the AND condition is present so we don't loop around to the back of array
            if row[lhai] <= patient_frame[idx_cur - 1][lhai] and idx_cur - 1 > 0:
                diff = patient_frame[idx_cur - 1][lhai] - row[lhai]
                for i in range(idx_cur - row[lhai] - diff, idx_cur - row[lhai] + 1):
                    if patient_frame[i][type_idx] > condition:
                        cur_count -= 1
            result.append(cur_count)
    return np.array(result).astype(np.int16)


def perform_all_post_processing(df):
    """
    Determine the number of breaths in the last hour and then derive other
    last hour stats from that
    """
    df = create_bs2(df)
    df = df.sort_values(by=['patient', 'abs_bs'])
    df = df[np.logical_not(df.abs_bs.isnull())]
    time_cols = [('n_past_10', '_past_10', pd.Timedelta(minutes=10)), ('last_hour_all', '', pd.Timedelta(hours=1))]
    for col_name, col_suffix, delta in time_cols:
        df[col_name] = find_number_breaths_in_delta(df, delta)
        df['bsf_ms{}'.format(col_suffix)] = timedelta_pva_func(df, "bs", 1, col_name)
        df['bsf_mms{}'.format(col_suffix)] = timedelta_pva_func(df, "bs", 0, col_name)
        df['dblf{}'.format(col_suffix)] = timedelta_pva_func(df, "dbl", None, col_name)
        df['tvvf_mms{}'.format(col_suffix)] = timedelta_pva_func(df, "tvv", 0, col_name)
        df['tvvf_ms{}'.format(col_suffix)] = timedelta_pva_func(df, "tvv", 1, col_name)
        df['tvvf_s{}'.format(col_suffix)] = timedelta_pva_func(df, "tvv", 2, col_name)
        df['asyncf_ms{}'.format(col_suffix)] = (df['bsf_ms{}'.format(col_suffix)] + df['dblf{}'.format(col_suffix)]).astype(np.int16)
        df['asyncf_mms{}'.format(col_suffix)] = (df['bsf_mms{}'.format(col_suffix)] + df['dblf{}'.format(col_suffix)]).astype(np.int16)

    df['bsi_ms'] = (df['bsf_ms'] / df['last_hour_all']).astype(np.float16)
    df['bsi_mms'] = (df['bsf_mms'] / df['last_hour_all']).astype(np.float16)
    df['asynci_ms'] = (df['asyncf_ms'] / df['last_hour_all']).astype(np.float16)
    df['asynci_mms'] = (df['asyncf_mms'] / df['last_hour_all']).astype(np.float16)
    df['tvvi_mms'] = (df['tvvf_mms'] / df['last_hour_all']).astype(np.float16)
    df['tvvi_ms'] = (df['tvvf_ms'] / df['last_hour_all']).astype(np.float16)
    df['tvvi_s'] = (df['tvvf_s'] / df['last_hour_all']).astype(np.float16)
    df['breath_time'] = (df['e_time'] + df['i_time']).astype(np.float16)
    return df[PROCESSED_MAPPING.keys()]
