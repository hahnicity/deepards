from argparse import ArgumentParser

import numpy as np
import pandas as pd

import lib


def check_for_wrong_csn(processed, vent_phases, mapping):
    """
    First, check if the subject's csn actually has ventilator phase on it

    Second pass, check for blatantly wrong csn.

    Third pass, check if chunks of data exist outside vent
    """
    all_good = []
    no_data = []
    no_vent_phase = []
    blatantly_bad = []
    partial_data_in_window = []
    two_patients_same_prefix = []
    for patient in mapping.patient.unique():
        try:
            patient_csn = float(mapping[mapping.patient == patient]['Inpatient CSN'])
        except TypeError:
            two_patients_same_prefix.append(patient)
            continue
        patient_phases = vent_phases[vent_phases.PAT_ENC_CSN_ID == patient_csn]
        try:
            patient_df = processed.loc[patient]
        except KeyError:
            no_data.append(patient)
            continue
        if len(patient_df) == 0:
            no_data.append(patient)
            continue
        # check if there is actually a vent phase
        if len(patient_phases) == 0:
            no_vent_phase.append(patient)
            continue

        total_items_covered = 0
        for i, phase in patient_phases.iterrows():
            in_phase_data = patient_df[
                (patient_df.abs_bs >= phase.PHASE_START) &
                (patient_df.abs_bs <= phase.PHASE_END)
            ]
            total_items_covered += len(in_phase_data)

        # check if the csn is blatantly bad, as in there is no data in the phases
        if total_items_covered == 0:
            blatantly_bad.append(patient)
        # then check if there is data in processed df that is not covered in some
        # vent phase
        #
        # Is 95% too high? should it be 90% or something? Should it be a percentage
        # or should it be an absolute value of hours outside of window?
        elif total_items_covered / float(len(patient_df)) < .95:
            partial_data_in_window.append(patient)
        else:
            all_good.append(patient)

    return all_good, no_data, no_vent_phase, blatantly_bad, partial_data_in_window, two_patients_same_prefix


def find_hourly_coverage(processed, hour_idxs):
    """
    Find the number of seconds of coverage for a patient in each hourly bin they
    were connected to the ventilator.

    :param processed: The processed data for patients
    :param hour_idxs: Dictionary of vent phase hours to index of where each hour's data is in the processed data frame.
    """
    # Should probably operate on subset of patients we know to be worth
    # the analysis

    all_coverage = {}
    for patient in hour_idxs:
        patient_coverages = {"seconds_covered": {}, "frac_coverage": {}, "seconds_available": {}}
        try:
            patient_idxs = hour_idxs[patient]['hour_idxs']
            patient_hour_start_end = hour_idxs[patient]['hour_start_end']
        except KeyError:
            continue
        try:
            pt_df = processed[processed.patient == patient]
        except KeyError:
            continue
        if len(pt_df) == 0:
            continue
        for i in sorted(patient_idxs.keys()):
            hour_start = patient_hour_start_end[i][0]
            hour_end = patient_hour_start_end[i][1]
            time_covered = (hour_end - hour_start).total_seconds()
            time_available = time_covered
            low_idx, high_idx = patient_idxs[i]

            if low_idx == lib.SKIP_HOUR:
                patient_coverages['seconds_covered'][i] = 0
                patient_coverages['frac_coverage'][i] = 0
                patient_coverages['seconds_available'][i] = time_available
                continue

            data_slice = pt_df.loc[low_idx:high_idx]

            # subtract start gap from how much time the bin covers
            time_covered -= (data_slice.iloc[0].abs_bs - hour_start).seconds

            # subtract off intermediary diffs
            diff = data_slice.abs_bs - (data_slice.abs_bs + pd.to_timedelta(data_slice.breath_time, unit='s')).shift(1)
            significant_diffs = diff[diff > pd.Timedelta(seconds=1)]
            time_covered -= significant_diffs.sum().seconds

            # subtract end gap
            final_gap = (hour_end - (data_slice.iloc[-1].abs_bs + pd.to_timedelta(data_slice.iloc[-1].breath_time, unit='s')))
            if final_gap > pd.Timedelta(seconds=0):
                time_covered -= final_gap.seconds

            patient_coverages['seconds_covered'][i] = time_covered
            patient_coverages['frac_coverage'][i] = float(time_covered) / time_available
            patient_coverages['seconds_available'][i] = time_available
        all_coverage[patient] = patient_coverages

    return all_coverage
