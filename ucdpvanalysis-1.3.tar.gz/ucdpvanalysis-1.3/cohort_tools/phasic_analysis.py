"""
phasic_analysis
~~~~~~~~~~~~~~~

If we ever need to analyze information for specific patient vent phases then we
can supply that information in a separate phase information file

patient_id,PHASE_START,PHASE_END,patient_state,phase_type,O2_DEV_CLEANED,PAT_ENC_CSN_ID
227, 01:01:10 01/01/2018, 10:00:00 01/02/2018, paralyzed, pre-clinical-trial, ventilator,XXX
...

Note: the incongruity in header var names is due to legacy TDAP constraints.

This python file will supply analytics to assist final output of phasic analysis.
Currently it only supports
"""
import pandas as pd

from cohort_tools.constants import SKIP_HOUR
from cohort_tools.non_phasic_analysis import get_slice_indexes

# XXX
# XXX
# XXX need a find_asyncs_by_indexed_hour method!! Need to do this when you redo
# XXX the ROSE analysis


def compute_patient_hour_idxs(patient_df, vent_phases):
    """
    Precompute phasic idx's for specific hour locations on a patient so
    we can do quick slicing on a patient

    For the DF we have hours we may have no data for. So we denote them
    as 'skip'

    Returns a dictionary of data in the form

    {
        "vent_phase_hours": [
            (0, 1, 2, 3, 4, 5, 6),
            (6, 7, 8, 9, ...),
            ...
        ],
        "vent_phase_idxs": [
            (0, 10000),
            (10001, 20000),
            ...
        ],
        "hour_start_end": {
            0: (<time start>, <time end>),
            1: (<time start>, <time end>),
            ...
        },
        "hour_idxs": {
            0: (0, 1000)
            1: (1001, 2000),
            ...
        }
    }

    :param patient_df: The df of specific patient data we wish to analyze
    :param vent_phases: The df of TDAP vent phases for the specific patient
    """
    vent_phases = vent_phases[vent_phases.O2_DEV_CLEANED == 'ventilator']
    patient_hour_locs = {
        "vent_phase_hours": [],
        "vent_phase_idxs": [],
        "hour_start_end": {},
        "hour_idxs": {}
    }
    if len(vent_phases) == 0:
        return patient_hour_locs

    abs_hour = 0
    for _, phase in vent_phases.iterrows():
        vent_start = phase.PHASE_START
        vent_end = phase.PHASE_END
        phase_range = patient_df[(patient_df.abs_bs >= vent_start) & (patient_df.abs_bs <= vent_end)]
        if len(phase_range) == 0:
            patient_hour_locs["vent_phase_idxs"].append((SKIP_HOUR, SKIP_HOUR))
            continue
        patient_hour_locs['vent_phase_idxs'].append(get_slice_indexes(phase_range))

    # Now compute hour idxs. The deal about this is that we want our hour idxs to
    # be agnostic to vent phases. But we also want to be aware if the patient
    # is disconnected from the vent for some period of time. So if a new vent
    # phase overlaps with an hour then we don't want to cut off the hour
    # prematurely
    phase_idx = 0
    hour_offset = 0
    first_phase = vent_phases.iloc[phase_idx]
    vent_start = first_phase.PHASE_START
    vent_end = first_phase.PHASE_END
    phase_hours = [[] for _ in range(len(vent_phases))]

    # XXX you'd like something a little more intelligent than 60 * 24
    for hour in range(60 * 24):
        bin_start = vent_start + pd.Timedelta(hours=hour-hour_offset)
        bin_end = vent_start + pd.Timedelta(hours=hour+1-hour_offset)

        if bin_start >= vent_end:
            try:  # look out for corner case that we hit end vent phase exactly
                phase_idx += 1
                hour_offset = hour + 1
                next_phase = vent_phases.iloc[phase_idx]
                vent_start = next_phase.PHASE_START
                vent_end = next_phase.PHASE_END
                if not next_phase.PHASE_START <= bin_start <= next_phase.PHASE_END:
                    continue
            except IndexError:  # there is no next phase
                break

        phase_hours[phase_idx].append(hour)

        if bin_end > vent_end:
            try:
                phase_idx += 1
                hour_offset = hour + 1
                next_phase = vent_phases.iloc[phase_idx]
                vent_start = next_phase.PHASE_START
                vent_end = next_phase.PHASE_END
                if not next_phase.PHASE_START <= bin_end <= next_phase.PHASE_END:
                    bin_end = vent_end
                else:  # the new phase shares an hour with the old one
                    phase_hours[phase_idx].append(hour)
            except IndexError:  # if there is no next phase
                bin_end = vent_end

        patient_hour_locs['hour_start_end'][hour] = (bin_start, bin_end)
        slice = patient_df[
            (patient_df.abs_bs < bin_end) &
            (patient_df.abs_bs >= bin_start)
        ]
        if len(slice) == 0:
            patient_hour_locs["hour_idxs"][hour] = (SKIP_HOUR, SKIP_HOUR)
        else:
            patient_hour_locs["hour_idxs"][hour] = get_slice_indexes(slice)

    patient_hour_locs['vent_phase_hours'] = phase_hours
    return patient_hour_locs


def get_patient_vent_phases(mapping, patient, vent_phases):
    """
    Returns the vent phases for a specific patient. Returns None if there
    were no vent phases for whatever reason.
    """
    mapped = mapping[mapping.patient == patient]
    if len(mapped) > 0 and len(mapped['Inpatient CSN'].unique()) == 1:
        encounter_id = mapping[mapping.patient == patient].iloc[0]['Inpatient CSN']
        pt_phases = vent_phases[vent_phases.PAT_ENC_CSN_ID == int(encounter_id)]
        if len(pt_phases) > 0:
            return pt_phases


def perform_patient_hour_mapping(processed, mapping, vent_phases):
    patients = processed.patient.unique()
    patient_hour_locs = {}
    for patient in patients:
        pt_phases = get_patient_vent_phases(mapping, patient, vent_phases)
        if len(pt_phases) == 0:
            continue
        patient_df = processed.loc[patient]
        patient_hour_locs[patient] = compute_patient_hour_idxs(patient_df, pt_phases)
    return patient_hour_locs
