"""
full_cohort_quality_check
~~~~~~~~~~~~~~~~~~~~~~~~~

Run a quality check on the entire cohort. This requires specifying a CSV file of patients
with their start and end times like so:

patient, vent_start, vent_end, mphase_start, mphase_end
0001RPI, 2018-01-01 01:30:00, 2018-01-10 10:12:00, 2018-01-01 01:30:00, 2018-01-10 10:12:00
0002RPI, ...
...

The script will then run through all data we have collected for a patient and index their
start/end times for their breaths. It will then send these results to analysis scripts that
we have created. Patients with data outside a tolerable range of vent start/end will be
noted and sent to a file.
"""
import argparse
import csv
from glob import glob
import multiprocessing
import os
from warnings import warn

import numpy as np
import pandas as pd
from ventmap.raw_utils import extract_raw

from non_phasic_analysis import find_extended_data_out_of_bounds


def collect_data(patient_id, data_dir, intermediate_results_dir, warn_file, no_intermediates):
    files = glob(os.path.join(data_dir, patient_id, "*.csv"))
    cols = ['patient', 'vent_bn', 'abs_bs', 'breath_time']
    if len(files) == 0:
        if os.path.exists(warn_file):
            file_mode = 'a'
        else:
            file_mode = 'w'
        with open(warn_file, file_mode) as f:
            f.write(patient_id + '\n')
        warn('Could not find any data for patient: {}'.format(patient_id))
        return pd.DataFrame([], columns=cols)

    intermediate_file = os.path.join(intermediate_results_dir, patient_id) + '.pkl'
    if os.path.exists(intermediate_file) and not no_intermediates:
        results = pd.read_pickle(intermediate_file)
        # For some reason the datetimes come in different formats. Some are in format of
        # %H:%M:%S and others in %H-%M-%S
        try:
            results['abs_bs'] = pd.to_datetime(results.abs_bs)
        except:
            results['abs_bs'] = pd.to_datetime(results.abs_bs, format='%Y-%m-%d %H-%M-%S.%f')
        return results

    print('Analyze breaths for patient {}'.format(patient_id))
    breaths = []
    for file in files:
        generator = extract_raw(open(file, 'rU'), False)
        for breath in generator:
            if len(breath['ts']) == 0:
                continue
            breaths.append([patient_id, breath['vent_bn'], breath['ts'][0], breath['frame_dur']])
    results = pd.DataFrame(breaths, columns=cols)
    try:
        results['abs_bs'] = pd.to_datetime(results.abs_bs)
    except:
        results['abs_bs'] = pd.to_datetime(results.abs_bs, format='%Y-%m-%d %H-%M-%S.%f')
    results.to_pickle(intermediate_file)
    return results


def func_star(args):
    return collect_data(*args)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('vent_phases', help='CSV file with vent phase information like vent start and vent end')
    parser.add_argument('--data-dir', help="Directory where we keep all patient data")
    parser.add_argument('-tol', '--data-tolerance', type=int, default=1000)
    parser.add_argument('-i', '--intermediate-results-dir', default='tmp_cohort_results')
    parser.add_argument('-t', '--threads', type=int, default=multiprocessing.cpu_count())
    parser.add_argument('--debug', action='store_true', help='Only run with one thread. That way if a thread dies the stacktrace will be clear')
    parser.add_argument('-wf', '--warn-file', default='no_data_found_warnings.txt')
    parser.add_argument('--to-pickle')
    parser.add_argument('-p', '--from-pickle')
    parser.add_argument('--only-patient', help='only analyze certain patient')
    parser.add_argument('--no-intermediates', help='do not use intermediates for analysis. Redo all processing', action='store_true')
    args = parser.parse_args()

    phases = pd.read_csv(args.vent_phases)
    phases_new = phases.copy()
    # sanity check to ensure everything is datetimed
    col = ['vent_start', 'vent_end', 'mphase_start', 'mphase_end']
    for c in col:
        phases[c] = pd.to_datetime(phases[c])

    if not args.from_pickle and not args.data_dir:
        raise Exception('Must input either a data directory to read from or a pickle file!')

    if not args.from_pickle:
        if not os.path.exists(args.intermediate_results_dir):
            os.mkdir(args.intermediate_results_dir)

        print('Analyze all breaths for patients')
        all_runs = [(patient_id, args.data_dir, args.intermediate_results_dir, args.warn_file, args.no_intermediates) for patient_id in phases.patient[~phases.patient.isnull()]]
        if args.only_patient:
            all_runs = filter(lambda x: x[0] == args.only_patient, all_runs)
        if not args.debug:
            pool = multiprocessing.Pool(args.threads)
            results = pool.map(func_star, all_runs)
            pool.close()
            pool.join()
        else:
            results = [collect_data(*args) for args in all_runs]
        if len(results) == 0:
            raise Exception('No results found!')
        processed = pd.concat(results)
        processed = processed.sort_values(by=['patient', 'abs_bs'])
        if args.to_pickle:
            processed.to_pickled(args.to_pickle)
    else:
        processed = pd.read_pickle(args.from_pickle)

    patient_id_array = processed.patient.values
    idxs = range(len(patient_id_array))
    new_index = pd.MultiIndex.from_tuples(list(zip(*[patient_id_array, idxs])), names=['patient_ids', 'row_idx'])
    processed.index = new_index

    patients_above_tolerances = []
    data_with_vwd_start_end = []
    mapping = {}
    print('Analyze for out of bounds observations')
    for patient in sorted(processed.patient.unique()):
        print('Analyze patient {} for out of bounds observations'.format(patient))
        phases_rows = phases[phases.patient == patient]
        if len(phases_rows) == 0:
            continue
        phases_row = phases_rows.iloc[0]
        vent_start = phases_row.vent_start
        vent_end = phases_row.vent_end
        patient_df = processed.loc[patient]
        mapping[patient] = find_extended_data_out_of_bounds(patient_df, phases_row)
        if mapping[patient]['len_after_end'] >= args.data_tolerance or mapping[patient]['len_before_start'] >= args.data_tolerance:
            patients_above_tolerances.append([
                patient,
                vent_start,
                mapping[patient]['len_before_start'],
                vent_end,
                mapping[patient]['len_after_end'],
                len(patient_df[(patient_df.abs_bs >= vent_start) & (patient_df.abs_bs <= vent_end)]),
                phases_row.mphase_start,
                mapping[patient]['len_before_first_meta'],
                phases_row.mphase_end,
                mapping[patient]['len_after_first_meta'],
                len(patient_df[(patient_df.abs_bs >= phases_row.mphase_start) & (patient_df.abs_bs <= phases_row.mphase_end)]),
                patient_df.iloc[0].abs_bs.strftime('%Y-%m-%d %H:%M:%S'),
                patient_df.iloc[-1].abs_bs.strftime('%Y-%m-%d %H:%M:%S'),
            ])
        phases_new.loc[phases_new.patient == patient, 'vwd_start'] = patient_df.iloc[0].abs_bs.strftime('%Y-%m-%d %H:%M:%S')
        phases_new.loc[phases_new.patient == patient, 'vwd_end'] = patient_df.iloc[-1].abs_bs.strftime('%Y-%m-%d %H:%M:%S'),

    with open('tolerance_violations.csv', 'w') as out:
        writer = csv.writer(out)
        writer.writerow(['patient_id', 'vent_start', 'breaths_before_vent_start', 'vent_end', 'breaths_after_vent_end', 'len_in_intubation_time', 'mphase_start', 'len_before_first_meta', 'mphase_end', 'len_after_first_meta', 'len_in_first_meta', 'vwd_start', 'vwd_end'])
        for row in patients_above_tolerances:
            writer.writerow(row)

    vent_phases_with_vwd_start_end = os.path.splitext(os.path.basename(args.vent_phases))[0] + '-with-vwd-start-end.csv'
    phases_new.to_csv(vent_phases_with_vwd_start_end, index=False)


if __name__ == "__main__":
    main()
